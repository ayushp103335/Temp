# Chapter number · A concrete engineering decision

Open with a user-visible problem and the observable capability the reader should gain. Specify required prior knowledge, tool versions, starting directory and any environment that incurs costs.

## Understand the mechanism

Define the terms that the example depends on. Follow one operation through its components and identify the state, identity and failure boundary at each step. Use a diagram when it resolves a real ambiguity. Compare architecture options through the workload's constraints.

## Operate the example

Include or link the actual source and configuration. Explain important fields. Provide a clean setup, a sequence of explained commands, expected observations, an intentional failure, recovery and scoped teardown. Make synthetic fixtures and permissions explicit.

## Review the decision

Explain a common operational mistake and how evidence distinguishes it from another cause. Cover access, data sensitivity, reliability and cost when they affect the decision. Give a practice assignment, a worked interview question, a follow-up and primary references.

## Editorial acceptance

Verify relative links, diagram rendering, source paths and version-dependent claims. Record the exact checks actually run in PROGRESS.md and distinguish rendering or unit tests from a live deployment. Update the canonical summary, curriculum, lab manifest and part assessments when scope changes.
