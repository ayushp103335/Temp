"""Validate handbook structure using only the Python standard library."""
from collections import Counter
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit

root = Path(__file__).resolve().parents[1]
src = root / "src"
summary = (src / "SUMMARY.md").read_text()
links = re.findall(r"\[[^\]]+\]\(([^)]+\.md)\)", summary)
pages = {p.relative_to(src).as_posix() for p in src.rglob("*.md") if p.name != "SUMMARY.md"}
errors = []
if set(links) != pages:
    errors.append(f"Summary mismatch: {sorted(set(links) ^ pages)}")
for link, count in Counter(links).items():
    if count != 1:
        errors.append(f"Summary repeats {link}")
chapters = sorted(src.glob("part-*/*[0-9]-*.md"))
numbers = sorted(int(p.name[:2]) for p in chapters)
if numbers != list(range(1, 59)):
    errors.append(f"Numbered curriculum mismatch: {numbers}")
for chapter in chapters:
    body = chapter.read_text()
    if "### Further reading" not in body or "https://" not in body:
        errors.append(f"No references: {chapter.name}")
for item in sorted(pages):
    path = src / item
    opened = False
    prose = []
    for n, line in enumerate(path.read_text().splitlines(), 1):
        if line.startswith("```"):
            if not opened and not line[3:].strip():
                errors.append(f"Missing code language: {item}:{n}")
            opened = not opened
        elif not opened:
            prose.append(line)
    if opened:
        errors.append(f"Unclosed code fence: {item}")
    for target in re.findall(r"!?\[[^\]]*\]\(([^) ]+)\)", "\n".join(prose)):
        url = urlsplit(target)
        if url.scheme or not url.path:
            continue
        resolved = (path.parent / unquote(url.path)).resolve()
        if not resolved.is_relative_to(src) or not resolved.is_file():
            errors.append(f"Missing or out-of-tree link: {item} -> {target}")
if errors:
    sys.exit("\n".join(errors))
print(f"Validated {len(chapters)} numbered chapters, {len(links)} linked pages, local targets and code fences.")
