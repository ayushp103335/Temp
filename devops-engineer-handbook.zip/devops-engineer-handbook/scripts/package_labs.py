"""Package the checked-in learning materials only; never walk local runtime state."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
manifest = (root / "scripts/lab-files.txt").read_text().splitlines()
out = root / "src/downloads/handbook-labs.zip"
out.parent.mkdir(exist_ok=True)
with ZipFile(out, "w", compression=ZIP_DEFLATED, compresslevel=8) as archive:
    for name in manifest:
        path = (root / name).resolve()
        if not path.is_relative_to(root / "labs") or not path.is_file() or "secrets" in path.parts:
            raise ValueError(f"Invalid lab source: {name}")
        archive.write(path, name)
print(f"Packed {len(manifest)} lab source files.")
