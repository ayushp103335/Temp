#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
exec mdbook serve --hostname 127.0.0.1 --port "${PORT:-3000}"
