#!/usr/bin/env bash
# Run from a GNU/Linux machine with Bash, Python 3 and GNU utilities.
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d)
trap 'rm -rf -- "$work"' EXIT
export PYTHONDONTWRITEBYTECODE=1
python3 -m unittest discover -s labs/release -p 'test_*.py' -v
mkdir -p "$work/source" "$work/backup" "$work/restore" "$work/logs"
cp labs/release/jobs.json "$work/source/jobs.json"
archive=$(bash labs/linux/backup.sh "$work/source" "$work/backup")
(cd "$archive" && sha256sum --check SHA256SUMS)
tar -xzf "$archive/data.tar.gz" -C "$work/restore"
cmp "$work/source/jobs.json" "$work/restore/jobs.json"
if bash labs/linux/backup.sh "$work/source" "$work/source"; then
    echo 'Overlapping backup unexpectedly accepted' >&2; exit 1
fi
touch "$work/logs/.handbook-logs" "$work/logs/demo-keep.log"
touch -d '9 days ago' "$work/logs/demo-old.log"
bash labs/linux/cleanup.sh "$work/logs" | grep -F 'demo-old.log'
bash labs/linux/cleanup.sh "$work/logs" --apply
test ! -e "$work/logs/demo-old.log"
test -e "$work/logs/demo-keep.log"
bash labs/linux/health.sh "$work"
bash labs/release/promote.sh labs/release/service.py "$work/releases"
baseline=$(readlink "$work/releases/current")
cp labs/release/service.py "$work/edit.py"
echo '# second candidate' >> "$work/edit.py"
bash labs/release/promote.sh "$work/edit.py" "$work/releases"
test "$(readlink "$work/releases/current")" != "$baseline"
sed -i 's/"queued": 0/"waiting": 0/' "$work/edit.py"
candidate=$(readlink "$work/releases/current")
if bash labs/release/promote.sh "$work/edit.py" "$work/releases"; then exit 1; fi
test "$(readlink "$work/releases/current")" = "$candidate"
ln -s "$baseline" "$work/releases/rollback"
mv -Tf "$work/releases/rollback" "$work/releases/current"
python3 "$work/releases/current" "$work/restore/jobs.json" | grep -F '"done": 2'
python3 labs/python/inventory.py labs/python/inventory.json | grep -F '"running": 2'
printf '%s\n' 'Local release, restore, retention and inventory checks passed.'
