# The Complete DevOps Engineer Handbook

Zero to Professional: A Practical Guide to DevOps, Cloud, Automation, CI/CD, Containers, Kubernetes, Infrastructure as Code, and Site Reliability Engineering.

## Read immediately

Extract the full ZIP. Open `book/index.html` in a browser. The prebuilt book, Mermaid runtime, syntax highlighting and search assets are included. For the most consistent search behavior across browsers, serve the prebuilt folder with `python3 -m http.server 8000 --bind 127.0.0.1 --directory book`, open `http://127.0.0.1:8000` and stop it with Ctrl+C. No account or cloud infrastructure is required to read the book.

## Build and serve from source

Install **mdBook 0.5.4** from the official release for your operating system and put the binary on PATH. A Rust/Cargo installation can instead run `cargo install mdbook --version 0.5.4 --locked`. Use Bash and Python 3.11+ for the repository checks. From the directory containing `book.toml`:

```bash
# Confirm the documentation compiler version.
mdbook --version
# Validate the curriculum, internal links, references and Markdown structure.
bash scripts/validate.sh
# Run validation and compile the offline HTML into book/.
bash scripts/build.sh
# Watch Markdown sources and preview at http://127.0.0.1:3000.
bash scripts/serve.sh
```

## Publish with GitHub Pages

Add the extracted repository contents to a repository you control. In **Settings → Pages → Build and deployment** select **GitHub Actions**. On the default branch open **Actions → Publish handbook → Run workflow**. The included workflow verifies the mdBook archive's SHA-256, builds the site, uploads the HTML and deploys the Pages artifact. It is manual by default. The build has read-only repository access and the separate deployment job requests Pages and OIDC permissions. No repository or Pages site was published on your behalf. Installation and deployment documentation: [mdBook](https://rust-lang.github.io/mdBook/guide/installation.html), [GitHub Pages workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

## Repository map

| Path | Purpose |
|---|---|
| `src/SUMMARY.md`, `src/curriculum.md` | Canonical navigation and study progression. |
| `src/part-01/` … `src/part-16/` | 58 numbered chapters, including 10 projects, plus part guides and reviews. |
| `src/reference/` | Command guide, troubleshooting, comparisons and glossary. |
| `labs/` | Application, scripts, manifests, workflows, infrastructure modules and monitoring stack used by the chapters. |
| `theme/` | Responsive styling and bundled offline Mermaid renderer. |
| `scripts/`, `.github/workflows/pages.yml` | Validation, local build, serving and Pages publication. |
| `PROGRESS.md` | Coverage, tested versions, checks performed and remaining runtime verification. |

Begin with the introduction, use each part's practical assessment and run the corresponding project when its prerequisites are met. Labs use synthetic data. Some operations explicitly require a Linux VM, a working container engine, a hosted service, or a billable training account. Read the relevant project prerequisites, cost assumptions and teardown before using those environments. Original text and code use the MIT license. Bundled third-party assets retain their upstream licenses. Mermaid 11.12.0 is included for offline rendering.
