document.addEventListener("DOMContentLoaded", async () => {
  const blocks = [...document.querySelectorAll("code.language-mermaid")];
  if (!blocks.length) return;
  mermaid.initialize({startOnLoad: false, securityLevel: "strict", theme: "neutral",
                      flowchart: {htmlLabels: false}});
  for (const [index, block] of blocks.entries()) {
    try {
      const {svg} = await mermaid.render("handbookDiagram" + index, block.textContent);
      const figure = document.createElement("figure");
      figure.className = "architecture";
      figure.innerHTML = svg;
      block.parentElement.replaceWith(figure);
    } catch (error) {
      block.setAttribute("data-render-error", String(error));
      console.error(error);
    }
  }
});
