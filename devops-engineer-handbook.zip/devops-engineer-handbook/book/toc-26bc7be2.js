// Populate the sidebar
//
// This is a script, and not included directly in the page, to control the total size of the book.
// The TOC contains an entry for each page, so if each page includes a copy of the TOC,
// the total size of the page becomes O(n**2).
class MDBookSidebarScrollbox extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = '<ol class="chapter"><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="introduction.html">Start here</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="curriculum.html">Study route</a></span></li><li class="chapter-item expanded "><li class="part-title">1 · DevOps fundamentals</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-01/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-01/01-devops.html">1 · Introduction to DevOps</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-01/02-sdlc.html">2 · From a requirement to a recoverable release</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-01/03-architecture.html">3 · Draw the delivery path and the request path</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-01/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">2 · Linux and system administration</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-02/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-02/04-linux.html">4 · Linux from the point of view of a service</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-02/05-linux-admin.html">5 · Diagnose a Linux host under load</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-02/06-bash.html">6 · Write Bash automation you can operate</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-02/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">3 · Networking fundamentals</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-03/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-03/07-networking.html">7 · Follow a request from name to response</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-03/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">4 · Git and development fundamentals</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-04/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-04/08-git.html">8 · Git and GitHub for shared infrastructure</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-04/09-python.html">9 · Python for repeatable operations</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-04/10-artifacts.html">10 · Build once and promote the artifact</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-04/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">5 · Containerization</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-05/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-05/11-docker.html">11 · Docker from image to running process</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-05/12-images.html">12 · Engineer the image you intend to run</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-05/13-compose.html">13 · Connect a frontend, API, database and cache</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-05/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">6 · Kubernetes</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/14-kubernetes.html">14 · Kubernetes as a set of control loops</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/15-objects.html">15 · Kubernetes objects and the contracts between them</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/16-advanced.html">16 · Placement, probes, persistent data and access</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/17-helm.html">17 · Package a Kubernetes service with Helm</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/18-kustomize.html">18 · Layer environment differences with Kustomize</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/19-operations.html">19 · Operate Kubernetes through a disruption</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-06/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">7 · CI/CD and automated delivery</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-07/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-07/20-pipelines.html">20 · Design a pipeline around release evidence</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-07/21-actions.html">21 · GitHub Actions and the deployment boundary</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-07/22-jenkins.html">22 · Jenkins controllers, agents and Pipeline as Code</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-07/23-gitlab.html">23 · GitLab CI/CD and the life of an artifact</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-07/24-progressive.html">24 · Progressive delivery and supply-chain evidence</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-07/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">8 · Cloud computing</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-08/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-08/25-cloud.html">25 · Cloud resources, failure domains and bills</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-08/26-aws.html">26 · AWS through a complete request</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-08/27-cloud-comparison.html">27 · Map a workload to Azure and Google Cloud</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-08/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">9 · Infrastructure as code and configuration management</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-09/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-09/28-iac.html">28 · Infrastructure as Code and the meaning of state</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-09/29-terraform.html">29 · Terraform plans, providers and concurrency</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-09/30-ansible.html">30 · Converge host configuration with Ansible</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-09/31-tool-choice.html">31 · Choose the right owner for an infrastructure change</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-09/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">10 · Web servers and infrastructure</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-10/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-10/32-nginx.html">32 · Nginx at the boundary of a service</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-10/33-infrastructure.html">33 · Design for queues, caches and failures</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-10/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">11 · Monitoring, logging and observability</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-11/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-11/34-monitoring.html">34 · Measure the user operation</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-11/35-prometheus.html">35 · Prometheus, Alertmanager and Grafana</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-11/36-logging.html">36 · Carry a log from a worker to a query</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-11/37-tracing.html">37 · Explain latency with distributed traces</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-11/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">12 · DevSecOps and security</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-12/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-12/38-devsecops.html">38 · Put a security decision where it can change the release</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-12/39-hardening.html">39 · Bound the damage a workload can cause</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-12/40-supply-chain.html">40 · Trust a release and rotate its credentials</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-12/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">13 · GitOps and platform engineering</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-13/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-13/41-gitops.html">41 · Reconcile deployments from version control</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-13/42-platform.html">42 · Build a platform as a product for developers</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-13/43-mesh.html">43 · Workload identity, service mesh and policy</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-13/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">14 · SRE and production engineering</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-14/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-14/44-sre.html">44 · Use an error budget to make a release decision</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-14/45-finops.html">45 · Explain cost per successful job</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-14/46-incidents.html">46 · Investigate a production incident without destroying its evidence</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-14/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">15 · Real-world projects</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/47-toolkit.html">47 · Project 1 · Linux server automation toolkit</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/48-dashboard.html">48 · Project 2 · A containerized job dashboard</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/49-delivery.html">49 · Project 3 · Test, publish and deploy a container by digest</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/50-aws.html">50 · Project 4 · A two-zone AWS environment with Terraform</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/51-cluster.html">51 · Project 5 · A Kubernetes deployment with persistent evidence</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/52-gitops.html">52 · Project 6 · Promote an image through GitOps</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/53-monitoring.html">53 · Project 7 · A working metrics and alerting stack</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/54-logging.html">54 · Project 8 · Trace a synthetic job through centralized logs</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/55-secure.html">55 · Project 9 · Gate and sign a release</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/56-capstone.html">56 · Project 10 · Operate a cloud-native release on EKS</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-15/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">16 · Interview and career preparation</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-16/overview.html">Part guide</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-16/57-interviews.html">57 · DevOps interview workshop</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-16/58-career.html">58 · Build a portfolio an engineering team can evaluate</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="part-16/review.html">Part review</a></span></li><li class="chapter-item expanded "><li class="part-title">Field reference</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="reference/commands.html">Commands</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="reference/troubleshooting.html">Troubleshooting</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="reference/glossary.html">Glossary</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="reference/comparisons.html">Technology comparisons</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="validation.html">Validation and limitations</a></span></li></ol>';
        // Set the current, active page, and reveal it if it's hidden
        let current_page = document.location.href.toString().split('#')[0].split('?')[0];
        if (current_page.endsWith('/')) {
            current_page += 'index.html';
        }
        const links = Array.prototype.slice.call(this.querySelectorAll('a'));
        const l = links.length;
        for (let i = 0; i < l; ++i) {
            const link = links[i];
            const href = link.getAttribute('href');
            if (href && !href.startsWith('#') && !/^(?:[a-z+]+:)?\/\//.test(href)) {
                link.href = path_to_root + href;
            }
            // The 'index' page is supposed to alias the first chapter in the book.
            // Check both with and without the '.html' suffix to be robust against pretty URLs
            if (link.href.replace(/\.html$/, '') === current_page.replace(/\.html$/, '')
                || i === 0
                && path_to_root === ''
                && current_page.endsWith('/index.html')) {
                link.classList.add('active');
                let parent = link.parentElement;
                while (parent) {
                    if (parent.tagName === 'LI' && parent.classList.contains('chapter-item')) {
                        parent.classList.add('expanded');
                    }
                    parent = parent.parentElement;
                }
            }
        }
        // Track and set sidebar scroll position
        this.addEventListener('click', e => {
            if (e.target.tagName === 'A') {
                const clientRect = e.target.getBoundingClientRect();
                const sidebarRect = this.getBoundingClientRect();
                sessionStorage.setItem('sidebar-scroll-offset', clientRect.top - sidebarRect.top);
            }
        }, { passive: true });
        const sidebarScrollOffset = sessionStorage.getItem('sidebar-scroll-offset');
        sessionStorage.removeItem('sidebar-scroll-offset');
        if (sidebarScrollOffset !== null) {
            // preserve sidebar scroll position when navigating via links within sidebar
            const activeSection = this.querySelector('.active');
            if (activeSection) {
                const clientRect = activeSection.getBoundingClientRect();
                const sidebarRect = this.getBoundingClientRect();
                const currentOffset = clientRect.top - sidebarRect.top;
                this.scrollTop += currentOffset - parseFloat(sidebarScrollOffset);
            }
        } else {
            // scroll sidebar to current active section when navigating via
            // 'next/previous chapter' buttons
            const activeSection = document.querySelector('#mdbook-sidebar .active');
            if (activeSection) {
                activeSection.scrollIntoView({ block: 'center' });
            }
        }
        // Toggle buttons
        const sidebarAnchorToggles = document.querySelectorAll('.chapter-fold-toggle');
        function toggleSection(ev) {
            ev.currentTarget.parentElement.parentElement.classList.toggle('expanded');
        }
        Array.from(sidebarAnchorToggles).forEach(el => {
            el.addEventListener('click', toggleSection);
        });
    }
}
window.customElements.define('mdbook-sidebar-scrollbox', MDBookSidebarScrollbox);


// ---------------------------------------------------------------------------
// Support for dynamically adding headers to the sidebar.

(function() {
    // This is used to detect which direction the page has scrolled since the
    // last scroll event.
    let lastKnownScrollPosition = 0;
    // This is the threshold in px from the top of the screen where it will
    // consider a header the "current" header when scrolling down.
    const defaultDownThreshold = 150;
    // Same as defaultDownThreshold, except when scrolling up.
    const defaultUpThreshold = 300;
    // The threshold is a virtual horizontal line on the screen where it
    // considers the "current" header to be above the line. The threshold is
    // modified dynamically to handle headers that are near the bottom of the
    // screen, and to slightly offset the behavior when scrolling up vs down.
    let threshold = defaultDownThreshold;
    // This is used to disable updates while scrolling. This is needed when
    // clicking the header in the sidebar, which triggers a scroll event. It
    // is somewhat finicky to detect when the scroll has finished, so this
    // uses a relatively dumb system of disabling scroll updates for a short
    // time after the click.
    let disableScroll = false;
    // Array of header elements on the page.
    let headers;
    // Array of li elements that are initially collapsed headers in the sidebar.
    // I'm not sure why eslint seems to have a false positive here.
    // eslint-disable-next-line prefer-const
    let headerToggles = [];
    // This is a debugging tool for the threshold which you can enable in the console.
    let thresholdDebug = false;

    // Updates the threshold based on the scroll position.
    function updateThreshold() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;

        // The number of pixels below the viewport, at most documentHeight.
        // This is used to push the threshold down to the bottom of the page
        // as the user scrolls towards the bottom.
        const pixelsBelow = Math.max(0, documentHeight - (scrollTop + windowHeight));
        // The number of pixels above the viewport, at least defaultDownThreshold.
        // Similar to pixelsBelow, this is used to push the threshold back towards
        // the top when reaching the top of the page.
        const pixelsAbove = Math.max(0, defaultDownThreshold - scrollTop);
        // How much the threshold should be offset once it gets close to the
        // bottom of the page.
        const bottomAdd = Math.max(0, windowHeight - pixelsBelow - defaultDownThreshold);
        let adjustedBottomAdd = bottomAdd;

        // Adjusts bottomAdd for a small document. The calculation above
        // assumes the document is at least twice the windowheight in size. If
        // it is less than that, then bottomAdd needs to be shrunk
        // proportional to the difference in size.
        if (documentHeight < windowHeight * 2) {
            const maxPixelsBelow = documentHeight - windowHeight;
            const t = 1 - pixelsBelow / Math.max(1, maxPixelsBelow);
            const clamp = Math.max(0, Math.min(1, t));
            adjustedBottomAdd *= clamp;
        }

        let scrollingDown = true;
        if (scrollTop < lastKnownScrollPosition) {
            scrollingDown = false;
        }

        if (scrollingDown) {
            // When scrolling down, move the threshold up towards the default
            // downwards threshold position. If near the bottom of the page,
            // adjustedBottomAdd will offset the threshold towards the bottom
            // of the page.
            const amountScrolledDown = scrollTop - lastKnownScrollPosition;
            const adjustedDefault = defaultDownThreshold + adjustedBottomAdd;
            threshold = Math.max(adjustedDefault, threshold - amountScrolledDown);
        } else {
            // When scrolling up, move the threshold down towards the default
            // upwards threshold position. If near the bottom of the page,
            // quickly transition the threshold back up where it normally
            // belongs.
            const amountScrolledUp = lastKnownScrollPosition - scrollTop;
            const adjustedDefault = defaultUpThreshold - pixelsAbove
                + Math.max(0, adjustedBottomAdd - defaultDownThreshold);
            threshold = Math.min(adjustedDefault, threshold + amountScrolledUp);
        }

        if (documentHeight <= windowHeight) {
            threshold = 0;
        }

        if (thresholdDebug) {
            const id = 'mdbook-threshold-debug-data';
            let data = document.getElementById(id);
            if (data === null) {
                data = document.createElement('div');
                data.id = id;
                data.style.cssText = `
                    position: fixed;
                    top: 50px;
                    right: 10px;
                    background-color: 0xeeeeee;
                    z-index: 9999;
                    pointer-events: none;
                `;
                document.body.appendChild(data);
            }
            data.innerHTML = `
                <table>
                  <tr><td>documentHeight</td><td>${documentHeight.toFixed(1)}</td></tr>
                  <tr><td>windowHeight</td><td>${windowHeight.toFixed(1)}</td></tr>
                  <tr><td>scrollTop</td><td>${scrollTop.toFixed(1)}</td></tr>
                  <tr><td>pixelsAbove</td><td>${pixelsAbove.toFixed(1)}</td></tr>
                  <tr><td>pixelsBelow</td><td>${pixelsBelow.toFixed(1)}</td></tr>
                  <tr><td>bottomAdd</td><td>${bottomAdd.toFixed(1)}</td></tr>
                  <tr><td>adjustedBottomAdd</td><td>${adjustedBottomAdd.toFixed(1)}</td></tr>
                  <tr><td>scrollingDown</td><td>${scrollingDown}</td></tr>
                  <tr><td>threshold</td><td>${threshold.toFixed(1)}</td></tr>
                </table>
            `;
            drawDebugLine();
        }

        lastKnownScrollPosition = scrollTop;
    }

    function drawDebugLine() {
        if (!document.body) {
            return;
        }
        const id = 'mdbook-threshold-debug-line';
        const existingLine = document.getElementById(id);
        if (existingLine) {
            existingLine.remove();
        }
        const line = document.createElement('div');
        line.id = id;
        line.style.cssText = `
            position: fixed;
            top: ${threshold}px;
            left: 0;
            width: 100vw;
            height: 2px;
            background-color: red;
            z-index: 9999;
            pointer-events: none;
        `;
        document.body.appendChild(line);
    }

    function mdbookEnableThresholdDebug() {
        thresholdDebug = true;
        updateThreshold();
        drawDebugLine();
    }

    window.mdbookEnableThresholdDebug = mdbookEnableThresholdDebug;

    // Updates which headers in the sidebar should be expanded. If the current
    // header is inside a collapsed group, then it, and all its parents should
    // be expanded.
    function updateHeaderExpanded(currentA) {
        // Add expanded to all header-item li ancestors.
        let current = currentA.parentElement;
        while (current) {
            if (current.tagName === 'LI' && current.classList.contains('header-item')) {
                current.classList.add('expanded');
            }
            current = current.parentElement;
        }
    }

    // Updates which header is marked as the "current" header in the sidebar.
    // This is done with a virtual Y threshold, where headers at or below
    // that line will be considered the current one.
    function updateCurrentHeader() {
        if (!headers || !headers.length) {
            return;
        }

        // Reset the classes, which will be rebuilt below.
        const els = document.getElementsByClassName('current-header');
        for (const el of els) {
            el.classList.remove('current-header');
        }
        for (const toggle of headerToggles) {
            toggle.classList.remove('expanded');
        }

        // Find the last header that is above the threshold.
        let lastHeader = null;
        for (const header of headers) {
            const rect = header.getBoundingClientRect();
            if (rect.top <= threshold) {
                lastHeader = header;
            } else {
                break;
            }
        }
        if (lastHeader === null) {
            lastHeader = headers[0];
            const rect = lastHeader.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            if (rect.top >= windowHeight) {
                return;
            }
        }

        // Get the anchor in the summary.
        const href = '#' + lastHeader.id;
        const a = [...document.querySelectorAll('.header-in-summary')]
            .find(element => element.getAttribute('href') === href);
        if (!a) {
            return;
        }

        a.classList.add('current-header');

        updateHeaderExpanded(a);
    }

    // Updates which header is "current" based on the threshold line.
    function reloadCurrentHeader() {
        if (disableScroll) {
            return;
        }
        updateThreshold();
        updateCurrentHeader();
    }


    // When clicking on a header in the sidebar, this adjusts the threshold so
    // that it is located next to the header. This is so that header becomes
    // "current".
    function headerThresholdClick(event) {
        // See disableScroll description why this is done.
        disableScroll = true;
        setTimeout(() => {
            disableScroll = false;
        }, 100);
        // requestAnimationFrame is used to delay the update of the "current"
        // header until after the scroll is done, and the header is in the new
        // position.
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                // Closest is needed because if it has child elements like <code>.
                const a = event.target.closest('a');
                const href = a.getAttribute('href');
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    threshold = targetElement.getBoundingClientRect().bottom;
                    updateCurrentHeader();
                }
            });
        });
    }

    // Takes the nodes from the given head and copies them over to the
    // destination, along with some filtering.
    function filterHeader(source, dest) {
        const clone = source.cloneNode(true);
        clone.querySelectorAll('mark').forEach(mark => {
            mark.replaceWith(...mark.childNodes);
        });
        dest.append(...clone.childNodes);
    }

    // Scans page for headers and adds them to the sidebar.
    document.addEventListener('DOMContentLoaded', function() {
        const activeSection = document.querySelector('#mdbook-sidebar .active');
        if (activeSection === null) {
            return;
        }

        const main = document.getElementsByTagName('main')[0];
        headers = Array.from(main.querySelectorAll('h2, h3, h4, h5, h6'))
            .filter(h => h.id !== '' && h.children.length && h.children[0].tagName === 'A');

        if (headers.length === 0) {
            return;
        }

        // Build a tree of headers in the sidebar.

        const stack = [];

        const firstLevel = parseInt(headers[0].tagName.charAt(1));
        for (let i = 1; i < firstLevel; i++) {
            const ol = document.createElement('ol');
            ol.classList.add('section');
            if (stack.length > 0) {
                stack[stack.length - 1].ol.appendChild(ol);
            }
            stack.push({level: i + 1, ol: ol});
        }

        // The level where it will start folding deeply nested headers.
        const foldLevel = 3;

        for (let i = 0; i < headers.length; i++) {
            const header = headers[i];
            const level = parseInt(header.tagName.charAt(1));

            const currentLevel = stack[stack.length - 1].level;
            if (level > currentLevel) {
                // Begin nesting to this level.
                for (let nextLevel = currentLevel + 1; nextLevel <= level; nextLevel++) {
                    const ol = document.createElement('ol');
                    ol.classList.add('section');
                    const last = stack[stack.length - 1];
                    const lastChild = last.ol.lastChild;
                    // Handle the case where jumping more than one nesting
                    // level, which doesn't have a list item to place this new
                    // list inside of.
                    if (lastChild) {
                        lastChild.appendChild(ol);
                    } else {
                        last.ol.appendChild(ol);
                    }
                    stack.push({level: nextLevel, ol: ol});
                }
            } else if (level < currentLevel) {
                while (stack.length > 1 && stack[stack.length - 1].level > level) {
                    stack.pop();
                }
            }

            const li = document.createElement('li');
            li.classList.add('header-item');
            li.classList.add('expanded');
            if (level < foldLevel) {
                li.classList.add('expanded');
            }
            const span = document.createElement('span');
            span.classList.add('chapter-link-wrapper');
            const a = document.createElement('a');
            span.appendChild(a);
            a.href = '#' + header.id;
            a.classList.add('header-in-summary');
            filterHeader(header.children[0], a);
            a.addEventListener('click', headerThresholdClick);
            const nextHeader = headers[i + 1];
            if (nextHeader !== undefined) {
                const nextLevel = parseInt(nextHeader.tagName.charAt(1));
                if (nextLevel > level && level >= foldLevel) {
                    const toggle = document.createElement('a');
                    toggle.classList.add('chapter-fold-toggle');
                    toggle.classList.add('header-toggle');
                    toggle.addEventListener('click', () => {
                        li.classList.toggle('expanded');
                    });
                    const toggleDiv = document.createElement('div');
                    toggleDiv.textContent = '❱';
                    toggle.appendChild(toggleDiv);
                    span.appendChild(toggle);
                    headerToggles.push(li);
                }
            }
            li.appendChild(span);

            const currentParent = stack[stack.length - 1];
            currentParent.ol.appendChild(li);
        }

        const onThisPage = document.createElement('div');
        onThisPage.classList.add('on-this-page');
        onThisPage.append(stack[0].ol);
        const activeItemSpan = activeSection.parentElement;
        activeItemSpan.after(onThisPage);
    });

    document.addEventListener('DOMContentLoaded', reloadCurrentHeader);
    document.addEventListener('scroll', reloadCurrentHeader, { passive: true });
})();

