# 8 · Git and GitHub for shared infrastructure

**By the end** you can stage exactly one change, explain a merge conflict, and undo a published change while preserving its history. Install Git 2.28 or newer for the commands below. All writes in the lab occur in a disposable local repository.

## Three versions can exist on your laptop

The working tree contains the files you edit. The index, also called the staging area, records what you propose for the next commit. A commit records a snapshot, its parent reference or references, authorship and a message. A branch is a movable reference to a commit. HEAD usually identifies the current branch. If you stage a file, edit it again and commit immediately, the commit contains the staged version. That is why `git diff` and `git diff --staged` can show different changes.

Git stores objects by content and builds history by linking commits to parents. A merge commit has multiple parents. A fast-forward simply moves a branch tip along an existing path. Rebasing replays a sequence of changes on a new base and produces new commit identities. That can simplify private work but disrupt people who already used the original identities.

## Lab · Resolve competing rollout values

```bash
# Create an isolated repository with a known initial branch.
gitlab=$(mktemp -d)
git -C "$gitlab" init -b main
# Set the author for this disposable repository only.
git -C "$gitlab" config user.name "Lab Engineer"
git -C "$gitlab" config user.email "lab@example.invalid"
# Establish a baseline release policy and commit the staged file.
echo 'canary_percent=5' > "$gitlab/rollout.conf"
git -C "$gitlab" add rollout.conf
git -C "$gitlab" commit -m 'Begin rollout at five percent'
# Prepare a proposed policy on a branch.
git -C "$gitlab" switch -c larger-cohort
echo 'canary_percent=10' > "$gitlab/rollout.conf"
git -C "$gitlab" commit -am 'Increase initial sample for busy hours'
# Model a concurrent main-branch change to the same line.
git -C "$gitlab" switch main
echo 'canary_percent=2' > "$gitlab/rollout.conf"
git -C "$gitlab" commit -am 'Limit exposure while workers recover'
# Request a merge. A nonzero status and a content conflict are expected.
git -C "$gitlab" merge larger-cohort
git -C "$gitlab" status --short
```

The conflict is a policy decision. Git cannot know whether the changed traffic or recovering workers take priority. Assume the incident commander keeps the 2% policy. Resolve the file, stage the agreed content and record the decision.

```bash
# Complete the merge with the selected rollout value.
echo 'canary_percent=2' > "$gitlab/rollout.conf"
git -C "$gitlab" add rollout.conf
git -C "$gitlab" commit -m 'Keep recovery cohort until backlog clears'
# Visualize both parents of the merge and check that the tree is clean.
git -C "$gitlab" log --oneline --graph --all
git -C "$gitlab" status --short
```

A clean status says there are no pending local changes. It says nothing about correctness of the chosen policy. The reviewer should ask for the stop condition, expected sample volume and owner.

## Revert, reset, cherry-pick or rebase?

| Intent | Command form | Effect and boundary |
|---|---|---|
| Undo an ordinary published commit | `git revert COMMIT` | Records a new inverse commit. Later edits can conflict. Reverting a merge requires a parent choice. |
| Unstage a file | `git restore --staged PATH` | Resets that index entry while preserving working edits in the usual committed-HEAD case. |
| Repoint a private branch | `git reset --soft COMMIT` | Moves HEAD and keeps index and working files. Other reset modes alter more state. |
| Pick one fix for a supported release | `git cherry-pick COMMIT` | Reapplies that change to the current branch as a new commit. Verify its dependencies. |
| Refresh a private feature branch | `git rebase main` | Replays work after main. Use `git rebase --abort` to abandon an unresolved attempt. |

## From local history to GitHub

A remote is a named repository location. A push sends local commits and requests updates to remote refs. A GitHub pull request proposes integrating a branch and gives reviewers a durable place for discussion and checks. Require review for deployment identity changes. A workflow in `.github/workflows/` can run tests on a pull request. Credentials granting production access belong only in trusted deployment contexts.

Trunk-based teams integrate small changes frequently, often with short-lived branches and feature flags. GitFlow separates development, release and hotfix lines. It can support multiple maintained versions at the cost of merging fixes between lines. An annotated tag marks a release decision; the registry digest identifies what ran. Releases can attach notes, binaries and their checksums.

**Troubleshooting.** “Nothing to commit” can mean the edit was made in another directory. Compare `git rev-parse --show-toplevel`, `git status` and `git diff --staged`. An untracked credential accidentally committed requires revocation or rotation; removing it from the next snapshot leaves earlier copies accessible.

**Practice.** Add `owner=oncall` as an ordinary commit, revert that commit, and explain why both records remain in `git log`. Keep this evidence with the merge graph.

**Interview. A pull request was green yesterday and is red after merging. How?** Another change could have altered the integration base. Test the merged result, keep branches short and serialize integration when necessary.

### Further reading

[Pro Git](https://git-scm.com/book/en/v2) · [Git revert](https://git-scm.com/docs/git-revert) · [GitHub pull requests](https://docs.github.com/en/pull-requests)
