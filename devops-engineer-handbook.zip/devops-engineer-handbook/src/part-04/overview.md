# Part 4 · Git and development fundamentals

**Study time:** 6–9 h including practice. **Starting point:** Parts 1–3; Git and Python 3.

Reconcile competing changes, parse cloud inventory and identify the exact bytes produced by a build.

## What you will demonstrate

Submit a reviewed change to the inventory parser, retain its tested artifact and show the failure for malformed input.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
