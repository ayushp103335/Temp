# Part 4 review · Git and development fundamentals

## Revision and assessment

**Could an empty inventory and a permission failure produce the same operator decision?**

Only if the client loses the distinction. Preserve a valid empty response and signal failed collection separately.

## Practical assignment

Submit a reviewed change to the inventory parser, retain its tested artifact and show the failure for malformed input.

## Mini-project and self-evaluation

Resolve a conflict using the release policy. Explain what the digest verifies and what remains dependent on the signer.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
