# 9 · Python for repeatable operations

**By the end** you can parse a structured response, preserve the difference between empty and failed inventory, and put boundaries on an external call. Use Python 3.11 or newer. The included exercise uses the standard library and an offline cloud response.

## Turn provider output into an operating decision

An engineer needs to count running machines before a maintenance window. A text search for “running” can match notes and nested fields. A JSON parser gives you actual values and structure. JSON objects become Python dictionaries, arrays become lists, strings remain strings and null becomes `None`. Treat absent data as a separate condition. Converting a failed inventory request into a zero count could authorize maintenance on an active system.

Open `labs/python/inventory.py`. Its function accepts reservations, walks the instances inside each one and counts their state names. The local dictionary maps a string to an integer. A `for` loop visits each item. `counts.get(state, 0)` supplies a first count for a newly observed state. A function groups this transformation so you can test it independently from file or network access. The `if __name__ == "__main__"` guard runs the command-line interface only when the file is executed as a program.

## Lab · A zero-machine account and an unreadable account

```bash
# Print the inventory for the synthetic EC2-shaped provider response.
python3 labs/python/inventory.py labs/python/inventory.json
# Create two small responses representing different operational situations.
pywork=$(mktemp -d)
echo '{"Reservations":[]}' > "$pywork/empty.json"
echo '{"Error":"AccessDenied"}' > "$pywork/denied.json"
# Observe successful empty inventory, then inspect the failure exit status.
python3 labs/python/inventory.py "$pywork/empty.json"
python3 labs/python/inventory.py "$pywork/denied.json" || echo "exit=$?"
```

The first output has two running and one stopped. Empty inventory produces `{}` and exit zero. The error response produces a diagnostic on standard error and exit two. `argparse` also reports missing command-line arguments. `pathlib.Path` represents a filesystem path, `read_text` chooses an encoding, and `json.loads` converts text into values. The narrow exception handler covers input and shape errors and lets programming defects surface.

### Call programs and HTTP endpoints deliberately

```python
import subprocess
result = subprocess.run(
    ["git", "--version"], check=True, capture_output=True, text=True, timeout=5
)
print(result.stdout.strip())
```

The list preserves argument boundaries. A timeout bounds the wait; `check=True` raises an exception for a nonzero exit. Capture only outputs small enough to hold in memory. For an HTTP GET, the standard library offers `urllib.request.urlopen(url, timeout=5)`. Close the response with a `with` block, check content expectations and bound the amount read. An HTTP client timeout may apply to individual blocking operations; an overall job deadline can be a separate requirement.

For a real EC2 inventory, the equivalent SDK flow creates an EC2 client and iterates its `describe_instances` paginator. Each page has a `Reservations` array. Aggregate every page in the intended account and region. Use a short-lived read-only identity and allow the SDK's credential provider chain to locate it. A list permission in one region does not establish global coverage. If a page fails after earlier pages succeeded, mark the result incomplete. Blindly retrying a read is usually less risky than retrying a create after an ambiguous timeout. Use provider-supported idempotency tokens for relevant writes.

### Packages and configuration

A module is an importable unit such as `json`. A package groups modules. A virtual environment gives a project its own Python environment. From the repository root, `python3 -m venv .venv` creates it. `source .venv/bin/activate` adjusts the shell path and `python -m pip --version` shows which installer belongs to that interpreter. `deactivate` leaves it. A minimal Debian installation may need its distribution's venv package.

YAML allows comments and indentation-based nesting, which makes it convenient for human-edited configuration. JSON is a better fit when strict interoperable data exchange is the goal. If adding PyYAML, lock the dependency and use `yaml.safe_load` for configuration. Validate expected field names, types and ranges after parsing. Use `os.environ.get("AWS_REGION")` for a nonsecret optional setting. Report missing required settings early and keep credential values out of exceptions and logs.

**Troubleshooting.** A `ModuleNotFoundError` after installing a package usually merits comparing `python -m pip --version` with `python -c 'import sys; print(sys.executable)'`. For a KeyError in an inventory parser, inspect a sanitized record's structure before assuming that the provider returned no machines.

**Practice.** Implement a pure function that merges counts from two pages. Test a page containing an unknown but valid state name, an empty page, and a malformed page. The last should cause the command to fail.

**Interview. Why unit-test the parser without a cloud account?** It gives fast deterministic coverage for known response shapes. A separate scoped integration check verifies permissions, pagination and current provider behavior.

### Further reading

[Python tutorial](https://docs.python.org/3/tutorial/) · [subprocess](https://docs.python.org/3/library/subprocess.html) · [Boto3 EC2 paginator](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/ec2/paginator/DescribeInstances.html)
