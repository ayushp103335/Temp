# 10 · Build once and promote the artifact

**By the end** you can explain why a source commit may yield different binaries, inspect a build output and draw a reliable promotion boundary. You need the release lab and GNU tar, gzip and sha256sum. Maven, Gradle and npm are optional comparisons.

## Which exact bytes did we test?

A build transforms inputs into something deployable. Java compilation translates source to class files that can be packaged in a JAR. A browser application may resolve JavaScript packages, compile TypeScript and generate static bundles. A Python service can ship as a wheel, source archive or container image. Each build also consumes tools, dependency versions, environment settings and sometimes a clock. “Built from main” does not identify these inputs.

A dependency is software the project needs. Transitive dependencies are pulled in by direct dependencies. A lockfile or comparable resolution record narrows the set used by a build. A cache accelerates fetching or building. An artifact is an output you intend to retain. Losing a cache should slow a build; losing an unrecoverable release artifact can defeat rollback.

| Tool | Configuration | Useful command and interpretation |
|---|---|---|
| Maven | `pom.xml` with coordinates, dependencies and plugin configuration | `./mvnw verify` runs lifecycle phases through verification when the repository includes the wrapper. Output commonly lands in `target/`. |
| Gradle | `build.gradle` or `build.gradle.kts`, often with settings and a wrapper | `./gradlew build` executes a task graph. Tasks and outputs depend on applied plugins. |
| npm | `package.json` for scripts and constraints; `package-lock.json` for resolution | `npm ci` installs from a consistent lockfile. `npm run build` invokes the project's defined build script. |
| OCI registry | Image manifests and content-addressed layers | Pull by digest for unambiguous bytes; keep a meaningful release tag for humans. |

Repository managers such as Sonatype Nexus Repository and JFrog Artifactory can host build outputs and proxy upstream packages. A container registry implements image distribution. Choose supported formats, access boundaries, retention and recovery policy before comparing dashboard features. Separate upload permission from production promotion authority.

## Lab · Make an archive twice and compare it

```bash
# Copy the deployable program to an isolated build context.
buildlab=$(mktemp -d)
mkdir "$buildlab/src"
cp labs/release/service.py "$buildlab/src/"
# Normalize metadata and omit gzip's stored original filename and timestamp.
for version in first second; do
    tar --sort=name --mtime='@0' --owner=0 --group=0 --numeric-owner \
        --mode=0644 -C "$buildlab/src" -cf - service.py |
        gzip -n > "$buildlab/$version.tar.gz"
done
# Both digests should match. Compare actual bytes and inspect archive contents.
sha256sum "$buildlab/"*.tar.gz
cmp "$buildlab/first.tar.gz" "$buildlab/second.tar.gz"
tar -tzf "$buildlab/first.tar.gz"
```

The two builds share a toolchain and source file. Sorting stabilizes entry order for larger inputs. The other flags normalize timestamps, ownership, file mode and compressor metadata. This establishes reproducibility under these conditions. A different compiler, tar format or compressor implementation can still change the bytes. A real pipeline must also fail if the producer side of the pipe fails, for example with Bash's `set -o pipefail`.

## Design the promotion record

Record the source commit, artifact digest, toolchain identity, test result, creation time and approver or policy decision. A deployment record adds the destination, configuration revision and deployment time. Promotion can be a database or Git change selecting an existing digest. Copying to another registry also works if you verify the destination digest and preserve signatures and attestations as required. Retain enough older artifacts for the agreed rollback window and protect the registry itself with backup and restore tests.

**Field scenario.** Staging passed with a tag called `stable`. Overnight a rebuild moved that tag; production pulled different bytes. Compare the deployed digests, recover the tested artifact if available and change the promotion record to select a digest. Retrying the same tag could compound the mismatch.

**Practice.** Add a second source file that should ship with the application. Update the archive command explicitly. Show that omitting the new file can yield perfectly repeatable but functionally incomplete packages. Write one test against the unpacked artifact.

**Interview. Does a matching hash prove a package is safe?** It establishes equality with the referenced bytes. Trust also depends on who supplied the expected digest, what checks ran and who could alter the build process.

### Further reading

[Maven build lifecycle](https://maven.apache.org/guides/introduction/introduction-to-the-lifecycle.html) · [Gradle build lifecycle](https://docs.gradle.org/current/userguide/build_lifecycle.html) · [npm ci](https://docs.npmjs.com/cli/commands/npm-ci) · [OCI distribution specification](https://github.com/opencontainers/distribution-spec)
