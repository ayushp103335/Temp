# Part 10 review · Web servers and infrastructure

## Revision and assessment

**What does a 200 from the static homepage prove after the API stops?**

It proves that the edge can serve that file. Query the API and verify a business result separately.

## Practical assignment

Run the proxy failure drill; design idempotent recovery for a worker that dies immediately before acknowledging a successful job.

## Mini-project and self-evaluation

Show which connection failed and how a retry would affect each durable side effect.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
