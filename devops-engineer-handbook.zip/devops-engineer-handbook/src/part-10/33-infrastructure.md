# 33 · Design for queues, caches and failures

**By the end** you can select an interaction pattern, calculate the cost of retries and explain what must be durable before accepting work. Use the architecture in chapter 3 and the concrete service in project 2.

A synchronous call asks a dependency for a result before returning to its caller. If the dependency slows down, caller connections remain occupied. A queue lets a producer and consumer make progress at different times, but accepted work must be retained and observable. A cache reduces repeated reads. Its expiration policy defines how stale the answer may become. A database provides durable records and the transactions appropriate to its design. Assign each piece of state one authoritative owner.

A multi-tier job service might use Nginx and a load balancer for entry, an API tier for validation, a queue for pending work, a worker tier for processing, a database for job state and object storage for documents. In project 2 a read-only dashboard uses only three of these boundaries. Adding a queue to serve a simple cached read would add latency and operations without addressing a requirement.

| Pattern | Strong fit | Failure to design for |
|---|---|---|
| Direct HTTP call | Caller requires a quick answer before continuing. | Timeout after the server committed a change. |
| RabbitMQ work queue | Competing workers acknowledge tasks after processing. | Worker dies after a side effect but before acknowledgment. |
| Kafka partitioned log | Consumers independently replay ordered records within a partition. | Consumer lag, partition skew and duplicate effects during replay. |
| Redis cache-aside | Expensive repeatable reads tolerate a defined stale window. | Cache loss sends a burst of reads to the database. |
| Relational transaction | Several updates must satisfy an invariant together. | Long transactions, contention or replication lag at readers. |

## Worked design · An accepted job must survive a crash

Have the API persist the accepted job and an outbox event in one database transaction. A relay publishes the event and records progress. A relay can crash after publish and before recording success. The worker therefore treats the job ID as an idempotency key and atomically records completion alongside the business update where feasible. For an external side effect, use the downstream system's idempotency contract or a reconciliation procedure. “At least once” at the transport layer can be compatible with a once-only business result when the consumer is designed for duplicates.

## Lab · Examine one crash window at a time

Write a table with columns “last durable fact,” “next retry,” and “user-visible result.” Fill in three rows: before the initial transaction commits, after it commits but before relay publication, and after worker output is committed but before acknowledgment. For the third row, execute the same synthetic job twice in a small dictionary keyed by job ID. Verify that the completed count remains one even if a delivery counter becomes two. Explain why a process-local dictionary would lose its protection after a restart.

If each of three layers makes one initial attempt plus two retries independently, one failing request can generate as many as 27 downstream attempts. Bound retries, add randomized delay, and respect a propagated overall deadline. For a database failover, preserve a single authoritative writer or use the consistency rules of the specific distributed database. Simply enabling writes on two copies does not resolve conflicting transactions. Test recovery with reads, writes, duplicate submissions and data reconciliation.

**Practice.** Estimate backlog drain time with arrivals at 40/minute and recovery capacity of 55/minute. A backlog of 900 needs about 60 minutes under those steady conditions. **Interview. Would doubling consumers help?** Only if the downstream bottleneck can absorb the extra concurrency. Examine database connection pressure and completion rate per worker.

### Further reading

[RabbitMQ acknowledgments and confirms](https://www.rabbitmq.com/docs/confirms) · [Apache Kafka design](https://kafka.apache.org/documentation/#design) · [Transactional outbox](https://docs.aws.amazon.com/prescriptive-guidance/latest/cloud-design-patterns/transactional-outbox.html)
