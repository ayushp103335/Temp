# 32 · Nginx at the boundary of a service

**By the end** you can predict which location handles a request, trace an upstream error and reload a validated configuration. Use chapters 7 and 13. The lab uses the loopback-only Compose stack from project 2.

Nginx accepts connections, serves files or proxies requests to an upstream. The master process manages configuration and workers. Workers use event-driven I/O to handle many connections without dedicating one operating-system process to each client. A low connection count can still produce high latency when upstream work is slow. Measure proxy and application timing separately.

Open `labs/docker/nginx.conf`. A `server` block listens on port 80. Its `root` supplies a directory for static content. A request for `/api/summary` matches the more specific `location /api/` and goes to the API. The supplied `proxy_pass http://api:8000;` has no URI component, so the existing path reaches the upstream in this simple configuration. Adding a slash after 8000 would change the prefix-replacement behavior. The API expects `/api/summary`, so an apparently harmless slash can produce a 404.

## Lab · Locate a proxy failure

```bash
# From the repository root, start the project 2 stack.
cd labs/docker
bash setup-secrets.sh
docker compose up -d --build
# Validate syntax inside the actual container and its loaded filesystem.
docker compose exec -T edge nginx -t
# Exercise the file handler and the proxy handler separately.
curl -i http://127.0.0.1:8088/
curl -i http://127.0.0.1:8088/api/summary
# Stop the API only, leaving the static frontend and data tier up.
docker compose stop api
curl -i http://127.0.0.1:8088/
curl -i http://127.0.0.1:8088/api/summary
# Restore the API, inspect recent errors and repeat the business check.
docker compose start api
docker compose logs --tail 20 edge
bash smoke.sh
```

Expect the HTML route to remain available during the outage. The proxy route usually returns 502 for a refused upstream connection. A gateway timeout can indicate that a connection opened but the upstream failed to answer in time. If replacing the API container gives it a different address, review how this Nginx configuration resolves its upstream hostname. Reload the proxy after its upstream is resolvable where appropriate. A simple static configuration does not guarantee immediate rediscovery of recreated endpoints.

## Add production features one decision at a time

An `upstream` group can balance requests across backends. Verify that sessions and writes remain consistent when requests land on different instances. TLS termination requires a certificate chain and private key readable only to the appropriate account. A typical HTTPS server uses `listen 443 ssl;`, `ssl_certificate` and `ssl_certificate_key`; test hostname, trust and renewal. When a proxy passes client-address or protocol headers, the backend should trust them only from an authorized proxy path.

Proxy caching requires a cache key, expiration and a decision about which responses are safe to share. A cached authenticated response served to another user is a serious confidentiality failure. Rate limiting uses a shared zone and a key, often a verified client identity or address; choose units and bursts that preserve normal retries. A fleet behind one NAT may look like one client if IP is the only key. Start with measurement and observe rejected requests.

**Operations.** On a Linux host, install the distribution's Nginx package, test configuration with `nginx -t` under the intended privileges, then use the service manager's reload operation. A reload starts workers with the new configuration while old workers drain. Keep a known working file so an invalid edit can be reverted. For local teardown use `docker compose down` and retain or discard the named data volume as described in project 2.

**Practice.** Draw the precise client URL and upstream URI for both versions of the proxy directive. **Interview. Why can the homepage be green during an API outage?** It is a file response generated at the edge. A synthetic data-path request crosses the boundary that failed.

### Further reading

[Nginx proxy module](https://nginx.org/en/docs/http/ngx_http_proxy_module.html) · [Request processing](https://nginx.org/en/docs/http/request_processing.html) · [HTTPS configuration](https://nginx.org/en/docs/http/configuring_https_servers.html)
