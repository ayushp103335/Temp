# Part 10 · Web servers and infrastructure

**Study time:** 4–6 h including practice. **Starting point:** Parts 3 and 5 plus application architecture.

Diagnose reverse-proxy behavior and reason about durable queues, caches and source-of-truth data.

## What you will demonstrate

Run the proxy failure drill; design idempotent recovery for a worker that dies immediately before acknowledging a successful job.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
