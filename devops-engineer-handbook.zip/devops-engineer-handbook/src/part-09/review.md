# Part 9 review · Infrastructure as code and configuration management

## Revision and assessment

**Can a remote state lock prevent out-of-band console changes?**

It coordinates state writers using the backend. Other API clients can still cause drift.

## Practical assignment

Run the provider-free Terraform tests and two Ansible playbook runs. Inspect any unexpected replacement or second-run change.

## Mini-project and self-evaluation

Identify an immutable artifact, a managed cloud object and a guest file. Give each a single authoritative writer.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
