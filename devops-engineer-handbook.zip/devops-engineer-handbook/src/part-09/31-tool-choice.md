# 31 · Choose the right owner for an infrastructure change

**By the end** you can assign ownership of a cloud resource, a machine image and guest configuration, and explain the cost of two controllers managing the same property. Complete chapters 28–30. This design lab requires only the supplied Terraform and Ansible files.

A team asks whether to use Terraform, Pulumi, CloudFormation, the AWS Cloud Development Kit (CDK) or Packer. Start by naming the output. A machine image, a deployed network stack and a guest configuration file have different lifecycles. The right comparison is between tools owning the same outcome.

| Tool | Input and output | State and responsibility |
|---|---|---|
| Terraform | HCL modules describe provider-managed resources. | A backend stores bindings between configuration addresses and remote identities. |
| Pulumi | Programs in supported languages declare cloud resources. | An engine records a stack's state; language-level packaging and evaluation also need version control. |
| CloudFormation | A template describes an AWS stack. | AWS manages the stack lifecycle and reports resource events. A failed update can require rollback investigation. |
| AWS CDK | Constructs in a supported language synthesize CloudFormation templates. | Review the synthesized template and bootstrap resources in addition to the source. |
| Packer | A build template and provisioners produce an image artifact. | Image IDs and build provenance feed later deployment. Existing instances do not update automatically. |
| Ansible | Inventory, modules and templates express host changes. | Tasks observe targets; use rollout policy, backups and explicit ownership. |

## Lab · Map the ownership boundary

Read the provided Terraform AWS module and the Ansible local playbook. On paper design a change that updates the guest Python runtime while preserving the two-zone network.

1. Name the owner of the base image. In an image-based design, Packer installs and verifies Python during the image build, then emits an approved image ID.
2. Name the owner of the deployed VM. Terraform or a CloudFormation stack references that image ID. The plan must identify whether a change replaces instances and how clients are drained.
3. Name the owner of runtime configuration. Ansible may own a worker slot count, or deployment tooling can supply it at startup. Pick one authoritative writer.
4. Record recovery. Keep the previous image ID and compatible runtime settings. Verify both traffic and processing behavior after promotion.

**Worked conflict.** An autoscaler changes a group's desired count based on queue age. An infrastructure pipeline reapplies the original desired count every hour. The consequence is repeated capacity loss. Agree which controller owns that field and configure the other to model only its own bounds. Ignoring all changes to the entire group would also hide unexpected security and networking drift.

**Choosing among viable tools.** A small AWS-only team may value integrated stack events and CloudFormation change sets. A team with many providers may value Terraform's shared language or Pulumi's library model. Strong language familiarity helps, but the ability to review a plan, recover state, test provider updates and hand over operations matters just as much. Compare a concrete maintenance operation such as replacing a load balancer with an attached certificate.

**Practice.** Build a decision record with four rows: ownership, change preview, recovery and team operating cost. Explain what evidence would make you revisit the choice. A good answer can favor different tools for building an image and operating a VM.

**Interview. Does CDK remove the need to understand CloudFormation?** CDK synthesizes the underlying template. When deployment fails, the stack's resource events and replacement rules often provide the explanation.

### Further reading

[Pulumi concepts](https://www.pulumi.com/docs/iac/concepts/) · [CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html) · [AWS CDK](https://docs.aws.amazon.com/cdk/v2/guide/home.html) · [Packer](https://developer.hashicorp.com/packer/docs)
