# 30 · Converge host configuration with Ansible

**By the end** you can target an inventory, run a playbook twice and explain why a handler runs after a change. Use a Linux control machine with Python 3 and ansible-core. The supplied exercise connects only to localhost and writes to a private temporary directory.

Terraform can create a VM and assign its network identity. Ansible can configure packages, services and files inside that VM. A control node selects hosts from an **inventory**, connects using a plugin such as SSH or the local connection, and executes **tasks** using modules. A **play** associates hosts with tasks and variables. A **playbook** contains plays. Most Unix host modules expect a compatible Python interpreter on the managed host. Connection setup and privilege escalation are separate decisions.

Read `labs/ansible/inventory.ini`. The `training` group contains one host called local with local connection. In `site.yml`, the first task validates inputs. The file module ensures a private directory exists. The template module renders a Jinja template and changes the file when output or managed metadata differs. A changed result notifies the handler. Several tasks notifying the same handler generally trigger one run per handler flush. For training, the handler reports a change. A production service could reload validated configuration instead.

## Lab · Prove a second run is quiet

```bash
# Create a practice location and enter the Ansible example.
dest=$(mktemp -d)
cd labs/ansible
# Inspect the inventory and use an ad hoc module to check execution.
ansible-inventory -i inventory.ini --graph
ansible training -i inventory.ini -m ansible.builtin.ping
# Validate playbook syntax, apply the configuration and inspect the file.
ansible-playbook -i inventory.ini site.yml --syntax-check
ansible-playbook -i inventory.ini site.yml -e "lab_dir=$dest"
cat "$dest/worker.conf"
# Run again, then preview a deliberate change without applying it.
ansible-playbook -i inventory.ini site.yml -e "lab_dir=$dest"
ansible-playbook -i inventory.ini site.yml -e "lab_dir=$dest worker_slots=6" --check --diff
```

On the second ordinary run expect `changed=0`. The preview should propose a change to slots. The ping module verifies Ansible module execution rather than ICMP network reachability. Check mode support is module-specific; a successful preview cannot prove all runtime side effects or external dependencies. Diff mode may expose sensitive content. Disable sensitive logging where appropriate and verify that downstream logs do not capture those values.

Facts are observed host attributes available to a play. The sample disables gathering because the template needs no facts. Variables can come from inventory, group or host files, roles, plays and command-line overrides. Document which input is authoritative. A **role** groups tasks, templates, handlers, defaults and supporting files for a repeated capability. Galaxy distributes collections and roles. Review and pin third-party content just as you would a build dependency.

Dynamic inventory can discover current cloud instances by tags. Check the resolved host list before a write. Vault encrypts sensitive Ansible content at rest. Secure its unlock mechanism and control output once decrypted. For a fleet rollout, target a small batch with `serial`, verify the service after a change and stop expanding the rollout when a shared dependency fails.

**Troubleshooting.** “Unreachable” often points to connectivity, host-key trust, identity or interpreter selection. A task that reports changed every run may use a raw shell command, embed timestamps or change an unmanaged attribute. Compare the desired file and observed state before suppressing the changed signal.

**Practice.** Edit the rendered worker file by hand, run the playbook again and identify the exact task that reconciles drift. Reapply once more and verify zero changes.

**Interview. When would you bake a new machine image instead?** A large bootstrap with slow package installation or strong reproducibility needs can favor prebuilt images. Small runtime-specific configuration and secret delivery may still belong at provision or startup time.

### Further reading

[Ansible playbooks](https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_intro.html) · [Check and diff mode](https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_checkmode.html) · [Ansible Vault](https://docs.ansible.com/ansible/latest/vault_guide/index.html)
