# 28 · Infrastructure as Code and the meaning of state

**By the end** you can distinguish a desired configuration, an observed resource and the identity mapping between them. You can explain why a second reviewer must inspect the plan when a resource will be replaced. Use chapters 8 and 25.

Imagine two load balancers have the same label. A script says “create a load balancer named training.” If its first call succeeded but the response was lost, a retry could create another. An imperative approach specifies operations and must explicitly handle discovery, retry and compensation. A declarative configuration describes desired properties. An engine compares those properties to recorded and observed resources, then proposes changes. This changes where the complexity lives.

**State** records the association between a configuration address and a provider's resource identity, along with attributes required for planning. A successful state write matters: cloud-side creation and local bookkeeping can fail independently. **Drift** is a difference between intended or recorded configuration and the observed environment. A hotfix applied through a console may represent legitimate recovery. Blindly applying yesterday's desired state could reverse the repair.

## Lab · Reconcile a managed object without a cloud account

Install Terraform using the official instructions. Use a separate copy of the supplied local module so each learner has an independent state. The built-in `terraform_data` resource stores a small object in Terraform state and contacts no provider.

```bash
# Copy the local exercise and initialize its working directory.
iac=$(mktemp -d)
cp -r labs/terraform/local "$iac/module"
terraform -chdir="$iac/module" init
# Review a saved plan and apply exactly those operations.
terraform -chdir="$iac/module" plan -out=first.tfplan
terraform -chdir="$iac/module" apply first.tfplan
# Compare desired and recorded state again. Expect "No changes."
terraform -chdir="$iac/module" plan
terraform -chdir="$iac/module" state list
```

Repeat the plan with `-var=replicas=3`. Read which attribute changes and whether Terraform proposes replacement. Do not infer how a cloud VM changes from this built-in resource: each provider schema and API determines which attributes require replacement. This lab teaches the identity and planning model.

Idempotency means that repeated successful execution with unchanged inputs converges on the intended outcome. It is weaker than a guarantee of zero side effects for every implementation. A provisioner that sends an email or appends a line can break that expectation. A provider's polling and retry behavior also matters. A remote backend can make state shared and recoverable. Locking serializes cooperating state writers. It cannot prevent an administrator changing cloud resources through another interface.

## Change control and incident practice

Review the configuration change and the plan together. For a replacement, ask which data lives with the resource and what clients observe while it is replaced. Use consistent versions, keep state and saved plans confidential, and store code and state under separate access policies. Give each environment a deliberate state scope so a training cleanup cannot affect applications sharing a production state.

**Failure drill.** Assume a cloud create call succeeded and the runner died before recording the object. Inspect the provider inventory and state before retrying. If appropriate, import the known object to its intended address and review a fresh plan. Deleting the object or state reflexively can compound the incident.

**Practice.** Draw the configuration address, state binding and real resource ID for two environments. Name one policy that prevents cross-environment access and one backup that helps recover lost state.

**Interview. Does a zero-change plan guarantee healthy users?** It says the tool found no applicable configuration changes for its modeled resources and observations. Application correctness and data integrity need different checks.

### Further reading

[Terraform state](https://developer.hashicorp.com/terraform/language/state) · [Terraform plan](https://developer.hashicorp.com/terraform/cli/commands/plan)
