# Part 9 · Infrastructure as code and configuration management

**Study time:** 7–11 h including practice. **Starting point:** Cloud fundamentals, Git and Bash.

Review infrastructure plans, protect state and demonstrate idempotent host configuration.

## What you will demonstrate

Run the provider-free Terraform tests and two Ansible playbook runs. Inspect any unexpected replacement or second-run change.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
