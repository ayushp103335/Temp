# 29 · Terraform plans, providers and concurrency

**By the end** you can read an AWS configuration's dependency graph, use a remote backend and explain why a destructive plan requires human judgment. Use Terraform 1.10 or later for the S3 lockfile example. Chapter 28 supplies the zero-cost lab, and [project 4](../part-15/50-aws.md) supplies a complete AWS root module.

A **provider** implements the resource and data-source schemas and talks to an external API. A **resource** represents managed lifecycle. A **data source** reads external information, such as available zones. An **input variable** exposes a supported setting. A **local value** gives a reusable expression a name. An **output** publishes selected values to an operator or another consumer. A **module** is a directory of Terraform configuration; a root module can call child modules.

In `labs/terraform/aws/main.tf`, `local.zones` maps two zone names to subnet offsets. `for_each` creates stable addresses keyed by zone. The subnet calculation adds an offset to avoid overlapping public and private subnets. References from an instance to its subnet and security group imply dependencies. The load balancer also waits for public route associations, a dependency that cannot be inferred solely from its subnet ID list.

`count` is useful for interchangeable indexed instances. Removing a middle entry from a list used by index can shift identities. `for_each` is useful when each instance has a stable meaningful key. A dynamic block generates repeated nested blocks according to a collection. Prefer explicit blocks when there are just one or two fixed policies. A lifecycle rule such as `create_before_destroy` can reduce interruption only when names, quotas and dependencies permit overlap. Provisioners run imperative commands with weaker state and failure modeling than native resources. The example uses cloud-init boot data to install the VM's local unit.

## Lab · Encode a protection as a test

```bash
# Initialize, validate the configuration, and run the included isolated test runs.
tfdir=$(mktemp -d)
cp -r labs/terraform/local "$tfdir/local"
terraform -chdir="$tfdir/local" init
terraform -chdir="$tfdir/local" validate
terraform -chdir="$tfdir/local" test
# Ask for an invalid replica count. Variable validation should reject the plan.
terraform -chdir="$tfdir/local" plan -var=replicas=0
```

The test file asserts the default count and expects invalid input to fail. The built-in provider keeps this example local. Terraform tests using real providers can create billable resources. Read the module and its test command before invoking a suite.

## Remote state and imports

The S3 backend in the AWS project is partially configured. Copy the sample backend file and supply a private versioned bucket, region and a dedicated object key. Use `use_lockfile = true` for S3-native locking on supported versions. The backend also needs permission for its lock object. DynamoDB-based locking is deprecated in the current S3 backend documentation. Encrypt state, restrict readers and keep credentials outside backend configuration. A value marked sensitive can still be present in state and plans.

CLI workspaces provide separate state instances for one configuration/backend. They do not establish a strong security boundary. Separate accounts and credentials are stronger controls for production isolation. HCP Terraform, historically Terraform Cloud, offers remote execution, workspace state and team governance capabilities. Decide where providers execute and which identity they use. To adopt an existing object, create its configuration, use an import block or the supported `terraform import ADDRESS ID` form, then inspect the plan for unexpected changes. Import does not prove your declared properties match reality.

**Troubleshooting.** On a lock error, identify the active or interrupted writer before taking action. For a surprising replacement inspect the exact changed attribute, provider version and object identity. A new latest-AMI lookup can change a VM plan without any code edit. Capture and promote an approved AMI identifier for controlled releases.

**Practice.** Add a validation that a proposed port lies between 1 and 65535. Test both bounds and one invalid value without contacting AWS.

**Interview. Why retain the provider lockfile?** It records provider selections and checksums for reproducibility. It does not freeze remote data-source results or replace state locking.

### Further reading

[S3 backend and locking](https://developer.hashicorp.com/terraform/language/backend/s3) · [Terraform testing](https://developer.hashicorp.com/terraform/language/tests) · [Terraform modules](https://developer.hashicorp.com/terraform/language/modules)
