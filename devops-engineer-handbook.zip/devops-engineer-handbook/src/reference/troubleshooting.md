# Field reference · Troubleshooting by symptom

Begin with a timestamp, the affected user operation, scope and the last known good observation. Prefer a read-only test that distinguishes plausible causes. Record the result before selecting a mitigation.

| Symptom | First discriminating observation | Next decision |
|---|---|---|
| Shell command works manually and fails in a service | Compare working directory, effective identity, interpreter path and environment. | Correct the unit or file access; repeat under the actual service identity. |
| Application cannot create a file despite free space | Compare mount, inode count, quota, mode and read-only flags. | Fix the specific exhausted or inaccessible resource. |
| Disk stays full after deleting a log | Inspect open deleted files and filesystem boundaries. | Coordinate log reopen/rotation or address the correct volume. |
| DNS resolves but connection is refused | Inspect the target listener and bind address from its own network context. | Correct the listener or target address. |
| TLS verification fails | Check the served hostname, chain, trust root and clock. | Correct certificate delivery and validate a fresh connection. |
| Edge page works; API returns 502 | Compare static route with upstream address, name resolution and port. | Restore proxy-to-application connectivity. |
| API returns 503 on a cache miss | Check database availability, authentication, schema and pool pressure. | Test a fresh connection and a representative read. |
| Cache seems empty after every request | Inspect TTL, key convention, write failures and instance selection. | Fix the failing cache path and measure source-of-truth load. |
| Image works locally, fails after deployment | Compare digest, CPU architecture, entry command, runtime UID and mounts. | Reproduce the target runtime contract. |
| Pod is Pending | Read scheduler events and PVC state. | Resolve placement, resources or storage before debugging application code. |
| Pod is Ready but public endpoint fails | Check Service endpoints, ingress/gateway status, host/path and TLS. | Repair the first failing hop, then retest the public operation. |
| GitOps reverses an incident edit | Compare current Git revision, live object and controller ownership. | Commit the intended state or use the documented emergency process. |
| CI job cannot see prior-stage output | Inspect artifact declaration, retention, dependency and permissions. | Transfer the retained candidate explicitly. |
| Terraform wants unexpected replacement | Review the changed field, provider schema/version and data-source output. | Reconcile actual ownership and data implications before apply. |
| Prometheus alert never arrives | Follow raw series → expression → pending/firing → Alertmanager route → receiver. | Fix the first missing transition and rehearse recovery. |
| Loki query finds no record | Check source file, collector permission/position, backend and time range. | Preserve source and cursor while diagnosing delivery. |
| Cost rises while throughput stays flat | Compare retries, storage age, transfer, autoscaling and allocation. | Optimize the measured driver, then verify user SLOs. |

For a worked incident with a capacity calculation, see [chapter 46](../part-14/46-incidents.md).
