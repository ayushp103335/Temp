# Glossary

| Term | Operational meaning |
|---|---|
| Admission | A decision about whether a proposed resource may enter a managed system. |
| Artifact | Identifiable output retained from a build, such as a wheel, archive or image. |
| Attestation | A statement about a subject, often signed and bound to an artifact digest. |
| Availability zone | A provider-defined location designed to isolate some failures within a region. |
| Backpressure | Slowing or limiting producers when downstream work cannot keep up. |
| Blast radius | The users, data or systems a failure or change can affect. |
| Canary | Limited exposure of a candidate version so its behavior can be evaluated before wider rollout. |
| CIDR | Notation combining an IP address and a prefix length to express an address range. |
| Commit | A Git snapshot with metadata and parent references. |
| Container | An isolated running process or group of processes using a host kernel. |
| Context | A saved environment selection such as a Kubernetes cluster, identity and default namespace. |
| Control plane | Components that decide or coordinate desired behavior. |
| Data plane | Components that serve traffic or execute workload behavior. |
| Deployment | In Kubernetes, a controller-managed declaration of replicated application Pods and updates. |
| Digest | A content-derived fingerprint used to identify bytes. |
| Drift | A difference between declared, recorded or observed infrastructure state. |
| Error budget | The failure allowance implied by a reliability objective and its measurement window. |
| Executor / runner / agent | An execution environment or slot that runs build work; exact meanings vary by product. |
| Failure domain | A boundary within which a single fault may affect several resources. |
| File descriptor | A process-local handle referring to an open file, socket, pipe or related kernel object. |
| Golden path | A supported, repeatable route for a common developer task. |
| HPA | Horizontal Pod Autoscaler, a controller that adjusts workload replica count using metrics. |
| IaC | Infrastructure as code, storing and applying infrastructure definitions through versioned source. |
| Idempotent | Repetition under unchanged inputs reaches the intended outcome without unintended additional effects. |
| Ingress | An entry path; in Kubernetes, also an API for HTTP routing through a controller. |
| Least privilege | Granting only the actions, resource scope and duration required by the task. |
| Namespace | Scope for names and policies; the precise meaning differs between Linux and Kubernetes. |
| OCI | Open Container Initiative, which specifies image, distribution and runtime standards. |
| Outbox | A durable event record written in the same transaction as the business change it announces. |
| Pod | Kubernetes scheduling unit containing one or more containers sharing selected resources. |
| Probe | A check used to evaluate startup, readiness or liveness. |
| Provenance | Evidence describing where and how an artifact was produced. |
| Reconciliation | Repeated comparison and correction of observed state toward desired state. |
| Replica | An additional instance of a service or data copy; application and database semantics differ. |
| RPO / RTO | Maximum tolerable data-loss window / target time to restore usable service. |
| SBOM | Software bill of materials, an inventory of components detected or declared in an artifact. |
| Secret | A credential or other value whose disclosure would compromise protected access or confidentiality. |
| Service account | An identity used by a workload or automation rather than an individual person. |
| SLI / SLO / SLA | Measured service indicator / target for that indicator / contractual service commitment. |
| Span | A timed operation in a distributed trace with identifying context and attributes. |
| State lock | A coordination mechanism that prevents simultaneous cooperating writers to infrastructure state. |
| Synthetic transaction | A deliberately generated request or workflow used to verify service behavior. |
| Taint / toleration | A Kubernetes scheduling constraint on a node / a Pod's permission to tolerate it. |
| TTL | Time to live, an expiry duration for data such as a cached result or DNS record. |
| Unit cost | Allocated cost per meaningful business output, such as one thousand successful jobs. |
