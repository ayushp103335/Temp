# Field reference · Commands

Use these as observations in a specific environment. Uppercase words such as UNIT and CONTEXT stand for values you must select. Check the current directory, target account and cluster context first. A command's return status is often as important as its text output.

| Question | Command | Read the result |
|---|---|---|
| Where am I and under which identity? | `pwd`, `id`, `command -v python3` | Directory, effective user/groups and interpreter selected by the shell. |
| Who can reach this file? | `ls -ld PATH`, `stat PATH` | Inspect parent traversal as well as the file mode and owner. |
| Is the host out of space? | `df -h PATH`, `df -i PATH`, `findmnt -T PATH` | Identify the actual filesystem, bytes and inodes. |
| What stopped? | `systemctl status UNIT`, `journalctl -u UNIT -n 50` | Find the first failing start and its evidence. |
| Which program is listening? | `ss -ltnp` | Address, port and available process identity information. |
| Is name resolution the issue? | `getent hosts NAME`, `dig NAME A` | Compare configured system lookup with DNS directly. |
| Did HTTP respond? | `curl -i --max-time 5 URL` | Status, response headers and actual body. |
| What changed in Git? | `git status --short`, `git diff`, `git diff --staged` | Separate working changes from the proposed snapshot. |
| What did the build deliver? | `sha256sum FILE`, `tar -tf ARCHIVE` | Digest and archive members. Retain the trusted manifest. |
| Is the right Docker daemon selected? | `docker context show`, `docker version` | Local configuration and reachable server version. |
| Which Compose service failed? | `docker compose ps -a`, `docker compose logs --tail 30 api` | Running/stopped state and scoped startup errors. |
| What will Kustomize apply? | `kubectl kustomize labs/kubernetes/overlays/staging` | Fully rendered manifests, with no cluster mutation. |
| Where is a Pod stuck? | `kubectl --context CONTEXT -n NS describe pod POD` | Events, scheduling, image pulls, probe and termination state. |
| Which Kubernetes revision progressed? | `kubectl --context CONTEXT -n NS rollout status deploy/NAME` | Deployment progress; follow up with a user-level check. |
| What will a chart create? | `helm lint CHART`, `helm template pilot CHART` | Chart lint and rendered manifests. |
| Which AWS identity is active? | `aws sts get-caller-identity --profile training` | Account and principal; region for subsequent commands is separate. |
| What will Terraform change? | `terraform plan -out=review.tfplan`, `terraform show review.tfplan` | Planned actions and affected resources; protect the plan file. |
| Did Ansible converge? | `ansible-playbook -i inventory.ini site.yml -e "lab_dir=$dest"` | Compare changed counts on successive runs with the same input. |
| Can Prometheus parse these rules? | `promtool check rules labs/observability/rules.yml` | Rule grammar and validity; live alerts require runtime evidence. |
| Is the training service returning the right result? | `bash labs/docker/smoke.sh` | Bounded HTTP check of synthetic business counts through the edge. |

For full setup, failure expectations and cleanup use the corresponding chapters. Commands that restart services, rotate identities or destroy data need their chapter's context.
