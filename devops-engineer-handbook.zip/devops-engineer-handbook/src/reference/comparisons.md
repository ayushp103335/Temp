# Technology comparisons and decision guide

| Decision | Option A | Option B | Evidence to collect |
|---|---|---|---|
| Deployment unit | VM for a distinct OS/kernel boundary | Container for portable userspace packaging | Kernel requirements, operator skills and recovery time. |
| Local orchestration | Compose for a single-host development stack | kind for testing Kubernetes APIs locally | Is the goal to exercise dependencies or cluster reconciliation? |
| Application packaging | Helm for a chart with public inputs and release history | Kustomize for variants of concrete manifests | Review rendered output and who owns environment changes. |
| Delivery system | Hosted Actions or GitLab runners | Jenkins with managed controller and agents | Network reach, isolation, maintenance effort and required integrations. |
| Release strategy | Blue-green for rapid traffic switchback | Canary for cohort-based comparison | Spare capacity, representative volume and compatible shared state. |
| Machine lifecycle | Terraform provisions resources | Ansible configures host state | Which API owns each property, and how is drift detected? |
| Message transport | RabbitMQ for work distribution and acknowledgment | Kafka for partitioned replayable logs | Delivery semantics, retention, order and consumer independence. |
| Data system | Relational database for transactions and authoritative state | Redis for fast derived data under an explicit expiry policy | Recovery guarantee, latency and effects of cache loss. |
| Log backend | Search indexes for broad field-based investigation | Loki streams for label selection plus log filtering | Query mix, cardinality, retention and operating cost. |
| GitOps | Argo CD application model | Flux composable source and reconciliation resources | Tenant boundaries, operational workflows and integration needs. |
| Service security | Mesh transport identity and common policy | Application-level identity and authorization | Who authenticates the caller, and who authorizes each protected record? |
| Cloud portability | Provider-native managed services | Portable runtime and standard interfaces | Recovery test, team expertise and total lifecycle cost. |

A defensible decision names the workload, its failure boundary, the option chosen, the most important trade-off and one measurable condition that would justify revisiting it.
