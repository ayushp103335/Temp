# Curriculum and study route

All 58 numbered chapters are included. Chapters 47–56 are the ten portfolio projects. The estimates below include reading and practice and are planning ranges, not deadlines. A cloud lab can take longer if account access or quotas are still being arranged.

| Part | Chapters | Study time | Deliverable |
|---|---|---|---|
| [1 · DevOps fundamentals](part-01/overview.md) | 01–03 | 3–5 h | Produce a release record containing the previous digest, candidate digest, check result, rollout stop rule and rollback observation. |
| [2 · Linux and system administration](part-02/overview.md) | 04–06 | 6–9 h | Restore the chapter 6 fixture into a new directory, prove byte equality and run the application against it. |
| [3 · Networking fundamentals](part-03/overview.md) | 07–07 | 3–5 h | Write a three-case diagnostic report using a good response, a missing path and a stopped listener. |
| [4 · Git and development fundamentals](part-04/overview.md) | 08–10 | 6–9 h | Submit a reviewed change to the inventory parser, retain its tested artifact and show the failure for malformed input. |
| [5 · Containerization](part-05/overview.md) | 11–13 | 5–8 h | Run project 2 and save a cache hit, a successful fallback and a database-unavailable response. |
| [6 · Kubernetes](part-06/overview.md) | 14–19 | 10–15 h | Render two overlays, deploy the staging service in a dedicated cluster and prove it recovers from one Pod loss. |
| [7 · CI/CD and automated delivery](part-07/overview.md) | 20–24 | 7–11 h | Compare the GitHub, Jenkins and GitLab configurations. Trace one candidate from source to evidence across runner boundaries. |
| [8 · Cloud computing](part-08/overview.md) | 25–27 | 5–8 h | Design a two-zone cloud deployment and calculate surviving capacity and billable resource-hours for a rehearsal. |
| [9 · Infrastructure as code and configuration management](part-09/overview.md) | 28–31 | 7–11 h | Run the provider-free Terraform tests and two Ansible playbook runs. Inspect any unexpected replacement or second-run change. |
| [10 · Web servers and infrastructure](part-10/overview.md) | 32–33 | 4–6 h | Run the proxy failure drill; design idempotent recovery for a worker that dies immediately before acknowledging a successful job. |
| [11 · Monitoring, logging and observability](part-11/overview.md) | 34–37 | 6–10 h | Run the alert drill and a log query for a single synthetic failure. Annotate the trace critical path of an example request. |
| [12 · DevSecOps and security](part-12/overview.md) | 38–40 | 5–8 h | Review a release workflow and its image, write an exception with expiry and verify the signer decision for a known digest. |
| [13 · GitOps and platform engineering](part-13/overview.md) | 41–43 | 5–8 h | Review and revert a digest change in a practice GitOps environment. Specify the guardrails a platform should offer other teams. |
| [14 · SRE and production engineering](part-14/overview.md) | 44–46 | 5–8 h | Run a fault drill, publish an incident timeline and compute cost per successful outcome before and after a proposed change. |
| [15 · Real-world projects](part-15/overview.md) | 47–56 | 35–55 h | Choose two projects that share a dependency. Change one interface, show which test catches the incompatibility and recover the system. |
| [16 · Interview and career preparation](part-16/overview.md) | 57–58 | 4–7 h | Deliver a twenty-minute design interview and have a colleague follow one project's README from a clean checkout. |

## Choosing a pace

For a team cohort, use two sessions per part: one guided walkthrough and one independent failure drill. Run project 1 after Linux, project 2 after Compose, and projects 3–6 after CI, AWS and IaC. Projects 7–9 use the observability and security parts. Begin project 10 only after its prerequisite projects and cost review. Existing practitioners can start at a part review, then read the chapters behind any task they cannot demonstrate.

The [validation record](validation.md) explains which labs were run and which require independent environment checks.
