# 23 · GitLab CI/CD and the life of an artifact

**By the end** you can trace artifacts between GitLab jobs, distinguish a cache from a release record and review a deployment rule. Use chapters 10 and 20. The included pipeline can run in a disposable GitLab project with a runner that supports container images.

A pipeline usually starts from a repository event and reads `.gitlab-ci.yml`. Runners accept eligible jobs according to registration, permissions, tags and executor type. An image setting supplies a container environment on a compatible executor such as Docker or Kubernetes. A shell executor uses the host's tools. A job that works under one executor can fail under another despite identical YAML.

The example has three stages. Contract tests run first. A package job retains the Python program and its checksum under `dist/`. The verify job explicitly requests that artifact through `needs`, checks the digest and exercises the delivered program with the repository's synthetic fixture. The example keeps releases for seven days for teaching purposes; long-lived releases need a retention period compatible with rollback and audit requirements.

## Lab · Rehearse inter-job transfer on a single host

```bash
# Prepare isolated directories representing two different runner workspaces.
glab=$(mktemp -d)
mkdir -p "$glab/build/dist" "$glab/verify"
cp labs/release/service.py "$glab/build/dist/"
(cd "$glab/build/dist" && sha256sum service.py > SHA256SUMS)
# Simulate the transfer of the declared artifact directory.
cp -r "$glab/build/dist" "$glab/verify/"
(cd "$glab/verify/dist" && sha256sum -c SHA256SUMS)
python3 "$glab/verify/dist/service.py" labs/release/jobs.json
```

If the package retained only the checksum, the verify job would fail because the referenced file was absent. For a hosted run copy `labs/cicd/gitlab-ci.yml` to `.gitlab-ci.yml` in your own practice repository, review it with the CI Lint facility, commit and inspect the three job logs. If using a runner with required tags, specify a matching tag in the job configuration.

Variables configure destinations and nonsecret build options. Protected and environment-scoped variables can supply trusted jobs with sensitive settings where appropriate. A masked variable reduces accidental display; code granted the variable can still use it. Protect production branches, environment promotion and runner identities. GitLab Container Registry stores images. GitLab's job registry credentials can authenticate within their scope, but use an explicit digest to select what deploys.

A cache reduces repeated downloads and can be evicted. Artifacts intentionally connect builds and jobs. Environments organize deployment history and destinations. A manual job can gate promotion; a review environment can be created for a branch and torn down when the branch closes. Security scanning integrations depend on the GitLab edition and configuration; inspect the reports and enforcement behavior of the specific deployment.

**Troubleshooting.** A job stuck pending needs a matching available runner. An expired artifact cannot be retrieved just by restarting the consuming job. Regenerate or recover the trusted candidate and make the new identity explicit. A missing executable in a shell job is an agent provisioning issue.

**Practice.** Make the artifact lifetime shorter than the expected production approval interval on paper. Describe the resulting failure and propose a release registry or longer retention with ownership and cleanup.

**Interview. Would sharing a cache key promote a package safely?** Caches are replaceable performance aids. Promote a named, retained artifact whose identity and verification record you can check.

### Further reading

[GitLab CI/CD YAML reference](https://docs.gitlab.com/ci/yaml/) · [Job artifacts](https://docs.gitlab.com/ci/jobs/job_artifacts/) · [Runner executors](https://docs.gitlab.com/runner/executors/)
