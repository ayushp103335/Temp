# 21 · GitHub Actions and the deployment boundary

**By the end** you can follow an event through a workflow, identify which job can publish a package and explain how the deployment obtains its artifact. Use the complete `labs/cicd/dashboard-ci.yml` and [project 3](../part-15/49-delivery.md). Reading and local testing require no GitHub credentials.

A workflow is a YAML file in `.github/workflows/`. An event such as a pull request or a push starts a run. Each job runs on its assigned runner. Steps within a job share its workspace, while a later job generally starts with a fresh workspace. `needs` establishes ordering and exposes declared outputs. Files on a runner do not magically appear on the next one. Transfer them as artifacts or use a registry. Use environment or repository variables for nonsecret settings, and secrets or short-lived identity for sensitive access.

## Read the supplied workflow as a permission table

| Job | Trigger or dependency | Authority and evidence |
|---|---|---|
| test | Pull request, matching push, or manual run | Read source, run unit tests and start disposable dependencies. No publishing privilege. |
| publish | Trusted main revision after test | Write a package. Build the candidate, exercise its exact local image, push it, capture its registry digest. |
| deploy | Successful publication | Read the package, select the published digest, exercise it on a fresh training target and record the verified identity. |

The test branch can propose changes to code and tests. Production credentials must never be necessary to exercise a pull request from an untrusted branch. The protected environment called `training` can enforce reviewer or branch rules if configured in the repository and supported by its plan. A name in YAML alone does not establish those protections. An ephemeral hosted runner gives this lab a disposable deployment target. A persistent production environment needs its own scoped identity and cleanup policy.

## Lab · Trace one concrete value

Open the workflow and locate `steps.publish.outputs.image`. Work backward to the write to `GITHUB_OUTPUT`, then forward through the job output to the consuming deployment. Check the `--no-build` setting. A deploy job allowed to rebuild the image would weaken the link between its digest and the upstream smoke test.

```bash
# Exercise the local logic that runs before the hosted integration job.
python3 -m venv .venv
.venv/bin/python -m pip install -r labs/docker/app/requirements.txt
(cd labs/docker/app && ../../../.venv/bin/python -m unittest -v)
# Inspect the exact workflow path the project tells you to enable.
ls labs/cicd/dashboard-ci.yml
```

A matrix expands a job into several combinations, useful for testing supported Python versions. Choose combinations you promise to support. A cache keyed by the lockfile speeds dependency installation. A retained test report is a workflow artifact. A reusable workflow invoked via `workflow_call` can standardize permissions and release steps across repositories. Version it and document the interface as carefully as the service interface.

Self-hosted runners can reach internal targets and specialized hardware. That reach also gives untrusted jobs potential access to sensitive networks or persistent files. Separate trust domains, isolate runners and prefer disposable workers. For hardened use, pin third-party actions to reviewed immutable commit SHAs and rotate pins through reviewed updates. The examples use readable major-version tags; inspect resolved revisions before adapting them to production.

**Troubleshooting.** A job skipped after a pull request may be the intended reference guard. A 403 during push calls for checking package authority and repository package linkage. A successful upload that cannot deploy may indicate the next job lacks package read access.

**Practice.** Add a matrix only to the unit-test stage in a copy. Decide which single job is responsible for publishing to avoid duplicate writers for one tag.

**Interview. How do users approve exactly what was tested?** Show the commit, registry digest and successful gate results. Bind the deployment to that digest and restrict who can change the workflow or override its environment rules.

### Further reading

[GitHub Actions workflow syntax](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax) · [Deployment environments](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments) · [GitHub Actions security](https://docs.github.com/en/actions/security-for-github-actions)
