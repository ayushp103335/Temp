# 20 · Design a pipeline around release evidence

**By the end** you can draw the decision made at each stage, identify which test belongs before packaging and explain where an approval gate adds value. You need chapters 1–3, 8, 10 and 13.

## Start at the deployment decision

A request arrives to deploy a change to the status dashboard. The person approving it needs answers to four questions. Is the change authorized? Did the code behave correctly? Was the deployable artifact tested with its runtime dependencies? Can the operator identify and recover the exact prior version? A pipeline turns these questions into repeatable checks and records evidence with a commit and an artifact.

A **unit test** isolates one behavior, such as returning a cached summary without a database lookup. An **integration test** exercises real boundaries, such as PostgreSQL authentication and a query. A **smoke test** is a narrow check that a deployed system's critical path works. A frontend that returns HTTP 200 while its data request returns 503 should fail the dashboard smoke test. Code-quality gates and security scans supply additional evidence with explicit failure policies.

```mermaid
flowchart TD
  Source["Reviewed source revision"] --> Tests["Contract tests"]
  Source --> Checks["Static checks and dependency review"]
  Tests --> Build["Build identified artifact"]
  Checks --> Build
  Build --> Trial["Run artifact against dependencies"]
  Trial --> Gate{"Release conditions met?"}
  Gate -->|Yes| Deploy["Select digest and verify outcome"]
  Gate -->|No| Hold["Retain results and stop"]
```

## Timing feedback and preserving identity

Independent checks can run in parallel, but publishing must depend on the checks the release policy requires. A cache hit can skip repeated downloads. A recorded artifact must survive the runner's temporary workspace. Let fast deterministic checks block bad changes early and place high-cost integration checks where they catch actual packaging failures. Keep the final candidate by digest so a delayed approval cannot move the release to a different build.

### Lab · Run a two-stage pipeline yourself

```bash
# Stage one verifies the contract in source form.
python3 -m unittest discover -s labs/release -p 'test_*.py' -v
# Stage two retains tested bytes, then runs the candidate through its public CLI.
stage=$(mktemp -d)
bash labs/release/promote.sh labs/release/service.py "$stage"
python3 "$stage/current" labs/release/jobs.json
# Record the artifact identity alongside its observed result.
sha256sum "$stage/current"
```

Write down a condition this pipeline cannot detect. One answer is a missing database table in the full dashboard. Add `bash labs/docker/smoke.sh` after starting the Compose environment from chapter 13. The smoke check polls with bounded waits and compares actual JSON to the expected synthetic counts. A connection error at startup may be transient. A successful response with the wrong business result fails immediately.

**Field decision.** A flaky smoke test fails 5% of healthy releases. Unlimited reruns until success conceal regressions. Capture timings and failure reasons, assign an owner, distinguish startup readiness from application defects and cap retries. A temporarily quarantined test needs a replacement decision rule and an expiry.

**Practice.** Design a manual approval for a schema migration. Name what evidence the approver sees, what identity they approve, what happens when approval expires and who can stop the rollout.

**Interview. If a pipeline passes, is production healthy?** It establishes only the covered checks under their tested conditions. The release still requires observations from the actual target and a defined response to failure.

### Further reading

[DORA on continuous integration](https://dora.dev/capabilities/continuous-integration/) · [GitHub Actions concepts](https://docs.github.com/en/actions/concepts) · [Google SRE on canarying](https://sre.google/workbook/canarying-releases/)
