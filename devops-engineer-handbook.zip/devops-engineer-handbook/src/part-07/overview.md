# Part 7 · CI/CD and automated delivery

**Study time:** 7–11 h including practice. **Starting point:** Git, build artifacts and containers.

Design a gate, transfer an identified artifact and evaluate a candidate using user outcomes.

## What you will demonstrate

Compare the GitHub, Jenkins and GitLab configurations. Trace one candidate from source to evidence across runner boundaries.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
