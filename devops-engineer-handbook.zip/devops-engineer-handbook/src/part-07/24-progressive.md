# 24 · Progressive delivery and supply-chain evidence

**By the end** you can define a canary decision, calculate pipeline duration, and distinguish an inventory from evidence of build origin. Use chapters 2, 10 and 20–23.

## Optimize the critical path

Suppose unit tests take 3 minutes, static checks take 4, a build takes 5 and a smoke test takes 2. Serial execution takes 14 minutes. If tests and static checks run together, both must finish before the build begins, giving 4 + 5 + 2 = 11 minutes under sufficient runner capacity. Parallel jobs that saturate one small runner might make both slower. Measure queue time, execution time and artifact transfer separately. Cache dependency downloads by toolchain and lockfile. Preserve the ability to rebuild from an empty cache.

The output of a deployment pipeline should identify which change went where, why it qualified and which observations followed. A pull-based GitOps system stores desired deployment state in version control and reconciles the target toward it. CI publishes the image and proposes a manifest update selecting its digest. A controller authorized for that environment applies it. Reverting the desired-state change can keep the controller from repeatedly reapplying a bad release. Any data migration still needs its own recovery plan.

## Worked canary · A baseline can hide a small bad cohort

A candidate serves 250 requests with five errors. The baseline serves 9,750 with ten errors. Across all requests the error rate is 15/10,000, or 0.15%. The candidate rate is 2%; baseline is about 0.103%. A global threshold of 1% would miss the candidate's regression. Compare the same user operation over similar time windows, and examine both request count and error count. A small canary may see no rare operations. Choose an adequate window and a maximum time you will wait before holding for review.

A blue-green cutover makes switching back fast if both groups have sufficient capacity and share compatible state. A rolling update limits simultaneous replacement. A canary evaluates candidate behavior on limited traffic. A controller can automate the stop rule, but someone must decide how to handle missing telemetry. Treat missing samples as an unknown outcome and use a bounded hold. Automatically promoting during a monitoring outage removes your decision evidence.

## Lab · Compute an explicit gate

```python
# Save as gate.py in a disposable directory and run with python3 gate.py.
def rollout_decision(requests, errors):
    if not 0 <= errors <= requests:
        raise ValueError("inconsistent counters")
    if requests < 200:
        return "hold: insufficient traffic"
    if errors / requests > 0.01:
        return "rollback: candidate exceeds one percent"
    return "eligible for next step"

for sample in [(0, 0), (250, 5), (1000, 2), (200, 2)]:
    print(sample, rollout_decision(*sample))
```

The last case is exactly 1%, which is eligible under this strict “greater than” example. Decide whether that matches the written policy. A production gate should also check latency, correctness, baseline health, remaining capacity and migration compatibility. Record which version created the observation.

## What belongs in a trusted release?

| Evidence | Question answered | Additional check needed |
|---|---|---|
| SBOM, or software bill of materials | Which components did the inventory tool identify? | Is coverage complete and is an affected component reachable? |
| Vulnerability report | Which known findings matched the scanned inputs at scan time? | Who owns triage, exceptions and updates? |
| Provenance attestation | Which builder and declared inputs produced this artifact? | Does a verifier trust that identity and match the digest? |
| Signature | Which approved identity signed a statement or artifact digest? | Does deployment actually enforce verification and policy? |
| SLSA build requirements | Which supply-chain protections are expected at a given build level? | Does the actual build process provide the required evidence? |

Protect workflow source and release identities, isolate untrusted jobs, use short-lived credentials and keep release evidence with the artifact. Pinning an image digest prevents tag movement from silently changing deployment; it does not establish that the original build was authorized.

**Practice.** An operator approved a digest on Monday and the deployment ran on Wednesday after a new vulnerability was disclosed. Decide which checks are immutable historical evidence and which must be evaluated again at deployment time.

**Interview. What happens if automated rollback keeps oscillating?** Stop automatic promotion, retain a known viable version, cap retries and identify whether the triggering signal is reliable. Keep the change record and protect the remaining capacity.

### Further reading

[SLSA specification](https://slsa.dev/spec/) · [OpenGitOps principles](https://opengitops.dev/) · [Google SRE canarying releases](https://sre.google/workbook/canarying-releases/) · [SPDX specifications](https://spdx.dev/use/specifications/)
