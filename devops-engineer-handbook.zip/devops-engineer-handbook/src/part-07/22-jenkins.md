# 22 · Jenkins controllers, agents and Pipeline as Code

**By the end** you can explain a queued build, assign the correct agent and preserve a tested artifact after its workspace goes away. Use the release lab and `labs/cicd/Jenkinsfile`. Running the hosted portion requires a separately administered Jenkins LTS controller and a Linux agent with Git, Python 3 and GNU coreutils.

A controller schedules builds and stores job configuration and build history. Agents supply execution resources. An executor is a slot on an agent that can run work. A queued build requesting the label `linux-python` waits until a matching online executor is available. Free space or spare CPU on a differently labelled agent cannot satisfy the request. Keep builds off the controller and restrict which jobs may use privileged agents.

A freestyle project stores build steps primarily in the job configuration. Pipeline as Code stores steps in version control as a Jenkinsfile, so changes can be reviewed alongside the application. A Declarative Pipeline has structured blocks such as `pipeline`, `agent`, `stages` and `post`. Scripted Pipeline expresses control flow in Groovy, typically inside `node` blocks. More flexibility can make a release policy harder to inspect.

## Lab · Connect one repository to one job

1. Install a supported Jenkins LTS using the distribution's official instructions. Match its Java requirement to that LTS release. Complete initial setup on a private interface and create named operator accounts.
2. Install the needed Pipeline and Git plugins through the controller's managed plugin process. Register an isolated Linux agent with label `linux-python`. Verify it can run the local commands below.
3. Create a Pipeline job and choose **Pipeline script from SCM**. Select the lab repository and the script path `labs/cicd/Jenkinsfile`. Use a narrowly scoped read credential if the repository is private.
4. Run the job. Inspect the Contract stage, then Package. Download `service.py` and `SHA256SUMS` from the archived artifacts. Verify the digest in their directory.
5. Stop or disconnect the lab agent during an idle period, trigger another run and inspect the queue reason. Reconnect it and observe scheduling. Remove the disposable job and agent when finished.

```bash
# On the intended agent, test its available binaries and source contract.
python3 --version
git --version
python3 -m unittest discover -s labs/release -p 'test_*.py' -v
```

The Pipeline sets a ten-minute timeout. `archiveArtifacts` retains outputs outside the build workspace according to job retention. `fingerprint` records identity information useful for tracking use. The `post` block always runs its final step. The package stage here verifies that the copied service matches its checksum. A real deployment gate also exercises the retained package.

## Distributed build design

Docker-based agents can supply consistent toolchains. Kubernetes agent plugins can allocate ephemeral Pods per job. Both need explicit handling of workspaces, networking, image provenance and exit cleanup. Controlling a host Docker socket can grant broad host-level authority. Reserve privilege for narrow, trusted jobs. Restrict credential IDs to their intended folders or jobs, inject secrets only around the steps that need them and keep their values out of shell tracing. Masking a secret in console output cannot make arbitrary job code trustworthy.

Shared libraries let teams version common build and release operations. A library upgrade affecting all pipelines needs review and a rollout plan. Track plugin compatibility, back up relevant controller state and rehearse recovery. “Works on my controller” frequently means an undocumented plugin or agent tool version is missing elsewhere.

**Practice.** Draft a reasoned response to “Jenkins is slow.” Distinguish queue delay, checkout delay, dependency download and actual test duration. Each requires a different fix.

**Interview. A job succeeds but downstream deployment finds no file. Why?** A later stage may run on another agent, a workspace may have been cleaned, or the output was never archived or published. Transfer an identified artifact explicitly.

### Further reading

[Jenkins installation](https://www.jenkins.io/doc/book/installing/) · [Pipeline syntax](https://www.jenkins.io/doc/book/pipeline/syntax/) · [Jenkins security](https://www.jenkins.io/doc/book/security/)
