# Part 7 review · CI/CD and automated delivery

## Revision and assessment

**Why is a cached dependency directory unsuitable as the only release artifact?**

A cache can be evicted, replaced or keyed for reuse. The release needs retained identified bytes and associated checks.

## Practical assignment

Compare the GitHub, Jenkins and GitLab configurations. Trace one candidate from source to evidence across runner boundaries.

## Mini-project and self-evaluation

Name who can publish, who can deploy, what runs on a pull request and which signal would stop a canary.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
