# The Complete DevOps Engineer Handbook

**Zero to Professional**  
A practical guide to DevOps, cloud, automation, CI/CD, containers, Kubernetes, infrastructure as code, and site reliability engineering.

At 09:05 a clinic uploads a synthetic test fax. The API accepts it immediately. Six minutes later the dashboard still says *processing*. The web server is up. Is the release healthy?

Keep that question in mind. It forces us to follow a piece of work across several boundaries. Someone must build the software, put the correct version on a machine, preserve accepted work through restarts and see when the user stops getting results. These are the problems this book uses to teach DevOps. All examples use invented job identifiers and counts.

## How to study

Read with a terminal open. First predict what a command will show, then run it, then explain a difference you observed. Save evidence in a personal notebook: a command, a short result, and the decision it supports. As you progress, deliberately break one thing in a disposable directory and recover it.

Start with Linux, macOS with a Linux VM, or Windows with Ubuntu on WSL2. A terminal is the window in which you type commands. Bash is the program that interprets them. An ordinary user account is enough for the first labs. Use a Linux VM for the systemd and disk administration exercises. The labs call for GNU tools when their flags are Linux-specific.

Extract the entire repository first. Open a terminal **in the extracted folder containing `book.toml`**. The examples use paths relative to that folder unless they explicitly change directory. To identify your starting point, run `pwd` to print your location and `ls` to list its contents. A line starting with `#` inside a shell example is an explanation. Run the remaining lines in order in the same terminal.

## Set up the first lab on Ubuntu or WSL2

You can read the entire book in a browser before installing any engineering tools. For the first executable lab, open a Linux terminal and check `python3 --version`, `bash --version` and `git --version`. The lab baseline is Python 3.11 or newer and GNU Bash. If a tool is missing on Ubuntu, `sudo apt update` refreshes the distribution package list and `sudo apt install python3 python3-venv git curl` installs the common learning tools. On a managed laptop use the approved software installation process. Windows learners can run the commands in an Ubuntu WSL2 terminal. A Linux VM with systemd is appropriate for service and administrator exercises.

The first tests run offline with Python's standard library. Install Docker only when you reach part 5. A Kubernetes cluster, registry credentials and an AWS account first appear in the chapters that use them. Use a fresh terminal or explicitly return to the repository root between labs that change directories.

## Your first fifteen minutes

1. Read chapter 1 and run its three checks. The baseline has three passing tests and the sample batch contains two completed jobs. Keep that result as your starting evidence.
2. Make the isolated change in the same chapter. Read the test failure and explain why the release must stop. This is the first useful pipeline decision in the course.
3. In chapter 2, compare the selected artifact before and after rollback. The same method works later when the artifact is a container image.

If you are reading a published copy without the repository, download and extract the [lab source bundle](downloads/handbook-labs.zip). Start shell commands in the directory containing `labs/`. The dashboard and capstone use synthetic clinical operations. Use the supplied fixtures for all exercises.

| If you are starting with… | Begin here |
|---|---|
| No terminal experience | [Linux orientation and a private working directory](part-02/04-linux.md), then [your first release test](part-01/01-devops.md). |
| Development experience and a goal of owning deployments | [Build artifacts](part-04/10-artifacts.md), then [containers](part-05/overview.md) and [CI/CD](part-07/overview.md). |
| Team-training responsibility | [Curriculum and part assessments](curriculum.md), then [portfolio projects](part-15/overview.md). |

## The learning route

| Stage | Evidence that you are ready to move on |
|---|---|
| Foundations | Trace a change from request to measurable outcome. Identify a failed release and restore a previous one. |
| Junior | Explain file access, diagnose a listener, review a Git change and automate a repeatable check. |
| Intermediate | Rebuild an environment from version control, promote a tested artifact and diagnose a failed rollout. |
| Advanced | Set a reliability objective, rehearse recovery, review access boundaries and explain the cost of redundancy. |
| Job-ready | Demonstrate an end-to-end project, defend its trade-offs and show evidence from a failure drill. |

See the [curriculum and publication status](curriculum.md) for all sixteen parts. The chapter numbers stay fixed between editions so lab notes and training plans remain valid.
