# Part 11 · Monitoring, logging and observability

**Study time:** 6–10 h including practice. **Starting point:** Service architecture, Docker Compose and basic rates.

Measure a user outcome, trace a metric to a page and locate one job across structured events.

## What you will demonstrate

Run the alert drill and a log query for a single synthetic failure. Annotate the trace critical path of an example request.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
