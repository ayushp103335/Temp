# 37 · Explain latency with distributed traces

**By the end** you can read parent/child timing, identify a missing context boundary and design a small OpenTelemetry pipeline. Use the multi-tier service from chapter 33. The local exercise uses timestamps on paper so you can reason about traces before installing a backend.

A trace is a collection of related timed operations called spans. Each span has an identifier, start and end time, attributes and status. A trace ID relates spans across processes; a parent reference or span link explains their relationship. Instrumentation can be automatic for supported libraries or manual around business operations such as queue delay. A request ID in logs can help search events but does not establish parentage or duration.

An OpenTelemetry SDK collects telemetry and exports it, commonly using OTLP. A Collector receives, processes and exports telemetry to a backend such as Jaeger or Grafana Tempo. A batch processor trades a little delay for fewer transfers. Memory limits and bounded queues prevent telemetry buffering from exhausting an application or collector. Decide what happens when the backend is slow. Losing traces is undesirable, but an unbounded telemetry queue can bring down the service being observed.

```mermaid
sequenceDiagram
  participant A as API
  participant Q as Queue
  participant W as Worker
  participant D as Database
  A->>Q: Publish job and trace context
  Q-->>W: Deliver job and context
  W->>D: Read input
  D-->>W: Return rows
  W->>D: Persist result
```

## Lab · Find the critical path

An API span runs from 0 to 200 ms. Its authorization span runs 10–40 ms. Two parallel reads run 45–145 and 45–175 ms. Rendering runs 178–195 ms. The sum of child durations exceeds the parent because reads overlap. The slower parallel read controls when rendering can begin. Optimizing only the 100 ms read may leave the 130 ms read on the critical path and deliver no improvement to the parent time.

Now add a worker span starting six seconds after the API completed. The queue is asynchronous. A single contiguous HTTP span cannot explain this delay. Include enqueue time and correlate the consuming span using propagated context or links appropriate to retries and batching. The W3C `traceparent` format carries trace and parent identifiers plus flags. Propagate selected context through message headers; avoid storing patient data or access tokens in baggage and span attributes.

**Sampling.** Head sampling decides early, reducing cost but potentially missing rare errors. Tail sampling observes completed traces before making a decision and requires memory, time and coherent routing of related spans. A trace count from a sampled dataset is a poor unadjusted denominator for an SLO. Use a reliable event counter for the population and traces to explain selected cases.

**Troubleshooting.** If the API and worker appear as separate roots, check extraction and injection at the queue boundary. If timings look impossible, inspect clock synchronization and which spans overlap. If no traces arrive, inspect endpoint protocol, TLS settings, sampling policy and collector exporter errors.

**Practice.** Sketch a trace for one retry and one parallel lookup. Name a span attribute of bounded cardinality and an identifier that should remain available only in appropriately protected traces. **Interview. Why keep metrics alongside traces?** Metrics summarize populations efficiently; traces provide causal and timing detail for individual operations.

### Further reading

[OpenTelemetry traces](https://opentelemetry.io/docs/concepts/signals/traces/) · [Collector configuration](https://opentelemetry.io/docs/collector/configuration/) · [W3C Trace Context](https://www.w3.org/TR/trace-context/)
