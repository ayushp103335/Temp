# 34 · Measure the user operation

**By the end** you can define a useful indicator, calculate it from events and choose an alert the on-call engineer can act on. Start with chapter 33. No monitoring product is required for the arithmetic.

Monitoring checks known conditions, such as expired certificates, failing requests or unavailable workers. Observability is the ability to infer what happened inside a system from emitted evidence, including when the question was not anticipated. Metrics aggregate numerical observations over time, logs record individual events, and traces relate operations across components. Each discards or retains a different level of detail.

Start with the user operation rather than the server. A clinic submits a job and expects a result within 60 seconds. The web API can be fast while workers are stalled. Measure timely completions against eligible submissions. Define the clock, eligibility rules, observation window and treatment of still-pending work. A job submitted ten seconds ago has not yet missed its deadline. A job submitted two minutes ago with no result has.

## Lab · Compute an SLI with a complete denominator

Imagine a closed cohort of 10,000 accepted synthetic jobs, each old enough to evaluate. There are 9,970 timely results, 20 late results and 10 still missing. The timely-result **service-level indicator** (SLI) is 99.7%. Dividing by completed jobs alone hides missing work. With a **service-level objective** (SLO) of 99.9% for this cohort, ten misses are allowed and thirty occurred. The budget is overspent by twenty. A **service-level agreement** (SLA) is a contractual commitment whose scope and consequences can differ from the internal engineering objective.

| Lens | Questions it organizes | Example measurements |
|---|---|---|
| Four golden signals | Latency, traffic, errors, saturation | Submission latency, arrivals/minute, missed results, queue age. |
| RED | Rate, errors, duration for a service | API request rate, 5xx ratio, duration histogram. |
| USE | Utilization, saturation, errors for a resource | CPU busy time, runnable queue, device errors. |

To design a page, ask which immediate action is both possible and necessary. A rapidly rising missed-deadline ratio can page the on-call; gradually shrinking disk headroom can open a ticket with time to act. Include service name, environment, user impact, time window and a runbook. A page on every high CPU sample creates noise during healthy batch processing.

**Troubleshooting.** A drop in error counts during an outage may mean traffic or telemetry vanished. Plot numerator and denominator, sample freshness and collection health together. Missing telemetry deserves its own policy. Avoid labels derived from job IDs, patient identifiers or unbounded URLs. They create high-cardinality time series and can leak private information.

**Practice.** Write the precise query contract for “results delivered within 60 seconds.” Decide how to treat cancellations, duplicate submissions and delayed events. Have a teammate calculate the answer on five sample records.

**Interview. If p95 latency improves, have all users benefited?** No. The request mix may have changed or a small critical cohort may be slower. Inspect counts, comparable cohorts and completion success.

### Further reading

[Google SRE on monitoring distributed systems](https://sre.google/sre-book/monitoring-distributed-systems/) · [Implementing SLOs](https://sre.google/workbook/implementing-slos/)
