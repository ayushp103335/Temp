# 36 · Carry a log from a worker to a query

**By the end** you can select useful log fields, locate a lost event and set a retention policy with an owner. Use [project 8](../part-15/54-logging.md) and the shared observability stack.

A worker writes a structured event containing time, synthetic job ID and outcome. A collector tails the file, records its read position and sends batches to a storage service. Operators query the store through Grafana. Separate the event timestamp, collection time and query window. A machine clock error or delayed batch can make a real event appear outside the selected range.

Elasticsearch and OpenSearch index structured fields for broad search and aggregations. In an Elastic-style pipeline, Logstash can parse and enrich events and Kibana provides search and dashboards for Elasticsearch. OpenSearch Dashboards is the corresponding interface for OpenSearch. Fluent Bit is a lightweight collector useful near sources, while Fluentd supports routing and transformation in a larger plugin ecosystem. Loki organizes streams by labels and stores log contents for later filtering. Choose indexing based on the questions you need and the data cost you can operate.

## Lab · Choose between label and field

Open `labs/observability/config.alloy`. The file-match component finds synthetic logs, the source component tails them and the write component forwards entries to Loki. The stream label `service_name="handbook-jobs"` is stable. The unique job ID remains inside each JSON record. Turning every ID into a label would create a new stream per job. Grafana Alloy supplies the collection path; Promtail reached end of life in 2026.

Start the stack using project 7. Send one failed job, copy its synthetic ID and open the Loki data source in Grafana Explore (use your local lab admin account if the viewer role cannot access Explore). Begin with the stream query, then parse the event:

```logql
{service_name="handbook-jobs"} | json | outcome="failed"
```

The selector limits the streams read, the parser extracts fields and the final condition keeps matching events. Widen the time window before concluding a record is missing. View `docker compose logs --tail 40 alloy loki` to distinguish a missing input file, forbidden mount, rejected stream or unreachable storage.

**Retention exercise.** At 80 events/second and 600 bytes/event the raw volume is about 4.15 GB/day using decimal units. Thirty days is about 124.4 GB before compression, indexing, replication and query overhead. Specify which events need 30 days versus shorter retention, who may access them, and what happens to copies and backups. The lab's local Loki defaults and named volumes do not implement an organizational retention policy. Configure and test deletion in the backend you deploy.

**Security consideration.** Generate safe fields at the source and redact sensitive data before centralization. A query filter merely hides data at viewing time. Control credentials, access and retention at every copy, including collector buffers.

**Practice.** Record one successful and one failed synthetic ID. Show a single query that finds the failure and another that retrieves one exact ID without adding a stream label. **Interview. Can a log be duplicated during collector recovery?** Yes, depending on checkpoint timing and delivery guarantees. Make consumers tolerant of duplicates and design audit evidence accordingly.

### Further reading

[Grafana Alloy file source](https://grafana.com/docs/alloy/latest/reference/components/loki/loki.source.file/) · [Loki query language](https://grafana.com/docs/loki/latest/query/) · [Promtail lifecycle](https://grafana.com/docs/loki/latest/send-data/promtail/)
