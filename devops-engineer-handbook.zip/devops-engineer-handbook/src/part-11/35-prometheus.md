# 35 · Prometheus, Alertmanager and Grafana

**By the end** you can follow a metric from source to alert, explain a counter reset and diagnose an empty panel. Use the runnable stack in `labs/observability/` and [project 7](../part-15/53-monitoring.md).

Prometheus periodically requests a metrics endpoint. Each sample has a metric name, label set, value and time. A time series is identified by its name and labels. An exporter presents a system's measurements in a format Prometheus can scrape. The included Node Exporter reads CPU and memory observations. The synthetic application separately exposes `handbook_jobs_total` with bounded outcome labels. On Docker Desktop the Linux node may be the container VM rather than the user's physical laptop.

A counter grows until its process restarts. A gauge can rise or fall. A histogram groups observations into buckets and supports distribution estimates when bucket layouts and query aggregation are appropriate. PromQL selects and combines series. To estimate jobs per second by outcome use `sum by (outcome) (rate(handbook_jobs_total[1m]))`. Calculate the rate before aggregating so that individual series resets can be accounted for. Give the range multiple samples. With no matching series the result may be empty; zero is a different observation.

```mermaid
flowchart TD
  Work["Application metrics"] --> Prom["Prometheus scrapes targets"]
  Node["Node Exporter"] --> Prom
  Prom --> Graf["Grafana query and dashboard"]
  Prom --> Rule["Evaluate alert rule"]
  Rule --> AM["Alertmanager groups notifications"]
  AM --> Sink["Training webhook receiver"]
```

## Lab · Observe collection, then trigger an alert

From `labs/observability`, run `bash setup.sh` to create the local Grafana credential, then `docker compose up -d` to start the stack. Visit Prometheus at port 9090 on loopback. Inspect **Status → Target health** (menu labels vary). Confirm that the jobs target is up. Send a few `curl http://127.0.0.1:8100/work/ok` requests and one `curl -i http://127.0.0.1:8100/work/failed`. The failure endpoint deliberately returns 503 and increments the failed counter.

Run three expressions: `up{job="jobs"}`, `handbook_jobs_total`, then the one-minute rate above. Inspect raw counts before interpreting a line graph. Open Grafana on port 3030 and select **Job processing**. Its provisioned Prometheus data source uses the internal service address, so browser network topology and data-source network topology differ.

Now stop the work service. A failed scrape produces `up=0`. The alert rule requires thirty seconds at this condition. It moves from pending to firing, then Alertmanager's grouping wait can delay notification further. Read the receiver log and restore the service. Prometheus records the counter reset as new samples arrive. In Kubernetes, service discovery and relabeling select Pods or Services. Control-plane health, node metrics and business metrics answer different questions.

**Practice.** Predict the earliest possible notification when scrapes and evaluations are five seconds apart, the alert requires thirty seconds and grouping waits another five. Explain why exact wall-clock latency also depends on phase, network and scrape timeout.

**Interview. Why can a dashboard be blank even though the application is healthy?** A wrong selector, missing scrape, wrong data source or too-short query range can each remove samples. Inspect the target and raw series first.

### Further reading

[Prometheus data model](https://prometheus.io/docs/concepts/data_model/) · [PromQL functions](https://prometheus.io/docs/prometheus/latest/querying/functions/) · [Alerting rules](https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/)
