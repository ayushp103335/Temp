# Part 11 review · Monitoring, logging and observability

## Revision and assessment

**Why can an aggregate graph look healthy while a candidate release fails?**

Its traffic may be a small share of the population. Compare the candidate and baseline separately with their sample counts.

## Practical assignment

Run the alert drill and a log query for a single synthetic failure. Annotate the trace critical path of an example request.

## Mini-project and self-evaluation

Record target health, actual notification times, query window and one metric that remains valid after a collector restart.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
