# 58 · Build a portfolio an engineering team can evaluate

**By the end** you can choose the right evidence for a target role, distinguish classroom exercises from operating experience and plan the next learning cycle. Start with one project you have personally deployed and one failure you have personally diagnosed.

A junior engineer is usually evaluated on repeatable execution, careful diagnosis, source control and clear escalation. A mid-level engineer should be able to own a service's release path, automate common failures and explain trade-offs. A senior or platform engineer helps several teams operate safely by designing boundaries, reviewing failure modes, mentoring operators and measuring whether shared capabilities improve outcomes. Actual role expectations differ. Read job descriptions for the decisions and scope of ownership they assign.

## Build three evidence packets

| Packet | Suggested projects | Include |
|---|---|---|
| Build and operate | Linux toolkit and Compose dashboard | Architecture, commands, restore proof, expected/actual outcome and scoped cleanup. |
| Deliver and recover | Pipeline and Kubernetes GitOps | Reviewed change, failed gate, artifact digest, rollout evidence and demonstrated rollback. |
| Design and improve | Monitoring and EKS capstone | User objective, alert drill, measured recovery, cost model and explicit production gaps. |

In each repository put a short README first. State the business problem, prerequisites, fastest verification, failure drill, cost and teardown. Keep credentials, tokens, real clinical data and customer identifiers out of screenshots and history. Show a redacted synthetic result rather than an inaccessible internal dashboard. Capture the tool versions you used, the date and precisely which parts ran on real infrastructure.

**Résumé workshop.** “Experienced in Kubernetes and Terraform” gives a reviewer little to verify. A better line after a real exercise is “Provisioned a two-zone staging service, verified target recovery after a controlled disruption and documented the teardown cost.” Add a measured duration or cost only after capturing it and defining the baseline. Label simulations and training work honestly. The important decision may be why you kept a service on a VM instead of adding a cluster.

## A practical learning route

1. For a junior role, reproduce parts 1–5 without following every command verbatim. Explain a permission failure, a Git conflict, a refused connection and a cache miss using your own lab evidence.
2. For mid-level preparation, own one deployment from CI to Kubernetes, including a failed version, an observability query, a rollback and a recovery note someone else can follow.
3. For senior or platform preparation, add design constraints. What happens when one zone fails, a credential rotates, a service exceeds budget or several teams need isolated release permissions? Demonstrate one trade-off with measurements.
4. Select five target job descriptions and map each repeated requirement to an artifact. Prioritize gaps that recur. During interviews ask about on-call ownership, release frequency, recovery practices and team support rather than treating a tool list as a role description.

## Optional certifications

| Path | Use it when your work needs | Accompany it with |
|---|---|---|
| AWS Solutions Architect or DevOps Engineer | Cloud design, delivery and operations on AWS | A reviewed architecture, failure exercise and current cost estimate. |
| CKA | Cluster administration and troubleshooting | A node maintenance plan, RBAC review and restore evidence. |
| CKAD | Application deployment and diagnosis | A rollout with probes, configuration and resource controls. |
| HashiCorp Terraform Associate | Infrastructure-as-code fundamentals | A state/locking lab, a plan review and a tested module. |
| Azure or Google Cloud certification | Work specific to the target provider | A provider-specific identity and deployment demonstration. |

Use official exam guides for current objectives, names and availability. Certifications can structure study. An interviewer can still ask how you proved the application worked after a dependency failed.

**Final exercise.** Give a colleague a clean checkout and your README. Ask them to deploy one project, observe one intentional failure and tear it down. Record where they needed help. Revise the instructions and repeat once. This produces evidence of operating judgment and technical communication at the same time.

**Interview. What would you learn next?** Identify one limitation you measured in your own project, propose an experiment and define a success condition. A concrete answer such as “measure restore time against an RTO using a separately stored backup” gives the interviewer something technical to explore.

### Further reading

[AWS Certification](https://aws.amazon.com/certification/) · [CNCF certifications](https://www.cncf.io/training/certification/) · [HashiCorp certification](https://developer.hashicorp.com/certifications) · [Microsoft credentials](https://learn.microsoft.com/en-us/credentials/) · [Google Cloud certifications](https://cloud.google.com/learn/certification)
