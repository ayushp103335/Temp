# Part 16 · Interview and career preparation

**Study time:** 4–7 h including practice. **Starting point:** At least one successfully run lab and one diagnosed failure.

Explain operational decisions at junior, mid-level and senior scopes and build an evidence-based portfolio.

## What you will demonstrate

Deliver a twenty-minute design interview and have a colleague follow one project's README from a clean checkout.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
