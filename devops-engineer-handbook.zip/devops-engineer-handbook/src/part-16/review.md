# Part 16 review · Interview and career preparation

## Revision and assessment

**What makes an engineering accomplishment defensible in an interview?**

The scope, assumptions, decisions and measured result are explicit. You can reproduce the check and discuss remaining limitations.

## Practical assignment

Deliver a twenty-minute design interview and have a colleague follow one project's README from a clean checkout.

## Mini-project and self-evaluation

Select three artifacts, rehearse two follow-ups per artifact and identify one uncertainty you would investigate next.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
