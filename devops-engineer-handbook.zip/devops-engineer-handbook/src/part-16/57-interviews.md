# 57 · DevOps interview workshop

**By the end** you can answer a technical question in plain language, explain its mechanism, use evidence from a real lab and defend a follow-up decision. Complete several projects first. Each answer below contains a mechanism, a concrete example, a common reasoning error and a follow-up. Rehearse aloud and replace hypothetical results with your own measured evidence.

## Foundations and host operation

**1. What changes when a team adopts DevOps?** Developers and operators share responsibility for delivering and running a service. A tested artifact, release record and user-facing measurement connect those responsibilities. In project 1 a successful backup command is followed by restoration and a business-level check. Buying a CI server alone does not create this feedback. **Follow-up:** who has the authority and evidence to stop an unhealthy release?

**2. Why can a Linux process read a deleted file?** Opening a file gives the process a descriptor referencing an open file description. Removing a directory entry removes a name. The data can remain available until the last relevant reference closes. Chapter 5 reproduces this with a temporary log. A directory listing may therefore omit bytes still counted in filesystem usage. **Follow-up:** which process owns the open file, and how can it reopen logs without interrupting work?

**3. DNS resolves correctly, but a request fails. Where do you look?** Name resolution gives an address. Inspect route, TCP connection, TLS verification and HTTP behavior in order, from the caller's actual network context. A 404 from the expected endpoint proves more about transport than a DNS answer. A timeout alone cannot identify a firewall as the cause. **Follow-up:** what evidence distinguishes an upstream 502 from a failure to connect to the edge?

**4. How do you undo a bad shared Git change?** For an ordinary published commit, a revert adds a new inverse change and preserves history used by colleagues. Resolve conflicts and test the resulting state because later commits can depend on the change. Reverting source may still require artifact promotion to affect the running system. **Follow-up:** what if the original change migrated persistent data?

## Build and delivery

**5. Why does data disappear when a container is replaced?** Files in the old container's writable layer belong to that container. A new container receives another layer. In project 2 a named volume stores PostgreSQL data across recreation. A persistent volume on the same failing host still needs an independent backup. **Follow-up:** which data can safely disappear with Redis, and what happens to database load?

**6. What does Kubernetes do when a Pod fails?** The kubelet can restart a container according to policy. A workload controller can request a replacement Pod to restore a replica count; the scheduler picks an eligible node. An unowned Pod has a different lifecycle. A replacement waiting on an unbound PVC illustrates why replica count alone cannot ensure recovery. **Follow-up:** which event tells you whether placement or startup failed?

**7. Why is a Jenkins job waiting when the controller looks idle?** A stage needs an eligible agent and executor under its label and other constraints. The example job requests `linux-python`; an idle Windows agent cannot satisfy that label. Controller CPU does not measure queue eligibility. **Follow-up:** what timings would distinguish queue delay from slow tests?

**8. How would you limit GitHub Actions release permissions?** Give pull-request checks read-only access and put publication behind a trusted revision, job-specific permissions and protected environment rules. Project 3 gives the publisher package-write permission and the deployer package-read permission. Secret masking alone does not make arbitrary pull-request code trustworthy. **Follow-up:** how would you prove that the deployment pulled the digest the publisher tested?

## Cloud and infrastructure automation

**9. How can AWS serve traffic from a private subnet?** A public ALB accepts the external connection and opens a separate connection to the target's private address. Routing and security groups must permit that hop. Project 4 restricts clients to an operator /32 and targets to the load balancer group. A NAT gateway is unnecessary for this inbound path. **Follow-up:** which path would a private target use to fetch updates, and what would that cost?

**10. Why lock Terraform state?** State associates resource addresses with provider identities. Two concurrent writers can make incompatible decisions based on competing snapshots. A supported backend lock coordinates cooperating writers. It cannot stop console changes or protect readers from seeing sensitive values. **Follow-up:** how do you identify an abandoned lock before acting on it?

**11. What does idempotence look like in Ansible?** When a host already matches the declared file and permissions, the task reports no change. Chapter 30 applies a template twice and checks `changed=0` on the second run. A successful exit code only reports success; a shell task could still append a duplicate line. **Follow-up:** why might a handler run after an apparently harmless template edit?

## Reliability, security and system design

**12. Which signal should page support for a delayed-job service?** Measure whether eligible accepted jobs get their expected result before the promised deadline. A healthy HTTP process can coexist with an unhealthy worker backlog. Use traffic and telemetry freshness to qualify the signal and a runbook for action. **Follow-up:** how do you count a pending job that was submitted five seconds ago?

**13. What does signing a container image prove?** Verification can tie an artifact digest to a signer or identity accepted under a trust policy. In project 9 both workflow identity and issuer matter. A valid signature can belong to software with defects or known vulnerabilities. **Follow-up:** where must verification be enforced to prevent an unapproved image from running?

**14. A release increased latency. Would you roll back?** First establish the affected operation, cohort, baseline and user impact. If an agreed stop rule is met and rollback is data-compatible, pause or revert the release and verify recovery. In the chapter 24 example, blending a small bad canary with healthy traffic hides its regression. A dashboard correlation alone does not prove cause. **Follow-up:** what decision changes if the database schema is already incompatible?

**15. Design for loss of one availability zone.** Size surviving capacity, distribute clients and data dependencies across independent domains, and rehearse failover. In chapter 25, four workers in each of three zones leave eight when one zone fails. The same arithmetic is worthless if all workers depend on one unavailable single-zone store. **Follow-up:** how much backlog accumulates during replacement and how quickly can it drain?

**16. How would you find a doubling of cloud cost?** Compare unit cost, workload volume and cost allocation across similar periods. Identify high-growth services and separate usage increases from price or commitment changes. In chapter 45 a larger bill accompanied lower cost per successful job. Cutting capacity before checking SLO headroom can create a more expensive incident. **Follow-up:** which metric would expose retries inflating cost while business output stays flat?

## Mock interview lab and grading

Take 20 minutes with a partner. Spend five minutes clarifying one design requirement, five drawing the request and release paths, five investigating a failure and five reviewing evidence. Score each response from zero to two on mechanism, example and verification: zero if missing, one if explained, two if demonstrated. A strong answer names its assumptions and the observation that would change the decision. Repeat the lowest-scoring item using a lab result.

### Further reading

[Google SRE workbook](https://sre.google/workbook/table-of-contents/) · [Kubernetes concepts](https://kubernetes.io/docs/concepts/) · [Terraform CLI documentation](https://developer.hashicorp.com/terraform/cli)
