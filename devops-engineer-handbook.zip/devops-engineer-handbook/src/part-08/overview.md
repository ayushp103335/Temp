# Part 8 · Cloud computing

**Study time:** 5–8 h including practice. **Starting point:** Networking, identity and the request-path diagram.

Map an application to compute, network and storage services and assign responsibility at each boundary.

## What you will demonstrate

Design a two-zone cloud deployment and calculate surviving capacity and billable resource-hours for a rehearsal.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
