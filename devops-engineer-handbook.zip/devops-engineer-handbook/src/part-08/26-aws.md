# 26 · AWS through a complete request

**By the end** you can design a public entry point with private compute, trace an AWS authorization failure and choose storage and monitoring appropriate to a workload. Use chapters 7, 20 and 25. The read-only CLI examples require AWS CLI v2 and an authorized training identity. [Project 4](../part-15/50-aws.md) contains the Terraform implementation.

## Network path and identity path

A support engineer opens a status page. DNS can use a Route 53 alias to direct the hostname to an Application Load Balancer (ALB). The ALB receives an HTTP or HTTPS connection and chooses a healthy target in its target group. The target can be an EC2 virtual machine in a private subnet. The target receives traffic from the ALB's security group. It needs neither a public address nor a direct inbound rule from the internet.

```mermaid
flowchart TD
  Operator["Allowed operator address"] --> ALB["ALB across public subnets"]
  ALB --> A["Private EC2 in zone A"]
  ALB --> B["Private EC2 in zone B"]
  IaC["Scoped provisioning role"] --> API["AWS control plane"]
  API --> ALB
  API --> A
  API --> B
```

A Virtual Private Cloud (VPC) defines an address and routing boundary. Each subnet lies in one availability zone. A route table selects a next hop for a destination prefix. A public subnet has a route to an internet gateway; an EC2 instance also needs a suitable public address and permitted traffic to use that path for direct IPv4 internet access. A private subnet can use a NAT gateway for outbound IPv4 connections. NAT adds hourly and traffic costs. The lab boots from preinstalled tools and uses no NAT.

Security groups are stateful rules attached to resources such as network interfaces. Network ACLs apply at the subnet boundary and are stateless, so both directions, including return ports, matter. Reachability depends on routes, filters and the actual listener. An IAM role can allow an engineer to inspect a machine without making TCP port 22 reachable.

## Identity and key handling

An IAM **principal** is an identity making a request. A role has a trust policy specifying who may assume it and permissions describing which actions are allowed on which resources. Conditions can constrain requests. Organization policies, permission boundaries and resource policies can affect the effective result. An applicable explicit deny takes precedence. Use temporary credentials, inspect the actual caller and scope deployment, runtime and operator roles separately.

Secrets Manager holds secrets and can support rotation. KMS controls use of encryption keys. Permission to read an encrypted secret and permission to decrypt it may involve separate decisions. Systems Manager can inventory and manage instances and supply parameters. Session Manager requires agent health, a suitable instance role, operator authorization and a network path to the service. Merely attaching an IAM policy does not connect an isolated subnet.

## Compute and data choices

| Service | Fit for a job-processing system | Operational responsibility to check |
|---|---|---|
| EC2 and Auto Scaling groups | Host custom long-lived workers; replace unhealthy instances and adjust capacity. | Image patches, startup time, draining in-flight work. |
| ECR, ECS and EKS | Store images, run tasks with ECS or run Kubernetes with EKS. | Deployment identity, registry retention, task/Pod IAM, node or managed compute choices. |
| Lambda | Short event-driven tasks with eligible duration, memory and concurrency requirements. | Duplicate events, timeouts, downstream limits and failure handling. |
| S3 | Durable objects such as synthetic documents, artifacts and backup exports. | Access policy, versioning, lifecycle and retrieval costs. |
| EBS and EFS | Block volumes attached to compute versus shared network filesystem semantics. | Zone constraints for EBS; filesystem performance, mounting and access for EFS. |
| RDS | Managed relational database for transactional jobs and queries. | Schema, connection limits, failover behavior, backups and restore tests. |
| DynamoDB | Key-based access with a designed partition key and optional indexes. | Access patterns, key distribution, consistency choices and capacity. |

A queue worker fleet can scale on backlog age or backlog per worker. CPU-only scaling can miss workers that spend most of their time awaiting a database. Route 53 health policies, ELB target health and instance health represent different boundaries. Workloads should verify the user's critical operation after a scaling or failover event.

## Lab · Identify the account before interpreting data

```bash
# Authenticate using your configured training SSO profile.
aws sso login --profile training
# Inspect the caller and explicit region.
aws sts get-caller-identity --profile training
aws ec2 describe-vpcs --profile training --region us-east-1 \
  --query 'Vpcs[].{Id:VpcId,CIDR:CidrBlock}' --output table
# List available zones for a placement plan.
aws ec2 describe-availability-zones --profile training --region us-east-1 \
  --query 'AvailabilityZones[?State==`available`].ZoneName' --output text
```

Replace region/profile with your assigned lab values. An empty result may be a genuine empty account or an incorrect target. A denied action is a different outcome. Use the offline EC2-shaped response in chapter 9 if you have no cloud account.

CloudWatch collects telemetry such as metrics, logs and alarms. CloudTrail records account activity and API events according to its configuration. Use CloudWatch to ask when target latency increased and CloudTrail to ask who changed the target group. CodePipeline orchestrates release stages; CodeBuild runs build commands in a configured environment. Like the GitHub pipeline, give the build role only its needed access and retain the tested artifact.

**Troubleshooting.** An ALB reports unhealthy targets. Check the target's health reason, path, protocol, port, target-group attachment, security groups and application listener. An empty target group and failing target checks require different fixes. If all targets are unhealthy, account for ALB fail-open behavior; health state is one signal, not proof that traffic has stopped.

**Practice.** Choose storage for a shared job ledger, large original document and ephemeral cache. For each, state the access pattern, failure domain, backup owner and proof of recovery.

**Interview. Why can a private EC2 instance receive public user traffic without a public IP?** The ALB terminates the client connection and opens another connection to a target on private addresses. Routing and security rules allow that internal hop.

### Further reading

[AWS VPC security](https://docs.aws.amazon.com/vpc/latest/userguide/VPC_Security.html) · [ALB target health](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/target-group-health-checks.html) · [IAM roles](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html) · [AWS Well-Architected](https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html)
