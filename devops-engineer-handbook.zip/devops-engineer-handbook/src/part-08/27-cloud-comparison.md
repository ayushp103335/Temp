# 27 · Map a workload to Azure and Google Cloud

**By the end** you can translate an architectural requirement across providers and spot a misleading service-name match. Start with chapter 26. This is a design lab; no cloud deployment is required.

Take one workload: receive an uploaded document, retain it, enqueue work, run a containerized processor and show completion latency. Each capability maps to more than a product name. Ask where the identity lives, who patches the runtime, how private endpoints are reached and what data remains after compute is deleted.

| Capability | AWS | Azure | Google Cloud |
|---|---|---|---|
| Virtual machine | EC2 | Azure Virtual Machines | Compute Engine |
| Private networking | VPC | Virtual Network (VNet) | VPC network |
| Object storage | S3 | Blob Storage | Cloud Storage |
| Managed Kubernetes | EKS | Azure Kubernetes Service (AKS) | Google Kubernetes Engine (GKE) |
| Build and delivery | CodeBuild and CodePipeline | Azure Pipelines in Azure DevOps | Cloud Build and Cloud Deploy |
| Metrics and logs | CloudWatch | Azure Monitor and Log Analytics | Cloud Monitoring and Cloud Logging |

Azure subscriptions provide billing and management boundaries. A resource group groups related Azure resources for lifecycle and authorization decisions. A VNet is regional and has subnets. Blob data lives in containers in a storage account. Managed identities can give a workload Azure access without a manually rotated app password. Azure DevOps provides repositories, pipelines and other delivery services. Azure Monitor ingests metrics and logs; decide which diagnostic data is enabled and retained.

Google Cloud organizes resources into an organization, optional folders and projects. A VPC network is global and its subnets are regional. A VM in one zone can use an appropriate regional subnet. Cloud Storage buckets have location choices; evaluate actual redundancy and data-residency needs. Workload Identity Federation for GKE can connect workload identity to Google APIs. Cloud Build's build identity should be separate from the workload's runtime identity. A successful build cannot establish that the running Pod may read its bucket.

## Lab · Review a migration design

A team proposes “copy our AWS VPC per region directly into Google Cloud, use a long-lived storage key in every Pod and call the project complete when the Pods are Ready.” Write a revised plan:

1. Map the address ranges and regional subnets. Identify overlap with existing networks, routes and DNS behavior.
2. Bind a workload identity to a read-only test bucket. Verify it can read a synthetic object and cannot perform actions outside its scope.
3. Make the critical workflow observable. Time from upload acceptance to readable result. Identify which logs establish worker progress.
4. Verify the organization's access boundary, storage location and lifecycle. Use comparable failure and cost assumptions before claiming parity.

For an Azure design, identify the subscription, resource group, region, VNet, managed identity and storage scope. A resource-group deletion can remove multiple lab resources in one action. Shared infrastructure belongs under a separately controlled lifecycle.

**Troubleshooting.** A CLI listing the wrong environment may have a different active project or subscription. `az account show` displays the selected Azure account context. `gcloud config get-value project` displays the configured Google Cloud project. These are useful first read-only checks when credentials appear correct but resources are missing. Selecting the correct context does not grant missing permissions.

**Practice.** Prepare a one-page decision for the same workload on two providers. Include identity, data path, observability, recovery and teardown. Compare object storage request and network-transfer assumptions separately from VM prices.

**Interview. Is multi-cloud automatically more reliable?** Only if the service and its dependencies can actually fail over with usable data and capacity. The second implementation also creates extra configuration, monitoring and recovery work to test.

### Further reading

[Azure for AWS professionals](https://learn.microsoft.com/en-us/azure/architecture/aws-professional/) · [Google Cloud service comparison](https://cloud.google.com/docs/get-started/aws-azure-gcp-service-comparison) · [Google Cloud VPC](https://cloud.google.com/vpc/docs/vpc)
