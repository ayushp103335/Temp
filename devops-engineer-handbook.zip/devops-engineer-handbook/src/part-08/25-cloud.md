# 25 · Cloud resources, failure domains and bills

**By the end** you can assign operational responsibility to the right party, size a small service and identify the resources that keep charging after a test. Use the request-path model from chapter 3. No cloud account is needed for the calculations.

Cloud computing exposes infrastructure or managed capabilities through service APIs. A virtual machine (VM) is an operating-system environment on virtualized hardware. In infrastructure as a service (IaaS) the provider operates facilities and underlying infrastructure while you operate the guest OS, software and much of the network configuration. In platform as a service (PaaS) the provider also operates more of the runtime. In software as a service (SaaS) users consume an application and still manage access, data, sharing and configuration. Responsibility depends on the particular product and contract.

## Pick the failure domain before the replica count

A region is a geographic service area. Availability zones are distinct deployment locations within a region intended to isolate certain failures. Products expose zones differently. Two instances on one physical failure domain can both disappear together. Multi-zone design adds network, replication and capacity considerations. A region-wide recovery design also requires working dependencies, identity, traffic switching, accessible data and tested procedures in the recovery region.

**Scalability** asks whether the design can take on more load by adding capacity. **Elasticity** asks whether capacity can track changing load in time. **High availability** asks whether the user-facing operation meets its availability target. **Fault tolerance** asks what failures the service can absorb while continuing to deliver its specified behavior. A service can scale efficiently when healthy and still fail whenever its only database restarts.

## Lab · Calculate the fleet you need after a failure

A worker handles 12 jobs/minute. Peak incoming load is 60/minute. Five workers just match arrivals. Reserving 20% of worker throughput as headroom means only 9.6 jobs/minute per worker should be committed. Round 60/9.6 up to seven healthy workers. With three equal zones and a requirement to lose any one zone, four workers per zone leave eight after a zone loss. Three per zone leave six, below the headroom goal. This model assumes the queue and database also retain sufficient capacity and the measurements apply to the peak job mix.

Estimate the bill symbolically first. For a two-hour rehearsal, two VMs incur four VM-hours, one load balancer incurs two load-balancer hours plus usage charges, and public IPv4 addresses, provisioned storage, data transfer and logs can add charges. Storage retained for a month persists after compute shuts down. Substitute current rates for your account, selected region and service tier. Document what you assumed.

| Deployment model | Example reason to choose it | Cost of the choice |
|---|---|---|
| Public cloud | A team needs an on-demand training environment. | Metered use and provider dependencies. |
| Private cloud | Capacity and policies are operated within an organization's own environment. | Capacity planning and platform operation remain internal. |
| Hybrid | On-premises clinical records must connect to a cloud processing service. | Identity, routing and recovery span both environments. |
| Multi-cloud | Specific service or business constraints justify two providers. | Skills, observability and recovery are duplicated or integrated. |

**Practice.** Write a deletion checklist for a VM with a separately attached data disk, a public IP and a backup schedule. Identify which resource holds recoverable data and who authorizes its removal.

**Interview. Does using managed infrastructure transfer all security work to the vendor?** The provider's responsibilities vary by service. The team still decides identities, access rules, data retention and application behavior. Name the actual owner of each control when designing the service.

### Further reading

[NIST definition of cloud computing](https://csrc.nist.gov/pubs/sp/800/145/final) · [AWS shared responsibility](https://aws.amazon.com/compliance/shared-responsibility-model/) · [AWS Pricing Calculator](https://calculator.aws/)
