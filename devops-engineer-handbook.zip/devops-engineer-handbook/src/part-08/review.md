# Part 8 review · Cloud computing

## Revision and assessment

**Does a private target need NAT to receive traffic from an ALB?**

The ALB opens an internal connection. NAT is relevant to suitable outbound paths, not that incoming connection.

## Practical assignment

Design a two-zone cloud deployment and calculate surviving capacity and billable resource-hours for a rehearsal.

## Mini-project and self-evaluation

Explain the security group chain, backup ownership and operator identity. Check that your cost estimate includes idle retained resources.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
