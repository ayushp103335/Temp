# 2 · From a requirement to a recoverable release

**By the end** you can turn a requirement into a release record, choose a rollout strategy and explain which kinds of damage reversing a release can repair. Complete chapter 1 first. The hands-on exercise uses GNU/Linux, Bash, Python 3 and GNU coreutils.

## Follow the change across environments

Suppose a clinic wants queued jobs to appear on its dashboard within one minute. The software development lifecycle (SDLC) covers discovering the need, designing a change, implementing it, verifying it, releasing it, running it and retiring it. Start by asking when the clock starts, what fraction of jobs must meet the limit and who investigates a miss. These answers influence both code and monitoring.

In a waterfall process, work proceeds through planned phases with formal checkpoints. An organization migrating a reporting system might require an approved data contract before implementation. An agile team can deliver a narrow slice, measure it and revise the next slice. Scrum organizes work in time-boxed sprints around a goal. Kanban visualizes flow and limits work in progress. When review takes six days and coding takes one, limiting new starts and clearing the review queue can shorten delivery more than writing code faster.

In **development**, an engineer changes behavior quickly. **Test** isolates repeatable checks and fixtures. **Staging** rehearses installation, configuration and integration with production-like dependencies. **Production** serves actual users. Keep credentials and data separate in every environment. Promote identical artifact bytes and supply environment-specific settings at runtime. Rebuilding from the same source can yield different bytes when the build reads a mutable dependency.

## Version identity and compatibility

A release record answers three questions: which source produced the artifact, which bytes were deployed, and which configuration selected their behavior? A commit ID identifies a source revision. A digest is a fingerprint calculated from bytes. A human-friendly version conveys compatibility only if the publisher follows a convention. Under Semantic Versioning, a stable public interface uses major.minor.patch. A compatible addition to 1.4.2 can be 1.5.0. Removing an accepted status value calls for a major change if the field is public. A digest detects byte differences. Authenticity also requires a trusted source or verified signature.

| Rollout | How traffic changes | Resource and recovery implications |
|---|---|---|
| Rolling | Replace a few old instances at a time. | Needs capacity for the rollout and compatibility between old and new processes. Undo replaces instances again. |
| Blue-green | Prepare a second full environment and switch the traffic target. | Fast switchback if the old environment and its dependencies remain compatible. Budget for overlap. |
| Canary | Send a limited cohort to the candidate and compare outcomes. | Needs representative traffic, baseline measurements and a stop rule. Low volumes may take hours to evaluate. |

**Worked decision.** A candidate produces 8 errors in 400 jobs. The old version produces 10 in 10,000 over the same interval. The rates are 2% and 0.1%. If the agreed stop rule is at least 200 representative jobs and a candidate rate above 1%, pause the rollout. Before attributing cause, check whether the canary received a disproportionate share of large documents. Keep the sample counts with the percentages.

## Lab · Activate a tested release and restore it

```bash
# Use a private release store and copy the candidate for editing.
store=$(mktemp -d)
cp labs/release/service.py "$store/candidate.py"
# Test the baseline and point the local "current" link at its stored bytes.
bash labs/release/promote.sh "$store/candidate.py" "$store"
# Record the rollback target, then exercise the active version.
baseline=$(readlink "$store/current")
python3 "$store/current" labs/release/jobs.json
# Change a comment to produce different bytes with the same behavior.
echo '# change record: release rehearsal' >> "$store/candidate.py"
bash labs/release/promote.sh "$store/candidate.py" "$store"
readlink "$store/current"
# Select the retained baseline using a temporary link and one rename.
ln -s "$baseline" "$store/restore"
mv -Tf "$store/restore" "$store/current"
# Confirm both identity and behavior after restoring service.
test "$(readlink "$store/current")" = "$baseline"
python3 "$store/current" labs/release/jobs.json
```

The promotion script stages a copy, compiles it, runs its contract tests and hashes the same candidate it tested. It retains the prior artifact. A symbolic link is a named reference to another path. Renaming the prepared link on the same filesystem lets a new reader see either the old target or the new one. An already-running process may keep its old code in memory. Real deployments also drain or restart processes and verify the version serving requests. This lab models selection on one host with one operator.

> **Production consideration.** Record both the previous artifact and the last data change compatible with it. Test both in the rollback rehearsal.

## A rollback that cannot fix the data

Suppose version two drops a database column still read by version one. Switching the program back restores the old code and leaves the column missing. Use an expand-and-contract migration: add the new field, make clients tolerate both representations, migrate existing records, verify reads, and retire the old field after the rollback window closes. A restore from backup may discard valid intervening writes. Treat data recovery as a separate decision.

**Troubleshooting.** If GNU `mv` reports an invalid option on macOS, run the exercise inside the Linux environment specified above. If a checksum changes unexpectedly, inspect the candidate and its build inputs before publishing. Restrict write access to artifact storage since replacing existing files would undermine the release record.

**Practice.** Draft a release note for renaming a public status. Include the client migration, canary cohort, success signal, rollback target and point beyond which old clients cease to work. Name one check staging cannot prove.

**Interview. Is a successful switchback proof of recovery?** Check a new user request, the worker backlog and any side effects created while the faulty version ran. The router can point to the previous version while duplicate jobs still require repair.

### Further reading

[Semantic Versioning specification](https://semver.org/) · [Google SRE on canary evaluation](https://sre.google/workbook/canarying-releases/)
