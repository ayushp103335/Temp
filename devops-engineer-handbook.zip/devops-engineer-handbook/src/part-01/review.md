# Part 1 review · DevOps fundamentals

## Revision and assessment

**Why can an API accept work while a service misses its objective?**

A 202 covers acceptance. A queue, worker and result store still have to complete their parts before the deadline.

## Practical assignment

Produce a release record containing the previous digest, candidate digest, check result, rollout stop rule and rollback observation.

## Mini-project and self-evaluation

Trace one synthetic job from acceptance to a retrievable result. Show which observation would reveal a stalled worker.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
