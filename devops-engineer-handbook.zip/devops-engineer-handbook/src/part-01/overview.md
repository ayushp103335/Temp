# Part 1 · DevOps fundamentals

**Study time:** 3–5 h including practice. **Starting point:** Basic computer use and a terminal.

Follow a change from a request to a verified release. Separate the release path from the path taken by a live job.

## What you will demonstrate

Produce a release record containing the previous digest, candidate digest, check result, rollout stop rule and rollback observation.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
