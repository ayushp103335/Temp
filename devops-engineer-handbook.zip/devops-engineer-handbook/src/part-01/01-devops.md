# 1 · Introduction to DevOps

**By the end** you can distinguish integration, delivery and deployment, explain who owns a failed change, and use a local test to accept or reject a release. You need a terminal and Python 3. The exercises assume you opened the repository root as described in the introduction.

## A change that passes the wrong test

A developer adds a new job status to a fax-routing service. QA verifies that the API accepts a document. Operations installs the release on Friday. On Monday several documents still show *processing*. The API and its separate worker disagree on the spelling of a status. Each team did the work it had been assigned. The failure occurred in the space between their checks.

DevOps is a way of developing and operating software in which the people changing a service also receive evidence about how that service behaves after release. A useful first change for this team costs nothing: have the developer, tester and operator agree on a single acceptance test. Submit a synthetic document, wait for the worker and confirm that the result can be read. Name the person who can stop the release if that test fails.

Traditional handoffs can work when interfaces and changes are predictable. As release frequency and dependency count grow, queues between specialties grow too. A separate release team might receive ten changes at once. If the batch fails, it must investigate ten changes. Integrating smaller changes shortens that investigation. The trade-off is the investment in fast, trustworthy checks and in people who can operate what they build.

## CAMS and CALMS in the same incident

CAMS groups four practices: culture, automation, measurement and sharing. CALMS adds lean thinking, the habit of looking for waiting, rework and oversized batches. These frameworks help diagnose a delivery process.

| Practice | What changes in the fax service | Evidence |
|---|---|---|
| Culture | A developer and an operator agree on a stopping rule before release. | Either can pause a rollout without waiting for a manager. |
| Automation | Every proposed status change runs the same producer/consumer test. | A spelling mismatch fails reproducibly. |
| Lean | Ship the status change separately from a database migration. | A failure has fewer plausible causes. |
| Measurement | Count jobs completed within the promised time window. | A healthy API can coexist with a rising backlog. |
| Sharing | Save a sanitized test fixture and a recovery note with the code. | A second person can reproduce the diagnosis. |

## Three different promises

**Continuous integration (CI)** means developers integrate changes frequently into a shared line of development and get automated feedback. A month-old private branch with passing tests can still be expensive to integrate. **Continuous delivery** adds enough packaging, environment and release work to keep a tested version ready for production. A person may decide when it goes live. **Continuous deployment** lets a qualifying change go live automatically. All three require a response when verification fails.

The lifecycle typically passes through planning, implementation, integration, packaging, release, operation and observation. The observation can change the next plan. When a worker accepts jobs faster than it can finish them, the next change might limit submissions or increase capacity. Adding another check to the build cannot create runtime capacity.

```mermaid
flowchart TD
  A["Change and acceptance test"] --> B["Build and exercise candidate"]
  B --> C{"Checks pass?"}
  C -->|Yes| D["Activate tested artifact"]
  C -->|No| A
  D --> E["Measure completed work"]
  E --> A
```

## People and boundaries

A DevOps engineer might maintain the build runner and deployment workflow. A cloud engineer designs the network and permissions those runners use. A site reliability engineer (SRE) might set a reliability objective and investigate recurring operational work. A platform engineer might offer an approved service template so ten teams can deploy independently. Job titles overlap. Ask who can approve a change, who is paged when it fails, and who can fix the underlying code.

## Lab · Decide whether a change is releasable

The supplied program reads a JSON file, a text representation of structured data. Each record carries a synthetic ID and a state. The program returns counts by state. Nothing leaves your machine.

```bash
# List the program, tests, sample records and promotion script.
ls labs/release
# Run the tests that establish its current behavior.
python3 -m unittest discover -s labs/release -p 'test_*.py' -v
# Exercise the application on a batch containing two completed jobs.
python3 labs/release/service.py labs/release/jobs.json
```

Expect three passing tests and counts of two done, one queued and zero failed. Read the test names. Which check would catch an unrecognized state? Which check proves a real worker finishes on time? The first question has an answer in the test suite. The second needs a timer and an actual worker. This distinction matters when deciding what a green pipeline authorizes.

Make a private copy before testing an incompatible change.

```bash
# Allocate a new directory and copy only the candidate and its tests.
trial=$(mktemp -d)
cp labs/release/{service.py,test_service.py} "$trial/"
# Rename a state in the candidate without changing the agreed test contract.
sed -i 's/"queued": 0/"waiting": 0/' "$trial/service.py"
# Run the isolated suite. A nonzero exit is the expected outcome.
(cd "$trial" && python3 -m unittest -v)
```

The mixed-batch test now reports an unrecognized state. The original repository still supplies a passing candidate. In a real pipeline, keep the failure message with the change and withhold promotion. Fixing the fixture to accept the rename would conceal the compatibility problem. For cleanup, remove the disposable directory after checking its path with `printf '%s\n' "$trial"`.

## Review and field questions

**What if no tests are discovered?** Check the working directory and the `test_*.py` filename pattern. A success message reporting zero tests does not establish coverage. **What belongs in a build log?** Use version IDs, test names, timings and synthetic job IDs. Input documents and credentials are unnecessary for this diagnosis.

**Practice.** Write two acceptance criteria for the same change. One must be testable before release and the other must be observable after release. Name the owner and the time limit for each.

**Interview. Can a team deliver continuously and release once a month?** Yes, if it keeps a verified production-ready artifact and can release on demand. Ask how it demonstrates readiness between release dates. A monthly rebuild from an unpinned dependency list weakens that claim.

**Remember:** integration establishes compatibility with shared work, promotion moves a known artifact, and operational feedback tests the assumption that the change helped its users.

### Further reading

[DORA on continuous delivery](https://dora.dev/capabilities/continuous-delivery/) · [Google SRE workbook on release decisions](https://sre.google/workbook/canarying-releases/)
