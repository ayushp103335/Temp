# 3 · Draw the delivery path and the request path

**By the end** you can sketch both paths, name the state held at each step and isolate a delayed-job incident. You need the release lab from chapter 2 and a basic understanding of an artifact.

## Two paths with different owners

A repository stores versioned source. A runner is a machine or process that executes the build. A registry stores the resulting artifacts. A deployment identity has permission to select the artifact for an environment. Together these form the **delivery path**. When the registry is unavailable, new hosts may fail to start. Existing hosts that already have the image often continue serving requests. That difference changes whom you page.

A client sends a request to a service address. A reverse proxy accepts it and forwards it to an application process. The application records a job, arranges for a worker to process it and returns an identifier. A separate request reads the result. This is the **request path**. An HTTP 202 means the service has accepted a request for processing. A successful response at submission cannot establish successful completion.

```mermaid
flowchart TD
  subgraph Delivery
    Git["Source repository"] --> CI["Test and package"]
    CI --> Registry["Artifact registry"]
  end
  Registry --> API["Submission API"]
  Registry --> Worker["Background worker"]
  Client["Client"] --> Proxy["Reverse proxy"]
  Proxy --> API
  API --> Queue["Job queue"]
  Queue --> Worker
  Worker --> DB["Result store"]
  API --> DB
```

Arrows from the registry represent deployment dependencies. Arrows from the client trace live requests. The queue retains work waiting for capacity. The result store retains outcomes through process restarts. The drawing leaves an important question open: what if a database insert succeeds and publishing the job to the queue fails? One design writes a job and an outbox record in the same database transaction. A relay publishes pending records. Because delivery may repeat, a worker uses the job ID to recognize work already completed.

## Choosing an application shape

A monolith packages several functions into one deployable unit. A small team can test one version, deploy it once and trace many calls inside one process. It can still move long-running work into another process using the same release artifact. Microservices give independently owned components independent release and scaling schedules. The price includes network timeouts, versioned contracts and more failure modes.

A container packages a program and its userspace dependencies into an image that starts as an isolated process. A container can run either design. Cloud-native architectures often combine replaceable instances, declarative configuration and managed services. A legacy monolith running on a virtual machine can also have an excellent release pipeline. Choose the operations you can actually support.

## Capacity with units

Assume one worker finishes a job in four seconds and handles one at a time. Its ideal throughput is 15 jobs/minute. With 60 jobs/minute arriving, four workers only match arrivals in this simple model. If an outage leaves 600 jobs waiting, that fleet has no spare throughput to drain them. Six workers can ideally finish 90/minute. The backlog falls by 30/minute and takes about 20 minutes to clear. A shared database limit or variable document size can invalidate the estimate. Measure actual completion rate before promising recovery.

## Lab · Separate deployment identity from user behavior

```bash
# Prepare an independent local environment.
envdir=$(mktemp -d)
bash labs/release/promote.sh labs/release/service.py "$envdir"
# Capture the deployed identity and compute the actual bytes' digest.
readlink "$envdir/current"
sha256sum "$envdir/current"
# Validate a request-path behavior with the known fixture.
python3 "$envdir/current" labs/release/jobs.json
# Create invalid input in your lab directory and observe the application failure.
printf '%s\n' '[{"id":"demo-bad","state":"unknown"}]' > "$envdir/invalid.json"
python3 "$envdir/current" "$envdir/invalid.json"
```

The filename contains the same digest printed by the second command. The last invocation exits with an error. The selected artifact still exists. Record the two facts separately in your incident note. This exercise runs the summarizer only. The architecture diagram describes the wider service you would instrument.

## On call · The web tier is green

| Observation | Next discriminating check | Decision |
|---|---|---|
| Job accepted, no record visible | Query the durable job record by synthetic ID. | Inspect the submission transaction. |
| Record exists and queue age rises | Compare ingress rate, completion rate and active worker count. | Restore consumer capacity or limit admission. |
| Worker completes, result lookup fails | Compare key, storage destination and reader configuration. | Repair the read path before increasing workers. |
| Only new instances fail | Compare image digest, configuration and startup events. | Pause the rollout while healthy capacity serves. |

Give each component only the access it needs. For example, a build runner may publish an artifact without permission to read job records. Keep customer identifiers out of metric labels and example traces.

**Practice.** Add an identity, an observable success signal and a failure owner to each boundary in the drawing. Calculate drain time for a backlog of 180 when arrivals are 24/minute and three workers each complete 10/minute. **Answer:** 30 minutes at constant rates.

**Interview. When would you split the worker into its own service?** A separate deployment is justified if worker resource needs or release cadence differ enough to offset operational cost. Start with measurements of queue age, deploy frequency and failure isolation.

### Further reading

[Docker architectural overview](https://docs.docker.com/get-started/docker-overview/) · [Transactional outbox pattern](https://docs.aws.amazon.com/prescriptive-guidance/latest/cloud-design-patterns/transactional-outbox.html) · [HTTP semantics](https://www.rfc-editor.org/rfc/rfc9110.html)
