# 17 · Package a Kubernetes service with Helm

**By the end** you can render a chart locally, inspect its generated objects and describe exactly what Helm can recover. The examples use Helm 3.19 semantics. Rendering requires no cluster. Installation uses the dedicated kind cluster from chapter 14.

## One template, several installations

A chart is a package containing metadata, default settings and templates. A release is a named installation of a chart in a namespace. Two installations can use the same package and different values. Helm renders templates before submitting ordinary Kubernetes resources. The cluster controllers then reconcile those resources. A successful render proves the template emitted text; a deployment still needs valid APIs, credentials, images and capacity.

Open `labs/kubernetes/chart/`. `Chart.yaml` identifies the package. Its `version` versions the chart. Its `appVersion` is descriptive application metadata. The `image` value controls the actual container reference in this example. `values.yaml` provides defaults. `templates/resources.yaml` uses the release name consistently in the ConfigMap, Deployment, Service and selector. That prevents two releases with different names from selecting each other's Pods.

The template hashes the message and places the checksum in the Pod template metadata. Changing that annotation changes the Pod template and triggers a rollout. Without that mechanism, mounted ConfigMap files can eventually refresh independently of a Deployment revision and some processes may never reload them. Decide which behavior your service needs.

## Lab · Catch configuration errors before reaching a cluster

```bash
# Lint the chart and render defaults to a private output directory.
hwork=$(mktemp -d)
helm lint labs/kubernetes/chart
helm template pilot labs/kubernetes/chart > "$hwork/baseline.yaml"
# Render an alternate configuration for the same release and inspect the differences.
helm template pilot labs/kubernetes/chart --set replicas=3 --set-string message=Ready > "$hwork/candidate.yaml"
diff -u "$hwork/baseline.yaml" "$hwork/candidate.yaml" || test "$?" -eq 1
```

Look for changes to the ConfigMap, checksum and replica count. The Service selector should stay stable. `diff` returns 1 for differences and greater values for errors. In a team, put the overrides in versioned YAML and pass `-f FILE` so a reviewer can reproduce the installation. Keep secret values out of rendered artifacts and release history.

```bash
# On the training cluster, install or upgrade and wait for resource readiness.
helm upgrade --install pilot labs/kubernetes/chart --kube-context kind-handbook -n handbook --wait --timeout 3m
# Introduce a second revision and list release history.
helm upgrade pilot labs/kubernetes/chart --kube-context kind-handbook -n handbook --set-string message=Updated --wait
helm history pilot --kube-context kind-handbook -n handbook
# Restore revision one and remove this demo release when finished.
helm rollback pilot 1 --kube-context kind-handbook -n handbook --wait
helm uninstall pilot --kube-context kind-handbook -n handbook
```

Repositories publish charts through indexed HTTP repositories or OCI registries. Pin the chart version and inspect dependencies and rendered manifests before installation. A third-party chart can request cluster-wide permissions. Release rollback restores managed configuration according to the recorded revision. It cannot recover dropped database columns, external queues or all persistent data.

**Troubleshooting.** “Cannot re-use a name” requires inspecting the existing release and namespace. A timed-out wait might reflect a pull error, missing storage class or failing probe. Use ordinary Kubernetes events to distinguish them. A rerun with a longer timeout can hide an invalid setting.

**Practice.** Add a values file for staging with one replica and a distinct page message. Render it, identify every changed field, and explain why the selector stayed the same.

**Interview. Why keep image and chart versions separate?** A chart-only release might correct resource requests or routing while deploying exactly the same application image.

### Further reading

[Helm chart guide](https://helm.sh/docs/topics/charts/) · [Template functions](https://helm.sh/docs/chart_template_guide/functions_and_pipelines/) · [Helm rollback](https://helm.sh/docs/helm/helm_rollback/)
