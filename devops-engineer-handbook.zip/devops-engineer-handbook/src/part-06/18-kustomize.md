# 18 · Layer environment differences with Kustomize

**By the end** you can render an overlay, trace a generated ConfigMap reference and review which resource fields differ between environments. Use kubectl with built-in Kustomize support. You can complete the rendering exercise offline.

## What belongs in a base?

A base is a set of Kubernetes resources that gives environments a common starting shape. An overlay references it and declares selected changes. The base in this repository contains a Deployment, a Service and a ConfigMap generator that reads an HTML file. Staging sets one replica and its namespace. The live training overlay requests three replicas and another namespace. Both names refer to disposable lab environments.

Kustomize reads structured resources, applies transformations and writes the result. The generator appends a content-derived suffix to a ConfigMap name by default. Its name-reference transformation updates the matching volume reference in the Deployment. A page content change can therefore change the Pod template and produce a rollout without an engineer manually synchronizing two strings.

```bash
# Render each overlay without sending any request to an API server.
kw=$(mktemp -d)
kubectl kustomize labs/kubernetes/overlays/staging > "$kw/staging.yaml"
kubectl kustomize labs/kubernetes/overlays/live > "$kw/live.yaml"
# Compare the exact resources each environment would receive.
diff -u "$kw/staging.yaml" "$kw/live.yaml" || test "$?" -eq 1
# Locate the generated ConfigMap name and its corresponding Pod reference.
grep -n 'status-page-' "$kw/staging.yaml"
```

Expect the same generated name for identical page content, and different replica counts and namespaces. Namespaces must exist before namespaced resources are applied. The `namespace` transformer assigns resource scope. It does not create the Namespace resource. For a live exercise use `kubectl --context kind-handbook create namespace handbook-staging`, then `kubectl --context kind-handbook apply -k labs/kubernetes/overlays/staging`. The `-k` selects a Kustomization directory; `-f` accepts already constructed resources.

## Choose the smallest meaningful difference

A targeted patch can address a named container's resource settings. A replica transformer is clearer for a single replica-count change. Copying all base YAML into each environment makes one environment easy to read in isolation and makes common fixes harder to propagate. Conversely, six layers of nested patches can make the deployed result difficult to predict. Review the rendered result alongside the source diff.

| Need | Usually simpler starting point |
|---|---|
| Ship a reusable package with a documented public set of inputs and release history | Helm chart |
| Maintain a few explicit variations on the same in-house manifests | Kustomize base and overlays |
| Audit the exact workload admitted to a cluster | Render either approach, compare with server-side validation and inspect admission changes |

A generated ConfigMap name changes when contents change. Old generated objects can remain after simple apply operations. Define pruning deliberately, scoped to managed objects. Deleting an old generated config prematurely can interfere with rollback. Treat rendered Secrets as sensitive even if their values appear encoded.

**Troubleshooting.** “No matches for selector” during patching often means the kind, name or API version did not match the base. Inspect the base alone with `kubectl kustomize labs/kubernetes/base`. If deployment succeeds but the page does not change, compare the mounted ConfigMap reference, Deployment revision and actual response.

**Practice.** Copy the base and overlays to a temporary directory, change the base HTML and render again. Explain why both the generated object name and its consumer reference change. Compare to changing only the replica count.

**Interview. Who continuously corrects drift after a render?** Rendering produces desired manifests. A user or controller must apply or reconcile them. A saved YAML file has no process watching the cluster.

### Further reading

[Kubernetes declarative configuration with Kustomize](https://kubernetes.io/docs/tasks/manage-kubernetes-objects/kustomization/) · [Kustomize reference](https://kubectl.docs.kubernetes.io/references/kustomize/)
