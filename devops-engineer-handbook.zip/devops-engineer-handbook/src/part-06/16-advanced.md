# 16 · Placement, probes, persistent data and access

**By the end** you can reason through a Pending Pod, distinguish three probes and explain why a replica count alone cannot guarantee availability. Start with the workload and routing contracts in chapter 15.

## Where can this Pod run?

The scheduler considers node capacity already allocated to resource requests, selectors, affinity and other constraints. CPU requests are used for placement and influence CPU shares under contention. CPU limits can throttle execution. Memory limits can result in an out-of-memory termination when exceeded. With requests of 25 millicores and 32 MiB, four lab Pods request 0.1 CPU and 128 MiB in total before system overhead. The runtime footprint may be larger.

Node affinity expresses preferences or requirements about nodes. Pod anti-affinity can spread related workloads apart. Topology spread constraints can distribute replicas across zones. A taint repels Pods that lack a matching toleration. A toleration permits placement but cannot guarantee it. The Horizontal Pod Autoscaler (HPA) changes replica count based on metrics. A CPU utilization target depends on CPU requests and a metrics provider. Vertical Pod Autoscaler can recommend or adjust resource sizes, depending on its installation and update policy. A node autoscaler adds or removes machines to satisfy workloads. These loops operate at different speeds.

## Which failure should cause which action?

| Signal | Kubernetes response | Example |
|---|---|---|
| Startup probe | Gives slow initialization a window before readiness and liveness probes take over; repeated startup failure can restart the container. | Loading a local model once. |
| Readiness probe | Excludes an unready endpoint from ordinary Service traffic. | An HTTP worker cannot accept another request. |
| Liveness probe | Repeated failure triggers a container restart according to Pod behavior. | A local event loop is irrecoverably stuck. |

A liveness probe that requires a shared database can cause every API replica to restart during a database outage. Restarting the clients cannot restore the database. A Pod disruption budget (PDB) constrains certain voluntary evictions. It cannot prevent a node crash and it does not automatically regulate Deployment rolling-update deletions. Pair it with rollout settings, spare capacity and placement across independent failure domains.

## Workloads and storage have different identities

A StatefulSet provides stable Pod identities and can associate claims with individual replicas. A DaemonSet runs a Pod on each eligible node, useful for node-level telemetry. Neither controller makes a database consistent across replicas. A PersistentVolume (PV) represents storage, a PersistentVolumeClaim (PVC) requests it, and a StorageClass describes provisioning policy and a driver. Binding may depend on requested size, access mode, node topology and volume binding mode. ReadWriteOnce generally restricts read-write mounting to one node; it is not a single-process write lock.

An Ingress declares routing to Services and requires a controller. Gateway API offers typed resources such as GatewayClass, Gateway and HTTPRoute with separate infrastructure and application responsibilities. Its CRDs and a compatible implementation must exist. An object accepted by the API may still lack a programmed route. Inspect status and controller events.

## Lab · Predict a scheduling failure without causing an outage

```bash
# Inspect requests/limits, probe status and placement of existing training Pods.
kubectl --context kind-handbook -n handbook describe deployment status-web
kubectl --context kind-handbook -n handbook get pod -o wide
# Examine allocatable capacity and current commitments on the local node.
kubectl --context kind-handbook describe node handbook-control-plane
# Check which storage classes and ingress controllers are represented.
kubectl --context kind-handbook get storageclass,ingressclass
```

Now assume a node has 1 CPU available for new requests and the next Pod requests 1500m. Predict whether idle CPU at observation time makes it schedulable. The request exceeds allocatable headroom. Identify the failed scheduling event you would look for. For a live demo create a separate disposable Deployment with one oversized request, describe the Pending Pod and delete that demo Deployment after observation.

## Security and recovery

RBAC binds verbs on resources to subjects. A service account gives a workload a cluster identity. Disable automatic credential mounting when the application never calls the Kubernetes API. NetworkPolicy describes allowed traffic when the network plugin enforces it. A default-deny egress policy often needs explicit DNS access. Check both ingress and egress policies for a path.

A control-plane backup and a volume backup protect different state. A managed Kubernetes provider may own etcd recovery while the application owner still owns database recovery. Before a cluster upgrade, inventory deprecated APIs, check component version skew and add-on support, restore a recent backup in a separate environment and rehearse a small node-pool rollout.

**Practice.** Two replicas and a PDB requiring two available replicas block a planned node drain. Explain when this is the desired safety signal. Propose adding capacity and verifying readiness before repeating the drain.

**Interview. Would increasing a CPU limit fix a Pending Pod?** Inspect the scheduler's reason first. Requests, placement constraints or unbound volumes may be decisive. CPU throttling after the Pod starts is a different condition.

### Further reading

[Resource management](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/) · [Probes](https://kubernetes.io/docs/concepts/configuration/liveness-readiness-startup-probes/) · [Persistent volumes](https://kubernetes.io/docs/concepts/storage/persistent-volumes/) · [Gateway API](https://kubernetes.io/docs/concepts/services-networking/gateway/) · [Disruptions](https://kubernetes.io/docs/concepts/workloads/pods/disruptions/)
