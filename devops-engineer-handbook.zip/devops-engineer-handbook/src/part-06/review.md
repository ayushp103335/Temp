# Part 6 review · Kubernetes

## Revision and assessment

**What might keep a replacement Pod from restoring availability?**

Placement constraints, unavailable storage, image pull failures, lack of capacity or failing readiness checks.

## Practical assignment

Render two overlays, deploy the staging service in a dedicated cluster and prove it recovers from one Pod loss.

## Mini-project and self-evaluation

Show the changed Pod identity, stable Service name and ready endpoints. Separate a one-node exercise from proof of zone resilience.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
