# 19 · Operate Kubernetes through a disruption

**By the end** you can build a maintenance plan, calculate spare capacity and distinguish control-plane recovery from recovery of application data. Use chapters 14–18. The single-node kind cluster is useful for inspecting evidence; a multi-zone fault-tolerance claim requires a different environment.

## A node drain is a capacity calculation

Consider three zones, one worker in each. The service needs two healthy replicas to meet peak traffic. Three replicas spread across all three zones can lose one replica and still meet that requirement if the remaining nodes, database and ingress can handle the load. A fourth replica placed without a spread rule might land beside another in the same zone. Count independent failure domains and capacity after a loss.

A Deployment with `maxUnavailable: 0` and `maxSurge: 1` may need room for an extra Pod during rollout. A PDB allowing one voluntary disruption can permit a maintenance eviction. Neither creates spare node capacity. Autoscaling may eventually add a node, but image downloads, volume attachment and startup time all count during recovery. Managed control planes remove some administrative work while leaving workload placement, add-on compatibility, access and data recovery with the application team.

## A maintenance runbook

1. **Inventory the actual work.** Record the cluster version, nodes and zones, current Pods and their owners, rollout status, storage topology and PDBs. Locate singleton workloads, local storage and jobs with side effects.
2. **Establish headroom.** Calculate available CPU, memory and attachment capacity in surviving zones. Confirm the ingress and database can serve peak traffic there.
3. **Move one failure domain at a time.** Cordon a node to prevent ordinary new scheduling there. Drain uses eviction where supported and awaits workload movement under its options and constraints. A blocked eviction is evidence to investigate.
4. **Check user outcomes.** Verify a synthetic request, completions, queue age and latency. Compare the new baseline to the pre-maintenance measurements.
5. **Return capacity deliberately.** Verify node health, networking and storage attachment, then uncordon. Record how long each transition took and which operator could stop the change.

## Lab · Write a preflight report from a local cluster

```bash
# Record resources and placement in the disposable cluster.
kubectl --context kind-handbook get nodes -o wide
kubectl --context kind-handbook -n handbook get pods -o wide
kubectl --context kind-handbook -n handbook get pdb,pvc
# Inspect readiness and recent events during a rollout.
kubectl --context kind-handbook -n handbook rollout status deployment/status-web
kubectl --context kind-handbook -n handbook get events --sort-by=.metadata.creationTimestamp
# Ask which nodes claim zone labels and preserve the output in your report.
kubectl --context kind-handbook get nodes -L topology.kubernetes.io/zone
```

On a typical single-node kind cluster the zone column may be empty. Write the conclusion you can support: the lab demonstrates reconciliation on one node. Draining its only schedulable node cannot demonstrate uninterrupted service. In a multi-node rehearsal, inspect the disruption budget and reserve capacity first. Avoid forcing evictions to make a checklist turn green.

## Diagnose the failing boundary

| Symptom | Evidence to collect before a change | Possible mitigation |
|---|---|---|
| New Pods remain Pending | Scheduler event, requests, constraints, PVC binding | Add matching capacity or correct constraints. |
| Ready count drops just after startup | Container logs, probe path, timeouts, endpoint list | Correct the probe or restore a working version. |
| Database Pod starts with empty data | Bound claim, volume identity, application mount and restore record | Isolate writes and recover the correct data. |
| Public endpoint fails while Pod is healthy | Controller status, TLS certificate, route host and Service endpoints | Repair the failing routing layer. |
| Restart count grows | Previous container logs, termination reason, memory limits | Address the failure cause and verify request success. |

Control-plane backups capture cluster configuration. Database-native backups, volume snapshots and object-storage policies protect other data. Record **recovery point objective (RPO)** as the maximum tolerable data loss measured in time, and **recovery time objective (RTO)** as the target elapsed time to usable service. A thirty-minute snapshot schedule alone cannot promise a thirty-minute RTO. Rehearse restore to an isolated environment, verify application invariants and measure the clock.

**Security review.** Restrict who can modify cluster-wide admission, RBAC and network controls. Preserve auditable identities for incident changes. Centralize logs before losing a node. Tune requests from observed working sets over representative load and test performance after every cost reduction.

**Practice.** Design a maintenance decision for a fleet with four replicas, two per node on two nodes, with peak demand equal to three replicas. Losing one node leaves two. State whether to proceed and how much healthy capacity must be added outside the affected node.

**Interview. What proves disaster recovery worked?** A fresh client can perform the agreed critical workflow, its data reconciles to the accepted recovery point, access and monitoring work, and measured recovery time is within the objective.

### Further reading

[Operating highly available clusters](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/high-availability/) · [Safely draining nodes](https://kubernetes.io/docs/tasks/administer-cluster/safely-drain-node/) · [Backing up etcd](https://kubernetes.io/docs/tasks/administer-cluster/configure-upgrade-etcd/)
