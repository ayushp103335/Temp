# 15 · Kubernetes objects and the contracts between them

**By the end** you can trace a request from a Service to a ready backend, select the appropriate workload controller and read a manifest without treating every YAML field as a new concept. Use the training cluster and deployment from chapter 14.

## Four fields unlock most manifests

`apiVersion` identifies a served API group/version. `kind` selects an object type. `metadata` supplies names, labels and annotations. `spec` declares what the object should do for types that use it. The system writes observations into `status`. A label is an identifying key/value used by selectors. An annotation carries supporting metadata such as a release note or configuration checksum.

Open `labs/kubernetes/base/deployment.yaml`. The Deployment selector must match its Pod template labels. Its ReplicaSet creates two Pods from that template. Containers in one Pod share the Pod network and can share mounted volumes. An init container typically runs to completion before ordinary application containers start. A sidecar runs alongside the main process, for example to forward telemetry. Native restartable init sidecars have version-dependent behavior. Check the cluster's supported API before adopting a lifecycle pattern.

## How a Service finds a Pod

The Service in `service.yaml` selects `app: status-web`, exposes port 80 and sends traffic to the Pod port named `http`, which the Deployment maps to 8080. EndpointSlices track backend addresses and readiness. The Service gives clients a stable destination while the selected Pod addresses change.

| Object or exposure | Choose it when | Operating detail |
|---|---|---|
| ClusterIP Service | Other workloads need a stable internal address. | The default type. Inspect endpoints if connections fail. |
| NodePort Service | A client or external balancer must reach a port on eligible nodes. | Routing, firewall and node reachability still apply. |
| LoadBalancer Service | A controller can provision external or internal load-balancing infrastructure. | Provisioning may incur charges; local clusters often need an implementation. |
| Job | Work should complete successfully a specified number of times. | Handle retries and duplicate external effects. |
| CronJob | Jobs should start according to a schedule. | Set a concurrency policy and handle delayed or duplicate execution. |
| ConfigMap | Nonsecret configuration belongs outside the image. | A file mount and an environment snapshot have different update behavior. |
| Secret | A credential must reach an authorized workload. | Base64 is encoding. Use encryption at rest and restrict API and Pod access. |

A namespace divides names and scopes many policies and quotas. Network isolation requires additional controls. Secrets can be accessed indirectly by someone allowed to create Pods that mount them. Consider workload creation permission when reviewing secret access.

> **Operator tip.** Compare the selector with the live Pod labels before restarting a workload. A single mismatch can explain an empty service.

## Lab · Separate a selector error from an application error

```bash
# Inspect matching Pod labels and the addresses advertised by the Service.
kubectl --context kind-handbook -n handbook get pods --show-labels
kubectl --context kind-handbook -n handbook get endpointslices -l kubernetes.io/service-name=status-web
# Forward a local port to a selected backend. Leave this terminal running.
kubectl --context kind-handbook -n handbook port-forward service/status-web 8089:80
```

In a second terminal, run `curl -i http://127.0.0.1:8089/`. Expect a page containing “Job dashboard is available.” Stop the forward with Ctrl+C. A Service port-forward chooses a backing Pod and uses the Kubernetes API tunnel. It establishes that the selected application can respond; it does not exercise every hop of the in-cluster Service dataplane.

For a disposable selector drill, edit a copy of the Service's selector to a value no Pod carries and apply it to the training namespace. Watch EndpointSlices. Reapply the base with `kubectl --context kind-handbook -n handbook apply -k labs/kubernetes/base`. Wait for endpoints to return and repeat your request. Comparing two concrete label values is faster than restarting both tiers.

**Practice.** Choose objects for a web API, a nightly aggregation task and a shared nonsecret configuration file. State who recreates each workload if a node disappears.

**Interview. A Service has an IP but no ready endpoints. What next?** Inspect namespace, selector, Pod labels and readiness conditions. If addresses exist, move to target port, listener and network policy. A Service IP alone says little about available capacity.

### Further reading

[Kubernetes Services](https://kubernetes.io/docs/concepts/services-networking/service/) · [Pods](https://kubernetes.io/docs/concepts/workloads/pods/) · [Jobs](https://kubernetes.io/docs/concepts/workloads/controllers/job/) · [Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)
