# 14 · Kubernetes as a set of control loops

**By the end** you can explain what happens after an operator asks for two copies of a service, identify the component responsible for each transition and start a dedicated local cluster. You need chapter 13, a working Docker daemon, kind and kubectl. Use a disposable development machine. Allow capacity for the node image and application images.

## Why add an orchestrator?

Compose can run a set of containers on one host. Suppose a team now needs to place copies on several machines, replace failed copies, change versions gradually and keep one service address while individual processes move. An orchestrator coordinates those tasks. Kubernetes gives the user an API for desired state and runs controllers that act on discrepancies. It also introduces a control plane, networking plugins, storage integration and upgrades. A small single-host application can reasonably stay on Compose.

A cluster contains control-plane components and worker nodes. The API server accepts authenticated, authorized requests and applies admission and validation rules. The cluster's persistent configuration is backed by etcd. Controllers watch API objects. A Deployment controller manages ReplicaSets, and a ReplicaSet controller requests Pods. A Pod is a group of containers scheduled together. The scheduler selects a suitable node for an unscheduled Pod; the node's kubelet asks the container runtime to start it and reports status.

```mermaid
flowchart TD
  Client["kubectl"] --> API["API server"]
  API --> DB["etcd"]
  Controllers["Controllers"] <--> API
  Scheduler["Scheduler"] <--> API
  Kubelet["Node kubelet"] <--> API
  Kubelet --> Runtime["Container runtime"]
  Runtime --> Pods["Pod containers"]
```

These components communicate through recorded state. An accepted API write and an available running service are different events. A scheduler can bind a Pod while its image is still unavailable. kube-proxy or an alternative dataplane implements Service forwarding, depending on the cluster. It does not choose where Pods are scheduled.

## Lab · Observe reconciliation on kind

Install kind and kubectl using their platform-specific instructions below. kind runs Kubernetes nodes as containers. Check the command-line context before every cluster-changing exercise. Use a kubectl minor version supported by your API server.

```bash
# Create a dedicated local cluster and inspect its context and node readiness.
kind create cluster --name handbook
kubectl config current-context
kubectl --context kind-handbook get nodes -o wide
# Create a namespace for this exercise and submit the supplied manifests.
kubectl --context kind-handbook create namespace handbook
kubectl --context kind-handbook -n handbook apply -k labs/kubernetes/base
# Wait for the Deployment, then inspect its child objects.
kubectl --context kind-handbook -n handbook rollout status deployment/status-web --timeout=180s
kubectl --context kind-handbook -n handbook get deploy,rs,pods
```

Expect two ready replicas after the image has been pulled. The Deployment name remains stable. The generated ReplicaSet and Pod names contain suffixes. If progress stalls, inspect `kubectl --context kind-handbook -n handbook get events --sort-by=.metadata.creationTimestamp` and describe the affected Pod. A Pending Pod with failed scheduling events needs a different intervention from a scheduled Pod whose image pull failed.

**Exercise.** List Pod names, delete one Pod by its exact name inside the training namespace, and list them again. The controller creates another because the desired count remains two. A direct Pod without an owning controller has a different recovery story. Deleting the Deployment removes the desired state itself.

**Operate safely.** An exported kubeconfig can contain sensitive credentials. Keep it private. The context determines cluster and identity; the namespace scopes many resources, but nodes and some other objects are cluster-wide. For full teardown at the end of the part, `kind delete cluster --name handbook` removes the local training cluster and its local state.

**Interview. Can existing processes run during an API-server outage?** Existing containers may continue serving while the control plane cannot accept changes or reliably coordinate replacement and scheduling. Availability depends on which component failed and whether existing traffic needs it.

### Further reading

[Kubernetes cluster architecture](https://kubernetes.io/docs/concepts/architecture/) · [kind quick start](https://kind.sigs.k8s.io/docs/user/quick-start/) · [kubectl installation](https://kubernetes.io/docs/tasks/tools/)
