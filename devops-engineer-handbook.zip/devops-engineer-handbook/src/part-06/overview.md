# Part 6 · Kubernetes

**Study time:** 10–15 h including practice. **Starting point:** Parts 3 and 5; Docker-capable host, kind, kubectl and Helm.

Interpret desired state, placement and routing, then review configuration changes before applying them.

## What you will demonstrate

Render two overlays, deploy the staging service in a dedicated cluster and prove it recovers from one Pod loss.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
