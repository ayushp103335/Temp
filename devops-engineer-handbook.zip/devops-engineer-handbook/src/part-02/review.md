# Part 2 review · Linux and system administration

## Revision and assessment

**How can a filesystem fill up while a deleted log is missing from directory listings?**

A process can retain an open reference. Inspect file descriptors and coordinate a supported log reopen.

## Practical assignment

Restore the chapter 6 fixture into a new directory, prove byte equality and run the application against it.

## Mini-project and self-evaluation

Explain permissions on every directory in the fixture path and show a restore failure that checksum verification detects.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
