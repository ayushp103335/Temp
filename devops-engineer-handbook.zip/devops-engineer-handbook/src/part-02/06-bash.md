# 6 · Write Bash automation you can operate

**By the end** you can design a command's success contract, quote input safely, publish a complete backup and run an automation twice. Use GNU/Linux, Bash, tar and coreutils. Start with chapters 4–5 and a private directory.

## From a command line to an interface

A script is a program other people and schedulers will call. Decide what its inputs mean, where it writes, what a retry will do and how it signals failure. Our disk checker prints one measurement on standard output. It returns 0 below threshold, 1 at or above it and 2 for invalid arguments; lower-level utility errors can also propagate. A monitoring wrapper must preserve that distinction if it expects to page someone.

Bash variables normally contain strings. `((...))` evaluates an arithmetic expression. `[[ ... ]]` tests conditions. The first positional argument is `$1`, the argument count is `$#`, and `"$@"` expands each argument separately. Quote variable expansions that represent paths. Otherwise spaces split a single path into multiple arguments and wildcard characters can expand against your filesystem.

```bash
# Define a function. "local" gives the names function scope.
check_paths() {
    local path
    for path in "$@"; do
        if [[ -r "$path" ]]; then
            printf 'readable: %s\n' "$path"
        else
            printf 'unreadable: %s\n' "$path" >&2
            return 1
        fi
    done
}
# A Bash array preserves each path as a distinct value.
fixtures=(labs/release/service.py labs/release/jobs.json)
check_paths "${fixtures[@]}"
```

A function's return code describes success or failure. Its printed output is a separate channel. `set -u` catches many accidental references to unset variables. `set -o pipefail` exposes failure earlier in a pipeline. `set -e` exits on many unhandled failures, with exceptions in conditions and other shell contexts. Write explicit branches for expected failures. Avoid enabling command tracing around secrets because expanded arguments can reach logs.

## Lab · Quarantine a partial backup

Open `labs/linux/backup.sh` alongside these instructions. It resolves the source and destination, rejects a destination inside the source, makes a private staging directory, writes the archive and its checksum, and renames the directory on the same filesystem. A cooperating reader looks only for published names starting with `backup-`. It cannot accidentally pick up the partially written archive. An interrupted run may leave a hidden staging directory after an abrupt machine failure.

```bash
# Create separate source, archive and restore directories with a space in a name.
run=$(mktemp -d)
mkdir "$run/input data" "$run/backups" "$run/restore"
cp labs/release/jobs.json "$run/input data/"
# Capture the published backup directory printed by the script.
snapshot=$(bash labs/linux/backup.sh "$run/input data" "$run/backups")
# Verify the archive bytes against their recorded digest.
(cd "$snapshot" && sha256sum -c SHA256SUMS)
# Recover into a clean destination and compare the restored content.
tar -xzf "$snapshot/data.tar.gz" -C "$run/restore"
cmp "$run/input data/jobs.json" "$run/restore/jobs.json"
# Confirm that an overlapping destination is refused.
if bash labs/linux/backup.sh "$run/input data" "$run/input data"; then
    echo 'Unexpected acceptance'
else
    echo 'Overlapping destination rejected'
fi
```

A successful `cmp` is silent. A checksum confirms byte integrity against its manifest. An attacker able to replace both could defeat that check. A file archive of a changing database may be inconsistent even if every checksum matches. Use the database's supported backup protocol and exercise application-level recovery.

## Six scripts and their boundaries

| File in `labs/linux/` | Example invocation from that directory | Behavior and operating boundary |
|---|---|---|
| `backup.sh` | `bash backup.sh SRC DEST` | Both directories must exist. Publishes into a unique directory. Budget retention separately. |
| `disk.sh` | `bash disk.sh . 85` | Checks the filesystem containing the path. Check inodes separately. |
| `health.sh` | `bash health.sh .` | Captures UTC, load, available memory and disk use. Take more than one sample for a trend. |
| `cleanup.sh` | `bash cleanup.sh LOG_DIR` | Lists matching demo logs older than seven days. A marker and `--apply` are required for deletion. |
| `restart.sh` | `bash restart.sh` | Reads a fixed user unit. The explicit `--apply` restarts that unit and checks its state. |
| `user.sh` | `bash user.sh` | Previews one dedicated system account. A privileged `--apply` creates it on a disposable VM. |

When scheduling the health script, redirect output to a controlled log or send it to the journal. Add a time, the measured path and the result to each observation. A restart script running every minute can hide a real outage. First inspect the exit reason, capture evidence and cap retry frequency. A user creation script that sees an existing account should report its identity. Verify its ownership and policy before repurposing it.

## Lab · Preview and apply a retention policy

```bash
# Make a marked directory containing one eligible log and one file to preserve.
logs=$(mktemp -d)
touch "$logs/.handbook-logs" "$logs/demo-old.log" "$logs/demo-new.log"
touch -d '9 days ago' "$logs/demo-old.log"
# Preview the old path, apply the same rule, then run the preview again.
bash labs/linux/cleanup.sh "$logs"
bash labs/linux/cleanup.sh "$logs" --apply
bash labs/linux/cleanup.sh "$logs"
# Check that the recent file survived.
test -f "$logs/demo-new.log"
```

**Troubleshooting.** A `Permission denied` from direct execution may mean the script lacks an execute bit or the mount disallows execution. Invoking Bash explicitly still requires read permission. A cron-only failure often points to a relative path, missing environment variable or different user.

**Practice.** Call the disk checker with `0`, `85` and a nonexistent path. Record output, error and status separately. Design an alert that identifies a broken measurement.

**Interview. Is a unique backup directory idempotent?** Repeating the backup creates another snapshot, so storage state changes. Retrying the cleanup on an unchanged directory converges to the same retained set. Decide which contract the caller needs.

### Further reading

[Bash reference manual](https://www.gnu.org/software/bash/manual/bash.html) · [GNU tar manual](https://www.gnu.org/software/tar/manual/tar.html) · [GNU coreutils](https://www.gnu.org/software/coreutils/manual/coreutils.html)
