# 4 · Linux from the point of view of a service

**By the end** you can find a program, identify the account running it, predict access to a file and distinguish a process from a supervised service. Use Bash on GNU/Linux. On Windows, an Ubuntu WSL2 terminal works for the file lab. The optional service lab requires a working systemd user session.

## What runs when you press Enter?

Linux is the kernel, the part of the operating system that schedules processes, manages memory and controls access to devices and files. A distribution such as Debian, Ubuntu or Fedora adds tools, packages and a release policy. Bash is a shell: it interprets the line you type, expands variables, starts programs and reports their exit status.

When you run `python3 labs/release/service.py labs/release/jobs.json`, Bash searches the directories in the `PATH` environment variable for the Python interpreter. The kernel starts it under your user and group identities. Python opens the program and the JSON file relative to the current working directory. A service can run the same command with another identity, directory or environment. All three can explain “works in my terminal.”

| Path | Typical contents | Question it answers |
|---|---|---|
| `/etc` | Host configuration | Which settings did the administrator intend? |
| `/usr/bin` | Installed executables | Which binary can this unit start? |
| `/var/lib`, `/var/log` | Persistent application state and many logs | What must survive a restart? Where is evidence retained? |
| `/run`, `/tmp` | Runtime state and temporary files | Could this disappear across a reboot or cleanup? |
| `/proc`, `/sys` | Kernel-provided views | What does the running system report? |
| `/home` | Users' working files | Does a system service really need access here? |

An absolute path starts at `/`. A relative path starts at the process's current directory. `.` means this directory and `..` its parent. A variable such as `LAB_DIR` only reaches child processes if exported or provided with the command.

## Permissions are checked along the whole path

The three permission classes are owner, group and others. For a regular file, read allows reading bytes, write allows changing bytes and execute allows asking the kernel to execute it. For a directory, read lists names, execute searches or traverses it, and write with execute can create or remove entries, subject to other controls. This explains how an account can read a file but be unable to open it through an inaccessible parent.

```bash
# See your user and group IDs before reasoning about access.
id
# Build a private lab containing a copy of the fixture.
work=$(mktemp -d)
mkdir "$work/incoming"
cp labs/release/jobs.json "$work/incoming/batch.json"
# Set permissions to owner read/write and group read, then inspect them.
chmod 640 "$work/incoming/batch.json"
ls -ld "$work" "$work/incoming" "$work/incoming/batch.json"
# Inspect path, owner, mode and size using GNU stat.
stat -c '%n owner=%U group=%G mode=%a bytes=%s' "$work/incoming/batch.json"
# Rename the directory entry and list the surviving contents.
mv "$work/incoming/batch.json" "$work/incoming/accepted.json"
ls "$work/incoming"
```

Octal 6 adds read (4) and write (2). The final 0 grants outsiders no permissions on the file. Even a group allowed to read the file must traverse the private directory made by `mktemp`. `chgrp GROUP PATH` changes group ownership to an eligible group. An administrator can use `chown USER:GROUP PATH` to set both. Investigate the current owner and each directory before changing permissions. A blanket grant of write permission would let other users edit the work being processed.

## Processes, supervisors and startup

A process is a running instance with a process ID (PID), open files and an environment. A daemon is a background service. A supervisor can start it at boot, keep its output and decide when to restart. `systemctl start` activates a unit now. `systemctl enable` connects it to startup targets. `--user` selects your user's service manager.

```bash
# In a Linux VM with user systemd, install the example for your account.
mkdir -p "$HOME/.config/systemd/user"
install -m 644 labs/linux/handbook-demo.service "$HOME/.config/systemd/user/"
# Reload definitions, then start the exercise unit.
systemctl --user daemon-reload
systemctl --user start handbook-demo.service
# Inspect supervision state and recent messages for this unit.
systemctl --user status handbook-demo.service
journalctl --user -u handbook-demo.service -n 20 --no-pager
# Stop the exercise, remove its definition and refresh the manager.
systemctl --user stop handbook-demo.service
rm "$HOME/.config/systemd/user/handbook-demo.service"
systemctl --user daemon-reload
```

Use a fresh VM or verify that the exercise unit name is unused. Open the unit file first. `ExecStart` selects an absolute executable, `Type=exec` waits for the program to execute successfully, and `Restart=on-failure` retries unexpected failure after `RestartSec`. A running sleep process proves supervision only. An application needs an additional behavior check. A “failed to connect to bus” message points to the service-manager session.

## Daily operation

Use your distribution's package manager to install signed packages and resolve dependencies. On Debian/Ubuntu, `apt-cache policy curl` shows installed and candidate versions. `sudo apt update` refreshes metadata. `sudo apt install curl` installs the chosen package. Fedora uses `dnf info curl` and `sudo dnf install curl`. Older RPM-based systems use `yum`, sometimes as a compatibility command for DNF. `sudo` executes a permitted command under another identity, commonly root. Keep day-to-day investigation unprivileged.

To connect to a VM you administer, `ssh USER@HOST` opens an encrypted remote session. Replace both placeholders and verify the host key fingerprint through the provisioning record before accepting it. Keep private keys on the client. For scheduling, a common user crontab line is `15 2 * * * /absolute/path/health.sh`. It asks cron to run at 02:15 each day according to the scheduler's timezone. Use absolute paths, set the required environment, choose where logs go and account for overlapping runs.

## Diagnose before restarting

| Symptom | Inspect | Interpretation |
|---|---|---|
| Process disappears | `journalctl -u UNIT -n 40` | Exit code, missing path or repeated startup failure. |
| Writes fail | `df -h PATH` and `df -i PATH` | Byte capacity and inode capacity can be exhausted independently. |
| Host feels slow | `free -h`, `uptime`, `ps -eo pid,comm,rss --sort=-rss` | Compare available memory, runnable or blocked work, and large processes. |
| Different binary in automation | `command -v python3` and unit `ExecStart` | Different search path or interpreter. |

**Practice.** Give another team read access to one output directory on paper. Specify file mode, directory traversal and group membership. Identify one access the team should never inherit.

**Interview. Why can root read a file when the application cannot?** Their effective identities and capabilities differ. Reproduce the check as the service account and inspect the path. A root-shell success is weak evidence for service health.

### Further reading

[Filesystem hierarchy](https://refspecs.linuxfoundation.org/FHS_3.0/fhs/index.html) · [GNU coreutils manual](https://www.gnu.org/software/coreutils/manual/coreutils.html) · [systemd service configuration](https://www.freedesktop.org/software/systemd/man/latest/systemd.service.html)
