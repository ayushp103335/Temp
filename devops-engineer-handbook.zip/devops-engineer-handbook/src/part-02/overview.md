# Part 2 · Linux and system administration

**Study time:** 6–9 h including practice. **Starting point:** Part 1; a GNU/Linux shell.

Relate a pathname to its filesystem, an open file to its process, and a service to its operating identity.

## What you will demonstrate

Restore the chapter 6 fixture into a new directory, prove byte equality and run the application against it.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
