# 5 · Diagnose a Linux host under load

**By the end** you can follow an open file, explain why deleting a large log may free no space, and separate CPU pressure from storage pressure. Complete chapter 4. The lab requires a Linux kernel exposing `/proc` and Python 3. It uses a small temporary file.

## From power-on to a worker

Firmware selects a boot target, a bootloader loads the kernel and often an initial RAM filesystem, and early userspace prepares the real root filesystem. The kernel starts the first userspace process, commonly systemd. That manager follows dependencies to mount filesystems and launch services. If a required data disk mounts late, a worker may write into the directory underneath the intended mount. Mounting the disk hides those early files from the normal pathname. Check the filesystem actually backing a path before deciding where the data went.

A disk may be divided into partitions. A filesystem manages files, directories, names and free space on a volume. A mount connects that filesystem to a directory in the visible tree. Logical Volume Manager (LVM) can pool physical volumes into a volume group and allocate logical volumes from it. Increasing a virtual disk, growing a partition or physical volume, extending a logical volume and growing its filesystem can be separate operations. The exact sequence depends on the layout and filesystem. Inventory first.

```bash
# Print block devices, filesystem types and mount points where available.
lsblk -f
# Identify the filesystem backing the current directory.
findmnt -T .
# Compare space usage with inode consumption.
df -h .
df -i .
```

> **Common mistake.** Extending a block device can leave the filesystem at its original size. Check the device, volume and filesystem separately.

## Connections that outlive a name

When a process opens a file, the kernel returns a small integer called a file descriptor. Standard input, output and error conventionally occupy descriptors 0, 1 and 2. A pipe connects one process's output to another's input. `>` creates or truncates a file, `>>` appends, and `2>` redirects errors. Redirections are applied in order. In `job >run.log 2>&1`, the second operation points errors at the already redirected output.

A directory entry names a file. Removing its last name can leave its storage allocated while a process still has it open. This is a common explanation when the filesystem reports more use than a walk of visible files.

```bash
# Run a self-contained experiment. The context manager closes the descriptor.
python3 - <<'PY'
import os
from pathlib import Path
from tempfile import TemporaryDirectory

with TemporaryDirectory() as directory:
    path = Path(directory) / "worker.log"
    with path.open("w+") as stream:
        stream.write("job=demo-001 result=done\n")
        stream.flush()
        path.unlink()
        print("name exists:", path.exists())
        print("open descriptor:", os.readlink(f"/proc/self/fd/{stream.fileno()}"))
        stream.seek(0)
        print("still readable:", stream.read().strip())
PY
```

Expect `False`, a path ending in `(deleted)` and the original log line. On a live host, an authorized operator can inspect open deleted files with `lsof +L1` where installed. Arrange for the owning daemon to reopen logs using its supported rotation mechanism. A broad restart can interrupt valid work. Signals are requests to processes: TERM asks for orderly termination and KILL prevents cleanup. HUP behavior depends on the program.

## Use a pipeline to test a hypothesis

```bash
# Build four synthetic worker events in a private directory.
logdir=$(mktemp -d)
printf '%s\n' 'api ok' 'worker retry' 'worker ok' 'worker retry' > "$logdir/events"
# Filter the worker lines, extract status, group identical values and count.
grep '^worker ' "$logdir/events" | awk '{print $2}' | sort | uniq -c
# Transform the label in displayed output while preserving the original file.
sed 's/^worker /consumer /' "$logdir/events"
# Process filenames safely even when a path contains spaces.
find "$logdir" -type f -print0 | xargs -0 -r wc -l
```

The first pipeline yields one ok and two retries. `uniq` compares adjacent lines, which explains the sort. `cut -d' ' -f2` also extracts a field when the delimiter is reliably a single space. Structured JSON with escaped strings needs a JSON parser.

## Triage with competing hypotheses

A load average counts runnable tasks and tasks in certain uninterruptible waits. A high average may indicate blocked I/O. Measure over time. `vmstat 1 5` samples runnable tasks, swap activity and CPU categories; the first row typically summarizes time since boot. Memory used for file cache can be reclaimed. Compare available memory and sustained swap-in/out before prescribing more RAM. Swap lets cold pages move out of RAM. Frequent page movement can make a process painfully slow.

| Evidence | Plausible bottleneck | Next check |
|---|---|---|
| Long runnable queue and busy CPU over multiple samples | Compute saturation | Identify the hot process and its workload. |
| Write latency rises and tasks wait while CPUs have idle time | Storage or remote mount | Check device latency and the specific mount carrying writes. |
| File creation fails with free bytes available | Inodes or quota | Inspect inode use and the affected account's quota. |
| Unexpected exit under load | Kernel or container memory limit | Check kernel or cgroup events and recent working-set growth. |

**Practice.** Explain why deleting logs cannot fix exhausted inodes when the real problem is millions of unrelated tiny files. Choose a read-only query to distinguish that case from an open deleted file.

**Interview. Would increasing swap fix a memory leak?** It may delay failure while latency grows. Measure memory against request count, inspect the largest processes and fix the retained allocation. The appropriate mitigation depends on how much service capacity remains.

### Further reading

[Linux kernel proc filesystem](https://docs.kernel.org/filesystems/proc.html) · [Linux open file descriptions](https://man7.org/linux/man-pages/man2/open.2.html) · [GNU findutils](https://www.gnu.org/software/findutils/manual/html_mono/find.html)
