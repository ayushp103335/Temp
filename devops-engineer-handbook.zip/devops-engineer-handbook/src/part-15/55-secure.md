# 55 · Project 9 · Gate and sign a release

**Business problem.** A release owner wants an identified image, a software inventory, code-quality and vulnerability gates, and signer verification before promotion. Budget 2–4 hours given an existing supported SonarQube service, a practice GitHub repository, GHCR access and a runner that can reach the scanner databases, SonarQube and Sigstore services. Hosted analysis and storage can incur charges. The local application is the synthetic dashboard from project 2.

```mermaid
flowchart TD
  Source["Protected revision"] --> Sonar["SonarQube quality gate"]
  Sonar --> Candidate["Build and test candidate"]
  Candidate --> Scan["Dependency and image gates"]
  Candidate --> SBOM["CycloneDX inventory"]
  Scan --> Registry["Publish digest"]
  Registry --> Sign["Sign and verify workflow identity"]
```

`labs/security/secure-release.yml` supplies the complete workflow and `sonar-project.properties` scopes analysis to the dashboard. The app, unit tests and Dockerfile come from `labs/docker/app/`. The workflow scans declared dependencies and the saved image; support for a given manifest and detectable transitive dependencies varies by analyzer. Review the inventory from the actual final image and add a locked dependency manifest for a production build.

## Install the release gate

1. Create or select a training SonarQube project with key `handbook-dashboard`. Define the quality gate it should enforce. Configure a narrowly scoped analysis token as the GitHub environment secret `SONAR_TOKEN` and the reachable service URL as variable `SONAR_HOST_URL`.
2. Copy `labs/security/secure-release.yml` to `.github/workflows/secure-release.yml` in the practice repository. Protect main and configure the `training-security` environment before granting its release authority. Review action revisions and scanner image digest according to your policy.
3. Run the workflow manually on main. Observe the Sonar quality result, unit tests, image export, dependency scan, CycloneDX SBOM and vulnerability gate. The strict example rejects high and critical matches. A real unpatched finding may correctly block the exercise. Record it, verify applicability, update the affected dependency or base image, rebuild and rescan.
4. On success, the workflow authenticates to the registry with its job-scoped credential, pushes the candidate, signs the digest using workflow OIDC identity and verifies the certificate issuer and exact workflow identity. Record the resulting digest, verification outcome and SBOM artifact.

## Validate a held release

In a separate training branch review a copy with a deliberately unmet quality threshold or a failing existing unit test. Demonstrate that the gate prevents publication without introducing a vulnerable component. Revert the experimental change. The workflow itself allows signing only on main. Use local unit tests or a separate unprivileged CI job to demonstrate a failing branch check.

A missing quality report may indicate unreachable SonarQube, wrong project key or missing analysis permission. A registry 403 points to the package policy. A signature identity mismatch should prompt inspection of repository, workflow path, ref and identity issuer. Broadening verification to accept arbitrary identities would defeat this project's trust objective. Scan databases and build images change over time; save scan dates and tool versions with decisions.

**Production review.** Separate build, signing and admission roles further, pin reviewed tools to immutable IDs, retain provenance along with the SBOM and enforce signature verification at deployment. A quality gate and signer check do not replace application authorization testing. Limit exception lifetime and use a closure test for each exception. Remove the disposable workflow, environment token and unneeded package versions after the exercise, preserving only approved evidence.

**Portfolio evidence.** Show one held release and one verified digest after a fix. **Interview. Why verify the issuer in addition to the certificate identity?** The policy specifies which trust provider may attest the identity. **Follow-up:** how do you prevent an unrestricted workflow editor from using an otherwise trusted signing workflow?

### Further reading

[SonarQube GitHub integration](https://docs.sonarsource.com/sonarqube-server/devops-platform-integration/github-integration/) · [Trivy SBOM](https://trivy.dev/latest/docs/supply-chain/sbom/) · [Cosign verification](https://docs.sigstore.dev/cosign/verifying/verify/)
