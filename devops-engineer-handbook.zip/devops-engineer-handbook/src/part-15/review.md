# Part 15 review · Real-world projects

## Revision and assessment

**What evidence belongs in a portfolio after a lab could only be rendered offline?**

Keep the validated config and its results, and explicitly label live deployment, runtime and cloud cost as unverified until measured.

## Practical assignment

Choose two projects that share a dependency. Change one interface, show which test catches the incompatibility and recover the system.

## Mini-project and self-evaluation

Retain a diagram, user-level result, failure observation, time or cost measurement, and cleanup record for each project you actually run.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
