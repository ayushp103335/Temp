# 49 · Project 3 · Test, publish and deploy a container by digest

**Business problem.** A release manager needs a reproducible answer to “Which image passed the data-path check and where did it run?” Use a practice GitHub repository with Actions and GitHub Container Registry enabled. Budget 2–3 hours, including one failed pull request and one successful trusted release. Hosted minutes and registry storage may incur charges under your plan.

```mermaid
flowchart TD
  PR["Pull request"] --> Test["Unit tests and Compose smoke test"]
  Main["Trusted main revision"] --> Test
  Test --> Gate{"Trusted release event?"}
  Gate -->|Yes| Publish["Exercise candidate and push to GHCR"]
  Publish --> Deploy["Pull digest on fresh runner"]
  Deploy --> Evidence["Verified business counts and job summary"]
```

## Files and setup

Project 2 supplies the complete `labs/docker/` app, integration config and smoke check. `labs/cicd/dashboard-ci.yml` supplies the workflow. Its installed path is `.github/workflows/dashboard-ci.yml`. The Pages workflow is a separate publication operation. This project deploys a complete test stack to a temporary runner and removes it after verification. Real production promotion needs an independently operated destination.

```bash
# In your practice repository, enable the workflow under the discovery path.
mkdir -p .github/workflows
cp labs/cicd/dashboard-ci.yml .github/workflows/dashboard-ci.yml
# Examine the change before committing; inspect both source and generated destination.
git status --short
diff -u labs/cicd/dashboard-ci.yml .github/workflows/dashboard-ci.yml
```

Commit the workflow on a branch and open a pull request. The branch filter and path filter in the file describe which runs start. Check that **test** runs and publishing is skipped on a pull request. A direct manual run from a non-main branch also skips release. In repository settings establish the `training` environment, configure allowed branches and any available required-reviewer rule. Ensure Actions may create the intended package. The workflow grants its publish job package-write authority and its deployment job package-read authority.

## Acceptance drill

1. In a practice pull request change the cache-hit response to an incorrect body and verify the unit test fails. Save the test name and restore the correct code.
2. After review, merge a qualifying change to main, or manually dispatch on main. Inspect the three jobs. The publish job builds a commit-tagged candidate, uses a Compose override to run that exact image, runs the smoke check and then pushes it.
3. Find the registry digest recorded by the publish job's output and referenced in the final job summary. The deploy job pulls the digest and runs Compose with `--no-build`. It cannot silently compile a different candidate on the target.
4. Confirm that an integration failure prevents the publish job from pushing its candidate. Confirm that a rejected environment approval prevents the deployment job from running.
5. Check teardown even after a failed smoke test. Timeouts at the HTTP and poll layers keep startup issues diagnosable.

| Failure | Inspect first | Recovery |
|---|---|---|
| No workflow run | Filename, default branch, event and changed paths | Enable it under the required directory; trigger an eligible event. |
| Package push denied | Job permissions and package settings | Narrowly grant the trusted job the needed package authority. |
| Candidate starts but check fails | Compose logs and actual JSON | Correct the application or dependency initialization and build a new candidate. |
| Digest unavailable at deployment | Package retention, read scope and exact reference | Recover or rebuild a verified release and record its new identity. |

**Security and production improvements.** Keep secrets out of test fixtures and pull-request jobs. Restrict changes to the release workflow, pin reviewed actions, sign the digest, attach provenance, and verify admission policy in the production environment. Record the last successful digest. A rollback should select and verify that retained version while considering data compatibility.

**Cleanup.** The workflow removes its training stack and volumes in each job. If the repository is only for this exercise, remove the test workflow and delete only the disposable test package versions using the registry's package settings. Retain any version needed to demonstrate rollback.

**Portfolio evidence.** Link the failed check, reviewed fix, digest and verified deployment run after exercising them in your repository. A résumé line can describe the measured result: “Built a GitHub Actions pipeline that exercised a container against PostgreSQL and Redis, published it to GHCR and deployed its digest to an isolated target.”

**Interview. Why test again after publishing?** A fresh target proves registry access, artifact selection and deployment behavior. **Follow-up:** which identity can publish, and which identity only reads the package?

### Further reading

[GitHub Container Registry](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry) · [GitHub deployments](https://docs.github.com/en/actions/how-tos/deploy)
