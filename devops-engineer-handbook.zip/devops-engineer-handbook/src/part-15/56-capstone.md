# 56 · Project 10 · Operate a cloud-native release on EKS

**Business problem.** An engineering team needs to demonstrate that a reviewed change can reach a multi-zone AWS cluster, that operators can observe it, and that the cluster can recover and be retired with a known cost. Build a production-oriented staging environment, then make an evidence-based decision about production readiness. Budget one or two dedicated lab days. AWS charges begin at provisioning.

```mermaid
flowchart TD
  TF["Terraform and protected S3 state"] --> EKS["EKS and two-zone private node network"]
  CI["GitHub Actions"] --> Image["Tested registry digest"]
  Image --> Git["Reviewed deployment overlay"]
  Git --> Argo["Argo CD in EKS"]
  Argo --> App["Replicated status service and HPA"]
  EKS --> App
  App --> Logs["CloudWatch centralized logs"]
  EKS --> Prom["Prometheus and Grafana"]
  Job["Evidence Job with scoped identity"] --> SM["Secrets Manager"]
```

## Requirements, files and cost decision

Use a dedicated commercial AWS training account, two supported availability zones, a **separate remote state key**, sufficient EKS/EC2/IAM quota, an authorized training operator role, and an operator IPv4 /32. Use Bash, Terraform 1.10+, AWS CLI v2, supported kubectl, Helm 3 and an approved Git repository and image registry. Select an EKS Kubernetes minor in standard support in the target region, verify add-on compatibility and select reviewed chart versions for that cluster. The EKS endpoint is also available privately for nodes; public administration is restricted to the operator's /32.

| Location | What it supplies |
|---|---|
| `labs/capstone/main.tf` | VPC, two NAT gateways, EKS, private managed nodes, Pod Identity, centralized logging add-on, secret metadata and scoped reader role. |
| `install-platform.sh` | Installs selected Helm releases for Argo CD, Metrics Server and kube-prometheus-stack. |
| `kustomization.yaml`, `scaling.yaml` | Workload overlay, zone spread preference, horizontal autoscaling, disruption budget and evidence identity. |
| `application.yaml`, `read-secret.sh` | GitOps Application with replica ownership delegated to HPA, plus a secret-read acceptance Job. |
| `../gitops/`, `../kubernetes/base/` | Build workflow, Dockerfile, reviewed image digest and reusable Deployment/Service. |
| `../terraform/aws/backend.hcl.example` | Backend configuration template. Use a new key such as `handbook/capstone/terraform.tfstate`. |

Estimate EKS control-plane hours, three m6i.large node-hours per elapsed hour, EBS storage, two NAT gateway-hours per hour plus data processing, public IPv4, CloudWatch logs and Container Insights, cross-zone traffic, Secrets Manager and retained storage. Compute costs using regional rates and the planned lab duration. Six hours corresponds to 6 cluster-hours, 18 node-hours and 12 NAT gateway-hours before additional services. Record a teardown owner and end time. Use the provider calculator before deciding to apply.

> **Production consideration.** Confirm a separate state key and record the exact cluster name before you plan, apply or destroy. Control-plane, node, NAT and logging costs have separate lifecycles.

## Provision and deploy

1. Complete project 6 in your practice repository, including the `images` section with an actual digest. The capstone reuses that release overlay. Commit the capstone manifests to the same repository. Confirm your nodes can pull the package.
2. From `labs/capstone`, copy `../terraform/aws/backend.hcl.example` to `backend.hcl`. Fill in the existing protected bucket and a new state key. Set `AWS_PROFILE`, `TF_VAR_region`, `TF_VAR_operator_cidr` and `TF_VAR_kubernetes_version` for this training environment. Verify `aws sts get-caller-identity`. Inspect your chosen minor with the EKS version and add-on compatibility tools in the AWS console or API.
3. Run `terraform init -backend-config=backend.hcl`, then `terraform validate` and `terraform plan -out=capstone.tfplan`. Review the account, zones, NAT count, node group, identities and chargeable services before `terraform apply capstone.tfplan`. Retain reviewed provider lockfiles. Node group bounds allow capacity from two to five nodes; changing node count automatically requires a separate node autoscaler. The workload HPA in this project changes Pod count.
4. Configure the intended Kubernetes context and install the platform.

```bash
# Inside labs/capstone, select the provisioned cluster under a distinct local alias.
export AWS_REGION="$TF_VAR_region"
export KUBE_CONTEXT=handbook-capstone
aws eks update-kubeconfig --region "$AWS_REGION" --name "$(terraform output -raw cluster_name)" --alias "$KUBE_CONTEXT"
kubectl --context "$KUBE_CONTEXT" get nodes -L topology.kubernetes.io/zone
# Install the chart versions recorded in the script after reviewing compatibility.
# Override ARGO_CHART, METRICS_CHART or PROM_CHART to select a reviewed alternative.
bash install-platform.sh
```

5. Set the repository URL in `application.yaml` to your practice repository. Apply it with `kubectl --context "$KUBE_CONTEXT" apply -f application.yaml`. Inspect Argo's sync and health conditions, observed Git revision, Pods and ready endpoints. Forward `service/status-web` in namespace `handbook-staging` to a local port and verify the body. Workload exposure is internal in this lab.
6. Put a **synthetic** secret value into the provisioned Secrets Manager record. The value is generated locally, supplied via a file and kept outside Terraform state.

```bash
# Generate a private temporary value, upload it, and erase this exercise's local copy.
export SECRET_ARN="$(terraform output -raw secret_arn)"
keydir=$(mktemp -d)
(umask 077 && python3 -c 'import secrets; print(secrets.token_urlsafe(32))' > "$keydir/value")
aws secretsmanager put-secret-value --secret-id "$SECRET_ARN" --secret-string "file://$keydir/value" --region "$AWS_REGION" >/dev/null
rm "$keydir/value"
rmdir "$keydir"
# Verify the workload identity can read only its configured secret without displaying it.
bash read-secret.sh
```

## Demonstrate operations and decide readiness

Check `kubectl --context "$KUBE_CONTEXT" top pods -n handbook-staging` and `get hpa -n handbook-staging`. A missing metric needs Metrics Server or resource-request diagnosis before tuning the HPA. Use `kubectl get pods -n monitoring` to establish Prometheus and Grafana health, then view their Kubernetes workloads dashboard via a local port-forward to `service/observe-grafana` on port 80. Retrieve its generated admin credential through your approved credential workflow. Check CloudWatch Logs for the namespace and synthetic status-page access. Record a user request, log time, Pod version, scrape evidence and actual placement. The zone preference allows scheduling when capacity is constrained; check where replicas really landed.

Run a controlled Pod replacement on one replica and observe ready endpoints and user requests. Revert one app digest in Git and time recovery. Capture resource consumption around the change and compare with the estimate. The Helm chart's training monitoring storage and one-day retention are intentionally disposable. Durable metrics, off-cluster backups, independent restore tests, policy enforcement, restricted Argo projects, stronger release controls, DNS/TLS at an approved edge and measured zone-loss capacity are decisions for a production deployment. This exercise alone cannot establish a production availability objective.

## Teardown order

Remove the Application and its dedicated workloads while the cluster and credentials still exist. Uninstall the three Helm releases in their original namespaces. Check for Services of type LoadBalancer, external volumes and externally created resources. Then plan destruction of this capstone state, review and apply it. Verify EKS, nodes, NAT gateways, addresses and load balancers are gone. Inspect CloudWatch log groups created by agents, retained snapshots and all state versions for ongoing cost. Secrets Manager schedules recovery-window deletion as configured. Retain or remove independent data only according to the owner's policy.

**Portfolio evidence.** Keep a cost estimate, reviewed plan, Git revision, image identity, deployment health, secret-read success, HPA metrics, log query, recovery time and teardown evidence. Describe only the steps actually performed. **Interview. Why separate the app's CI identity from the cluster's reconciliation identity?** Publishing build output and changing an environment have different authority and audit needs. **Follow-up:** which single-region dependency remains after a two-zone deployment?

### Further reading

[EKS endpoint access](https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html) · [CloudWatch Observability add-on](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/install-CloudWatch-Observability-EKS-addon.html) · [EKS Pod Identity](https://docs.aws.amazon.com/eks/latest/userguide/pod-identities.html) · [AWS Pricing Calculator](https://calculator.aws/)
