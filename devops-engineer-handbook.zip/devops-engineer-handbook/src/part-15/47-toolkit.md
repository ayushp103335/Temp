# 47 · Project 1 · Linux server automation toolkit

**Business problem.** An on-call engineer must determine whether a job worker's disk is filling and restore the previous batch fixture during a rehearsal. The team wants evidence another operator can verify. Build a small toolkit with separate observation, backup and maintenance commands. Budget 90–150 minutes, including writing and reviewing your recovery record.

## Architecture and files

```mermaid
flowchart TD
  Operator["Operator or scheduler"] --> Observe["Health and disk checks"]
  Operator --> Backup["Backup script"]
  Backup --> Archive["Archive, checksum and member list"]
  Archive --> Restore["Isolated restore directory"]
  Restore --> Verify["Compare source and restored fixture"]
  Operator --> Maintenance["Scoped account, cleanup and service operations"]
```

All implementation files are under `labs/linux/`. The directory contains `health.sh`, `disk.sh`, `backup.sh`, `cleanup.sh`, `restart.sh`, `user.sh` and `handbook-demo.service`. Chapter 6 explains their interfaces. The fixture comes from `labs/release/jobs.json`. GNU/Linux, Bash, GNU coreutils and tar are required. User-level systemd and administrative permission are optional for the supervised unit and system account exercises. No cloud resources are used.

## Build an operational evidence set

```bash
# Give this run its own paths so repeated rehearsals do not collide.
lab=$(mktemp -d)
mkdir -p "$lab/input" "$lab/archive" "$lab/restore" "$lab/logs"
cp labs/release/jobs.json "$lab/input/batch.json"
# Capture host conditions with timestamps and a threshold outcome.
bash labs/linux/health.sh "$lab" > "$lab/health-before.txt"
bash labs/linux/disk.sh "$lab" 95
# Snapshot the quiescent directory and retain the location of the published set.
bundle=$(bash labs/linux/backup.sh "$lab/input" "$lab/archive")
cat "$bundle/members.txt"
(cd "$bundle" && sha256sum -c SHA256SUMS)
# Restore to a fresh directory and verify bytes and application behavior.
tar -xzf "$bundle/data.tar.gz" -C "$lab/restore"
cmp "$lab/input/batch.json" "$lab/restore/batch.json"
python3 labs/release/service.py "$lab/restore/batch.json"
# Preview a maintenance operation using the assigned log naming convention.
touch "$lab/logs/.handbook-logs" "$lab/logs/demo-stale.log"
touch -d '10 days ago' "$lab/logs/demo-stale.log"
bash labs/linux/cleanup.sh "$lab/logs"
bash labs/linux/cleanup.sh "$lab/logs" --apply
test ! -e "$lab/logs/demo-stale.log"
```

Expected results include one archived fixture, a passing checksum, two done and one queued, and exactly one eligible stale log. Execute the overlap-rejection exercise from chapter 6. For a failure drill, copy the bundle to a new directory, append a byte to the copied archive and repeat checksum verification there. Keep the original recovery set untouched. Time a full restore from a clean directory and record the result.

## Maintenance scope and handoff

Use the unit setup from chapter 4 for a systemd-enabled VM. `bash labs/linux/restart.sh` reads state. The `--apply` form restarts only the named demo user service. `bash labs/linux/user.sh` previews the dedicated nonlogin account. Only create that account on a disposable VM after checking the name was unused. If you created it, remove it at teardown with `sudo userdel handbook-demo` after ensuring it owns no required data. If the name existed earlier, leave account administration to its owner.

| Failure | Evidence | Correction |
|---|---|---|
| Backup exits before publication | Staging path, free bytes and input readability | Fix space or source access; retry into a fresh snapshot. |
| Script reports unhealthy disk but writes still work | Reported percent versus chosen threshold | Investigate growth and free space before capacity is exhausted. |
| Archive passes checksum but restore is unusable | Application read and expected record count | Fix source consistency or missing inputs, then repeat the restore drill. |

For production, copy verified backups to an independent failure domain, limit reader/writer authority, configure retention, encrypt sensitive material and exercise the real application's restore protocol. The project stores a private local snapshot for training. Recoverable files on the same failed disk do not meet a host-loss recovery objective. Track backup age and most recent successful restore, along with archive size and elapsed restoration time.

**Cleanup.** Check `printf '%s\n' "$lab"` and remove only that disposable run directory after saving the evidence you want. Follow chapter 4 to remove the user service. Local storage cost is the accumulated size of archives and restores.

**Portfolio evidence.** Include the scripts, a redacted successful restore, the failed checksum from the failure drill and the measured restore duration. After performing the lab, a defensible résumé line is “Built a Bash backup and host-check toolkit and verified recovery of a synthetic workload with checksums and an application-level test.”

**Interview. Why verify both checksum and business output?** One confirms stored bytes against the manifest; the other catches a correctly stored but incomplete or unusable source. **Follow-up:** what independent copy would survive loss of this host?

### Further reading

[GNU tar](https://www.gnu.org/software/tar/manual/tar.html) · [systemd service units](https://www.freedesktop.org/software/systemd/man/latest/systemd.service.html)
