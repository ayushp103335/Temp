# 54 · Project 8 · Trace a synthetic job through centralized logs

**Business problem.** Support receives a synthetic job ID and needs to recover its outcome after the application process restarts. Build a file-to-Loki pipeline and demonstrate a repeatable search. Budget 60–90 minutes after project 7. The local stack costs disk and memory; logs can grow for as long as you keep generating traffic.

```mermaid
flowchart TD
  Client["Synthetic work request"] --> App["Work service"]
  App --> File["JSON lines on events volume"]
  File --> Alloy["Alloy tailer and saved position"]
  Alloy --> Loki["Loki stream storage"]
  Query["Grafana Explore query"] --> Loki
```

Use the entire `labs/observability/` project described in project 7. Specifically, `service.py` writes one JSON line per generated job, `compose.yaml` shares the events volume read-only with Alloy and the positions volume retains collector state. `config.alloy` discovers files every five seconds and sends to Loki's push endpoint. `provisioning/datasources/sources.yml` points Grafana to Loki on the internal network. The Loki container uses the supplied single-process configuration in `loki.yml` and a volume at its storage prefix. This installation has one storage copy.

```bash
# From the repository root, start or reuse the shared stack.
cd labs/observability
bash setup.sh
docker compose up -d
# Generate one successful and one failed job. Record the returned synthetic IDs.
curl -sS http://127.0.0.1:8100/work/ok
curl -sS http://127.0.0.1:8100/work/failed
# Compare the producer's last events with the collector and backend logs.
docker compose exec -T work tail -n 2 /events/jobs.log
docker compose logs --tail 30 alloy loki
```

Open Grafana Explore on loopback port 3030. If Explore is unavailable to the anonymous viewer, sign in to the local Grafana instance as admin using the credential generated in `secrets/admin`. Choose Loki and set a recent time range that includes the two observations. Run `{service_name="handbook-jobs"} | json | outcome="failed"`. To retrieve a specific event, add `| job_id="YOUR_SYNTHETIC_ID"` after `| json`. Compare the ID and outcome with the original response. Initial file discovery and batch shipping introduce delay, so record both source time and query time.

**Failure drill.** Stop the Alloy service, generate three events, restart Alloy, and check whether all three appear. Keep the source and positions volumes during this drill. Compare IDs rather than relying solely on counts. Inspect restart position, duplicate entries, time range and backend ingestion failures if the results differ. Restarting the work process does not erase the volume-backed source file. Deleting the volume is a different failure. Production deployments need finite buffer policies for outages longer than local storage capacity.

**Security and improvement.** The job identifiers are synthetic and payloads are excluded. Apply redaction before collection for real services. Add identity and tenant controls before exposing Loki or Grafana and validate actual data retention. Use object storage and a tested availability design appropriate to the volume. Index stable labels and parse unique IDs after stream selection. Evaluate the cost of storage, replication, retention, retrieval and operator queries.

**Cleanup.** Export the few synthetic records needed for the portfolio. `docker compose down` preserves data for another run. `docker compose down -v` discards this stack's log, cursor, metric and Grafana history. Coordinate with anyone still running project 7 on that same host and project name.

**Portfolio evidence.** Include one source event, its LogQL query and a post-collector-restart result. **Interview. What happens if the collector loses its position file?** Behavior depends on tailing configuration and retained source files; duplicates or omissions are possible. **Follow-up:** how would you detect this without making job IDs index labels?

### Further reading

[Alloy file collection](https://grafana.com/docs/alloy/latest/reference/components/loki/loki.source.file/) · [Loki LogQL](https://grafana.com/docs/loki/latest/query/)
