# 51 · Project 5 · A Kubernetes deployment with persistent evidence

**Business problem.** A release engineer needs to verify an internal status page and retain evidence after the verification Pod exits. The service must have a stable network name, independently editable content and an optional hostname at the edge. Budget 2–3 hours on a local kind cluster. Chapters 14–19 supply the operating model.

```mermaid
flowchart TD
  Client["Training client"] --> Ingress["Optional Ingress controller"]
  Ingress --> Service["Service status-web"]
  Job["One-off evidence Job"] --> Service
  Service --> Pods["Ready web Pods"]
  Config["Generated ConfigMap"] --> Pods
  Key["Mounted Secret"] --> Job
  Job --> PVC["Evidence PVC"]
```

## Files, requirements and build

`labs/kubernetes/base/` contains `deployment.yaml`, `service.yaml`, `index.html` and `kustomization.yaml`. `labs/kubernetes/project/audit.yaml` supplies a claim and a Job. The Job reads the page via the Service, computes an HMAC with a mounted key and writes the result to a persistent volume. An HMAC is a keyed message authentication code. Comparing values later requires the same key and exact input bytes. It does not by itself prove who observed the page or at what time. `project/ingress.yaml` supplies the optional route.

Use the dedicated `kind-handbook` context, a working default StorageClass and capacity for two web Pods and a Job. For the optional ingress test install or supply a maintained compatible controller; the provided class name is `traefik`. First follow chapter 14 to create the cluster and namespace.

```bash
# Apply the service and check readiness before generating evidence.
kubectl --context kind-handbook -n handbook apply -k labs/kubernetes/base
kubectl --context kind-handbook -n handbook rollout status deployment/status-web
# Generate a fresh private key without printing it or putting it in command history.
keydir=$(mktemp -d)
(umask 077 && python3 -c 'import secrets,sys; sys.stdout.buffer.write(secrets.token_bytes(32))' > "$keydir/key")
kubectl --context kind-handbook -n handbook create secret generic evidence-key --from-file=key="$keydir/key"
# Request persistent evidence storage and run the application-level verifier.
kubectl --context kind-handbook -n handbook apply -f labs/kubernetes/project/audit.yaml
kubectl --context kind-handbook -n handbook wait --for=condition=complete job/evidence-writer --timeout=180s
kubectl --context kind-handbook -n handbook logs job/evidence-writer
kubectl --context kind-handbook -n handbook get pvc audit-evidence
```

A successful Job should report a stored observation and the claim should be Bound. Keep the key only for the duration of the drill. A rerun after a completed Job requires a new Job object or removal of the completed training Job. Do not regenerate a key and assume previous HMACs will still verify under the new one.

## Verify storage independently

After completion, delete just the Job with `kubectl --context kind-handbook -n handbook delete job evidence-writer`. The claim survives. Apply the supplied `labs/kubernetes/project/evidence-reader.yaml` in the same training namespace using `kubectl --context kind-handbook -n handbook apply -f labs/kubernetes/project/evidence-reader.yaml`. Wait with `kubectl --context kind-handbook -n handbook wait --for=condition=complete job/evidence-reader --timeout=180s`, then inspect `kubectl --context kind-handbook -n handbook logs job/evidence-reader`. This independent Job mounts the claim read-only, recomputes the HMAC from the current page and compares it to the stored value using `hmac.compare_digest`. Expect “Retained evidence matches current page.” A content update between observations should change the result. An independent restore test is required to establish backup recovery.

**Optional ingress.** Compare `kubectl --context kind-handbook get ingressclass` with the manifest; adjust the class to your installed controller. Apply `project/ingress.yaml` in namespace handbook. Reach the controller's exposed local address with HTTP Host header `status.example.test` and confirm the page. A kind cluster without a controller can still test the internal Service by port-forward as in chapter 15.

**Common failures.** An unbound claim calls for StorageClass, provisioner, topology and capacity checks. A Job unable to start may lack the Secret or fail to pull its image. A Job that starts and cannot find the service needs DNS, endpoints and readiness checks. A 404 at ingress can indicate host or path mismatch even while the internal service is healthy.

**Production, cost and cleanup.** Use authenticated TLS ingress, enforce network and identity policy, pin images and move evidence to durable independently backed-up storage. Document the PV reclaim policy before deleting a claim. Local kind uses local disk. Cloud volumes, load balancers and traffic may incur charges until explicitly removed. For this dedicated training cluster, remove the local key and delete the cluster with `kind delete cluster --name handbook` after saving your evidence. Never use that cleanup against shared training work.

**Portfolio evidence.** Save a rendered manifest, ready EndpointSlice, successful Job log and a post-Job verification of stored data. After the drill: “Deployed a replicated service on Kubernetes and verified its network, configuration and persistent evidence path with a scoped batch Job.”

**Interview. Why keep the audit record outside the Job's writable layer?** Job Pods are disposable and their local container state can disappear. **Follow-up:** which storage failure would still destroy the record?

### Further reading

[Kubernetes Jobs](https://kubernetes.io/docs/concepts/workloads/controllers/job/) · [Persistent volumes](https://kubernetes.io/docs/concepts/storage/persistent-volumes/) · [Ingress](https://kubernetes.io/docs/concepts/services-networking/ingress/)
