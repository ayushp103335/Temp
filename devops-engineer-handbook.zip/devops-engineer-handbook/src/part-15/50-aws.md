# 50 · Project 4 · A two-zone AWS environment with Terraform

**Business problem.** A team wants a repeatable way to expose one synthetic status page to an operator while keeping the serving machines private. Deliver two private targets, an operator-restricted ALB, a private artifacts bucket and remote locked Terraform state. Budget 2–4 hours for design, plan review and an optional deployment. Cloud resources are billable.

Read the [AWS request-path diagram](../part-08/26-aws.md) and [Terraform chapter](../part-09/29-terraform.md). The AWS module in `labs/terraform/aws/` contains `main.tf`, `bootstrap.sh` and `backend.hcl.example`. The bootstrap writes a static synthetic status page and installs a systemd unit using Python already supplied by the selected AL2023 image. Private targets need no NAT download during startup. This deliberately limited HTTP training endpoint serves only public synthetic text to a single operator address.

## Prerequisites and estimate

Use a dedicated training account with two available zones, Terraform 1.10+, AWS CLI v2, an approved temporary provisioning identity and a private, encrypted, versioned S3 state bucket established outside this module. The backend must be accessible before Terraform can create application resources. Grant permission for the specific state object and its lock object. Never place credentials in the HCL.

Estimate two EC2 instance-hours per elapsed hour, two root volumes, one ALB-hour per elapsed hour plus ALB capacity usage, public IPv4 charges where applicable, S3 storage and requests, data transfer and retained state versions. For a two-hour rehearsal multiply the hourly components by two and prorate storage by actual retained duration. Use the current calculator for your region. A budget alarm is a notification; it does not stop resources.

> **Cost warning.** Applying this plan creates billable infrastructure. Check the account and regional estimate before applying it and reserve time for teardown.

## Deploy to your own training account

```bash
# Enter the AWS root module and configure a local copy of the sample backend file.
cd labs/terraform/aws
cp backend.hcl.example backend.hcl
# Open backend.hcl in your editor and enter the existing bucket, key and region.
# Select your training identity and verify the account before planning.
export AWS_PROFILE=training
aws sts get-caller-identity
# Supply region and the real operator public IPv4 /32 interactively.
read -r -p 'AWS region: ' TF_VAR_region
read -r -p 'Operator IPv4 CIDR ending in /32: ' TF_VAR_operator_cidr
export TF_VAR_region TF_VAR_operator_cidr
# Resolve the provider, select the remote backend and review a saved plan.
terraform init -backend-config=backend.hcl
terraform validate
terraform plan -out=lab.tfplan
# After reviewing resources, costs and account selection, apply that reviewed plan.
terraform apply lab.tfplan
```

The two public subnets have an internet gateway route. Private subnets use the VPC local route, and target instances have no public IPs. The edge group accepts TCP 80 only from the supplied /32; its outbound traffic targets the application group on 8080. The application group accepts that traffic. There is no inbound SSH rule. The separate artifacts bucket is private; state lives in the pre-existing backend bucket.

```bash
# Identify actual target health and fetch the synthetic status page.
aws elbv2 describe-target-health --region "$TF_VAR_region" \
  --target-group-arn "$(terraform output -raw target_group_arn)"
curl --fail --max-time 10 "$(terraform output -raw training_url)"
```

Wait for initialization and health-check registration. Save the actual target status, response and elapsed setup time. If both targets fail, inspect path, port, image selection and boot behavior. If healthy targets serve traffic from some networks only, inspect the operator CIDR, current address and routing. No private management channel is provisioned in this small lab. A production deployment should provide controlled diagnostics, TLS, centralized logs, immutable hardened images and auto-replacement of failed targets. The supplied two static instances demonstrate placement; an Auto Scaling group is a further production requirement.

## Teardown and evidence

Run `terraform plan -destroy -out=teardown.tfplan`, review the listed account-scoped resources, then `terraform apply teardown.tfplan`. Empty any objects you deliberately placed into the disposable artifacts bucket before destruction. Verify the ALB, instances, root volumes, network resources and artifacts bucket are gone. Keep the protected backend and state history according to the training account's ownership and retention policy. Remove saved plan files from your laptop after the exercise.

**Portfolio evidence.** Retain a sanitized plan, architecture, target health, response, estimate and teardown confirmation. After running the project: “Provisioned a two-zone AWS environment with private EC2 targets, restricted ALB access and S3-backed locked Terraform state.”

**Interview. Why does the application run without outbound internet?** Its local boot script uses tools supplied in the selected image. **Follow-up:** how would you distribute a new private dependency while keeping the targets private?

### Further reading

[AWS Pricing Calculator](https://calculator.aws/) · [Terraform S3 backend](https://developer.hashicorp.com/terraform/language/backend/s3) · [ALB health checks](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/target-group-health-checks.html)
