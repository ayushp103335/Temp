# Part 15 · Real-world projects

**Study time:** 35–55 h including practice. **Starting point:** Parts referenced by each project; local Linux first, isolated training accounts for hosted projects.

Build ten systems with observable success criteria and recovery or teardown evidence.

## What you will demonstrate

Choose two projects that share a dependency. Change one interface, show which test catches the incompatibility and recover the system.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
