# 48 · Project 2 · A containerized job dashboard

**Business problem.** A support team wants to see synthetic job counts without running a database query on each refresh. Build a browser dashboard, keep authoritative records in PostgreSQL, reduce repeated reads using Redis, and observe what happens when one dependency disappears. Budget 2–3 hours. Projects run on the local machine with Docker Engine, Compose v2, Bash, curl and Python 3. Check available disk for four images and one data volume.

## Architecture and implementation

Use the request sequence in [chapter 13](../part-05/13-compose.md). Nginx serves the frontend and forwards API requests on one origin. The API queries a read-only database account and caches successful responses for 15 seconds. The only published port is loopback 8088.

| File under `labs/docker/` | Responsibility |
|---|---|
| `frontend/index.html`, `nginx.conf` | Show job counts, handle an API error and route the URL. |
| `app/api.py`, `app/test_api.py` | Implement the cache-aside read and check success and failure paths. |
| `app/Dockerfile`, `app/.dockerignore`, `app/requirements.txt` | Build the non-root API runtime from the narrow app context. |
| `db.sql`, `init-credentials.sh` | Initialize fixture rows and grant a login account permission to read them. |
| `setup-secrets.sh`, `.gitignore` | Generate local credentials inside a private directory excluded from Git. |
| `compose.yaml`, `smoke.sh` | Declare topology and verify the public data path. |

```bash
# Start from the repository root, generate credentials once and inspect the model.
cd labs/docker
bash setup-secrets.sh
docker compose config --quiet
# Build the API, pull supporting images, initialize a fresh database and start.
docker compose up -d --build
bash smoke.sh
# Observe a response and inspect the four services.
curl -i http://127.0.0.1:8088/api/summary
docker compose ps
```

Open `http://127.0.0.1:8088` in a browser. Click **Refresh counts**. The synthetic fixture contains two completed jobs and one queued job. The SQL groups by state, so an absent state is omitted. The chapter 1 CLI instead returns all known states including zero. These contracts are intentionally distinct. Document which contract your client expects before replacing one endpoint with another.

## Prove persistence, fallback and recovery

1. Read the last 30 API events with `docker compose logs --tail 30 api`. A body-level check proves more than Nginx returning the HTML page.
2. Stop Redis with `docker compose stop cache`. Run the smoke check. The API should still return counts and log a cache warning. Observe increased query work while the cache is unavailable.
3. With Redis still stopped, stop PostgreSQL using `docker compose stop db`. A call to `curl -i http://127.0.0.1:8088/api/summary` should now return 503. Verify the frontend shows unavailability.
4. Use `docker compose start db cache` and run the smoke check again. The named volume retains the three rows. Compare the recovered result with the original.
5. Run `docker compose down` and `docker compose up -d`. Check the counts. The database init scripts run on an empty data directory; editing `db.sql` does not migrate an existing volume.

A refused connection to port 8088 means the edge is absent or mapped elsewhere. A 502 points to the edge-to-API hop. A 503 from the application's JSON error path points to its database read on a cache miss. A cached success may briefly hide a database outage. Distinguish the three by reading the status and body.

**Production changes.** Pin approved image digests, lock transitive packages, terminate TLS, add identity and authorization, move credentials to a managed secret store, ensure Redis access controls match its trust zone, and provision PostgreSQL backup and recovery. Measure cache hit ratio, fallback latency and database query rate. Scale tests should establish how far the database can absorb cache loss. This local stack has one instance of each data service.

**Cleanup and cost.** Local CPU, memory and disk are the costs. To keep the synthetic database stop with `docker compose down` and retain the generated secrets. To discard its data use `docker compose down -v`, then remove the two project-generated password files and their directory. The images remain in Docker's cache.

**Portfolio evidence.** Keep a topology diagram, the initial response, the cache-outage result, the database-outage 503 and the recovered counts. After performing the exercise, describe it as “Containerized a full-stack status dashboard and validated cache fallback and database recovery behind Nginx.”

**Interview. Why can the cache fail without user-visible data loss?** PostgreSQL owns the rows, so a miss can be recomputed. **Follow-up:** what happens to correctness and capacity during a fifteen-second cache window?

### Further reading

[Compose startup order](https://docs.docker.com/compose/how-tos/startup-order/) · [PostgreSQL official image](https://hub.docker.com/_/postgres) · [Redis expiration](https://redis.io/docs/latest/commands/expire/)
