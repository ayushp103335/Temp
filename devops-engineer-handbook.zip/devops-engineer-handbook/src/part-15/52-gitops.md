# 52 · Project 6 · Promote an image through GitOps

**Business problem.** A team needs to release its status page without giving its build runner direct access to a Kubernetes cluster. Build the image in GitHub Actions, publish its digest, review a desired-state change and let Argo CD reconcile the training cluster. Allow 2–4 hours with a working kind cluster, GitHub practice repository, Docker, kubectl and Argo CD. Local resources, Actions minutes and registry storage are the cost drivers.

Use the [GitOps architecture diagram](../part-13/41-gitops.md). Under `labs/gitops/`, `Dockerfile` defines the web image, `publish.yml` defines CI, `release/kustomization.yaml` defines the deployable overlay and `application.yaml` defines its controller. The overlay reuses `labs/kubernetes/base/` and removes its page ConfigMap mount so the image actually supplies the bytes you just built.

## Build, publish and promote

1. In a disposable repository, copy `labs/gitops/publish.yml` to `.github/workflows/status-page.yml`, review and commit it on main. Its explicit dispatch trigger prevents unintended publication. Use the workflow's **Run workflow** control on main. The job builds the image, tests the page inside it, pushes to GHCR and prints its full digest reference in the job summary.
2. Use a package and repository readable by your local training controller and nodes. A public synthetic training package simplifies this exercise. A private registry needs a narrowly scoped image pull identity; the controller's Git read credential is a separate permission.
3. Under the existing top-level fields of `labs/gitops/release/kustomization.yaml`, add the following section. Replace the repository and digest with the actual values from the successful run. Keep the original image name as the rewrite key.

```yaml
images:
  - name: nginxinc/nginx-unprivileged
    newName: ghcr.io/your-owner/your-repository/status-page
    digest: sha256:REPLACE_WITH_VERIFIED_HEX_DIGEST
```

4. Run `kubectl kustomize labs/gitops/release` and inspect the Deployment's `image` field. Review and merge the manifest change. In `labs/gitops/application.yaml`, set `repoURL` to your practice repository and ensure the tracked branch matches its actual default branch.
5. Install a supported Argo CD release in the `argocd` namespace of your dedicated kind cluster using the official getting-started instructions. Pin the release you install and record it with your run. Apply the Application and observe it.

```bash
# Create or update the controller's declaration in the training cluster.
kubectl --context kind-handbook apply -f labs/gitops/application.yaml
# Inspect sync, health and the revision the controller actually observed.
kubectl --context kind-handbook -n argocd get application handbook-status -o yaml
# Check the real image identities reported by the running containers.
kubectl --context kind-handbook -n handbook-staging get pods \
  -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.status.containerStatuses[*].imageID}{"\n"}{end}'
# Forward a local port to the reconciled Service for the final HTTP check.
kubectl --context kind-handbook -n handbook-staging port-forward service/status-web 8091:80
```

From a second terminal, `curl --fail http://127.0.0.1:8091/` should return the image's page. A manifest-list digest can differ from its platform-specific image ID. Relate the platform manifest to the promoted index before reporting an identity mismatch.

## Failure drill, recovery and teardown

Change a page in the practice repository, publish another image and record the new digest through review. The CI smoke test checks the phrase “Job dashboard is available”; keep that contract unless intentionally changing the test. Revert the desired-state commit and observe Argo CD restore the prior version. Save both Git revisions, actual health and the HTTP result. If resources remain OutOfSync inspect the source path, branch, credentials and target namespace. If a Pod cannot pull, check package visibility and digest spelling.

Use an environment-scoped AppProject and least-privilege reconciliation identity for production. Separate operator identities, gate changes to the release branch and use admission policy for signed images. The lab does not grant the publisher cluster credentials. Observe application health and working user requests separately from controller synchronization.

For cleanup remove the training Application, then remove its dedicated namespace after confirming its contents. Application deletion does not always cascade to managed resources, particularly without the Argo resources finalizer. Remove the dedicated kind cluster if no later exercise needs it. Remove only your test package versions according to retention policy.

**Portfolio evidence.** After executing the exercise: “Implemented reviewable image promotion and rollback using GitHub Actions, GHCR, Kustomize and Argo CD.” Include evidence from a reverted release. **Interview. Why did a config-only change suffice to deploy?** The controller observed a new desired digest. **Follow-up:** which principal authorized that change and which principal applied it?

### Further reading

[Argo CD getting started](https://argo-cd.readthedocs.io/en/stable/getting_started/) · [Argo automated sync](https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/) · [Kustomize image transformations](https://kubectl.docs.kubernetes.io/references/kustomize/kustomization/images/)
