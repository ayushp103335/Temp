# 53 · Project 7 · A working metrics and alerting stack

**Business problem.** Operators need to know when a synthetic worker disappears and confirm that notifications stop after recovery. Build a local stack that collects application metrics and selected host metrics, evaluates an alert, routes it to a webhook and visualizes outcomes. Allow 90–150 minutes on a Linux Docker host. The host mounts used by Node Exporter require Linux procfs and sysfs. Container Desktop environments report the underlying Linux VM where supported.

See the [monitoring architecture](../part-11/35-prometheus.md). All files are under `labs/observability/`. `service.py` implements work generation, metrics and a separate receiver process. `compose.yaml` connects the services. `prometheus.yml` and `rules.yml` configure target scraping and alert evaluation; `alertmanager.yml` groups and sends notifications. `provisioning/datasources/sources.yml`, `provisioning/dashboards/providers.yml` and `dashboards/jobs.json` provision Grafana. `setup.sh` generates a local admin credential. `config.alloy` and the Loki service extend this same stack for project 8.

```bash
# Create a private operator credential, validate Compose and start the stack.
cd labs/observability
bash setup.sh
docker compose config --quiet
docker compose up -d
# Emit a known workload, then see the integer counter values the target exports.
for i in 1 2 3; do curl -fsS http://127.0.0.1:8100/work/ok; done
curl -sS -i http://127.0.0.1:8100/work/failed
curl -fsS http://127.0.0.1:8100/metrics
# Remove only the work target. The independent receiver remains available.
docker compose stop work
docker compose logs --tail 30 receiver
```

Allow startup before generating work. The first three operations return 200 and the synthetic failure returns 503. Open Prometheus at `http://127.0.0.1:9090`, query `up{job="jobs"}` and `node_memory_MemAvailable_bytes`. Open Grafana at `http://127.0.0.1:3030`. The locally provisioned viewer can open the **Job processing** dashboard. Submit more work over a minute to make a rate visible across scrapes.

After stopping the service, wait for the alert condition's thirty seconds plus scrape, evaluation and grouping delay. Inspect pending/firing state in Prometheus, then Alertmanager at port 9093. The receiver log should contain `alert_notification firing`. Use `docker compose start work` and wait for `alert_notification resolved`. Record actual detection and notification times. A small readiness race at startup should not invalidate a correctly observed later transition.

**Troubleshooting.** If the target is absent from the target list, inspect the static scrape configuration. If listed down while running, check service name and listener from the Compose network. A firing alert with no receiver message points to routing, grouping wait, receiver availability or notification errors. If the host metric is absent, inspect the exporter flags and host file mounts.

**Security and operating cost.** Host telemetry can reveal sensitive machine details. The training endpoints publish only to loopback; use authenticated access, restricted collector identities and appropriate retention before shared deployment. The synthetic service is single-process and its counters reset on restart. Right-size storage using series count, scrape interval and retention. Choose an independent notification path in production and test it regularly.

**Cleanup.** Continue directly to project 8 to reuse the stack, or stop it with `docker compose down`. To erase only this training stack's history, inspect its named volumes and use `docker compose down -v`, then remove its generated credential. No cloud resources are created.

**Portfolio evidence.** Include the dashboard, raw counter, alert rule, firing notification, resolved notification and measured detection time. **Interview. Why keep the receiver independent of the target?** The target must be able to fail without also disabling its alarm. **Follow-up:** which additional failures remain shared on a single Docker host?

### Further reading

[Prometheus configuration](https://prometheus.io/docs/prometheus/latest/configuration/configuration/) · [Alertmanager configuration](https://prometheus.io/docs/alerting/latest/configuration/) · [Grafana provisioning](https://grafana.com/docs/grafana/latest/administration/provisioning/)
