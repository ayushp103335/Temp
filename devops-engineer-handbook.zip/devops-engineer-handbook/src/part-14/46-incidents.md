# 46 · Investigate a production incident without destroying its evidence

**By the end** you can state impact precisely, prioritize the next observation, choose a reversible mitigation and verify recovery. Use chapters 3, 5, 7, 19 and 34.

At 09:05 submissions continue to return 202. At 09:12 support reports no new results. The database accepts test reads. “All APIs healthy” describes one part of the path. Define impact as the number and age of accepted jobs missing a result, segmented by version, zone or client where authorized. Establish the last known good time and correlate deployments and infrastructure events. Assign an incident coordinator before multiple responders begin changing the same system.

## Worked timeline

At 09:14 queue age is nine minutes and rising. Arrival rate is 40/minute; completion fell from 45 to 5/minute after a worker release. Old and new API instances accept requests normally. Before adding capacity, compare old and new workers. New workers show connection timeouts to a database address that resolves to a private endpoint in another network. Existing workers still connect. Pause the worker rollout and restore the compatible worker configuration. If restored capacity finishes 60/minute and new arrivals remain 40/minute, a backlog of 400 takes approximately 20 minutes to drain. Announce recovery after checking results and backlog age, not just process restarts.

| Symptom | First evidence | Distinguishing question |
|---|---|---|
| Linux service restart loop | Unit status, recent journal, effective account and path | Did the executable start, then fail, or never execute? |
| CPU spike or suspected memory leak | Time series, process working set, requests and restart reason | Is pressure correlated with increased load or retained memory across equal loads? |
| Disk exhaustion | Filesystem bytes, inodes, quotas and open deleted files | Which mount and resource is exhausted? |
| DNS or TLS failure | Resolver answer, selected address, hostname, served chain and dates | Did resolution, connection or peer verification fail? |
| Container exits | Exit code, logs, configured command, mounts | Was normal completion mistaken for a daemon crash? |
| Pending or unready Pod | Scheduling events, requests, storage, probes, endpoints | Was placement possible, and can the process accept traffic? |
| CI failure | First failed stage, runner environment, dependency or artifact identity | Is it a source defect, tooling failure or permission issue? |
| Database connectivity | DNS, TCP connection, authentication, schema and pool occupancy | Did the caller reach the service, authenticate, and obtain a usable connection? |
| Cloud outage or zone loss | Regional/provider signals plus your per-zone success rates | Which dependencies and unaffected capacity are actually usable? |
| Long application latency | Histograms, trace critical path, queue age and saturation | Is the delay in ingress, execution, a dependency or waiting work? |

## Lab · Run one incident end to end

Use the cache and database failure drill in project 2, or the local service-identity drill from chapter 3 if Docker is unavailable. Choose one person to introduce the failure while another works only from the observable symptoms. Capture the first user-visible failure, two competing hypotheses, one observation that eliminates a hypothesis and the time the user operation recovers. Preserve the commands and expected observations. Use synthetic data throughout.

For a database outage, avoid assuming any read replica is safe to promote. Check replication position, fencing of the old writer and the failover procedure. A mistaken second writer can turn a recoverable outage into conflicting data. For a networking incident, preserve a functioning administrative access path while investigating authorized network policy. A cluster-wide restart often destroys useful evidence and expands user impact.

**Handoff.** An incident update should give time window, affected operation, scope, mitigation, what remains impaired and the next update time. The postmortem should describe detection, decision, recovery and prevention. Assign each corrective action a measurable completion criterion.

**Practice.** Rewrite “the server is down” into an evidence-based incident update using the worked timeline. **Interview. What do you do first when several alarms fire?** Verify user impact, establish ownership, identify the shared dependency or recent change, then pick the observation that most cheaply separates plausible causes.

### Further reading

[Google SRE on managing incidents](https://sre.google/sre-book/managing-incidents/) · [Effective troubleshooting](https://sre.google/sre-book/effective-troubleshooting/)
