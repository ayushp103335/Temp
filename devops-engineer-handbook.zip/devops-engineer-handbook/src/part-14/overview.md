# Part 14 · SRE and production engineering

**Study time:** 5–8 h including practice. **Starting point:** Observability, capacity calculations and failure domains.

Use an error budget, unit cost and incident timeline to make a production decision.

## What you will demonstrate

Run a fault drill, publish an incident timeline and compute cost per successful outcome before and after a proposed change.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
