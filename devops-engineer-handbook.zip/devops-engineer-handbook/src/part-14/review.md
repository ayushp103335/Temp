# Part 14 review · SRE and production engineering

## Revision and assessment

**Which result establishes that recovery is complete?**

The critical user workflow meets its target, affected data has been reconciled and backlog and dependencies are within the agreed bounds.

## Practical assignment

Run a fault drill, publish an incident timeline and compute cost per successful outcome before and after a proposed change.

## Mini-project and self-evaluation

Distinguish mitigation from prevention. Give one corrective action an owner, evidence of completion and a date.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
