# 45 · Explain cost per successful job

**By the end** you can calculate a unit cost, distinguish a usage change from a rate change and evaluate a saving against its reliability consequence. Use chapter 25 and a simple calculator. Figures below are synthetic teaching data.

FinOps brings engineering, finance and product owners together around the business value of technology spending. A monthly bill can rise for good reasons, such as processing more successful jobs. It can also rise because retry loops multiply work or unused volumes accumulate. Assign spend to a service, environment and owner, then divide by an outcome that matters.

## Lab · Compare two months with equal business meaning

| Item | Month A | Month B |
|---|---:|---:|
| Total allocated service cost | $8,000 | $9,000 |
| Successfully completed jobs | 400,000 | 600,000 |
| Cost per 1,000 successful jobs | $20 | $15 |

Total spend rose 12.5%, and cost per successful job fell 25%. Verify that the definition of success and allocation method stayed the same. Add shared monitoring, network transfer, storage and support allocations explicitly. Separate calendar differences and one-time migration costs. A workload that silently rejects expensive jobs can look cheaper on this metric, so review completion quality and SLO compliance beside it.

**Rightsizing** compares allocated resources with representative usage and headroom. Lowering Kubernetes CPU requests can fit more Pods per node but can change placement and autoscaling signals. Lowering memory limits can cause terminations during short peaks. Measure percentiles, batch behavior, startup load and capacity after an outage. A change that saves a node at steady state but doubles recovery time may violate the service objective.

| Lever | Measurement before the change | Verification afterwards |
|---|---|---|
| Autoscale worker count | Queue age, job mix, throughput and startup time | Deadline misses, recovery time and node-hours. |
| Change object storage tier | Read frequency, minimum duration and retrieval requirements | Effective cost including retrieval, plus restore latency. |
| Limit telemetry volume | Cardinality, bytes and queries by team | Retention, ability to diagnose incidents and unit cost. |
| Purchase committed capacity | Stable baseline and future demand uncertainty | Utilization, coverage and the cost of unused commitment. |

**Operating rhythm.** Give service owners dashboards and anomaly notifications with context. Review candidate changes jointly with reliability owners. Run a bounded experiment, compare a similar workload window and keep the rollback condition. Cloud pricing varies by region, date and contract; a current estimate should identify the rate source, units and assumptions.

**Practice.** If 30% of worker time is spent retrying requests and each retry has the same resource cost, explain why removing those retries may save less than 30% of the bill when fixed resources continue running. **Interview. Which metric would you put beside total Kubernetes cost?** Successful business units and reliability, broken down by service with shared idle capacity allocated transparently.

### Further reading

[FinOps Framework](https://www.finops.org/framework/) · [AWS cost optimization pillar](https://docs.aws.amazon.com/wellarchitected/latest/cost-optimization-pillar/welcome.html)
