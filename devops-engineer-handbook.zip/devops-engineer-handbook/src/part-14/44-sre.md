# 44 · Use an error budget to make a release decision

**By the end** you can translate reliability into an engineering policy, bound an experiment and measure a recovery exercise. Use chapters 19 and 34.

Site reliability engineering applies engineering methods to service operations. Its central question is which user-visible reliability is required and how to achieve it sustainably. Toil is repetitive operational work that grows with service scale and has little enduring value. Automating an unstable manual action can make failures faster; first understand which outcome the action is supposed to produce.

An error budget is the amount of failure allowed by a specified objective and measurement window. In a 30-day window of 43,200 minutes, a time-based 99.9% availability target allows 43.2 unavailable minutes. An event-based objective of 99.9% over 500,000 eligible requests allows 500 bad events. A three-minute low-traffic outage and a three-minute peak outage have the same duration and potentially very different event cost. Decide which represents user harm.

## Worked decision · Budget burn

At a 99.9% event-based target the allowed bad-event fraction is 0.001. A sustained 0.01 observed bad fraction burns budget at 10 times the sustainable rate. Under a constant traffic and error mix, a full thirty-day budget would be consumed in about three days. Short and long windows help distinguish a sharp incident from a persistent low-rate defect. A budget policy might pause discretionary high-risk releases while allowing corrective changes. Define who decides and how service is restored.

## Lab · Rehearse a bounded failure

Use project 2 with synthetic records. First record baseline response counts and latency. Form the hypothesis that stopping Redis preserves correctness at lower cache efficiency. Set an abort rule before starting: stop the experiment if the data check fails, restore Redis and capture logs. Run the cache outage drill, verify recovery and document durations. This is a small chaos experiment with a known fault and an explicit blast radius. Production experiments need appropriately isolated scope, oversight and a safe abort path.

Separate incident roles: one person coordinates decisions, one performs technical work, and one communicates impact and updates. Preserve a timeline of observations and actions. A blameless postmortem can identify unsafe defaults, missing visibility or conflicting incentives while still assigning corrective actions with owners and dates. Test those actions against the original failure.

**Capacity and recovery.** Model peak arrival rate, per-worker throughput, dependency limits and spare capacity after a failure. Define RPO and RTO for each critical dataset. A restore exercise must start from the documented backup, bring up dependencies, reconcile data and complete the customer workflow. Record the elapsed time from the moment recovery starts to the moment users can safely use the service.

**Practice.** Write a release decision for a team with 5% of its quarterly budget left and a proposed schema migration. Explain the consequence of delaying the release as well as its risk. **Interview. Is 100% availability a good default target?** A target should reflect user needs, dependencies and the cost of additional reliability. An unlimited goal provides little guidance on trade-offs.

### Further reading

[Google SRE workbook](https://sre.google/workbook/table-of-contents/) · [Google SRE on eliminating toil](https://sre.google/sre-book/eliminating-toil/) · [Postmortem culture](https://sre.google/sre-book/postmortem-culture/)
