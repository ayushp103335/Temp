# Part 3 review · Networking fundamentals

## Revision and assessment

**Why can a 404 be evidence of a functioning network path?**

An HTTP responder received the request. Verify its identity and the URL before investigating missing content.

## Practical assignment

Write a three-case diagnostic report using a good response, a missing path and a stopped listener.

## Mini-project and self-evaluation

Identify the listener, address family, port and HTTP response independently. Calculate four /26 ranges in one /24.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
