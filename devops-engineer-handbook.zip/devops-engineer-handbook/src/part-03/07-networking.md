# 7 · Follow a request from name to response

**By the end** you can calculate a subnet boundary, distinguish a DNS failure from a refused connection and isolate a broken route through a reverse proxy. Start with chapters 3–5. The lab uses your own loopback interface, Python 3, curl and Linux `ss`.

## What happens when a URL opens?

In `https://queue.example.test/jobs/42`, the scheme selects HTTPS, the hostname identifies the service and the path identifies an application resource. The client resolves the name using the Domain Name System (DNS). For a typical HTTP/1.1 or HTTP/2 connection it then opens a TCP connection to a chosen address and port, negotiates TLS, verifies the certificate and sends an HTTP request. An HTTP response proves that some application endpoint answered. It may be a proxy reporting an upstream failure. HTTP/3 uses QUIC over UDP, so the transport trace differs.

The OSI model describes seven conceptual layers. Physical sends signals. Data link moves frames on a local link. Network forwards packets between networks. Transport provides endpoints and transport behavior. Session organizes dialogues. Presentation handles representation. Application defines operations such as an HTTP GET. The practical TCP/IP model groups the lower two into link, uses IP for internet routing, TCP or UDP for transport, and groups higher-layer functions under application. These are models. TLS and modern protocols can straddle the textbook categories.

| Boundary | Address or evidence | Question |
|---|---|---|
| Local link | Interface and link state | Can the host use this interface? |
| Internet layer | IP prefix and route | Which interface or next hop will this destination use? |
| Transport | Address plus port | Is a process accepting this kind of connection here? |
| Application | Method, path, status and body | Did the expected operation succeed? |

## Plan an address range on paper

IPv4 uses 32 bits. In `10.42.8.0/26`, the first 26 bits describe the network and six vary, giving 64 addresses. A conventional IPv4 LAN reserves the network and broadcast addresses, leaving .1 through .62 as host candidates. The next /26 starts at .64. Four adjacent /26 ranges fill a /24. Cloud providers may reserve additional addresses. Private ranges such as 10.0.0.0/8 can be reused by separate networks. Overlap becomes an issue when those networks later need to route to each other.

IPv6 uses 128 bits. The documentation prefix `2001:db8::/32` is useful in examples, and `::1` is loopback. Global reachability requires correct routes and filtering in either address family. A public IP describes an addressing property. It does not guarantee that a firewall permits application traffic.

DHCP supplies host configuration such as addresses, gateway and DNS servers. Routing selects a next hop, usually by longest matching prefix. Network address translation (NAT) rewrites addresses and, commonly, ports as connections cross a boundary. A firewall enforces traffic rules. A VPN carries traffic through an authenticated tunnel. Each solves a different part of connectivity. A forward proxy acts on behalf of a client, a reverse proxy fronts servers, and a load balancer chooses among upstream instances. One implementation can perform several of these functions.

## Lab · Three failures with different owners

```bash
# Start a local-only web server serving a directory containing only the test fixture.
netlab=$(mktemp -d)
cp labs/release/jobs.json "$netlab/"
python3 -m http.server 8765 --bind 127.0.0.1 --directory "$netlab" >"$netlab-server.log" 2>&1 &
netpid=$!
# Find the listening socket. Repeat once if startup is still in progress.
ss -ltn 'sport = :8765'
# Fetch an existing file; print the status after the response.
curl --noproxy '*' -sS -w '\nstatus=%{http_code}\n' http://127.0.0.1:8765/jobs.json
# Request a missing file. This time print only the HTTP status.
curl --noproxy '*' -sS -o /dev/null -w 'status=%{http_code}\n' http://127.0.0.1:8765/missing
# Stop only the process you started and repeat the original request.
kill "$netpid"
wait "$netpid" || true
curl --noproxy '*' --max-time 2 http://127.0.0.1:8765/jobs.json
```

Expected sequence: JSON with 200, then 404, then a connection failure. With 404, a listener answered. After shutdown, an unused local port usually returns a refusal immediately. A timeout has more possible causes, including packet filtering, an unreachable destination or overload. If the server exits on startup, check its log for “Address already in use” before interpreting another process's response. Python's simple HTTP server is for this local lab.

**Optional DNS observation.** Compare `getent hosts localhost`, which uses the host's configured name-service mechanisms, with `dig localhost`, which queries DNS. A hosts-file entry can explain different results. Keep the requested hostname when investigating TLS because name selection affects certificate validation. Removing certificate verification hides precisely the error you are trying to diagnose.

## Command reference at the point of failure

| Tool and example | What success demonstrates |
|---|---|
| `ip addr`, `ip route get 127.0.0.1` | Interface configuration and the selected local route. |
| `ping -c 2 127.0.0.1` | ICMP echo works on this path. An application can fail independently. |
| `dig example.org A`, `nslookup example.org` | The queried resolver returned a DNS answer. Look at record type and caching lifetime. |
| `traceroute HOST` | Some routers responded to limited-hop probes. Missing responses are ambiguous. |
| `ss -ltn`, legacy `netstat -ltn` | Local TCP listening sockets and their bind addresses. |
| `nc -vz 127.0.0.1 8765` | A TCP connection to the lab listener can be established. Flags vary by implementation. |
| `curl -i URL`, `wget -O - URL` | HTTP headers/body or downloaded content from the named URL. |
| `tcpdump -D` | Lists interfaces available to the diagnostic tool. Check permissions before interpreting an empty list. |

SSH commonly uses TCP port 22, HTTPS 443, and DNS commonly uses UDP or TCP 53. TCP delivers an ordered byte stream with retransmission and flow control. UDP carries separate datagrams and leaves reliability policy to the application. TLS protects transport confidentiality and integrity and typically authenticates the server. “SSL” survives in product labels; configure supported TLS versions.

**Practice.** A proxy returns 502 while a direct request on the application host returns 200. Identify the upstream address and port configured in the proxy, then repeat the check from its network context. Loopback inside one container belongs to that container.

**Interview. How would you split a /24 into four equal subnets?** Add two prefix bits to produce four /26s starting at offsets 0, 64, 128 and 192. Follow-up: if a provider reserves five addresses in each subnet, how many remain in a /26? **59.**

### Further reading

[HTTP semantics](https://www.rfc-editor.org/rfc/rfc9110.html) · [Private IPv4 address space](https://www.rfc-editor.org/rfc/rfc1918) · [IPv6 addressing](https://www.rfc-editor.org/rfc/rfc4291) · [curl manual](https://curl.se/docs/manpage.html)
