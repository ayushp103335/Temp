# Part 3 · Networking fundamentals

**Study time:** 3–5 h including practice. **Starting point:** Linux process and file basics.

Trace a local HTTP request and distinguish name resolution, transport connectivity and application behavior.

## What you will demonstrate

Write a three-case diagnostic report using a good response, a missing path and a stopped listener.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
