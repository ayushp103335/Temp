# Summary

[Start here](introduction.md)

[Study route](curriculum.md)

# 1 · DevOps fundamentals

- [Part guide](part-01/overview.md)
- [1 · Introduction to DevOps](part-01/01-devops.md)
- [2 · From a requirement to a recoverable release](part-01/02-sdlc.md)
- [3 · Draw the delivery path and the request path](part-01/03-architecture.md)
- [Part review](part-01/review.md)

# 2 · Linux and system administration

- [Part guide](part-02/overview.md)
- [4 · Linux from the point of view of a service](part-02/04-linux.md)
- [5 · Diagnose a Linux host under load](part-02/05-linux-admin.md)
- [6 · Write Bash automation you can operate](part-02/06-bash.md)
- [Part review](part-02/review.md)

# 3 · Networking fundamentals

- [Part guide](part-03/overview.md)
- [7 · Follow a request from name to response](part-03/07-networking.md)
- [Part review](part-03/review.md)

# 4 · Git and development fundamentals

- [Part guide](part-04/overview.md)
- [8 · Git and GitHub for shared infrastructure](part-04/08-git.md)
- [9 · Python for repeatable operations](part-04/09-python.md)
- [10 · Build once and promote the artifact](part-04/10-artifacts.md)
- [Part review](part-04/review.md)

# 5 · Containerization

- [Part guide](part-05/overview.md)
- [11 · Docker from image to running process](part-05/11-docker.md)
- [12 · Engineer the image you intend to run](part-05/12-images.md)
- [13 · Connect a frontend, API, database and cache](part-05/13-compose.md)
- [Part review](part-05/review.md)

# 6 · Kubernetes

- [Part guide](part-06/overview.md)
- [14 · Kubernetes as a set of control loops](part-06/14-kubernetes.md)
- [15 · Kubernetes objects and the contracts between them](part-06/15-objects.md)
- [16 · Placement, probes, persistent data and access](part-06/16-advanced.md)
- [17 · Package a Kubernetes service with Helm](part-06/17-helm.md)
- [18 · Layer environment differences with Kustomize](part-06/18-kustomize.md)
- [19 · Operate Kubernetes through a disruption](part-06/19-operations.md)
- [Part review](part-06/review.md)

# 7 · CI/CD and automated delivery

- [Part guide](part-07/overview.md)
- [20 · Design a pipeline around release evidence](part-07/20-pipelines.md)
- [21 · GitHub Actions and the deployment boundary](part-07/21-actions.md)
- [22 · Jenkins controllers, agents and Pipeline as Code](part-07/22-jenkins.md)
- [23 · GitLab CI/CD and the life of an artifact](part-07/23-gitlab.md)
- [24 · Progressive delivery and supply-chain evidence](part-07/24-progressive.md)
- [Part review](part-07/review.md)

# 8 · Cloud computing

- [Part guide](part-08/overview.md)
- [25 · Cloud resources, failure domains and bills](part-08/25-cloud.md)
- [26 · AWS through a complete request](part-08/26-aws.md)
- [27 · Map a workload to Azure and Google Cloud](part-08/27-cloud-comparison.md)
- [Part review](part-08/review.md)

# 9 · Infrastructure as code and configuration management

- [Part guide](part-09/overview.md)
- [28 · Infrastructure as Code and the meaning of state](part-09/28-iac.md)
- [29 · Terraform plans, providers and concurrency](part-09/29-terraform.md)
- [30 · Converge host configuration with Ansible](part-09/30-ansible.md)
- [31 · Choose the right owner for an infrastructure change](part-09/31-tool-choice.md)
- [Part review](part-09/review.md)

# 10 · Web servers and infrastructure

- [Part guide](part-10/overview.md)
- [32 · Nginx at the boundary of a service](part-10/32-nginx.md)
- [33 · Design for queues, caches and failures](part-10/33-infrastructure.md)
- [Part review](part-10/review.md)

# 11 · Monitoring, logging and observability

- [Part guide](part-11/overview.md)
- [34 · Measure the user operation](part-11/34-monitoring.md)
- [35 · Prometheus, Alertmanager and Grafana](part-11/35-prometheus.md)
- [36 · Carry a log from a worker to a query](part-11/36-logging.md)
- [37 · Explain latency with distributed traces](part-11/37-tracing.md)
- [Part review](part-11/review.md)

# 12 · DevSecOps and security

- [Part guide](part-12/overview.md)
- [38 · Put a security decision where it can change the release](part-12/38-devsecops.md)
- [39 · Bound the damage a workload can cause](part-12/39-hardening.md)
- [40 · Trust a release and rotate its credentials](part-12/40-supply-chain.md)
- [Part review](part-12/review.md)

# 13 · GitOps and platform engineering

- [Part guide](part-13/overview.md)
- [41 · Reconcile deployments from version control](part-13/41-gitops.md)
- [42 · Build a platform as a product for developers](part-13/42-platform.md)
- [43 · Workload identity, service mesh and policy](part-13/43-mesh.md)
- [Part review](part-13/review.md)

# 14 · SRE and production engineering

- [Part guide](part-14/overview.md)
- [44 · Use an error budget to make a release decision](part-14/44-sre.md)
- [45 · Explain cost per successful job](part-14/45-finops.md)
- [46 · Investigate a production incident without destroying its evidence](part-14/46-incidents.md)
- [Part review](part-14/review.md)

# 15 · Real-world projects

- [Part guide](part-15/overview.md)
- [47 · Project 1 · Linux server automation toolkit](part-15/47-toolkit.md)
- [48 · Project 2 · A containerized job dashboard](part-15/48-dashboard.md)
- [49 · Project 3 · Test, publish and deploy a container by digest](part-15/49-delivery.md)
- [50 · Project 4 · A two-zone AWS environment with Terraform](part-15/50-aws.md)
- [51 · Project 5 · A Kubernetes deployment with persistent evidence](part-15/51-cluster.md)
- [52 · Project 6 · Promote an image through GitOps](part-15/52-gitops.md)
- [53 · Project 7 · A working metrics and alerting stack](part-15/53-monitoring.md)
- [54 · Project 8 · Trace a synthetic job through centralized logs](part-15/54-logging.md)
- [55 · Project 9 · Gate and sign a release](part-15/55-secure.md)
- [56 · Project 10 · Operate a cloud-native release on EKS](part-15/56-capstone.md)
- [Part review](part-15/review.md)

# 16 · Interview and career preparation

- [Part guide](part-16/overview.md)
- [57 · DevOps interview workshop](part-16/57-interviews.md)
- [58 · Build a portfolio an engineering team can evaluate](part-16/58-career.md)
- [Part review](part-16/review.md)

# Field reference

- [Commands](reference/commands.md)
- [Troubleshooting](reference/troubleshooting.md)
- [Glossary](reference/glossary.md)
- [Technology comparisons](reference/comparisons.md)
- [Validation and limitations](validation.md)
