# Part 5 review · Containerization

## Revision and assessment

**Why does stopping Redis have a different result from stopping PostgreSQL on a cache miss?**

Redis holds derived results. Only the database can produce an authoritative response on a miss.

## Practical assignment

Run project 2 and save a cache hit, a successful fallback and a database-unavailable response.

## Mini-project and self-evaluation

Draw frontend and data networks and name every published host port. Restore a usable end-to-end page.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
