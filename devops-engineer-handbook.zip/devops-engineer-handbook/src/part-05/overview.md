# Part 5 · Containerization

**Study time:** 5–8 h including practice. **Starting point:** Linux, networking and artifact identity; Docker-capable host.

Build a non-root image and connect a browser, proxy, API, cache and database.

## What you will demonstrate

Run project 2 and save a cache hit, a successful fallback and a database-unavailable response.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
