# 12 · Engineer the image you intend to run

**By the end** you can read a Dockerfile, identify the layer invalidated by an edit and verify how the runtime process starts. Use chapter 11 and the complete example in `labs/docker/app/`.

## A build context is a boundary

The build context is the directory tree made available to the builder. In `docker build -t handbook-api:lab labs/docker/app`, the final argument selects a narrow context. The database passwords live outside it. A `.dockerignore` reduces input size and prevents accidental inclusion of ignored files. It is safer to select a small build context than to rely on noticing every secret in a large one.

A Dockerfile declares a sequence of build operations. The builder can reuse cached results when the operation and relevant inputs match. Copying all application files before installing dependencies would force that expensive step to rerun on each code edit. Copy the dependency manifest first. Package local code afterwards. Mutable base tags and dependency resolution can change a clean rebuild even with identical source.

## Read the supplied Dockerfile from top to bottom

| Instruction | Effect in this project |
|---|---|
| `FROM python:3.12-slim AS build` | Starts the wheel-building stage. A wheel is a Python distribution archive. |
| `WORKDIR /build`, `COPY requirements.txt .` | Establish a working directory and dependency input. |
| `RUN python -m pip wheel ...` | Resolves dependencies and prepares wheels during the build. |
| Second `FROM`, then `COPY --from=build` | Start a separate runtime filesystem and transfer the wheel set. |
| `RUN ... --no-index` | Installs from those wheels without contacting a package index in the runtime stage. |
| `COPY api.py .`, `ENV ...` | Include the service program and suppress Python bytecode writes at runtime. |
| `USER 10001:10001` | Runs the application under numeric, unprivileged user and group IDs. |
| `EXPOSE 8000` | Documents the intended listener. Host exposure still requires a runtime setting. |
| JSON-array `CMD` | Starts Gunicorn directly with two workers and a bind address accessible from the proxy. |

`ENTRYPOINT` defines the executable or stable entry command, while `CMD` can supply defaults. Command-line arguments may replace the default command depending on how the image sets these fields. `ARG` provides build-time input. `ENV` persists a runtime default in image configuration. Neither is suitable for confidential build credentials. Use the builder's secret mount facility when private dependency access is necessary. `ADD` has extra behaviors such as archive extraction in supported cases. `COPY` states the simpler intent for the local Python files.

A multi-stage build separates the build environment from the runtime. Layer contents are immutable: copying wheels into one runtime layer and deleting them in another leaves the earlier bytes in the image. This example favors visibility. To optimize further, use a BuildKit stage bind mount to install wheels without copying them into a persistent layer, then compare image sizes and rerun the tests.

## Lab · Inspect the resulting contract

```bash
# Build using the Dockerfile in the app context.
docker build -t handbook-api:lab labs/docker/app
# See the configured runtime user and startup command.
docker image inspect handbook-api:lab --format '{{.Config.User}} {{json .Config.Cmd}}'
# Inspect layer sizes and the instructions associated with them.
docker history handbook-api:lab
# Replace the command for one run and verify the actual numeric user.
docker run --rm handbook-api:lab id
```

Expected identity is 10001. The dashboard needs its database and cache for a realistic request test, so chapter 13 supplies the integration environment. Compare two edits: changing a comment in `api.py` and changing `requirements.txt`. Predict which steps rebuild in each case, inspect build output and undo your local edits. A warm cache can mask dependency availability problems. Keep a clean-build check.

**Security review.** Scan the image by its built identity with your team's scanner, retain the software inventory, and triage findings by affected component, runtime exposure and available fix. Pins in the sample requirements cover direct dependencies only. Release builds should lock transitive dependencies, verify hashes, select approved base digests and refresh them through a reviewed update process. A scan without findings is evidence at a point in time.

**Troubleshooting.** “COPY failed” often means the file is outside the context or ignored. A process that starts as root locally but fails under uid 10001 may write to a root-owned path. Identify the required writable directory and grant the narrow access needed.

**Practice.** Explain why `docker tag handbook-api:lab handbook-api:reviewed` gives you another name for the same local image, and identify the separate operation needed to publish it.

**Interview. Can the final image omit the compiler and still run?** Yes when the build output and its runtime libraries are copied correctly. Verify dynamic dependencies and CPU architecture as well as the entry command.

### Further reading

[Dockerfile reference](https://docs.docker.com/reference/dockerfile/) · [Multi-stage builds](https://docs.docker.com/build/building/multi-stage/) · [Build secrets](https://docs.docker.com/build/building/secrets/)
