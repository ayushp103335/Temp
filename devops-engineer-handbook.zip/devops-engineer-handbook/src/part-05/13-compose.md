# 13 · Connect a frontend, API, database and cache

**By the end** you can read a Compose file, distinguish startup order from ongoing availability and demonstrate recovery from a cache outage. Complete chapters 11–12. The full implementation and teardown are in [project 2](../part-15/48-dashboard.md).

## Read the topology before starting it

The browser downloads a small frontend from Nginx. The page requests `/api/summary` on that same origin. Nginx forwards the path to `api:8000`. On a cache hit the API returns the saved summary. On a miss it counts rows in PostgreSQL and stores the answer in Redis for 15 seconds. PostgreSQL owns the job records. Cached counts may lag changes for the duration of their time to live.

```mermaid
sequenceDiagram
  participant B as Browser
  participant E as Nginx
  participant A as API
  participant C as Redis
  participant D as PostgreSQL
  B->>E: GET /api/summary
  E->>A: Forward request
  A->>C: Read summary
  alt Cache hit
    C-->>A: Cached counts
  else Miss or cache unavailable
    A->>D: Group jobs by state
    D-->>A: Counts
    A->>C: Attempt short lived cache write
  end
  A-->>E: JSON response
  E-->>B: JSON response
```

Compose describes services, networks, storage and runtime configuration in YAML. Indentation establishes nesting. A mapping pairs keys with values, and a list contains multiple entries. Quote port mappings for clarity. Inspect the resolved model before starting it.

> **Important.** The database owns the rows and Redis owns a disposable summary. That ownership determines what the outage drill should preserve.

## Important fields in the actual file

| Field | Operational meaning |
|---|---|
| `ports: 127.0.0.1:8088:80` | Nginx is reachable through the local host's port 8088. The other services have no host port mapping. |
| `networks: [front, data]` | The API can talk to the edge and data tiers. Nginx cannot directly resolve the database through the data network. |
| `volumes: pgdata:...` | PostgreSQL persists data in a named volume independent of container recreation. |
| `environment` and `secrets` | Nonsecret service names go in environment variables; generated database passwords are mounted as files. |
| `depends_on ... service_healthy` | Compose waits for a passing startup health check before starting a dependent service. |
| `read_only`, `tmpfs`, `cap_drop` | The API runs with a read-only root filesystem, a temporary writable location and reduced privileges. |

The API tolerates Redis starting late. A cache dependency is omitted from its startup conditions because it can answer a miss from the database. A database health check confirms a listening server accepts connections. It cannot establish that the dashboard account has SELECT privileges on the intended table. The end-to-end request tests that contract.

## Lab · Run and interpret the integration check

```bash
# Enter the supplied stack and generate two separate local credentials.
cd labs/docker
bash setup-secrets.sh
# Validate the resolved configuration without dumping it.
docker compose config --quiet
# Create networks, build the API, and start the services.
docker compose up --build -d
# Inspect container states, then request the same summary twice.
docker compose ps
curl -i http://127.0.0.1:8088/api/summary
curl -i http://127.0.0.1:8088/api/summary
```

Allow the proxy and API to start. The first successful response should report `X-Cache: MISS` for an empty cache. A second request within 15 seconds should report `HIT`. A request from the browser can also populate the cache. In either case expect two done and one queued for the initial fixture. Use `docker compose logs --tail 40 api db` to inspect startup or query failures.

**A useful failure drill.** Stop the cache with `docker compose stop cache`, request the summary and inspect the API log. The expected body is unchanged and the response indicates a miss. Restart the cache with `docker compose start cache`. A cache outage can raise database load across a larger fleet. Track query rate and response latency before treating this fallback as adequate.

**Cleanup.** `docker compose down` removes the exercise's containers and networks and keeps its database volume. To discard only this project's synthetic data, use `docker compose down -v` before removing its generated secret files. Recreating secrets while retaining the old database can cause authentication failures because PostgreSQL initialization only runs on an empty data directory.

**Practice.** Explain how you would detect that every request is a cache miss while users still get 200. Name one metric collected at the API and one at the database.

**Interview. Does a startup dependency make a service reliable?** It prevents one class of startup race. A dependency can fail after startup, so bound connection and query times, return a clear error or fallback, and test recovery.

### Further reading

[Compose specification](https://docs.docker.com/reference/compose-file/) · [Startup order](https://docs.docker.com/compose/how-tos/startup-order/) · [Compose networking](https://docs.docker.com/compose/how-tos/networking/)
