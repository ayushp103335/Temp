# 11 · Docker from image to running process

**By the end** you can identify what an image contains, run a local service, inspect its bindings and predict which data survives removal. Complete the Linux and networking labs. Install a supported Docker Engine with Compose v2 on Linux, or Docker Desktop configured for Linux containers. On WSL2, use one daemon and verify which Docker context the CLI targets.

## Where does the process actually run?

A virtual machine includes a guest operating system and its kernel. A Linux container runs processes that use the host Linux kernel. Namespaces give processes distinct views of resources such as networking and process IDs. Control groups account for and limit resource consumption. On a non-Linux desktop the Linux kernel may itself run in a virtual machine. An image packages userspace files, configuration defaults and program instructions. Starting a container adds runtime settings and a writable layer.

The Docker CLI sends a request to the daemon selected by its context. If the image is missing, the daemon can pull a manifest and layers from a registry such as Docker Hub. The runtime prepares the filesystem, sets isolation parameters and starts the configured process. When that primary process exits, the container stops. Its logs and writable layer normally remain until removal, unless automatic removal was requested.

```mermaid
flowchart TD
  CLI["CLI and selected context"] --> Engine["Docker daemon"]
  Registry["Registry: manifests and layers"] --> Engine
  Engine --> A["Container A"]
  Engine --> B["Container B"]
  A --> Kernel["Linux host kernel"]
  B --> Kernel
  A --> Volume["Named volume"]
```

## Lab · Reach the correct side of the port mapping

```bash
# Confirm both the client and server respond and inspect the active context.
docker version
docker context show
# Start an Nginx container and publish its port 80 on the local host only.
docker run -d --name handbook-web -p 127.0.0.1:8087:80 nginx:stable-alpine
# Show running containers and the actual published port.
docker ps --filter name=handbook-web
docker port handbook-web
# Exercise HTTP through the host binding and inspect the access log.
curl -I http://127.0.0.1:8087/
docker logs --tail 10 handbook-web
# Start a short-lived shell command inside the running container.
docker exec handbook-web sh -c 'id; ls /usr/share/nginx/html'
# Inspect the configured image name and runtime state.
docker inspect --format '{{.Config.Image}} {{.State.Status}}' handbook-web
# Stop the service, inspect its retained record, then remove this lab container.
docker stop handbook-web
docker ps -a --filter name=handbook-web
docker rm handbook-web
```

The left port belongs to the host. The right port belongs to the container. With a remote Docker context, “host” means the remote daemon's machine. A stopped container cannot accept `docker exec`. Start it again to inspect live runtime state, or inspect its metadata and logs while stopped. If the chosen name already exists, identify the owner before removing anything.

## State, connectivity and trust

A bind mount exposes a chosen host path; a named volume is storage managed by Docker. Both can outlive a container. A bind mount is convenient for source edits, but a write-enabled mount allows the process to change those host files. Use read-only mounts for configuration and a named volume for the database lab. A volume surviving removal is a persistence property. A backup must also survive failures affecting that storage.

Containers on a user-defined bridge network can reach each other by names registered on that network. Inside the API container, `localhost` means the API container. In chapter 13 the database address is `db`. Publishing its port on the host is unnecessary for API-to-database communication. Limit daemon access: an identity controlling a powerful Docker daemon can affect host resources through container settings.

**Practice.** Start two named web containers with different loopback host ports and the same container port. Stop one. Record the HTTP result for both, then remove only your lab containers.

**Interview. Why does the container exit immediately after startup?** Inspect the configured primary process, its exit code and logs. A command that completes successfully can still leave no long-running service. Adding a sleep can conceal the incorrect startup command.

### Further reading

[Docker overview](https://docs.docker.com/get-started/docker-overview/) · [Docker volumes](https://docs.docker.com/engine/storage/volumes/) · [Publishing ports](https://docs.docker.com/engine/network/port-publishing/)
