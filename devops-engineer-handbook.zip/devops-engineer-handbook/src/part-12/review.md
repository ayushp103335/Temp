# Part 12 review · DevSecOps and security

## Revision and assessment

**Can a verified signature establish that a release has no vulnerabilities?**

It binds an identity or key to a statement or artifact. Its contents and runtime behavior require other evidence.

## Practical assignment

Review a release workflow and its image, write an exception with expiry and verify the signer decision for a known digest.

## Mini-project and self-evaluation

Follow a credential from issuance to rotation. Identify one place a secret value could leak and remove that exposure in a copy.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
