# 38 · Put a security decision where it can change the release

**By the end** you can model a trust boundary, choose evidence for a security requirement and assign a finding to the team able to fix it. Use the request and delivery paths from chapters 3 and 20.

A trust boundary is a point where identity, privilege, data ownership or execution context changes. In the job dashboard, a browser crosses a boundary when it calls the API. In the delivery pipeline, contributor-supplied code crosses another when a runner executes it. The same server can be well protected on its request path and exposed through an overprivileged release workflow. Threat modeling asks what assets matter, who can act at each boundary, what can go wrong and how a control would be verified.

“Shift left” means obtaining feedback early enough to change the design cheaply. A unit test can establish that a protected record requires an authorized identity. A static analysis check can flag sensitive logging during review. Deployment and runtime checks remain necessary because the running identity, network and data policy emerge from the actual environment. DevSecOps gives security work an owner and a place throughout the software lifecycle.

## Lab · Review the dashboard before expanding its audience

Draw the paths browser → proxy → API → PostgreSQL and contributor → CI → registry → deployment. Mark the database rows, registry package and deployment credential as protected assets. Write one requirement and test for each.

| Requirement | Early verification | Release or runtime evidence |
|---|---|---|
| Dashboard clients see only authorized tenant data in a future multi-tenant version. | Contract tests use two synthetic tenants and expected permission outcomes. | Query audit shows the authorized identity and scope without recording private payloads. |
| A pull request cannot publish a production artifact. | Inspect event guards and job permissions in the workflow. | Trusted revision and publisher identity appear in the release record. |
| Database credentials can be replaced. | Configuration supports file-based injection and has no hard-coded secret. | Rotate the training credential under controlled conditions and verify a new connection. |

The supplied project 2 is local synthetic training software without tenant authentication. Moving it to a shared public environment is a different security decision. Reachability restrictions in the training lab reduce exposure but do not implement user-level authorization.

**Prioritizing findings.** Record component, deployed versions, severity, exposure, fix availability, accountable owner and verification date. A vulnerability in a runtime parser reachable by untrusted input can deserve faster attention than an unused build-time dependency with the same numerical severity. A time-limited exception should identify compensating controls, a reviewer and an expiry. Keep the original report when a finding is disputed.

**Troubleshooting.** If a gate blocks every release, inspect its scope, duplicate reports, dependency freshness and policy. Blanket suppression discards evidence that can help the owning team. If a scan passes but a review finds a logic defect, add a requirement-specific test; generic scanning rarely knows the application's authorization model.

**Practice.** Define acceptance evidence for “only the runtime identity can read this secret.” Include verification of deployment job access and log output. **Interview. Who owns a security finding?** The service owner owns remediation of its delivered risk; the security and platform teams supply policy, expertise and shared controls.

### Further reading

[OWASP ASVS](https://asvs.owasp.org/) · [NIST Secure Software Development Framework](https://csrc.nist.gov/projects/ssdf)
