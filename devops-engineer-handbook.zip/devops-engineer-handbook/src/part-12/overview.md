# Part 12 · DevSecOps and security

**Study time:** 5–8 h including practice. **Starting point:** CI/CD, IAM and application boundaries.

Translate a threat into an acceptance test and identify which identity can authorize a release.

## What you will demonstrate

Review a release workflow and its image, write an exception with expiry and verify the signer decision for a known digest.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
