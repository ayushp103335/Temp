# 40 · Trust a release and rotate its credentials

**By the end** you can distinguish a secret from a key-management policy, a signature from an SBOM and a successful scan from permission to deploy. Use chapter 24 and [project 9](../part-15/55-secure.md).

A secret is a value whose disclosure grants access or compromises confidentiality. A secret manager stores or issues secrets, controls access and can support rotation. HashiCorp Vault can issue leased dynamic credentials through suitable engines. AWS Secrets Manager can store and rotate supported credentials. A key management service controls cryptographic keys and their permitted operations. Applications may be authorized to decrypt a value without receiving raw master key material. Keep separate records of who may fetch the secret, who may decrypt it and how rotation reaches running processes.

**Rotation exercise.** Draw the timeline for a database password used by a pool of long-lived connections. Provision the new credential or overlap window, update consumers, force or observe new connections, verify continued service and then retire the old credential. An existing successful query may use a previously authenticated connection. Verify a fresh connection before declaring the rotation complete. A failed rollout needs a recovery route that preserves legitimate access.

TLS uses certificates and trust configuration to authenticate identities on connections. A certificate can be in date yet fail hostname verification, lack an intermediate or use an unexpected trust root. Inventory names, issuers, renewal automation and reload behavior. Monitoring a certificate file on disk is insufficient if the endpoint still serves the old certificate.

| Mechanism | Evidence produced | Frequent interpretation error |
|---|---|---|
| SAST and SonarQube analysis | Findings in code and a configured quality-gate result | Treating a generic gate as proof of business authorization. |
| DAST | Observations of a running application under an approved assessment | Assuming the exercised paths cover all roles and workflows. |
| Dependency and image scanning with Trivy | Known issues matched to detected components and databases | Equating severity with exploitability in this exact deployment. |
| SBOM | Inventory of detected software components | Treating an inventory as a security verdict. |
| Cosign signature verification | An identified signer signed a specific artifact or statement | Accepting any valid signer without checking issuer, identity and digest. |

> **Security.** Keep the expected signer identity, issuer and artifact digest in the verification policy. A successful cryptographic operation alone cannot identify an authorized release.

## Lab · Follow the verification inputs

Open `labs/security/secure-release.yml`. Find which candidate bytes are exported to the scanner, where the SBOM goes, why a nonzero scanner exit blocks publication, and how the signer and issuer checks relate to a protected workflow. The workflow uses trusted main-branch publication and an identity token for keyless signing. The verification job exercises one trust decision; a production admission or deployment policy must independently enforce the same trust assumptions at the destination.

For a local review, write a one-line decision for each of these outcomes: valid signature from an unexpected repository, expected signer on a different digest, correct digest with a new critical vulnerability, and an unavailable vulnerability database. Record whether to hold, reject or escalate and list the evidence a human reviewer needs. Do not log the raw credential used to retrieve a report.

**Practice.** Compare OWASP ASVS requirements verified by code review with a release signing policy verified by infrastructure. Give each a separate owner. **Interview. Why sign after scanning?** The release identity and reports should refer to the exact candidate. A rebuild before publication can invalidate that link even when its source commit is unchanged.

### Further reading

[Sigstore verification](https://docs.sigstore.dev/cosign/verifying/verify/) · [Trivy documentation](https://trivy.dev/latest/docs/) · [Vault secrets engines](https://developer.hashicorp.com/vault/docs/secrets) · [OWASP ASVS](https://asvs.owasp.org/)
