# 39 · Bound the damage a workload can cause

**By the end** you can review a container's effective identity, separate network and API authorization, and identify the system that enforces each control. Use chapters 4, 11, 15 and 16.

Start with a service account that can read synthetic jobs and render a count. It needs data access through a narrowly scoped database login. It has no reason to install OS packages at runtime, administer a node or enumerate Kubernetes secrets. Write down the legitimate actions first. Each unnecessary permission is easier to remove before several services silently start depending on it.

At the host layer, use supported patches, named accounts, trusted SSH host keys, key-based administrative access and logged privilege elevation. Validate an SSH configuration with `sshd -t` using the intended configuration and preserve a working administrative session during a controlled change. Firewall rules should express the actual permitted source, destination, protocol and port. Ensure the management path remains reachable through its approved route.

## Lab · Review the supplied controls

1. Inspect `labs/docker/compose.yaml`. Identify the API's read-only root filesystem, temporary writable path, dropped capabilities and restricted database network. Find the one host-published service.
2. Inspect `labs/kubernetes/base/deployment.yaml`. Locate `runAsNonRoot`, runtime-default seccomp, disabled privilege escalation, dropped capabilities and disabled automatic mounting of a service-account token. Explain what would break if the image required root.
3. On the training cluster, `kubectl --context kind-handbook auth can-i get secrets -n handbook` tests the current operator's authorization for one action. A privileged reviewer can use authorized identity impersonation checks to evaluate a service account. Do not infer workload access from the operator's result.
4. Record which controls apply at build time, admission and runtime. Image scanning identifies known package issues. Pod Security Admission can enforce a selected Pod Security Standard profile. Runtime enforcement remains dependent on node and cluster configuration.

A NetworkPolicy selects Pods and describes allowed flows for ingress, egress or both. The CNI must implement it. Restricting the API's egress to the database alone can accidentally remove DNS resolution. Validate legitimate communication in a disposable namespace after changing policy. RBAC controls access to the Kubernetes API, while database roles control data operations and the network plugin filters connections. Passing one check does not imply passing the others.

Falco can evaluate runtime events against rules and report unusual behavior such as an unexpected shell in an application container. Confirm whether an event was a scheduled troubleshooting action, capture workload identity, and route the alert to an owner. A benchmark such as a relevant CIS profile is a configuration baseline. Compare its scope and version with your distribution and managed-provider responsibilities. Track justified exceptions.

**Practice.** A candidate image passes a scan but requests a privileged container and a writable host mount. Identify the review boundary that can reject the deployment and the evidence that the application truly needs the access. **Interview. Should every Pod receive an API token?** Only workloads with an API requirement should receive the necessary short-lived identity and narrowly scoped permissions.

### Further reading

[Kubernetes Pod Security Standards](https://kubernetes.io/docs/concepts/security/pod-security-standards/) · [Kubernetes network policies](https://kubernetes.io/docs/concepts/services-networking/network-policies/) · [Falco rules](https://falco.org/docs/concepts/rules/) · [CIS Benchmarks](https://www.cisecurity.org/cis-benchmarks)
