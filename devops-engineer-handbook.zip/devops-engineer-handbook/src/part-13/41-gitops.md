# 41 · Reconcile deployments from version control

**By the end** you can explain a deployment that appears to undo an operator's change, locate the desired version and reverse a faulty promotion durably. Use kubectl and Kustomize from chapter 18 and the Git workflow from chapter 8.

In GitOps, desired state is declarative, versioned, pulled automatically and continuously reconciled. A CI job that runs `kubectl apply` on each push can automate deployment, but it does not by itself watch for later drift. A controller such as Argo CD or Flux reads an approved source, renders desired resources, observes actual state and applies changes under its cluster identity. That identity and the people allowed to change its source jointly determine what can reach production.

```mermaid
flowchart TD
  CI["Build and test image"] --> Registry["Registry digest"]
  Registry --> Review["Review desired digest in Git"]
  Review --> Controller["Argo CD or Flux"]
  Controller --> Cluster["Kubernetes API"]
  Cluster --> Observe["Compare health and sync"]
  Observe --> Controller
```

Argo CD uses Application resources to associate a source, path and revision with a destination. Flux commonly composes source objects and reconcilers for Kustomizations or Helm releases. In both, sync and health answer different questions. A cluster can contain exactly the declared configuration and still fail every user request.

## Lab · Predict the outcome of an emergency change

Open `labs/gitops/application.yaml`. Read its repository URL, revision, path, destination and sync policy. `selfHeal` enables reconciliation of certain live deviations; `prune` permits removal of resources no longer in desired state. Review the repository and destination scope before enabling either. The default Argo project in this local exercise is broad; a production AppProject should restrict allowed sources, destinations and resource kinds.

Imagine an operator uses kubectl to increase replicas during an incident. If Git declares a fixed lower replica count and self-healing is enabled, the controller may restore the declared count. Record a durable incident change in Git or use a documented, time-bounded pause procedure and reconcile the final agreed state. For HPA-managed replica counts, align field ownership so automation does not fight itself.

For a local render use `kubectl kustomize labs/gitops/release`. The overlay removes the ConfigMap volume over the web root so the image's own page is served. [Project 6](../part-15/52-gitops.md) publishes that image and records a digest promotion. A rollback normally uses a reviewed reversal or digest change in Git. A live rollout undo alone leaves the controller with instructions to reinstall the bad version.

**Troubleshooting.** If sync fails, distinguish source authentication, manifest rendering, API authorization and workload readiness. Read the controller's reported revision. “Latest commit on main” might differ from the last successfully reconciled revision. Give each environment an explicit promotion event so a development commit cannot silently change every cluster.

**Practice.** Specify recovery if the Git provider is temporarily unreachable but the cluster remains healthy. Decide which emergency actions can be performed and how to restore a consistent change record later. **Interview. Why does pull-based delivery reduce the build job's role?** The build job can publish an image and propose desired state without retaining direct production cluster credentials.

### Further reading

[OpenGitOps principles](https://opengitops.dev/) · [Argo CD automated sync](https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/) · [Flux concepts](https://fluxcd.io/flux/concepts/)
