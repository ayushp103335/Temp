# 42 · Build a platform as a product for developers

**By the end** you can identify a repeated developer task, design a supported self-service path and measure whether it reduced operational work. Use the projects for containers, CI and deployment as building blocks.

Ten teams ask for “a staging service.” The platform team could handle ten tickets or define a supported path: register an owner, select an approved runtime, request a bounded namespace, generate a repository with checks, deploy an example, expose logs and provide removal. An internal developer platform is the set of capabilities that makes those operations usable and supportable. A portal is one interface to the platform. Teams may also use a CLI or a pull request.

A golden path is an opinionated, supported way to complete a common task. It should encode the parts common enough to standardize and expose the parameters developers genuinely need to choose. The platform owns its templates, upgrade path and failure modes. The service team owns its business behavior, on-call contact and data classification. A generated repository without a plan for future updates can create fifty copies of yesterday's defect.

## Lab · Specify a staging-service contract

| Input or output | Proposed contract |
|---|---|
| Inputs | Service name, owner, source repository, data classification and expected request rate. |
| Defaults | A bounded CPU/memory budget, restricted service account, CI contract tests and internal route. |
| Outputs | Repository path, namespace, service address, dashboard and cleanup operation. |
| Failure behavior | Each provisioning step records its result and a retry resumes from the last known state. |
| Ownership | Service owner handles application incidents; platform owner handles template and control-plane defects. |

Start with project 2. Identify the four files that can be shared safely across services and the settings that must remain application-specific. Then write three acceptance tests: can a new developer deploy the reference service, diagnose a failing database check and remove its resources without elevated cluster rights? Time the exercise with a learner who has never seen the template. Preserve their failed attempts as evidence of confusing interfaces.

Backstage organizes software entities in a catalog and provides software templates through its scaffolder. A template can gather parameters and trigger approved actions. Keep backend credentials scoped and validate requested repository and cloud destinations. A template parameter granting arbitrary network reach defeats the access controls the interface appeared to provide. Provisioned resources should be tagged with owner, environment and lifecycle information.

**Metrics.** Measure time to first working deployment, successful completion rate, abandoned requests, recurring help tickets and update adoption. Raw template invocation counts say little about whether the service became operable. Make an escape path available for unusual workloads and capture why teams needed it.

**Practice.** Write a two-paragraph design note for deprecating an old base image across twenty generated services. Include discovery, owner notification, testing, exception expiry and rollback evidence. **Interview. When would a platform be premature?** If there is little repeated work or unstable requirements, a small shared library or documented service example can be easier to maintain while learning what should be standardized.

### Further reading

[Backstage software catalog](https://backstage.io/docs/features/software-catalog/) · [Backstage software templates](https://backstage.io/docs/features/software-templates/) · [CNCF platform engineering](https://tag-app-delivery.cncf.io/whitepapers/platforms/)
