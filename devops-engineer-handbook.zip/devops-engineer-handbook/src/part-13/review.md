# Part 13 review · GitOps and platform engineering

## Revision and assessment

**Why might a successful emergency kubectl edit disappear?**

A reconciliation controller is restoring the declared state. Reconcile the approved emergency change through the authoritative source.

## Practical assignment

Review and revert a digest change in a practice GitOps environment. Specify the guardrails a platform should offer other teams.

## Mini-project and self-evaluation

Identify the authorizer, reconciler and runtime identity. State when a mesh would add more operating cost than value.

- [ ] I completed the specified task and recorded the environment and evidence.
- [ ] I can explain the mechanism behind the assessment answer using my own example.
- [ ] I can describe one failure the check would miss, the next observation I would collect and how to recover or clean up.
