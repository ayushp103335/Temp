# 43 · Workload identity, service mesh and policy

**By the end** you can explain what a mesh protects, distinguish authentication from authorization and evaluate whether adding a mesh is worthwhile. Use chapters 7, 15 and 39.

A service mesh provides common service-to-service networking capabilities. Its data plane handles traffic; its control plane distributes configuration, identity and policy. Istio offers deployment choices including sidecar and ambient modes. Linkerd uses lightweight proxies alongside meshed workloads. Their features and compatibility vary by release. An ingress gateway handles entry to a system, whereas a mesh commonly governs east–west traffic between services. One does not automatically replace the other.

Mutual TLS means both peers authenticate certificates during connection establishment. In a mesh, workload identities and automated certificate rotation can remove per-application certificate handling. An authenticated worker is still capable of asking for an operation it should not perform. Authorization policy must decide which identities may reach which services or methods. Network reachability, transport identity and end-user authorization answer three different questions.

## Lab · Trace one authorized call

A submission API may call a status reader, and a worker may write results to a separate endpoint. Write a table with calling identity, destination, method, path and decision. Include three examples: an authorized read, an unauthorized write from the API, and an unmeshed client. Then locate the enforcement points. A mesh policy can authenticate and authorize a workload. The application must still evaluate whether the requesting end user is entitled to the specific record.

Traffic management can split a canary by weight, apply timeouts or retry eligible requests. If both a proxy and application retry three times, the effective attempts may multiply. Coordinate timeout budgets and preserve idempotency for writes. Examine request histograms at both sides of the proxy; telemetry overhead and extra hops are measurable costs. A certificate rotation failure can look like a network outage if operators see only connection failures.

**Policy as code.** Open Policy Agent (OPA) evaluates structured input against policies written in Rego. Use it or an appropriate native admission mechanism to enforce controls such as approved image sources and required ownership labels. A policy decision must be integrated with an enforcement point. An offline test returning “deny” cannot block a live deployment by itself. Start in audit mode with representative manifests, review false positives and define controlled emergency handling.

**Troubleshooting.** Work from endpoint health to identity and policy. If a newly injected Pod never becomes ready, inspect proxy configuration and resource requests. If a TLS handshake fails, check trust domains, certificate time window and policy mode. If authenticated calls return permission errors, inspect authorization rules. Record which failure occurred before relaxing enforcement.

**Practice.** Design a mesh adoption experiment for just two synthetic services. Define measurable latency overhead, one intended denial, one intended success, a certificate rotation observation and a rollback route. **Interview. When would you skip a mesh?** A small fleet with adequate identity and observability may gain little relative to the added operations. Compare specific requirements and measured costs.

### Further reading

[Istio security concepts](https://istio.io/latest/docs/concepts/security/) · [Linkerd architecture](https://linkerd.io/2/overview/architecture/) · [OPA documentation](https://www.openpolicyagent.org/docs/)
