# Part 13 · GitOps and platform engineering

**Study time:** 5–8 h including practice. **Starting point:** Kubernetes overlays, IAM and release identities.

Identify desired-state ownership, design a self-service interface and place workload identity checks.

## What you will demonstrate

Review and revert a digest change in a practice GitOps environment. Specify the guardrails a platform should offer other teams.

Keep a record of the input, expected outcome, observed outcome and the first check you would make if they differ. Use the part review after completing the chapters.
