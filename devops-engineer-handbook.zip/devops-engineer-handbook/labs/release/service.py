"""Local-only job status summary. Run with a JSON file as the first argument."""
import json
import sys
from pathlib import Path

def summarize(records):
    if not isinstance(records, list):
        raise ValueError("expected a list of job records")
    counts = {"queued": 0, "done": 0, "failed": 0}
    for record in records:
        state = record["state"]
        if state not in counts:
            raise ValueError(f"unrecognized state: {state}")
        counts[state] += 1
    return counts

if __name__ == "__main__":
    print(json.dumps(summarize(json.loads(Path(sys.argv[1]).read_text())), sort_keys=True))
