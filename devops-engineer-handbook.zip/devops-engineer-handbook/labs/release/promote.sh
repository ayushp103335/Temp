#!/usr/bin/env bash
# Local single-operator lab. State lives in the directory passed as argument 2.
set -euo pipefail
if (( $# != 2 )); then echo 'Usage: promote.sh SERVICE.py LAB_DIRECTORY' >&2; exit 2; fi
src=$1
dest=$2
here=$(cd "$(dirname "$0")" && pwd)
mkdir -p -- "$dest/releases"
work=$(mktemp -d "$dest/.candidate.XXXXXXXX")
trap 'rm -rf -- "$work"' EXIT
cp -- "$src" "$work/service.py"
cp -- "$here/test_service.py" "$work/test_service.py"
(cd "$work" && python3 -I -m py_compile service.py && python3 -B -m unittest -v test_service)
digest=$(sha256sum < "$work/service.py" | cut -d' ' -f1)
artifact="$dest/releases/$digest.py"
if [[ -e "$artifact" ]]; then
    cmp -- "$work/service.py" "$artifact"
else
    mv -- "$work/service.py" "$artifact"
fi
ln -s "releases/$digest.py" "$work/current"
mv -Tf -- "$work/current" "$dest/current"
printf 'Active artifact %s\n' "$digest"
