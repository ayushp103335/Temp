import unittest
from service import summarize

class SummaryTests(unittest.TestCase):
    def test_mixed_batch(self):
        self.assertEqual(summarize([{"state": "done"}, {"state": "queued"}]),
                         {"done": 1, "queued": 1, "failed": 0})

    def test_empty(self):
        self.assertEqual(sum(summarize([]).values()), 0)

    def test_unknown_state(self):
        with self.assertRaises(ValueError):
            summarize([{"state": "lost"}])

if __name__ == "__main__":
    unittest.main()
