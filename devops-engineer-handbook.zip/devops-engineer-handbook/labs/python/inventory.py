"""Summarize a provider API response previously saved as JSON."""
import argparse
import json
import logging
from pathlib import Path

def count_by_state(reservations):
    counts = {}
    for reservation in reservations:
        for instance in reservation["Instances"]:
            state = instance["State"]["Name"]
            counts[state] = counts.get(state, 0) + 1
    return counts

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("response", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.response.read_text(encoding="utf-8"))
        counts = count_by_state(data["Reservations"])
    except (OSError, ValueError, KeyError, TypeError) as error:
        logging.error("Could not read EC2 inventory (%s)", type(error).__name__)
        return 2
    print(json.dumps(counts, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
