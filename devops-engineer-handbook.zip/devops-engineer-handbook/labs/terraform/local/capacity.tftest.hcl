run "default_capacity" {
  command = apply
  assert {
    condition     = output.capacity.replicas == 2
    error_message = "Default capacity should be two."
  }
}
run "reject_zero" {
  command = plan
  variables { replicas = 0 }
  expect_failures = [var.replicas]
}
