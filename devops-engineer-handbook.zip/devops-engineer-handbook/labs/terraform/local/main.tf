terraform {
  required_version = ">= 1.10, < 2.0"
}
variable "replicas" {
  type    = number
  default = 2
  validation {
    condition     = var.replicas >= 1 && var.replicas <= 8 && floor(var.replicas) == var.replicas
    error_message = "Choose a whole replica count between one and eight."
  }
}
resource "terraform_data" "capacity" {
  input = { service = "job-status", replicas = var.replicas }
}
output "capacity" {
  value = terraform_data.capacity.output
}
