#!/usr/bin/env bash
set -euo pipefail
mkdir -p /srv/handbook
echo 'Handbook training target ready' > /srv/handbook/index.html
cat > /etc/systemd/system/handbook-web.service <<'UNIT'
[Unit]
Description=Synthetic training target
After=network.target
[Service]
User=nobody
WorkingDirectory=/srv/handbook
ExecStart=/usr/bin/python3 -m http.server 8080 --bind 0.0.0.0
Restart=on-failure
NoNewPrivileges=true
ProtectSystem=strict
PrivateTmp=true
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now handbook-web.service
