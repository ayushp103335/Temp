terraform {
  required_version = ">= 1.10, < 2.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.100.0"
    }
  }
  backend "s3" {}
}
variable "region" {
  type = string
}
variable "operator_cidr" {
  type = string
  validation {
    condition     = can(cidrnetmask(var.operator_cidr)) && endswith(var.operator_cidr, "/32")
    error_message = "Supply the one public IPv4 address of the operator as a /32."
  }
}
provider "aws" {
  region = var.region
  default_tags {
    tags = { Project = "devops-handbook", Environment = "training" }
  }
}
data "aws_availability_zones" "usable" { state = "available" }
data "aws_ssm_parameter" "ami" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}
locals {
  zones = { for i, az in slice(data.aws_availability_zones.usable.names, 0, 2) : az => i }
}
resource "aws_vpc" "lab" {
  cidr_block           = "10.72.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true
}
resource "aws_internet_gateway" "edge" { vpc_id = aws_vpc.lab.id }
resource "aws_subnet" "public" {
  for_each          = local.zones
  vpc_id            = aws_vpc.lab.id
  availability_zone = each.key
  cidr_block        = cidrsubnet(aws_vpc.lab.cidr_block, 8, each.value)
}
resource "aws_subnet" "private" {
  for_each          = local.zones
  vpc_id            = aws_vpc.lab.id
  availability_zone = each.key
  cidr_block        = cidrsubnet(aws_vpc.lab.cidr_block, 8, each.value + 16)
}
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.lab.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.edge.id
  }
}
resource "aws_route_table_association" "public" {
  for_each       = aws_subnet.public
  subnet_id      = each.value.id
  route_table_id = aws_route_table.public.id
}
resource "aws_security_group" "edge" {
  name_prefix = "handbook-edge-"
  vpc_id      = aws_vpc.lab.id
}
resource "aws_security_group" "app" {
  name_prefix = "handbook-app-"
  vpc_id      = aws_vpc.lab.id
}
resource "aws_vpc_security_group_ingress_rule" "operator" {
  security_group_id = aws_security_group.edge.id
  ip_protocol       = "tcp"
  from_port         = 80
  to_port           = 80
  cidr_ipv4         = var.operator_cidr
}
resource "aws_vpc_security_group_egress_rule" "forward" {
  security_group_id            = aws_security_group.edge.id
  referenced_security_group_id = aws_security_group.app.id
  ip_protocol                  = "tcp"
  from_port                    = 8080
  to_port                      = 8080
}
resource "aws_vpc_security_group_ingress_rule" "from_edge" {
  security_group_id            = aws_security_group.app.id
  referenced_security_group_id = aws_security_group.edge.id
  ip_protocol                  = "tcp"
  from_port                    = 8080
  to_port                      = 8080
}
resource "aws_instance" "app" {
  for_each                    = aws_subnet.private
  ami                         = data.aws_ssm_parameter.ami.value
  instance_type               = "t3.micro"
  subnet_id                   = each.value.id
  associate_public_ip_address = false
  vpc_security_group_ids      = [aws_security_group.app.id]
  user_data                   = file("${path.module}/bootstrap.sh")
  user_data_replace_on_change = true
  metadata_options { http_tokens = "required" }
  root_block_device { encrypted = true }
}
resource "aws_lb" "edge" {
  name_prefix        = "hbook-"
  load_balancer_type = "application"
  subnets            = values(aws_subnet.public)[*].id
  security_groups    = [aws_security_group.edge.id]
  depends_on         = [aws_route_table_association.public]
}
resource "aws_lb_target_group" "app" {
  name_prefix = "hbook-"
  port        = 8080
  protocol    = "HTTP"
  vpc_id      = aws_vpc.lab.id
  health_check { path = "/index.html" }
}
resource "aws_lb_target_group_attachment" "app" {
  for_each         = aws_instance.app
  target_group_arn = aws_lb_target_group.app.arn
  target_id        = each.value.id
}
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.edge.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.app.arn
  }
}
resource "aws_s3_bucket" "artifacts" { bucket_prefix = "handbook-lab-" }
resource "aws_s3_bucket_public_access_block" "artifacts" {
  bucket                  = aws_s3_bucket.artifacts.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
output "training_url" { value = "http://${aws_lb.edge.dns_name}/index.html" }
output "target_group_arn" { value = aws_lb_target_group.app.arn }
