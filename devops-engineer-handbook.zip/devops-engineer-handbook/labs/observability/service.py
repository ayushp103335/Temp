"""Local synthetic work, application metrics and an exercise alert receiver."""
import json
import os
from collections import Counter
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from uuid import uuid4

counts = Counter(ok=0, failed=0)
events = Path(os.getenv("EVENT_DIR", "/tmp")) / "jobs.log"

class Handler(BaseHTTPRequestHandler):
    def reply(self, status, body, content_type):
        data = body.encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/metrics":
            lines = ["# HELP handbook_jobs_total Synthetic jobs by outcome.",
                     "# TYPE handbook_jobs_total counter"]
            for key, value in counts.items():
                lines.append(f'handbook_jobs_total{{outcome="{key}"}} {value}')
            self.reply(200, "\n".join(lines) + "\n", "text/plain; version=0.0.4")
        elif self.path in ("/work/ok", "/work/failed"):
            outcome = self.path.rsplit("/", 1)[1]
            counts[outcome] += 1
            event = dict(ts=datetime.now(timezone.utc).isoformat(), job_id=str(uuid4()), outcome=outcome)
            with events.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(event) + "\n")
            self.reply(200 if outcome == "ok" else 503, json.dumps(event), "application/json")
        else:
            self.reply(404, "unknown path\n", "text/plain")

    def do_POST(self):
        if self.path != "/alerts":
            return self.reply(404, "unknown path\n", "text/plain")
        size = int(self.headers.get("Content-Length", 0))
        if size > 65536:
            return self.reply(413, "too large\n", "text/plain")
        payload = json.loads(self.rfile.read(size))
        print("alert_notification", payload.get("status"), len(payload.get("alerts", [])), flush=True)
        self.reply(200, "received\n", "text/plain")

if __name__ == "__main__":
    HTTPServer(("0.0.0.0", int(os.getenv("PORT", "8000"))), Handler).serve_forever()
