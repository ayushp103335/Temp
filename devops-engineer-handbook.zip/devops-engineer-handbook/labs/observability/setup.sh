#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
umask 077
mkdir -p secrets
if [[ ! -e secrets/admin ]]; then
    python3 -c 'import secrets; print(secrets.token_urlsafe(32))' > secrets/admin
    chmod 444 secrets/admin
fi
