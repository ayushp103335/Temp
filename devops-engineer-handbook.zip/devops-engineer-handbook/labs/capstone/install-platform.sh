#!/usr/bin/env bash
set -euo pipefail
: "${KUBE_CONTEXT:?Select the dedicated capstone cluster context}"
: "${ARGO_CHART:=10.18.2}"
: "${METRICS_CHART:=3.14.0}"
: "${PROM_CHART:=93.4.1}"
helm repo add handbook-argo https://argoproj.github.io/argo-helm --force-update
helm repo add handbook-prom https://prometheus-community.github.io/helm-charts --force-update
helm repo add handbook-metrics https://kubernetes-sigs.github.io/metrics-server/ --force-update
helm repo update
helm upgrade --install argocd handbook-argo/argo-cd --version "$ARGO_CHART" --kube-context "$KUBE_CONTEXT" -n argocd --create-namespace --wait --timeout 10m
helm upgrade --install metrics-server handbook-metrics/metrics-server --version "$METRICS_CHART" --kube-context "$KUBE_CONTEXT" -n kube-system --wait
helm upgrade --install observe handbook-prom/kube-prometheus-stack --version "$PROM_CHART" --kube-context "$KUBE_CONTEXT" -n monitoring --create-namespace --wait --timeout 10m --set prometheus.prometheusSpec.retention=1d
