#!/usr/bin/env bash
# Read the value inside the authorized pod and return only a present/absent result.
set -euo pipefail
: "${SECRET_ARN:?Set SECRET_ARN from Terraform output}"
: "${AWS_REGION:?Select your training AWS region}"
: "${KUBE_CONTEXT:?Select the training cluster context}"
python3 - "$SECRET_ARN" "$AWS_REGION" <<'PY' | kubectl --context "$KUBE_CONTEXT" -n handbook-staging apply -f -
import json, sys
arn, region = sys.argv[1:]
print(json.dumps({
    "apiVersion": "batch/v1", "kind": "Job", "metadata": {"name": "verify-secret"},
    "spec": {"backoffLimit": 2, "template": {"spec": {
        "serviceAccountName": "evidence-reader", "restartPolicy": "Never",
        "containers": [{"name": "check", "image": "public.ecr.aws/aws-cli/aws-cli:2.27.49",
          "command": ["/bin/sh","-ec"],
          "args": ['value=$(aws secretsmanager get-secret-value --secret-id "$SECRET_ARN" --query SecretString --output text); test -n "$value"; echo "Secret read succeeded"'],
          "env": [{"name":"AWS_REGION","value":region},{"name":"SECRET_ARN","value":arn}]}]}}}}))
PY
kubectl --context "$KUBE_CONTEXT" -n handbook-staging wait --for=condition=complete job/verify-secret --timeout=180s
kubectl --context "$KUBE_CONTEXT" -n handbook-staging logs job/verify-secret
