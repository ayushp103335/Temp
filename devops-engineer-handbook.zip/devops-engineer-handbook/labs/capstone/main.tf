terraform {
  required_version = ">= 1.10, < 2"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.100.0" }
  }
  backend "s3" {}
}
variable "region" { type = string }
variable "kubernetes_version" { type = string }
variable "operator_cidr" {
  type = string
  validation {
    condition     = can(cidrnetmask(var.operator_cidr)) && endswith(var.operator_cidr, "/32")
    error_message = "Supply the authorized operator's public IPv4 /32."
  }
}
provider "aws" {
  region = var.region
  default_tags { tags = { Project = "handbook-capstone", Environment = "training" } }
}
data "aws_availability_zones" "usable" { state = "available" }
locals {
  name = "handbook-capstone"
  azs  = slice(data.aws_availability_zones.usable.names, 0, 2)
}
module "network" {
  source                 = "terraform-aws-modules/vpc/aws"
  version                = "5.21.0"
  name                   = local.name
  cidr                   = "10.84.0.0/16"
  azs                    = local.azs
  private_subnets        = ["10.84.10.0/24", "10.84.11.0/24"]
  public_subnets         = ["10.84.20.0/24", "10.84.21.0/24"]
  enable_nat_gateway     = true
  single_nat_gateway     = false
  one_nat_gateway_per_az = true
  enable_dns_hostnames   = true
  public_subnet_tags     = { "kubernetes.io/role/elb" = "1" }
  private_subnet_tags    = { "kubernetes.io/role/internal-elb" = "1" }
}
module "cluster" {
  source                                   = "terraform-aws-modules/eks/aws"
  version                                  = "20.37.2"
  cluster_name                             = local.name
  cluster_version                          = var.kubernetes_version
  cluster_endpoint_public_access           = true
  cluster_endpoint_private_access          = true
  cluster_endpoint_public_access_cidrs     = [var.operator_cidr]
  enable_cluster_creator_admin_permissions = true
  vpc_id                                   = module.network.vpc_id
  subnet_ids                               = module.network.private_subnets
  cluster_enabled_log_types                = ["api", "audit", "authenticator"]
  cloudwatch_log_group_retention_in_days   = 7
  cluster_addons = {
    coredns                = {}
    kube-proxy             = {}
    vpc-cni                = { before_compute = true }
    eks-pod-identity-agent = {}
  }
  eks_managed_node_groups = {
    system = {
      min_size       = 2
      max_size       = 5
      desired_size   = 3
      instance_types = ["m6i.large"]
      ami_type       = "AL2023_x86_64_STANDARD"
    }
  }
}
data "aws_iam_policy_document" "pods" {
  statement {
    actions = ["sts:AssumeRole", "sts:TagSession"]
    principals {
      type        = "Service"
      identifiers = ["pods.eks.amazonaws.com"]
    }
  }
}
resource "aws_iam_role" "logs" {
  name_prefix        = "handbook-cw-"
  assume_role_policy = data.aws_iam_policy_document.pods.json
}
resource "aws_iam_role_policy_attachment" "logs" {
  role       = aws_iam_role.logs.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
}
resource "aws_eks_addon" "observability" {
  cluster_name = module.cluster.cluster_name
  addon_name   = "amazon-cloudwatch-observability"
  pod_identity_association {
    role_arn        = aws_iam_role.logs.arn
    service_account = "cloudwatch-agent"
  }
  depends_on = [aws_iam_role_policy_attachment.logs, module.cluster]
}
resource "aws_secretsmanager_secret" "demo" {
  name_prefix             = "handbook-capstone-"
  recovery_window_in_days = 7
}
resource "aws_iam_role" "reader" {
  name_prefix        = "handbook-evidence-"
  assume_role_policy = data.aws_iam_policy_document.pods.json
}
resource "aws_iam_role_policy" "reader" {
  role = aws_iam_role.reader.id
  policy = jsonencode({
    Version   = "2012-10-17",
    Statement = [{ Effect = "Allow", Action = "secretsmanager:GetSecretValue", Resource = aws_secretsmanager_secret.demo.arn }]
  })
}
resource "aws_eks_pod_identity_association" "reader" {
  cluster_name    = module.cluster.cluster_name
  namespace       = "handbook-staging"
  service_account = "evidence-reader"
  role_arn        = aws_iam_role.reader.arn
}
output "cluster_name" { value = module.cluster.cluster_name }
output "secret_arn" { value = aws_secretsmanager_secret.demo.arn }
