#!/usr/bin/env bash
# Archive a quiescent directory to a private directory outside the source.
set -euo pipefail
umask 077
if (( $# != 2 )); then echo 'Usage: backup.sh SOURCE EXISTING_DESTINATION' >&2; exit 2; fi
src=$(realpath -e -- "$1")
dest=$(realpath -e -- "$2")
[[ -d "$src" && -d "$dest" && "$src" != / ]] || exit 2
case "$dest/" in "$src/"*) echo 'Destination overlaps source' >&2; exit 2;; esac
tmp=$(mktemp -d "$dest/.pending.XXXXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
tar -C "$src" -czf "$tmp/data.tar.gz" .
(cd "$tmp" && sha256sum data.tar.gz > SHA256SUMS && tar -tzf data.tar.gz > members.txt)
# Unique directory and a same-filesystem rename publish a complete set.
name="backup-$(date -u +%Y%m%dT%H%M%SZ)-${tmp##*.}"
mv -T -- "$tmp" "$dest/$name"
printf '%s\n' "$dest/$name"
