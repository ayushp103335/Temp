#!/usr/bin/env bash
set -euo pipefail
target=${1:-.}
printf 'observed_utc=%s\n' "$(date -u +%FT%TZ)"
printf 'load_1m_5m_15m='
cut -d' ' -f1-3 /proc/loadavg
awk '/^MemAvailable:/ {print "mem_available_kib=" $2}' /proc/meminfo
df -Pk -- "$target"
