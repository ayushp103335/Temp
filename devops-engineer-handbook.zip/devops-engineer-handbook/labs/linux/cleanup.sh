#!/usr/bin/env bash
# Only direct children matching the synthetic log convention are eligible.
set -euo pipefail
if (( $# < 1 || $# > 2 )); then echo 'Usage: cleanup.sh LAB_LOG_DIR [--apply]' >&2; exit 2; fi
root=$(realpath -e -- "$1")
[[ -d "$root" && "$root" != / && -f "$root/.handbook-logs" ]] || exit 2
case "${2:-preview}" in
  preview) find "$root" -maxdepth 1 -type f -name 'demo-*.log' -mmin +10080 -print ;;
  --apply) find "$root" -maxdepth 1 -type f -name 'demo-*.log' -mmin +10080 -print -delete ;;
  *) exit 2 ;;
esac
