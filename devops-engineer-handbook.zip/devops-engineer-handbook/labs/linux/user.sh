#!/usr/bin/env bash
# Exercise on a disposable Linux VM. Preview by default.
set -euo pipefail
name=handbook-demo
if id "$name" >/dev/null 2>&1; then id "$name"; exit 0; fi
case "${1:-preview}" in
  preview) echo "Would create system account $name with no login shell" ;;
  --apply)
    shell=$(command -v nologin)
    useradd --system --no-create-home --shell "$shell" "$name"
    id "$name" ;;
  *) echo 'Usage: user.sh [--apply]' >&2; exit 2 ;;
esac
