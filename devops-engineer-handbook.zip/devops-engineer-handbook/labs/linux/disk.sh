#!/usr/bin/env bash
set -euo pipefail
if (( $# != 2 )) || [[ ! $2 =~ ^([1-9][0-9]?|100)$ ]]; then
  echo 'Usage: disk.sh PATH THRESHOLD_PERCENT (1..100)' >&2; exit 2
fi
used=$(LC_ALL=C df -P -- "$1" | awk 'NR==2 {gsub(/%/,"",$5); print $5}')
[[ "$used" =~ ^[0-9]+$ ]] || { echo 'No usage reading' >&2; exit 2; }
printf 'used_pct=%s threshold_pct=%s\n' "$used" "$2"
if (( used >= $2 )); then exit 1; fi
