#!/usr/bin/env bash
# Explicit operator action on one dedicated user service.
set -euo pipefail
case "${1:-preview}" in
  preview) systemctl --user show handbook-demo.service -p ActiveState -p Result ;;
  --apply)
    systemctl --user restart handbook-demo.service
    systemctl --user is-active handbook-demo.service ;;
  *) echo 'Usage: restart.sh [--apply]' >&2; exit 2 ;;
esac
