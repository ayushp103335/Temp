#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
umask 077
mkdir -p secrets
chmod 700 secrets
for name in admin dashboard; do
    if [[ ! -e "secrets/$name" ]]; then
        temp=$(mktemp secrets/.new.XXXXXXXX)
        python3 -c 'import secrets; print(secrets.token_urlsafe(32))' > "$temp"
        # File-backed Compose secrets retain host file modes; directory is private.
        chmod 444 "$temp"
        ln "$temp" "secrets/$name" || test -s "secrets/$name"
        rm -- "$temp"
    fi
done
