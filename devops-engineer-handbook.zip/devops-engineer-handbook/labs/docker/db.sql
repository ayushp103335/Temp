CREATE TABLE jobs (
    id integer PRIMARY KEY,
    state text NOT NULL CHECK (state IN ('done', 'queued', 'failed'))
);
INSERT INTO jobs VALUES (1, 'done'), (2, 'done'), (3, 'queued');
CREATE USER dashboard;
GRANT CONNECT ON DATABASE jobs TO dashboard;
GRANT USAGE ON SCHEMA public TO dashboard;
GRANT SELECT ON jobs TO dashboard;
