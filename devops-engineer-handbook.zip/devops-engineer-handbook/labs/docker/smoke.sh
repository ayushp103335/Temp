#!/usr/bin/env bash
set -euo pipefail
# Bound both startup wait and individual network requests.
work=$(mktemp -d)
trap 'rm -rf -- "$work"' EXIT
for attempt in {1..40}; do
    if curl -fsS --max-time 4 http://127.0.0.1:8088/api/summary > "$work/body"; then
        python3 - "$work/body" <<'PY'
import json, sys
from pathlib import Path
counts = json.loads(Path(sys.argv[1]).read_text())
assert counts == {"done": 2, "queued": 1}, counts
PY
        echo 'Verified synthetic job counts through Nginx, API and data tier'
        exit 0
    fi
    sleep 2
done
echo 'Dashboard did not become ready before lab deadline' >&2
exit 1
