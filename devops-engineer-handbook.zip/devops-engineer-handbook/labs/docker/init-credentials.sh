#!/bin/sh
set -eu
# psql's quoted variable interpolation creates a SQL literal for this lab secret.
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  --set=app_password="$(cat /run/secrets/dashboard_password)" <<'SQL'
ALTER USER dashboard PASSWORD :'app_password';
SQL
