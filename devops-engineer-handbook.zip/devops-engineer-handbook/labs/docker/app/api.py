"""Synthetic workload dashboard. The database owns the result; Redis accelerates reads."""
import json
import os
from pathlib import Path

import psycopg
import redis
from flask import Flask, Response, jsonify
from redis.exceptions import RedisError

app = Flask(__name__)
cache = redis.Redis(host=os.environ.get("CACHE_HOST", "cache"),
                    socket_timeout=1, socket_connect_timeout=1, decode_responses=True)

def read_counts():
    password = Path(os.environ["DB_PASSWORD_FILE"]).read_text().strip()
    with psycopg.connect(host=os.environ.get("DB_HOST", "db"), dbname="jobs",
                         user="dashboard", password=password, connect_timeout=3,
                         options="-c statement_timeout=3000") as connection:
        rows = connection.execute("SELECT state, count(*) FROM jobs GROUP BY state").fetchall()
    return {state: count for state, count in rows}

@app.get("/health/live")
def live():
    return jsonify(status="up")

@app.get("/api/summary")
def summary():
    key = "demo:summary:v1"
    try:
        cached = cache.get(key)
        if cached:
            return Response(cached, mimetype="application/json", headers={"X-Cache": "HIT"})
    except RedisError:
        app.logger.warning("cache_read_unavailable")
    try:
        counts = read_counts()
    except psycopg.Error:
        app.logger.warning("database_unavailable")
        return jsonify(error="inventory unavailable"), 503
    payload = json.dumps(counts, sort_keys=True)
    try:
        cache.setex(key, 15, payload)
    except RedisError:
        app.logger.warning("cache_write_unavailable")
    return Response(payload, mimetype="application/json", headers={"X-Cache": "MISS"})
