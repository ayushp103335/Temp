import unittest
from unittest.mock import patch
from redis.exceptions import ConnectionError
import psycopg
import api

class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.client = api.app.test_client()

    def test_hit_skips_database(self):
        with patch.object(api.cache, "get", return_value='{"done":2}'), patch.object(api, "read_counts") as db:
            response = self.client.get("/api/summary")
        self.assertEqual(response.json, {"done": 2})
        self.assertEqual(response.headers["X-Cache"], "HIT")
        db.assert_not_called()

    def test_cache_outage_preserves_result(self):
        with patch.object(api.cache, "get", side_effect=ConnectionError()), patch.object(api.cache, "setex", side_effect=ConnectionError()), patch.object(api, "read_counts", return_value={"queued": 1}):
            response = self.client.get("/api/summary")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, {"queued": 1})

    def test_db_failure_on_miss(self):
        with patch.object(api.cache, "get", return_value=None), patch.object(api, "read_counts", side_effect=psycopg.OperationalError()):
            response = self.client.get("/api/summary")
        self.assertEqual(response.status_code, 503)

if __name__ == "__main__":
    unittest.main()
