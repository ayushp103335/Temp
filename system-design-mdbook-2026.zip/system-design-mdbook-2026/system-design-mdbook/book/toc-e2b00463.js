// Populate the sidebar
//
// This is a script, and not included directly in the page, to control the total size of the book.
// The TOC contains an entry for each page, so if each page includes a copy of the TOC,
// the total size of the page becomes O(n**2).
class MDBookSidebarScrollbox extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = '<ol class="chapter"><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="index.html">Welcome</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Start Here — No prerequisites</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="00/01-computers.html"><strong aria-hidden="true">1.</strong> How Computers Execute Software</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="00/02-programming-data.html"><strong aria-hidden="true">2.</strong> Programming, Data Formats, and Databases From Scratch</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="00/03-first-request.html"><strong aria-hidden="true">3.</strong> Follow One Request: Browser to Database and Back</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="00/04-programming-primer.html"><strong aria-hidden="true">4.</strong> Absolute Beginner Programming Primer: Learn to Read System Code</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="00/05-terminal-git-testing.html"><strong aria-hidden="true">5.</strong> Terminals, Git, Tests, and HTTP Debugging for First-Time Developers</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Architectural Thinking</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="01/01-how-to-design.html"><strong aria-hidden="true">6.</strong> A Repeatable System Design Method</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="01/02-requirements.html"><strong aria-hidden="true">7.</strong> Requirements, Quality Attributes, and Constraints</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="01/03-capacity-math.html"><strong aria-hidden="true">8.</strong> Capacity Planning and Back-of-the-Envelope Math</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="01/04-models-diagrams.html"><strong aria-hidden="true">9.</strong> HLD, LLD, Diagrams, and Architectural Boundaries</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="01/05-decision-records.html"><strong aria-hidden="true">10.</strong> Make and Defend Architecture Decisions</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="01/06-bottleneck-workshop.html"><strong aria-hidden="true">11.</strong> Bottleneck Reasoning and Trade-Off Workshop</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Networking and the Web</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="02/01-network-layers.html"><strong aria-hidden="true">12.</strong> Networks, IP, TCP, UDP, QUIC, and OSI</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="02/02-dns-routing.html"><strong aria-hidden="true">13.</strong> DNS, Routing, Proxies, and Service Discovery</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="02/03-http-tls.html"><strong aria-hidden="true">14.</strong> HTTP, HTTPS, TLS, HTTP/2, and HTTP/3</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="02/04-load-balancers.html"><strong aria-hidden="true">15.</strong> Load Balancing, Scaling, and Health Checks</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="02/05-cdn-edge.html"><strong aria-hidden="true">16.</strong> CDNs, Edge Caching, and Global Latency</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="02/06-realtime.html"><strong aria-hidden="true">17.</strong> WebSockets, SSE, Polling, and Real-Time Communication</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Application Architecture</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="03/01-processes-concurrency.html"><strong aria-hidden="true">18.</strong> Concurrency, Threads, Async I/O, and Race Conditions</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="03/02-architecture-styles.html"><strong aria-hidden="true">19.</strong> Monolith, Modular Monolith, Microservices, and SOA</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="03/03-api-contracts.html"><strong aria-hidden="true">20.</strong> REST, GraphQL, gRPC, RPC, and API Contracts</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="03/04-gateways-discovery.html"><strong aria-hidden="true">21.</strong> API Gateways, BFFs, Service Mesh, and Configuration</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="03/05-containers-kubernetes.html"><strong aria-hidden="true">22.</strong> Containers, Kubernetes, and Deployment Topology</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="03/06-web-servers-connections.html"><strong aria-hidden="true">23.</strong> Application Servers, Connection Pools, and Backpressure Internals</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Data and Storage</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/01-relational.html"><strong aria-hidden="true">24.</strong> Relational Databases, Modeling, and SQL</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/02-indexes-plans.html"><strong aria-hidden="true">25.</strong> Indexes, B-Trees, LSM Trees, and Query Optimization</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/03-transactions.html"><strong aria-hidden="true">26.</strong> ACID, Transactions, Locks, and Isolation Levels</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/04-database-types.html"><strong aria-hidden="true">27.</strong> SQL vs NoSQL: Document, Key-Value, Graph, Wide Column, Search, and Time Series</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/05-replication.html"><strong aria-hidden="true">28.</strong> Database Replication, Failover, and Read Consistency</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/06-sharding.html"><strong aria-hidden="true">29.</strong> Partitioning, Sharding, Consistent Hashing, and Federation</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/07-consistency-cap.html"><strong aria-hidden="true">30.</strong> Consistency Models, CAP Theorem, and PACELC</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/08-backups-recovery.html"><strong aria-hidden="true">31.</strong> Backups, PITR, Disaster Recovery, and Active-Active Databases</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/09-data-evolution.html"><strong aria-hidden="true">32.</strong> Schema Evolution, CDC, ETL, Search, and Geo-Indexing</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="04/10-data-integrity-repair.html"><strong aria-hidden="true">33.</strong> Data Integrity, Reconciliation, and Multi-Store Repair</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Caching</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="05/01-cache-fundamentals.html"><strong aria-hidden="true">34.</strong> Caching Fundamentals, Hierarchies, and Eviction</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="05/02-cache-patterns.html"><strong aria-hidden="true">35.</strong> Cache-Aside, Write-Through, Write-Behind, and Refresh-Ahead</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="05/03-stampede-resilience.html"><strong aria-hidden="true">36.</strong> Cache Stampedes, Hot Keys, and Consistency</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Queues, Events and Streams</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="06/01-background-jobs.html"><strong aria-hidden="true">37.</strong> Background Jobs, Schedulers, and Async Request-Reply</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="06/02-queues-vs-streams.html"><strong aria-hidden="true">38.</strong> Task Queues, Message Brokers, Pub/Sub, and Streaming Logs</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="06/03-delivery-idempotency.html"><strong aria-hidden="true">39.</strong> At-Most-Once, At-Least-Once, Deduplication, and Idempotency</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="06/04-outbox-saga.html"><strong aria-hidden="true">40.</strong> Transactional Outbox, Inbox, Saga, and Choreography</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="06/05-backpressure-streams.html"><strong aria-hidden="true">41.</strong> Backpressure, Rate Limiting, Stream Processing, and CDC</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="06/06-kafka-partitions.html"><strong aria-hidden="true">42.</strong> Stream Log Deep Dive: Partitions, Consumer Offsets, and Rebalancing</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Distributed Systems</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="07/01-distributed-failures.html"><strong aria-hidden="true">43.</strong> Why Distributed Systems Are Hard</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="07/02-time-ordering.html"><strong aria-hidden="true">44.</strong> Clocks, Logical Time, Ordering, and Event IDs</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="07/03-consensus.html"><strong aria-hidden="true">45.</strong> Consensus, Raft, Quorums, and Leader Election</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="07/04-distributed-transactions.html"><strong aria-hidden="true">46.</strong> Two-Phase Commit, Sagas, and Cross-Service Invariants</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="07/05-crdts-multiregion.html"><strong aria-hidden="true">47.</strong> CRDTs, Multi-Region Consistency, and Conflict Resolution</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Reliability and Scale</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="08/01-availability-slos.html"><strong aria-hidden="true">48.</strong> Availability, SLOs, SLIs, SLAs, and Error Budgets</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="08/02-failover.html"><strong aria-hidden="true">49.</strong> High Availability, Active-Passive, Active-Active, and DR</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="08/03-resilience-patterns.html"><strong aria-hidden="true">50.</strong> Retries, Circuit Breakers, Bulkheads, Throttling, and Timeouts</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="08/04-cells-geodes.html"><strong aria-hidden="true">51.</strong> Cells, Deployment Stamps, Geodes, and Blast Radius</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="08/05-chaos-recovery.html"><strong aria-hidden="true">52.</strong> Fault Injection, Runbooks, Restore Drills, and Postmortems</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="08/06-regional-dr-workshop.html"><strong aria-hidden="true">53.</strong> Disaster Recovery Workshop: Single Region, Two Zones, and Two Regions</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Security and Privacy</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="09/01-security-basics.html"><strong aria-hidden="true">54.</strong> Security From First Principles: CIA, Threat Models, and Trust Boundaries</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="09/02-authn-authz.html"><strong aria-hidden="true">55.</strong> Authentication, Authorization, Sessions, OAuth, and OIDC</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="09/03-crypto-secrets.html"><strong aria-hidden="true">56.</strong> Encryption, Hashing, TLS, Secrets, and Key Management</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="09/04-api-threats.html"><strong aria-hidden="true">57.</strong> Web/API Security: OWASP, IDOR, Injection, and Abuse Protection</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="09/05-data-governance.html"><strong aria-hidden="true">58.</strong> Data Classification, Privacy, Audit, Compliance, and Retention</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Operations and Performance</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="10/01-observability.html"><strong aria-hidden="true">59.</strong> Observability: Logs, Metrics, Traces, and Instrumentation</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="10/02-slo-alerts-incidents.html"><strong aria-hidden="true">60.</strong> Monitoring, Alerting, SLO Burn, and Incident Response</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="10/03-performance-antipatterns.html"><strong aria-hidden="true">61.</strong> Performance Antipatterns and Systematic Tuning</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="10/04-ci-cd-migrations.html"><strong aria-hidden="true">62.</strong> CI/CD, Deployment Strategies, and Safe Change</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="10/05-cloud-cost.html"><strong aria-hidden="true">63.</strong> Cloud Design, Cost, Sustainability, and Build vs Buy</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="10/06-load-testing.html"><strong aria-hidden="true">64.</strong> Load Testing, Tail Latency, and Performance Modeling</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Cloud Design Pattern Catalog</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="11/01-implementation-patterns.html"><strong aria-hidden="true">65.</strong> Design &amp; Implementation Cloud Patterns: Complete Catalog</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="11/02-data-patterns.html"><strong aria-hidden="true">66.</strong> Data Management Patterns: Materialized View, Event Sourcing, Index Tables, Sharding</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="11/03-messaging-patterns.html"><strong aria-hidden="true">67.</strong> Messaging Patterns: Queue Leveling, Consumers, Claim Check, Choreography, and More</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="11/04-reliability-security-patterns.html"><strong aria-hidden="true">68.</strong> Reliability, Availability, and Security Patterns: Complete Catalog</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="11/05-pattern-selection.html"><strong aria-hidden="true">69.</strong> Choosing Patterns Without Overengineering</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">AI-Native and Emerging Architectures</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="12/01-ml-inference.html"><strong aria-hidden="true">70.</strong> Modern ML/AI Serving Architecture and Capacity</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="12/02-rag-search.html"><strong aria-hidden="true">71.</strong> RAG, Embeddings, Vector Search, Hybrid Retrieval, and Evaluation</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="12/03-agents-mcp.html"><strong aria-hidden="true">72.</strong> Agentic Systems, Tool Execution, MCP, and Safe Autonomy</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="12/04-ai-security-evaluation.html"><strong aria-hidden="true">73.</strong> AI Reliability, LLM Security, Guardrails, and Production Evals</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="12/05-emerging.html"><strong aria-hidden="true">74.</strong> Emerging Design Areas: Serverless, Edge, Wasm, eBPF, and Platform Engineering</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="12/06-voice-ai.html"><strong aria-hidden="true">75.</strong> Voice AI and Multimodal Real-Time System Design</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">End-to-End Case Studies</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/01-url-shortener.html"><strong aria-hidden="true">76.</strong> Case Study: Design a URL Shortener</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/02-document-processing.html"><strong aria-hidden="true">77.</strong> Case Study: Robust High-Volume AI Document Processing</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/03-payments.html"><strong aria-hidden="true">78.</strong> Case Study: Payments and an Immutable Ledger</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/04-chat.html"><strong aria-hidden="true">79.</strong> Case Study: Global Chat and Presence</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/05-global-saas.html"><strong aria-hidden="true">80.</strong> Case Study: Multi-Tenant Global SaaS With Regional Failover</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/06-notifications.html"><strong aria-hidden="true">81.</strong> Case Study: A Reliable Notification Platform</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/07-healthcare-rag.html"><strong aria-hidden="true">82.</strong> Case Study: EHR Search and Pre-Charting AI</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/08-analytics-streaming.html"><strong aria-hidden="true">83.</strong> Case Study: Clickstream and Real-Time Analytics</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/09-video-media.html"><strong aria-hidden="true">84.</strong> Case Study: Media Upload, Transcoding, and CDN Delivery</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/10-rate-limiter.html"><strong aria-hidden="true">85.</strong> Case Study: Distributed API Rate Limiter</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="13/11-ride-hailing.html"><strong aria-hidden="true">86.</strong> Case Study: Location Search and Ride Dispatch</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Hands-On Labs</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="14/01-lab-setup.html"><strong aria-hidden="true">87.</strong> Lab Environment and the Experimental Method</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="14/02-http-experiment.html"><strong aria-hidden="true">88.</strong> Lab 1: Build, Call, and Break an HTTP Service</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="14/03-transactions-experiment.html"><strong aria-hidden="true">89.</strong> Lab 2: Prevent Overselling With Transactions</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="14/04-sharding-experiment.html"><strong aria-hidden="true">90.</strong> Lab 3: Shard Routing and Resharding</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="14/05-outbox-experiment.html"><strong aria-hidden="true">91.</strong> Lab 4: Make Duplicate Message Delivery Harmless</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="14/06-capacity-rate-limits.html"><strong aria-hidden="true">92.</strong> Lab 5: Capacity, Queues, and Token Buckets</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="14/07-capstone.html"><strong aria-hidden="true">93.</strong> Capstone: Design, Implement, Test, and Review a Production-Style Service</a></span></li><li class="chapter-item expanded "><li class="spacer"></li></li><li class="chapter-item expanded "><li class="part-title">Review, Glossary and References</li></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="15/01-checklists-formulas.html"><strong aria-hidden="true">94.</strong> Architect&#39;s Checklists, Equations, and Decision Tables</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="15/02-roadmap-coverage.html"><strong aria-hidden="true">95.</strong> Complete roadmap.sh Topic Coverage Matrix</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="15/03-glossary.html"><strong aria-hidden="true">96.</strong> Glossary: Key Terms for Beginners and Architects</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="15/04-questions-solutions.html"><strong aria-hidden="true">97.</strong> Scenario Questions, Worked Reasoning, and Self-Assessment</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="15/05-roadmap-study-plan.html"><strong aria-hidden="true">98.</strong> Structured Study Plan, Mastery Milestones, and Architecture Review Template</a></span></li><li class="chapter-item expanded "><span class="chapter-link-wrapper"><a href="15/06-references.html"><strong aria-hidden="true">99.</strong> Authoritative References, Edition Notes, and Update Policy</a></span></li></ol>';
        // Set the current, active page, and reveal it if it's hidden
        let current_page = document.location.href.toString().split('#')[0].split('?')[0];
        if (current_page.endsWith('/')) {
            current_page += 'index.html';
        }
        const links = Array.prototype.slice.call(this.querySelectorAll('a'));
        const l = links.length;
        for (let i = 0; i < l; ++i) {
            const link = links[i];
            const href = link.getAttribute('href');
            if (href && !href.startsWith('#') && !/^(?:[a-z+]+:)?\/\//.test(href)) {
                link.href = path_to_root + href;
            }
            // The 'index' page is supposed to alias the first chapter in the book.
            // Check both with and without the '.html' suffix to be robust against pretty URLs
            if (link.href.replace(/\.html$/, '') === current_page.replace(/\.html$/, '')
                || i === 0
                && path_to_root === ''
                && current_page.endsWith('/index.html')) {
                link.classList.add('active');
                let parent = link.parentElement;
                while (parent) {
                    if (parent.tagName === 'LI' && parent.classList.contains('chapter-item')) {
                        parent.classList.add('expanded');
                    }
                    parent = parent.parentElement;
                }
            }
        }
        // Track and set sidebar scroll position
        this.addEventListener('click', e => {
            if (e.target.tagName === 'A') {
                const clientRect = e.target.getBoundingClientRect();
                const sidebarRect = this.getBoundingClientRect();
                sessionStorage.setItem('sidebar-scroll-offset', clientRect.top - sidebarRect.top);
            }
        }, { passive: true });
        const sidebarScrollOffset = sessionStorage.getItem('sidebar-scroll-offset');
        sessionStorage.removeItem('sidebar-scroll-offset');
        if (sidebarScrollOffset !== null) {
            // preserve sidebar scroll position when navigating via links within sidebar
            const activeSection = this.querySelector('.active');
            if (activeSection) {
                const clientRect = activeSection.getBoundingClientRect();
                const sidebarRect = this.getBoundingClientRect();
                const currentOffset = clientRect.top - sidebarRect.top;
                this.scrollTop += currentOffset - parseFloat(sidebarScrollOffset);
            }
        } else {
            // scroll sidebar to current active section when navigating via
            // 'next/previous chapter' buttons
            const activeSection = document.querySelector('#mdbook-sidebar .active');
            if (activeSection) {
                activeSection.scrollIntoView({ block: 'center' });
            }
        }
        // Toggle buttons
        const sidebarAnchorToggles = document.querySelectorAll('.chapter-fold-toggle');
        function toggleSection(ev) {
            ev.currentTarget.parentElement.parentElement.classList.toggle('expanded');
        }
        Array.from(sidebarAnchorToggles).forEach(el => {
            el.addEventListener('click', toggleSection);
        });
    }
}
window.customElements.define('mdbook-sidebar-scrollbox', MDBookSidebarScrollbox);


// ---------------------------------------------------------------------------
// Support for dynamically adding headers to the sidebar.

(function() {
    // This is used to detect which direction the page has scrolled since the
    // last scroll event.
    let lastKnownScrollPosition = 0;
    // This is the threshold in px from the top of the screen where it will
    // consider a header the "current" header when scrolling down.
    const defaultDownThreshold = 150;
    // Same as defaultDownThreshold, except when scrolling up.
    const defaultUpThreshold = 300;
    // The threshold is a virtual horizontal line on the screen where it
    // considers the "current" header to be above the line. The threshold is
    // modified dynamically to handle headers that are near the bottom of the
    // screen, and to slightly offset the behavior when scrolling up vs down.
    let threshold = defaultDownThreshold;
    // This is used to disable updates while scrolling. This is needed when
    // clicking the header in the sidebar, which triggers a scroll event. It
    // is somewhat finicky to detect when the scroll has finished, so this
    // uses a relatively dumb system of disabling scroll updates for a short
    // time after the click.
    let disableScroll = false;
    // Array of header elements on the page.
    let headers;
    // Array of li elements that are initially collapsed headers in the sidebar.
    // I'm not sure why eslint seems to have a false positive here.
    // eslint-disable-next-line prefer-const
    let headerToggles = [];
    // This is a debugging tool for the threshold which you can enable in the console.
    let thresholdDebug = false;

    // Updates the threshold based on the scroll position.
    function updateThreshold() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;

        // The number of pixels below the viewport, at most documentHeight.
        // This is used to push the threshold down to the bottom of the page
        // as the user scrolls towards the bottom.
        const pixelsBelow = Math.max(0, documentHeight - (scrollTop + windowHeight));
        // The number of pixels above the viewport, at least defaultDownThreshold.
        // Similar to pixelsBelow, this is used to push the threshold back towards
        // the top when reaching the top of the page.
        const pixelsAbove = Math.max(0, defaultDownThreshold - scrollTop);
        // How much the threshold should be offset once it gets close to the
        // bottom of the page.
        const bottomAdd = Math.max(0, windowHeight - pixelsBelow - defaultDownThreshold);
        let adjustedBottomAdd = bottomAdd;

        // Adjusts bottomAdd for a small document. The calculation above
        // assumes the document is at least twice the windowheight in size. If
        // it is less than that, then bottomAdd needs to be shrunk
        // proportional to the difference in size.
        if (documentHeight < windowHeight * 2) {
            const maxPixelsBelow = documentHeight - windowHeight;
            const t = 1 - pixelsBelow / Math.max(1, maxPixelsBelow);
            const clamp = Math.max(0, Math.min(1, t));
            adjustedBottomAdd *= clamp;
        }

        let scrollingDown = true;
        if (scrollTop < lastKnownScrollPosition) {
            scrollingDown = false;
        }

        if (scrollingDown) {
            // When scrolling down, move the threshold up towards the default
            // downwards threshold position. If near the bottom of the page,
            // adjustedBottomAdd will offset the threshold towards the bottom
            // of the page.
            const amountScrolledDown = scrollTop - lastKnownScrollPosition;
            const adjustedDefault = defaultDownThreshold + adjustedBottomAdd;
            threshold = Math.max(adjustedDefault, threshold - amountScrolledDown);
        } else {
            // When scrolling up, move the threshold down towards the default
            // upwards threshold position. If near the bottom of the page,
            // quickly transition the threshold back up where it normally
            // belongs.
            const amountScrolledUp = lastKnownScrollPosition - scrollTop;
            const adjustedDefault = defaultUpThreshold - pixelsAbove
                + Math.max(0, adjustedBottomAdd - defaultDownThreshold);
            threshold = Math.min(adjustedDefault, threshold + amountScrolledUp);
        }

        if (documentHeight <= windowHeight) {
            threshold = 0;
        }

        if (thresholdDebug) {
            const id = 'mdbook-threshold-debug-data';
            let data = document.getElementById(id);
            if (data === null) {
                data = document.createElement('div');
                data.id = id;
                data.style.cssText = `
                    position: fixed;
                    top: 50px;
                    right: 10px;
                    background-color: 0xeeeeee;
                    z-index: 9999;
                    pointer-events: none;
                `;
                document.body.appendChild(data);
            }
            data.innerHTML = `
                <table>
                  <tr><td>documentHeight</td><td>${documentHeight.toFixed(1)}</td></tr>
                  <tr><td>windowHeight</td><td>${windowHeight.toFixed(1)}</td></tr>
                  <tr><td>scrollTop</td><td>${scrollTop.toFixed(1)}</td></tr>
                  <tr><td>pixelsAbove</td><td>${pixelsAbove.toFixed(1)}</td></tr>
                  <tr><td>pixelsBelow</td><td>${pixelsBelow.toFixed(1)}</td></tr>
                  <tr><td>bottomAdd</td><td>${bottomAdd.toFixed(1)}</td></tr>
                  <tr><td>adjustedBottomAdd</td><td>${adjustedBottomAdd.toFixed(1)}</td></tr>
                  <tr><td>scrollingDown</td><td>${scrollingDown}</td></tr>
                  <tr><td>threshold</td><td>${threshold.toFixed(1)}</td></tr>
                </table>
            `;
            drawDebugLine();
        }

        lastKnownScrollPosition = scrollTop;
    }

    function drawDebugLine() {
        if (!document.body) {
            return;
        }
        const id = 'mdbook-threshold-debug-line';
        const existingLine = document.getElementById(id);
        if (existingLine) {
            existingLine.remove();
        }
        const line = document.createElement('div');
        line.id = id;
        line.style.cssText = `
            position: fixed;
            top: ${threshold}px;
            left: 0;
            width: 100vw;
            height: 2px;
            background-color: red;
            z-index: 9999;
            pointer-events: none;
        `;
        document.body.appendChild(line);
    }

    function mdbookEnableThresholdDebug() {
        thresholdDebug = true;
        updateThreshold();
        drawDebugLine();
    }

    window.mdbookEnableThresholdDebug = mdbookEnableThresholdDebug;

    // Updates which headers in the sidebar should be expanded. If the current
    // header is inside a collapsed group, then it, and all its parents should
    // be expanded.
    function updateHeaderExpanded(currentA) {
        // Add expanded to all header-item li ancestors.
        let current = currentA.parentElement;
        while (current) {
            if (current.tagName === 'LI' && current.classList.contains('header-item')) {
                current.classList.add('expanded');
            }
            current = current.parentElement;
        }
    }

    // Updates which header is marked as the "current" header in the sidebar.
    // This is done with a virtual Y threshold, where headers at or below
    // that line will be considered the current one.
    function updateCurrentHeader() {
        if (!headers || !headers.length) {
            return;
        }

        // Reset the classes, which will be rebuilt below.
        const els = document.getElementsByClassName('current-header');
        for (const el of els) {
            el.classList.remove('current-header');
        }
        for (const toggle of headerToggles) {
            toggle.classList.remove('expanded');
        }

        // Find the last header that is above the threshold.
        let lastHeader = null;
        for (const header of headers) {
            const rect = header.getBoundingClientRect();
            if (rect.top <= threshold) {
                lastHeader = header;
            } else {
                break;
            }
        }
        if (lastHeader === null) {
            lastHeader = headers[0];
            const rect = lastHeader.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            if (rect.top >= windowHeight) {
                return;
            }
        }

        // Get the anchor in the summary.
        const href = '#' + lastHeader.id;
        const a = [...document.querySelectorAll('.header-in-summary')]
            .find(element => element.getAttribute('href') === href);
        if (!a) {
            return;
        }

        a.classList.add('current-header');

        updateHeaderExpanded(a);
    }

    // Updates which header is "current" based on the threshold line.
    function reloadCurrentHeader() {
        if (disableScroll) {
            return;
        }
        updateThreshold();
        updateCurrentHeader();
    }


    // When clicking on a header in the sidebar, this adjusts the threshold so
    // that it is located next to the header. This is so that header becomes
    // "current".
    function headerThresholdClick(event) {
        // See disableScroll description why this is done.
        disableScroll = true;
        setTimeout(() => {
            disableScroll = false;
        }, 100);
        // requestAnimationFrame is used to delay the update of the "current"
        // header until after the scroll is done, and the header is in the new
        // position.
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                // Closest is needed because if it has child elements like <code>.
                const a = event.target.closest('a');
                const href = a.getAttribute('href');
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    threshold = targetElement.getBoundingClientRect().bottom;
                    updateCurrentHeader();
                }
            });
        });
    }

    // Takes the nodes from the given head and copies them over to the
    // destination, along with some filtering.
    function filterHeader(source, dest) {
        const clone = source.cloneNode(true);
        clone.querySelectorAll('mark').forEach(mark => {
            mark.replaceWith(...mark.childNodes);
        });
        dest.append(...clone.childNodes);
    }

    // Scans page for headers and adds them to the sidebar.
    document.addEventListener('DOMContentLoaded', function() {
        const activeSection = document.querySelector('#mdbook-sidebar .active');
        if (activeSection === null) {
            return;
        }

        const main = document.getElementsByTagName('main')[0];
        headers = Array.from(main.querySelectorAll('h2, h3, h4, h5, h6'))
            .filter(h => h.id !== '' && h.children.length && h.children[0].tagName === 'A');

        if (headers.length === 0) {
            return;
        }

        // Build a tree of headers in the sidebar.

        const stack = [];

        const firstLevel = parseInt(headers[0].tagName.charAt(1));
        for (let i = 1; i < firstLevel; i++) {
            const ol = document.createElement('ol');
            ol.classList.add('section');
            if (stack.length > 0) {
                stack[stack.length - 1].ol.appendChild(ol);
            }
            stack.push({level: i + 1, ol: ol});
        }

        // The level where it will start folding deeply nested headers.
        const foldLevel = 3;

        for (let i = 0; i < headers.length; i++) {
            const header = headers[i];
            const level = parseInt(header.tagName.charAt(1));

            const currentLevel = stack[stack.length - 1].level;
            if (level > currentLevel) {
                // Begin nesting to this level.
                for (let nextLevel = currentLevel + 1; nextLevel <= level; nextLevel++) {
                    const ol = document.createElement('ol');
                    ol.classList.add('section');
                    const last = stack[stack.length - 1];
                    const lastChild = last.ol.lastChild;
                    // Handle the case where jumping more than one nesting
                    // level, which doesn't have a list item to place this new
                    // list inside of.
                    if (lastChild) {
                        lastChild.appendChild(ol);
                    } else {
                        last.ol.appendChild(ol);
                    }
                    stack.push({level: nextLevel, ol: ol});
                }
            } else if (level < currentLevel) {
                while (stack.length > 1 && stack[stack.length - 1].level > level) {
                    stack.pop();
                }
            }

            const li = document.createElement('li');
            li.classList.add('header-item');
            li.classList.add('expanded');
            if (level < foldLevel) {
                li.classList.add('expanded');
            }
            const span = document.createElement('span');
            span.classList.add('chapter-link-wrapper');
            const a = document.createElement('a');
            span.appendChild(a);
            a.href = '#' + header.id;
            a.classList.add('header-in-summary');
            filterHeader(header.children[0], a);
            a.addEventListener('click', headerThresholdClick);
            const nextHeader = headers[i + 1];
            if (nextHeader !== undefined) {
                const nextLevel = parseInt(nextHeader.tagName.charAt(1));
                if (nextLevel > level && level >= foldLevel) {
                    const toggle = document.createElement('a');
                    toggle.classList.add('chapter-fold-toggle');
                    toggle.classList.add('header-toggle');
                    toggle.addEventListener('click', () => {
                        li.classList.toggle('expanded');
                    });
                    const toggleDiv = document.createElement('div');
                    toggleDiv.textContent = '❱';
                    toggle.appendChild(toggleDiv);
                    span.appendChild(toggle);
                    headerToggles.push(li);
                }
            }
            li.appendChild(span);

            const currentParent = stack[stack.length - 1];
            currentParent.ol.appendChild(li);
        }

        const onThisPage = document.createElement('div');
        onThisPage.classList.add('on-this-page');
        onThisPage.append(stack[0].ol);
        const activeItemSpan = activeSection.parentElement;
        activeItemSpan.after(onThisPage);
    });

    document.addEventListener('DOMContentLoaded', reloadCurrentHeader);
    document.addEventListener('scroll', reloadCurrentHeader, { passive: true });
})();

