"""Lab 6: deterministic queue simulation, one job per available worker slot."""
from heapq import heappush, heappop


def simulate(arrival_rate=100/60, service_seconds=8.0, slots=8, duration_seconds=60):
    arrivals=[i/arrival_rate for i in range(int(duration_seconds*arrival_rate))]
    busy_until=[]
    waits=[]
    completion_times=[]
    for arriving_at in arrivals:
        # Service can start immediately if a worker is idle, otherwise wait.
        if len(busy_until)<slots:
            started=arriving_at
        else:
            earliest=heappop(busy_until)
            started=max(arriving_at,earliest)
        waits.append(started-arriving_at)
        completion_times.append(started+service_seconds)
        heappush(busy_until,started+service_seconds)
    completed_by_end=sum(t<=duration_seconds for t in completion_times)
    offered_capacity=slots/service_seconds*duration_seconds
    result={'arrivals':len(arrivals),'theoretical_capacity':offered_capacity,'completed_by_end':completed_by_end,
            'max_wait_seconds':round(max(waits,default=0),2),
            'queue_was_overloaded':len(arrivals)>offered_capacity}
    print(result)
    return result


if __name__=='__main__':
    simulate()
