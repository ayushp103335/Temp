"""Lab 1: minimal HTTP service using only Python stdlib. Run: python labs/http_server.py"""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path != '/health':
            body = {'error': 'not found'}
            code = 404
        else:
            body = {'status': 'ok', 'process': 'single service'}
            code = 200
        payload = json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


if __name__ == '__main__':
    print('Open http://127.0.0.1:8080/health; press Ctrl+C to stop')
    ThreadingHTTPServer(('127.0.0.1', 8080), Handler).serve_forever()
