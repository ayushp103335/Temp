"""Lab 3: compare modulo sharding with stable virtual buckets."""
import hashlib


def stable_int(s: str) -> int:
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8], 'big')


def modulo(key: str, n: int) -> int:
    return stable_int(key) % n


def bucket_owner(key: str, physical_nodes: list[str], virtual_buckets=1024) -> str:
    bucket = stable_int(key) % virtual_buckets
    # Teaching example: stable bucket IDs plus a deterministic owner map.
    # Real systems use an explicit, versioned bucket-to-node lookup table.
    owner_index = bucket % len(physical_nodes)
    return physical_nodes[owner_index]


def migration_demo(keys=10000):
    ids = [f'patient-{i}' for i in range(keys)]
    mod_moves = sum(modulo(x, 4) != modulo(x, 5) for x in ids)
    # Demonstrate an explicit bucket map that only reassigns one fifth of buckets.
    old = {bucket: f'db-{bucket % 4}' for bucket in range(1024)}
    new = old.copy()
    for bucket in range(0, 1024, 5):
        new[bucket] = 'db-4'
    bucket_moves = sum(old[stable_int(x)%1024] != new[stable_int(x)%1024] for x in ids)
    print(f'modulo remapped {mod_moves/keys:.1%} of keys')
    print(f'versioned virtual-bucket map remapped {bucket_moves/keys:.1%} of keys')
    return mod_moves, bucket_moves


if __name__ == '__main__':
    migration_demo()
