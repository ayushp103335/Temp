"""Lab 2: two threads compete to buy the last item, using SQLite transactions."""
import sqlite3
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path


def purchase(path: str, buyer: str) -> bool:
    db = sqlite3.connect(path, timeout=5, isolation_level=None)
    try:
        db.execute('BEGIN IMMEDIATE')  # Serialize writers in SQLite.
        changed = db.execute('UPDATE stock SET count=count-1 WHERE sku=? AND count>0', ('A',)).rowcount
        if changed:
            db.execute('INSERT INTO purchases(buyer,sku) VALUES (?,?)', (buyer, 'A'))
        db.execute('COMMIT')
        return changed == 1
    except Exception:
        if db.in_transaction:
            db.execute('ROLLBACK')
        raise
    finally:
        db.close()


def run():
    with tempfile.TemporaryDirectory() as folder:
        path = str(Path(folder) / 'inventory.db')
        db = sqlite3.connect(path)
        db.executescript('''
        CREATE TABLE stock(sku TEXT PRIMARY KEY, count INTEGER NOT NULL CHECK(count>=0));
        CREATE TABLE purchases(buyer TEXT PRIMARY KEY, sku TEXT NOT NULL);
        INSERT INTO stock VALUES ('A', 1);
        ''')
        db.commit(); db.close()
        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(lambda b: purchase(path,b), ['buyer1','buyer2']))
        db = sqlite3.connect(path)
        remaining = db.execute("SELECT count FROM stock WHERE sku='A'").fetchone()[0]
        purchased = db.execute('SELECT COUNT(*) FROM purchases').fetchone()[0]
        db.close()
        print({'purchase_results': outcomes, 'remaining': remaining, 'purchases': purchased})
        assert sum(outcomes)==1 and remaining==0 and purchased==1
        return outcomes,remaining,purchased


if __name__ == '__main__':
    run()
