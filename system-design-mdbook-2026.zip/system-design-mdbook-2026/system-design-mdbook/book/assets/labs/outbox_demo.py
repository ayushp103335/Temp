"""Lab 4: transactional outbox plus idempotent consumer; no external broker needed.

This models message publication/delivery with an in-process dispatcher. In real systems
an external queue provides delivery; the publisher still needs its own retry protocol.
"""
import sqlite3


def init(db):
    db.executescript('''
        CREATE TABLE jobs(id TEXT PRIMARY KEY, state TEXT NOT NULL);
        CREATE TABLE outbox(event_id TEXT PRIMARY KEY, job_id TEXT NOT NULL, sent INTEGER DEFAULT 0);
        CREATE TABLE processed_events(consumer TEXT NOT NULL,event_id TEXT NOT NULL,
            PRIMARY KEY(consumer,event_id));
        CREATE TABLE effects(job_id TEXT PRIMARY KEY, count INTEGER NOT NULL);
    ''')


def accept_job(db, job_id):
    with db:  # One SQLite transaction commits business state and event together.
        db.execute('INSERT INTO jobs VALUES (?,?)', (job_id, 'PENDING'))
        db.execute('INSERT INTO outbox(event_id,job_id) VALUES (?,?)', ('accepted:'+job_id, job_id))


def handle_event(db, event_id, job_id):
    # A consumer may run twice; the processed marker and business effect are atomic.
    with db:
        if db.execute('INSERT OR IGNORE INTO processed_events VALUES (?,?)', ('worker',event_id)).rowcount == 0:
            return 'duplicate: no effect'
        db.execute('INSERT INTO effects(job_id,count) VALUES (?,1)', (job_id,))
        db.execute("UPDATE jobs SET state='DONE' WHERE id=?", (job_id,))
    return 'processed'


def run():
    db=sqlite3.connect(':memory:')
    init(db)
    accept_job(db, 'j-100')
    # Broker redelivery is simulated: same event handled twice.
    first=handle_event(db, 'accepted:j-100', 'j-100')
    second=handle_event(db, 'accepted:j-100', 'j-100')
    effect_count=db.execute('SELECT SUM(count) FROM effects').fetchone()[0]
    status=db.execute("SELECT state FROM jobs WHERE id='j-100'").fetchone()[0]
    print({'first':first,'second':second,'effect_count':effect_count,'status':status})
    assert effect_count==1 and status=='DONE'
    db.close()
    return first,second,effect_count,status


if __name__ == '__main__':
    run()
