"""Lab 5: deterministic token bucket using a caller-provided monotonic clock."""

class TokenBucket:
    def __init__(self, rate_per_second: float, capacity: float):
        self.rate = rate_per_second
        self.capacity = capacity
        self.tokens = capacity
        self.last_time = 0.0

    def allow(self, now: float, cost=1.0):
        if now < self.last_time:
            raise ValueError('time must be monotonic')
        self.tokens=min(self.capacity, self.tokens + (now-self.last_time)*self.rate)
        self.last_time=now
        if self.tokens>=cost:
            self.tokens-=cost
            return True
        return False


def run():
    bucket=TokenBucket(rate_per_second=2,capacity=3)
    decisions=[bucket.allow(t) for t in [0,0,0,0,0.5,1.0]]
    print({'timestamps':[0,0,0,0,0.5,1.0], 'allowed':decisions})
    assert decisions==[True,True,True,False,True,True]
    return decisions


if __name__=='__main__':
    run()
