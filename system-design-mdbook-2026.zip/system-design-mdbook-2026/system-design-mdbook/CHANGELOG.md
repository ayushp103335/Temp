# Changelog

## 2026-11-05 — First complete learning edition

- Authored a structured textbook from absolute beginner through modern distributed, cloud, AI and agent architectures.
- Mapped the original roadmap.sh system-design taxonomy in Part 15 and expanded beyond it.
- Included six original SVG architecture diagrams, nine additional technical case studies and runnable labs.
- Added a self-contained offline HTML reader with chapter search/navigation, generated from the same Markdown source.
- Verified source links and five executable lab tests in the authoring environment.

### Known limitations

- No educational book can be permanently exhaustive; revisit official links as products/standards evolve.
- Workloads and sizes are teaching assumptions; validate against real traffic/cost requirements.
- Native mdBook CLI was not available in the authoring environment, so an actual `mdbook build` could not be executed here. The `book.toml`, `src/SUMMARY.md`, and linked Markdown sources follow the documented mdBook structure. A separate offline HTML reader was rendered and checked.
- Production authentication, financial and clinical examples illustrate design principles, not a production-certified or compliant implementation.
