# Containers, Kubernetes, and Deployment Topology

A **container** packages an application process with filesystem dependencies and an execution configuration, sharing the host operating-system kernel. It is not a VM and not a security boundary that eliminates kernel risk. A **virtual machine** has its own guest OS running on virtualized hardware.

## Container basics

A container image is immutable by convention and built from layers. Supply configuration and secrets at runtime; run as a non-root user when possible; pin base images and scan for known vulnerabilities. An orchestrator places containers, restarts failures, and coordinates networking and deployment.

## Kubernetes primitives

| Object | Purpose | Typical caution |
|---|---|---|
| Pod | One or more colocated containers | Ephemeral; do not store durable state in its writable layer |
| Deployment | Rollout and replica management | Readiness/draining required |
| Service | Stable endpoint for a pod set | Not a guarantee targets are healthy without probes |
| Ingress/Gateway | HTTP entry routing | TLS/policy boundaries need review |
| ConfigMap/Secret | Runtime configuration | Secret is not equivalent to external KMS + governance |
| StatefulSet/PVC | Stable identity/persistent volumes | Still need DB backups and repair plans |
| HPA | Scale by metrics | Cannot fix DB bottleneck or slow provisioning instantly |

## Scaling behavior

CPU-based HPA can lag a workload with abrupt bursts. Queue-based autoscaling may watch queue depth or age; scale workers based on **oldest message age, observed processing time, and provider quotas**, not queue depth alone. A worker may take minutes to start or load a large model, so predictive warm capacity may be necessary.

## Deployment topology

Prefer multiple availability zones for high-availability services, subject to data-store support and network costs. Distribute replicas with topology constraints and anti-affinity so one node failure does not remove every instance. For a self-hosted stateful DB, reason about quorum, fencing, and split-brain rather than assuming Kubernetes restart will preserve consistency.

**Exercise:** Sketch a two-zone API deployment with four pods, an ingress, a managed SQL database, a queue, object storage, and network egress controls. Explain which resources are zonal, regional, or global.
