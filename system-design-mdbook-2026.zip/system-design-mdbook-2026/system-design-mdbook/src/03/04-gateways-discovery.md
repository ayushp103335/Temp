# API Gateways, BFFs, Service Mesh, and Configuration

An API gateway is an entry point for routing, coarse request validation, rate limiting, TLS, and sometimes authentication. It should not become a giant shared business-logic service. A **Backend for Frontend (BFF)** tailors payloads for a specific client category (web, mobile, partner) without forcing all clients into one overloaded response contract.

## Gateway request flow

```text
Client -> CDN/WAF -> API gateway -> auth policy -> service
                              |              -> billing service
                              -> quota/metrics
```

Gateway authentication does not remove the need for service-level authorization. An authenticated clinician may still lack access to a particular patient's record. Internal east-west traffic should be authenticated and authorized as appropriate, especially in multi-tenant environments.

## Service mesh and sidecars

A service mesh typically manages service-to-service security, traffic routing, telemetry, and resilience through infrastructure proxies or node-integrated data planes plus a control plane. A **sidecar** runs alongside the application (e.g., a proxy or log collector). Benefits include consistent mTLS and telemetry; costs include operational burden, proxy latency, and additional failures. Kubernetes itself is not synonymous with a mesh.

## Configuration and feature flags

Keep runtime configuration outside baked artifacts when appropriate. Store secrets in a secrets manager, not in source files or environment-variable dumps. Feature flags support controlled rollouts, but long-lived flags create complexity and must be removed. A config-control-plane outage should not necessarily make every running service fail; design cached last-known-good behavior where safe.

**Technical example:** During a rollout of `/v2/eligibility`, the gateway routes 5% of requests to the new version. Compare error rate, p95/p99, and payload correctness. Roll back if the error budget burn exceeds the agreed threshold. Ensure both versions accept compatible DB schema during migration.

**Design judgment:** Introduce a service mesh for demonstrated cross-service policy/telemetry needs, not merely because there are multiple HTTP APIs.
