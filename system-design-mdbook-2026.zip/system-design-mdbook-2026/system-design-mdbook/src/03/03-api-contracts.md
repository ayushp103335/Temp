# REST, GraphQL, gRPC, RPC, and API Contracts

An **API contract** specifies messages, operations, statuses, validation, versioning, and compatibility. An RPC API exposes operations (`CheckEligibility`); REST emphasizes resources and standard HTTP semantics; GraphQL lets clients describe a selection of fields; gRPC commonly uses Protocol Buffers over HTTP/2 with unary and streaming modes.

## Compare communication styles

| Style | Strong use | Challenge |
|---|---|---|
| REST/JSON | Public APIs, tools, browser integration | May over/under-fetch, schema discipline needed |
| gRPC/Protobuf | Typed internal service calls, efficient streaming | Browser/proxy integration, proto evolution |
| GraphQL | Multiple client views needing flexible reads | Authorization, query cost, N+1 resolver risk |
| Event message | Decoupled async notifications | Schema evolution, duplicate/out-of-order delivery |

## Contract example

```http
POST /v1/jobs HTTP/1.1
Idempotency-Key: 4fb4b0...
Content-Type: application/json

{"document_id":"doc-17","mode":"BATCH"}
```

Response:

```json
{"id":"job-91","status":"PENDING","status_url":"/v1/jobs/job-91"}
```

Use `202 Accepted` if processing continues asynchronously. The schema should define required properties, allowed enum values, limits, and error responses. OpenAPI is commonly used for HTTP API specifications; Protobuf `.proto` files define gRPC message contracts.

## Pagination

`OFFSET 100000 LIMIT 50` may require a database to scan/sort many rows and can produce duplicates or omissions when data changes. **Cursor/keyset pagination** uses a stable ordering, such as `(created_at, id)`, and a last-seen cursor:

```sql
SELECT id, created_at FROM jobs
WHERE tenant_id = 't1' AND (created_at, id) < ('2026-10-01', 'j500')
ORDER BY created_at DESC, id DESC
LIMIT 50;
```

Adjust query syntax and index design to the database. Sign or validate opaque cursors if clients could manipulate sensitive filters.

## Contract evolution

Prefer additive optional fields; avoid repurposing field meanings. For protobuf, never reuse removed field numbers. For JSON, consumers should not reject unknown harmless fields unless a strict protocol specifically requires that behavior. Test backward compatibility with older client versions; mobile apps may remain un-updated for months.

**Exercise:** Design `POST /claims/{id}/appeals` with an idempotency key, authentication, status codes, and a clear concurrency conflict response.
