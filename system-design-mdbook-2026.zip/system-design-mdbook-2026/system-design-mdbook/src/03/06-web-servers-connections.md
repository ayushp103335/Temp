# Application Servers, Connection Pools, and Backpressure Internals

A web server has finite resources: worker processes, threads, socket file descriptors, request buffers, event loops, memory, and downstream connection pools. Understanding these limits helps identify overload without inventing new architecture prematurely.

## Ingress and worker capacity

Suppose a FastAPI service uses four worker processes. Each has its own memory and (unless explicitly shared) its own DB connection pool. If each process can open 25 database connections, the instance can potentially open 100. Ten instances could create 1,000 connections, even when the database performs best with far fewer concurrent active queries.

**Connection pooling** reuses established DB connections and provides an admission queue. Pool size should be chosen against database capacity and query duration, not just web request count. Long-running transactions hold locks/connections and amplify wait times.

## Async event loop blocking

An async Python handler can await network I/O efficiently. But running a 10-second CPU OCR function directly on the event loop blocks other operations on that loop. Move CPU-intensive work to processes/background workers or suitable thread/process executors, accounting for GIL and runtime characteristics. A thread pool alone cannot guarantee Python CPU parallelism for all workloads.

## Limits at the boundary

Define request body size, header limits, connection idle timeouts, request deadlines, max in-flight work, and queue admission policy. Otherwise a malicious or faulty client can consume memory by opening many slow connections or uploading unbounded data. Prefer streaming large uploads to object storage under scoped authorization.

## Backpressure chain

```text
Client -> edge max concurrent -> API semaphore -> DB pool -> vendor quota
       429/503              bounded wait    bounded wait    bounded retry
```

If every layer queues independently without an overall deadline, a request can wait several seconds in each queue, creating high tail latency. Push back early and explicitly when business requirements allow. Avoid retrying automatically across every layer.

## Graceful shutdown

Stop accepting new work, drain requests, release database connections, and persist worker checkpoints. In container orchestration, process termination grace periods must exceed expected drain time or support client retry with idempotency.

**Exercise:** Calculate maximum DB connections for 12 instances × 3 worker processes × pool size 20; explain why a database configured for 200 connections will suffer if every pool eagerly fills.
