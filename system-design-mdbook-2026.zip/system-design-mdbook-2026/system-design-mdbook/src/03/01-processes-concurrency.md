# Concurrency, Threads, Async I/O, and Race Conditions

A **concurrent** system makes progress on more than one task during overlapping time intervals. A **parallel** system executes multiple tasks simultaneously on distinct CPU resources. An async event loop can multiplex many network operations on one thread without making CPU-intensive code parallel.

## Processes vs threads vs async tasks

A process has its own memory. Threads in one process share memory and therefore need synchronization for mutable shared state. An async task generally runs cooperatively on an event loop and suspends when awaiting I/O; a blocking CPU operation on the event loop can delay every other task.

```python
import asyncio

async def fetch_remote(job_id):
    await asyncio.sleep(0.5)  # Simulated remote I/O, NOT actual CPU work.
    return {"job_id": job_id}

async def main():
    results = await asyncio.gather(*(fetch_remote(str(i)) for i in range(20)))
    print(len(results))

asyncio.run(main())
```

Under ideal conditions, 20 independent 0.5-second waits overlap instead of taking 10 seconds sequentially. Actual throughput is limited by connection pools, remote service quotas, bandwidth, and CPU. `async` cannot make `time.sleep()` or a CPU-bound OCR loop non-blocking just by wrapping it.

## Race conditions

Suppose two workers read `stock=1`, both decide stock is available, and both decrement. In read-modify-write sequences without locking/atomic update, they may oversell.

```sql
UPDATE inventory
SET available = available - 1
WHERE sku = 'SKU-123' AND available >= 1;
```

Check the affected row count. In a transactional database, a conditional update can enforce the nonnegative stock invariant under competing requests when designed with proper transaction handling. This is not the same as issuing `SELECT available` followed by an unguarded `UPDATE`.

## Locks, contention, and deadlocks

A lock serializes access to a protected resource. Long lock holds reduce concurrency. Deadlock occurs when transactions wait on one another in a cycle; many databases detect and abort a victim. Establish consistent lock acquisition order and retry safe transaction failures within a budget.

## Thread pools and queueing

A bounded worker pool protects resources by limiting active tasks, but waiting requests still consume memory or queue space. Excessive thread counts cause context switching and memory overhead. For remote APIs, control **in-flight concurrency** and **requests/second** separately; a vendor may impose both.

**Exercise:** Two APIs each perform a 20 ms CPU check then call an external API for 700 ms. Explain why changing a synchronous server from one to ten worker processes differs from converting an I/O wait to async, and which metrics confirm a benefit.
