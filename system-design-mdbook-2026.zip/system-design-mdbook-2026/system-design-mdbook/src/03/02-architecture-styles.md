# Monolith, Modular Monolith, Microservices, and SOA

A **monolith** deploys a cohesive application as one unit. A **modular monolith** has explicit in-process boundaries around business domains. **Microservices** divide business capabilities into independently deployable services with independent operational lifecycles. Service-oriented architecture (SOA) is a broader family of service-based integration approaches, not an obsolete synonym for microservices.

## Start by drawing ownership

```text
Modular monolith:
  application
     |- Identity module
     |- Claims module
     |- Billing module
     |- Reporting module
     `- shared deployment and transactional database

Service split:
  Identity API + own data
  Claims API + own data
  Billing API + own data
  Event bus for cross-domain integration
```

A modular monolith can use clear APIs, separate packages, and transactional boundaries while avoiding distributed calls. A service split adds independent deployments and scaling but also latency, retries, partial failure, schema compatibility, network security, telemetry, and potentially eventual consistency.

## The distributed monolith trap

If every checkout requires synchronous calls across eight services, a small incident in any dependency can stop the whole transaction. If one team cannot deploy a service without coordinating changes in six others, the organization has inherited distributed complexity without actual independence.

## When microservices make sense

Strong indicators: different teams own separate business capabilities, traffic profiles differ radically, independent deployments matter, regulatory isolation exists, or language/runtime requirements are genuinely different. Weak indicator: "we expect growth someday."

**Technical example:** A document system's upload API has 100 RPS, but OCR processing takes 10 seconds and uses expensive accelerators. Separate the synchronous API from the asynchronous worker fleet, perhaps without splitting authentication and billing into distinct microservices. Independent **worker** scaling addresses the real bottleneck.

## Evolution safely

Use the **strangler fig** approach to move one endpoint/capability at a time from legacy into a new service. Route traffic through an edge facade, migrate data ownership carefully, run shadow reads when safe, measure parity, and keep rollback available. Avoid indefinite dual writes without reconciliation; they produce divergent sources of truth.

**Design judgment:** Service size should follow business ownership and change frequency, not fixed lines of code or an arbitrary maximum endpoint count.
