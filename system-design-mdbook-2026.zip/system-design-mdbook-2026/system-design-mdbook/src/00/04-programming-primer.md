# Absolute Beginner Programming Primer: Learn to Read System Code

System design does not require expertise in every programming language, but you must understand what happens when code reads input, calls a service, stores state, and handles failure. This chapter starts with executable Python using no third-party packages.

## A program is executed step by step

```python
patient_id = "p-42"
files_received = 3
if files_received > 0:
    print(patient_id, "has", files_received, "files")
```

`patient_id` is a name bound to a string, `files_received` to an integer. The `if` condition chooses whether to run the indented block. `print()` is a function call. Variables exist in process memory; setting them does not save the information to a durable database.

## Lists, dictionaries, and loops

```python
jobs = [
    {"id":"j-1", "status":"PENDING", "seconds":8},
    {"id":"j-2", "status":"DONE", "seconds":4},
]

pending_ids = []
for job in jobs:
    if job["status"] == "PENDING":
        pending_ids.append(job["id"])
print(pending_ids)  # ['j-1']
```

A **list** maintains an ordered collection. A **dictionary** maps keys to values. The loop processes every job once. In an in-memory list with one million items, a linear scan takes time proportional to the number of items (`O(n)`). A dictionary lookup by key is *typically* close to constant time (`O(1)` average) subject to hash-table behavior. A database index serves a related role when data is too large or must persist.

## Functions, arguments, and exceptions

```python
def estimate_slots(jobs_per_minute, seconds_per_job, utilization=0.7):
    if jobs_per_minute < 0 or seconds_per_job <= 0 or not 0 < utilization <= 1:
        raise ValueError("Invalid capacity assumptions")
    return (jobs_per_minute / 60) * seconds_per_job / utilization

try:
    print(estimate_slots(100, 8))
except ValueError as error:
    print("Bad input:", error)
```

A function accepts arguments and returns a value. An **exception** changes normal control flow; blindly catching all exceptions and returning a successful API response hides failures. In a server, errors should be classified: bad client input is usually a 4xx condition; unexpected server failures use 5xx with appropriate protected logs.

## Objects and state

```python
class Job:
    def __init__(self, job_id):
        self.job_id = job_id
        self.status = "PENDING"

    def complete(self):
        if self.status != "PENDING":
            raise ValueError("Invalid state transition")
        self.status = "DONE"
```

An **object** bundles data and behavior. Its state can change, but this code alone does not coordinate two independent Python server processes. Each process would have its own `Job` instance. Server architectures externalize shared state to a database, queue, distributed store, or other defined mechanism.

## Input validation and security

```python
def safe_page_size(raw):
    size = int(raw)
    if not 1 <= size <= 100:
        raise ValueError("page_size must be between 1 and 100")
    return size
```

Validate inputs at boundaries, but input validation alone does not authorize which user's resources may be accessed. A valid numeric `patient_id` can still identify someone else's record.

## Concurrency is not a loop

Calling a function for 100 jobs sequentially is different from running 100 tasks concurrently. Simultaneous operations can update the same database row and create races. System design therefore needs transaction isolation, idempotency, and worker ownership rules.

**Practice:** Write a program that reads five jobs, counts completed/pending status, and rejects unknown status values. Then describe why this program will lose all job state when it exits and what database schema would preserve it.
