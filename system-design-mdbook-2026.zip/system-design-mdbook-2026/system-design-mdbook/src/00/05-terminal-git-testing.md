# Terminals, Git, Tests, and HTTP Debugging for First-Time Developers

A terminal is a text interface to an operating system. It runs commands inside a **shell**. A repository is a version-controlled collection of files. A test is an executable check of expected behavior. These tools let you prove, rather than merely guess, how a system behaves.

## Files and directories

```sh
pwd                    # Show current directory
ls                     # List files (Linux/macOS)
mkdir practice         # Create directory
cd practice            # Enter directory
python --version       # Check interpreter
```

On Windows, PowerShell has similar commands and can run `python`; some Unix commands differ. Paths identify files, for example `/home/dev/project/app.py` (Unix) and `C:\\dev\\project\\app.py` (Windows). Use a local test directory; commands that delete or overwrite files deserve care.

## Git concepts

A **working tree** contains the files you're editing; `git add` stages changes, and `git commit` records a snapshot in local history. A branch is a movable line of commits. A remote such as GitHub hosts a shared repository, but Git works locally too.

```sh
git init
git status
git add app.py
git commit -m "Add initial API example"
git log --oneline
```

Do not commit secrets or regulated datasets. A deleted secret can remain in Git history even after the file is removed; rotate exposed credentials.

## Tests and assertions

```python
def normalize_status(raw):
    mapping = {"done": "DONE", "complete": "DONE", "pending": "PENDING"}
    return mapping.get(raw.strip().lower(), "UNKNOWN")

assert normalize_status(" Done ") == "DONE"
assert normalize_status("invalid") == "UNKNOWN"
```

An `assert` checks a condition during development; production business validation should not rely solely on `assert` because Python can disable assertions under optimized execution. Use explicit validation and raise controlled errors. Larger applications use test frameworks such as `unittest` or `pytest`.

## Curl and JSON inspection

```sh
curl -i http://127.0.0.1:8080/health
```

`curl -i` shows response headers and body. Inspect status code, content type, timing, and payload. A connection error means the client could not complete transport communication; `404` means an HTTP server responded and the requested resource was not found. These are fundamentally different failure classes.

## Debugging evidence

When a request fails, record the exact timestamp, request ID, request method/path, response status, latency, environment, service version, and downstream error. Avoid collecting raw passwords or patient data while troubleshooting.

**Practice:** Run the book's HTTP lab, change one response, verify with curl, write a unit test, commit the change locally, then stop the process and record how the error changes.
