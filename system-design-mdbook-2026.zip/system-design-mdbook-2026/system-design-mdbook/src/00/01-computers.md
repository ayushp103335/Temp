# How Computers Execute Software

**Learning objective:** Start from zero: know the hardware and operating-system objects that every software system depends on.

## 1. Bytes, files, memory, and processes

A **bit** is a 0 or 1; a **byte** is eight bits. Text, PDFs, program instructions, and network packets are represented by bytes. A PNG or PDF is not an image "inside the computer"; it is a sequence of bytes with a defined format. A **file** is a named sequence of bytes stored in persistent storage. A **directory** organizes files. An operating system (OS) provides APIs for opening files, allocating memory, running programs, and communicating over the network.

When you start a program, the OS creates a **process**: an executing program with its own virtual address space, open-file handles, and security identity. A process may have multiple **threads**, units of execution sharing that process's memory. A thread may be blocked waiting for disk or network I/O; multiple threads can race when they update shared memory. Processes can communicate through TCP sockets, pipes, files, or message queues.

**RAM** holds working data while code runs. **SSD/HDD storage** keeps data after power loss. Persistence requires more than writing to a programming-language variable. A server crash may lose in-memory jobs and unflushed database writes. Even `write()` succeeding does not always imply bytes are safely on durable media: durability depends on the application, OS buffering, filesystem, storage hardware, and sync policy.

## 2. Run your first HTTP-capable process

Create `hello.py`:

```python
from http.server import BaseHTTPRequestHandler, HTTPServer

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        payload = b'{"status":"ok"}'
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

HTTPServer(("127.0.0.1", 8080), Handler).serve_forever()
```

Run `python hello.py`, then open a second terminal and execute `curl -i http://127.0.0.1:8080/`. The OS is running a Python process; it owns a listening TCP socket on port 8080; `curl` creates a connection, sends an HTTP request, and reads a response. This teaching server is deliberately single-process and not production-ready.

## 3. CPU, memory, and I/O are different bottlenecks

For **CPU-bound** work (e.g., applying a CPU image filter), faster CPUs or parallel workers may help. For **I/O-bound** work (e.g., waiting for an external inference API), asynchronous I/O may let one process manage many in-flight requests. A memory leak increases RAM usage until the OS kills a process. A slow disk can make database commits slow even if CPU utilization is low.

Example: a service receives 200 PDF jobs/s, performs 0.1 CPU-seconds of parsing per job, and waits 3 seconds for remote inference. CPU demand is 20 CPU-seconds/s, *plus overhead*. Roughly 20 fully utilized CPU cores would be needed to keep up with the parsing alone; 600 average in-flight inference requests are implied by Little's Law (200/s × 3s) if the arrival rate is sustained. These are two different capacity constraints.

## 4. Basic command-line diagnostics

| Command | What you inspect | Why it matters |
|---|---|---|
| `pwd`, `ls`, `cd` | Current directory and files | Locate configuration and artifacts |
| `python --version` | Runtime version | Reproducible behavior |
| `curl -i URL` | HTTP headers and body | Test an API independently |
| `ss -ltn` (Linux) | Listening TCP ports | Diagnose service startup and exposure |
| `ps aux` (Linux) | Processes | Find runaway workers |
| `df -h`, `free -h` (Linux) | Disk and memory | Detect resource exhaustion |

**Failure lab:** Stop the Python process while `curl` is running. Observe a refused connection or truncated request. This is your first failure mode: a client cannot complete a request when the sole server process is unavailable.

**Design judgment:** Never start by assuming "add more servers" solves a performance problem. Identify whether the limit is CPU, memory, network, storage, or a downstream dependency.

**Check yourself:** Why does storing a pending job only in a Python list make it vulnerable to a process crash? What additional guarantees would a persistent database need to provide?
