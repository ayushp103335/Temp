# Follow One Request: Browser to Database and Back

![Follow One Request: Browser to Database and Back architecture diagram](../assets/request-flow.svg)

Imagine a developer types `https://api.example.com/jobs/j-001` into a browser. We will trace each technical step. The domain is an illustrative placeholder.

```text
Browser
  | DNS: what IP address serves api.example.com?
  v
Recursive DNS resolver -> (possibly cached answer)
  |
  v
TCP connection (or QUIC for HTTP/3) + encrypted TLS session
  |
  v
Edge / load balancer -> API process -> database query
                                |           |
                                +<- row ----+
  ^
  | HTTP status, headers, JSON body
Browser
```

## 1. DNS resolves names

The browser or OS looks for a cached DNS answer. If it needs a new answer, a recursive resolver can consult authoritative DNS servers. The answer may include an `A` (IPv4) or `AAAA` (IPv6) record. A DNS **TTL** controls how long a resolver may cache an answer. DNS resolution tells the client *where to connect*, not which database row it should read.

## 2. Establish communication and security

The browser uses a transport protocol (TCP for traditional HTTPS; QUIC/UDP for HTTP/3) and a TLS handshake to authenticate the server and negotiate encryption. DNS, TLS, and HTTP each solve a different problem. The connection may terminate at an edge load balancer that forwards a new request to an application server. Proxies must forward identity and provenance information safely; never blindly trust a client-supplied `X-Forwarded-For`.

## 3. The application receives a request

Example request:

```http
GET /jobs/j-001 HTTP/1.1
Host: api.example.com
Authorization: Bearer <access-token>
```

The API validates the token, checks the caller has permission to access *this specific job*, queries indexed data, and returns JSON with an appropriate status. `404` might mean missing (or intentionally hidden), `403` forbidden, `429` rate-limited, `503` unavailable. Authentication (who are you?) is not authorization (may you read this record?).

```sql
SELECT id, status, completed_at
FROM jobs
WHERE id = 'j-001' AND tenant_id = 'tenant-7';
```

Tenant scoping must be enforced server-side, not only in the UI. The app must use parameterized SQL rather than concatenating untrusted strings into a query.

## 4. The response must fit a contract

```http
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: private, no-store

{"job_id":"j-001","status":"COMPLETE"}
```

A request that returns quickly does not prove the whole system is reliable. A database node may fail a minute later. A slow dependency may create a long p99. A cache could accidentally expose one tenant's response to another. The system design process anticipates these failure modes.

**Practice:** Trace how the architecture behaves if DNS resolves correctly but the API port is closed; if TLS fails certificate validation; if the API is healthy but the DB is unavailable; or if the query returns a row from the wrong tenant.
