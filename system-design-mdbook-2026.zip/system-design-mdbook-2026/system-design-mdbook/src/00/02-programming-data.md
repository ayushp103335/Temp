# Programming, Data Formats, and Databases From Scratch

A **program** is a set of instructions. A **function** groups instructions. A **variable** names a value. An `if` statement branches; a loop repeats. You do not need mastery of one programming language to understand architecture, but you do need to read structured input, follow state changes, and reason about errors.

## 1. Read a minimal application

```python
jobs = {}  # A dictionary in this process's RAM.

def submit(job_id: str, document_path: str):
    if job_id in jobs:
        return {"error": "duplicate job"}
    jobs[job_id] = {"path": document_path, "status": "PENDING"}
    return {"job_id": job_id, "status": "PENDING"}

print(submit("j-001", "/uploads/report.pdf"))
```

`jobs` is a **dictionary**, a collection of keys and values. This example has no persistence, synchronization between processes, authentication, or protection against simultaneous writes. It illustrates application state, not a production job system.

## 2. JSON, CSV, SQL, and binary files

**JSON** expresses structured data as objects (`{}`), arrays (`[]`), strings, numbers, booleans, or null. API responses frequently use JSON:

```json
{"job_id":"j-001","status":"COMPLETE","result":{"patient_id":"P-22"}}
```

**CSV** is a simple tabular text format, often used for imports. **SQL** is a language for querying and modifying relational databases. **Protocol Buffers** and **Avro** encode structured records with schemas (and have compatibility rules). A **schema** describes permitted fields and their types. Versioned schemas prevent accidental producer/consumer breakage.

## 3. Why a database exists

A database manages structured or semi-structured data across process restarts and concurrent clients. A table stores rows and columns; a **primary key** uniquely identifies a row. A **foreign key** links rows. An **index** supports fast access, usually at a cost to writes and disk space. A **transaction** groups operations with defined failure behavior.

```sql
CREATE TABLE jobs (
    id VARCHAR(64) PRIMARY KEY,
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO jobs(id, status) VALUES ('j-001', 'PENDING');
SELECT id, status FROM jobs WHERE id = 'j-001';
```

The exact data types and default syntax can vary by database; SQL above is illustrative and works with common relational systems with small adjustments. For a practical single-file database, SQLite is excellent for learning, but a high-throughput distributed application commonly uses a networked database such as PostgreSQL.

## 4. Databases vs object storage vs caches

A PostgreSQL row might store a PDF's metadata and processing status. The actual 20 MB PDF belongs in object storage, identified by a durable URI or object key. A Redis cache might hold a frequently requested result for 30 seconds. These three stores optimize different access patterns. They do not automatically provide identical consistency or durability guarantees.

**Technical example:**

```text
jobs table:  id=j-001, object_key=uploads/j-001.pdf, status=PENDING
object store: uploads/j-001.pdf -> 20,971,520 bytes
cache:        result:j-001 -> {"status":"COMPLETE"}, TTL=30s
```

If the cache disappears, the authoritative database should still provide the result. If the object disappears, the database reference alone cannot reconstruct the PDF. Backups, retention rules, and integrity checks need to include both.

**Practice:** Explain which of the three stores should be the source of truth for job status, and why. Sketch the consequences of a process crash, a database crash, and accidental object deletion separately.
