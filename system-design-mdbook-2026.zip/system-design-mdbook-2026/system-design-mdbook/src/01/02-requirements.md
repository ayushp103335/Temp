# Requirements, Quality Attributes, and Constraints

A system can meet every feature requirement and still be unusable because it is slow, insecure, expensive, or impossible to operate. Capture different requirement classes separately.

## 1. Functional requirements (FRs)

FRs describe observable behaviors: "The API accepts a PDF and returns a job ID," "A user can see the result," "An operator can retry a failed job." Define inputs, outputs, error conditions, and permissions. Avoid ambiguous requirements such as "process documents quickly."

## 2. Non-functional requirements (NFRs)

| Attribute | Testable requirement example | Measurement |
|---|---|---|
| Latency | 95% of status requests below 200 ms | p95 server-side/request latency |
| Throughput | Sustain 100 submitted jobs/minute | Accepted jobs per minute |
| Durability | No acknowledged job lost after one-node failure | Fault-injection/data reconciliation |
| Availability | Monthly API availability >= 99.9% | Error-budget/SLO accounting |
| Security | Users only access documents of own tenant | Automated authorization tests |
| Recovery | Restore critical workflow in 30 min | RTO during DR rehearsal |
| Data loss | At most five minutes of recoverable data lost in regional disaster | RPO validated by restoration |
| Operability | Every request traceable end-to-end | Trace propagation and logs |
| Cost | Monthly operating spend <= stated budget | Cloud resource + egress + people costs |

**Critical distinction:** RTO is the maximum tolerated recovery time after disaster; RPO is the tolerated data-loss window. Neither is automatically zero merely because replicas exist.

## 3. Invariants and consistency requirements

An **invariant** must never be violated: a settled financial ledger entry must not be silently changed; an invoice cannot be paid twice due to retries; a document must not be shown to the wrong tenant. For a collaborative typing indicator, eventual consistency might be fine. For wallet transfer accounting, the debit and credit need atomic or equivalent invariant-preserving treatment.

## 4. Constraints and trade-offs

Constraints may include a fixed cloud, operating region, existing SQL database, team's skill level, compliance review, external vendor rate limits, recovery budget, or a hard deadline. Write them down; two architects can produce legitimately different designs because their constraints differ.

**Example decision:** If an external OCR API allows 50 requests/second but inbound traffic peaks at 200/second for 30 seconds, buffering can absorb the burst. Workers must be rate-limited to 50/second. If average input remains 200/second indefinitely, buffering only postpones overload; either renegotiate quota, reduce requests, or redesign.

**Exercise:** Write FRs and measurable NFRs for a "patient lab-result viewer". State which data must be correct immediately, whether stale data can be shown, and what happens when a downstream lab API is unavailable.
