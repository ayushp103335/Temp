# Bottleneck Reasoning and Trade-Off Workshop

An architect should ask **"What resource or invariant limits us?"** before recommending a technology. We will deliberately examine five situations where the obvious fix is often wrong.

## Scenario 1: API p99 rises after adding servers

Symptoms: traffic is 500 RPS, API replicas increase from 4 to 8, CPU per replica falls, but p99 grows from 350 ms to 900 ms. DB connection count jumps from 80 to 160; DB wait time increases. **Reasoning:** the new replicas doubled pooled DB connections and induced contention; horizontal app scale overloaded a shared dependency. **Possible fix:** bound total DB concurrency, improve queries/transactions, introduce pooling/proxying, and re-measure. Do not assume more replicas always help.

## Scenario 2: Massive Kafka lag but low worker CPU

Symptoms: lag grows, consumers idle, only one partition carries the hot key while 30 partitions are lightly loaded. **Reasoning:** partition-key skew rather than insufficient CPU. **Possible fix:** reassess partitioning and ordering boundary, use key bucketing where correctness permits, or isolate hot tenant. Adding consumers beyond active partitions alone is ineffective.

## Scenario 3: Read latency low but users see old data

Symptoms: primary commits a profile update; load balancer sends subsequent GET to lagging read replica. **Reasoning:** latency objective is met but read-your-writes consistency is violated. **Possible fix:** session read routing to primary, replication-position token, bounded staleness, or synchronous commit as justified. A faster cache makes stale responses faster, not correct.

## Scenario 4: Expensive LLM inference despite response caching

Symptoms: same user queries have different wording, so prompt cache hit rate is poor; the model receives 100 KB of context on every request. **Reasoning:** excessive retrieval context and prompt duplication, not just insufficient cache. **Possible fix:** hybrid retrieval, reranking, query normalization, relevant chunk limits, and evaluation. Verify that reducing context does not drop critical evidence.

## Scenario 5: Strong active-active availability but double billing

Symptoms: Regions A and B independently accept charges during a partition, then reconcile by latest timestamp. **Reasoning:** conflict resolution violates financial invariants. **Possible fix:** choose a write authority, transaction serialization/quorum semantics, or partition by account with fenced ownership; accept explicit latency/availability trade-offs.

## Standard design interview response

State observed symptoms, hypothesize likely bottlenecks, name metrics needed to confirm, propose lowest-complexity intervention, list its new failure modes, and describe a verification experiment.

**Exercise:** Write an ADR for each scenario and include one measurable condition that would make you reverse your decision.
