# Capacity Planning and Back-of-the-Envelope Math

System design estimates are not forecasts with perfect precision. They are a way to detect impossible architectures and identify measurements you must collect.

## Core conversions

- Requests per second (RPS) = requests per day / 86,400, **only for an even distribution**.
- Total traffic = count × bytes each; convert between decimal GB (`10^9` bytes) and binary GiB (`2^30` bytes) deliberately.
- Storage = daily ingest × retention days × replication/erasure overhead × index/metadata factor.
- CPU demand (CPU-seconds/s) = arrival rate × CPU seconds/request.
- Little's Law for stable systems: average in-flight work `L = lambda × W`, where `lambda` is completion/arrival rate and `W` is average time in the system.
- Utilization = offered work / service capacity; queue delay grows dramatically near saturation. Estimates at 100% utilization are operationally fragile.

## Worked document-processing estimate

Assume 100 documents/min, mean document size 8 MB decimal, and retention 90 days.

```text
Average arrival: 100 / 60 = 1.667 jobs/s
Daily documents: 100 * 60 * 24 = 144,000
Daily original bytes: 144,000 * 8 MB = 1.152 TB
90-day originals: ~103.68 TB (before replicas, versions, output, indexes)
```

This is intentionally an unusually large *continuous* ingest rate. Verify whether traffic occurs only during business hours. If jobs take an average of eight seconds of **active service time**, throughput capacity of eight independent worker slots is `8/8 = 1 job/s`, only 60 jobs/min. To keep steady-state utilization near 70%, required slots ≈ `(1.667 × 8) / .7 = 19.05`, so start planning at 20 and validate burst tolerance.

If the 8 seconds is mostly *asynchronous waiting* rather than exclusive worker occupancy, the concurrency/worker model changes; measure occupied worker slots, CPU demand, and external API concurrency separately. **Do not treat an average as a p99.**

## Capacity for peaks

A 10× peak-to-average ratio means an average of 100 RPS can imply 1,000 RPS peak. A caching strategy that handles 90% of reads still leaves 100 database queries/s at peak 1,000 RPS, assuming uniform hit ratio. Hot keys can defeat uniform assumptions. A queue's accumulated depth satisfies roughly `backlog increase = (incoming - processing) × duration` whenever incoming exceeds capacity.

## Network and storage units

An 8 MB payload over a theoretical 100 Mbps link takes about `8 MB × 8 / 100 Mbps = 0.64 s` for payload bits alone, ignoring handshakes, congestion, and protocol overhead. A write-heavy database can hit IOPS or fsync limits long before storage capacity fills. Ask vendors for actual sustained and burst performance characteristics rather than extrapolating from capacity in GB.

**Design judgment:** Provide ranges plus assumptions. Say "20 worker slots at 70% planned utilization under eight-second occupancy" rather than "we need 20 servers". Workers, containers, CPU cores, and VMs are not interchangeable units.

**Exercise:** A service accepts 120 requests/s; each triggers three downstream calls averaging 120 ms, 80 ms, and 60 ms in parallel. Estimate average downstream call rate and in-flight downstream calls; describe why p99 may be much worse than average.
