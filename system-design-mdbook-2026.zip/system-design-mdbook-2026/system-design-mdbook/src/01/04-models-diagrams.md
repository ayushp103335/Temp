# HLD, LLD, Diagrams, and Architectural Boundaries

**High-level design (HLD)** expresses major components and their interactions. **Low-level design (LLD)** expresses internal modules, classes, algorithms, state transitions, and precise interfaces. Neither replaces the other.

## Four useful diagrams

1. **System context:** people, external platforms, and trust boundaries. Example: user -> document system -> external OCR vendor.
2. **Containers/components:** API, DB, object storage, queue, worker pools, notification service; show ownership and authentication.
3. **Sequence diagram:** exact ordering of calls and durable state transitions in a single workflow.
4. **Deployment diagram:** zones, regions, network isolation, replicas, ingress, and data replication.

A diagram should label **synchronous vs asynchronous calls**, protocols, data ownership, failure boundaries, and trust boundaries. Ambiguous arrows make troubleshooting impossible.

## Example sequence for job submission

```text
Client        API           Job DB        Outbox Publisher      Queue
 | POST /jobs  |              |                  |              |
 |----------->| TX begin     |                  |              |
 |            | INSERT job   |                  |              |
 |            | INSERT outbox|                  |              |
 |            | COMMIT ------>|                  |              |
 |<--202+ID---|              |                  |              |
 |            |              |     polls row    |              |
 |            |              |<-----------------|              |
 |            |              |----------------->| publish ---->|
 |            |              |                  |<--ack---------|
 |            |              |<----mark sent----|              |
```

The diagram reveals an important invariant: returning `202 Accepted` should mean a recoverable job is persisted. Publisher crashes can leave the outbox row unsent, but a new publisher can retry it. A crash after queue publication but before marking "sent" can duplicate the event; the consumer must be idempotent.

## Data and state diagrams

Represent a job using a state machine:

```text
PENDING -> RUNNING -> SUCCEEDED
   |          |           ^
   |          +-> RETRYING-+
   +----------------> FAILED (terminal after retry budget)
```

Define valid transitions (`RUNNING -> SUCCEEDED`), terminal states, leases, and race handling. When two workers attempt the same job, use a conditional DB update (`WHERE status = 'PENDING'`) or another ownership mechanism rather than assuming the queue prevents all duplicates.

**LLD example:** `JobRepository.claim(job_id, lease_until)` must return an explicit success/failure, perform an atomic compare-and-set, and be safe under concurrent calls. This is more meaningful than a diagram filled with design-pattern names.

**Exercise:** Draw context, component, and sequence diagrams for a file-upload system using object-storage presigned URLs. Show which credential is exposed to the browser and how long it remains valid.
