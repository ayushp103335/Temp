# A Repeatable System Design Method

System design is the practice of choosing components, interfaces, data, operations, and controls so a system meets **stated requirements under realistic failures and growth**. A design is not a list of products or a pretty diagram. It is a collection of justified decisions.

## The seven-pass method

1. **Discover:** Identify actors, business operations, data classification, failure tolerance, and what is explicitly out of scope.
2. **Quantify:** Estimate average and peak arrival rate, stored data, request size, read/write mix, concurrency, latency, retention, regional distribution, and budget.
3. **Define contracts:** Specify APIs, event schemas, invariants, authentication, ownership, consistency requirements, and error semantics.
4. **Draft the simplest viable architecture:** Show request path, data path, sources of truth, and boundaries. Prefer a modular monolith until requirements justify distribution.
5. **Identify bottlenecks and failure modes:** Single points of failure, slow dependencies, hot keys, duplicate messages, storage growth, security gaps.
6. **Evolve deliberately:** Add load balancing, replicas, caching, queues, shards, or regions only to address a measured or well-justified constraint.
7. **Validate:** Load-test, inject faults, verify recovery, observe p95/p99, check data integrity, budget cost, and record trade-offs in architecture decision records (ADRs).

## Guided example: asynchronous PDF processing

Requirements (assumed): upload 5–20 MB PDFs, 100 submissions/minute sustained, occasional burst to 300/minute, normal result within 90 seconds, authenticated access, no silent loss of accepted jobs. A batch backlog of several minutes may be acceptable during a short burst. The process needs deduplication, job status, and a mechanism for retries.

**API contracts:** `POST /jobs` with an idempotency key, `GET /jobs/{id}`, and `GET /jobs/{id}/result`. Durable job acceptance means returning a success only after the server has committed a recoverable record. A simplistic "write DB, then send message" can crash between the operations; use an outbox or reconciliation process when this matters.

**Initial architecture:** one API service, relational job DB, object storage for PDFs, durable queue, worker pool, result store, and polling. For higher arrival rates, scale API replicas independently from workers. For distributed reliability, define retries, dead-letter policy, duplicate suppression, and storage retention.

**Data integrity invariants:** one `job_id` must correspond to exactly one logical document processing request; clients must never see data belonging to another tenant; retries may repeat execution, but must not produce duplicate externally visible effects.

**Failure table:**

| Failure | Expected system behavior | Required mechanism |
|---|---|---|
| API process crashes before acceptance | Client may retry safely | Client idempotency key |
| DB record committed but publish fails | Job eventually enqueued | Transactional outbox/reconciler |
| Worker crashes after remote AI call | Job redelivered; side effects safe | Ack after commit, idempotent worker |
| AI rate limit | Backoff, bounded attempts | Retry budget and rate limiting |
| Region offline | Defined RTO/RPO and degraded UX | DR plan, replicated data, tested restoration |

**Architecture-review questions:** How do we know a job isn't lost? How do we know a retry hasn't double charged the customer? What indicates the queue is unhealthy? Can an operator replay one failed job safely? Where do PDFs live? What is the maximum acceptable age of a pending job?

## Deliverables of a design review

Produce a requirements sheet; context and component diagrams; sequence diagram for the critical path; data model; capacity table; SLOs; risk and failure table; budget; deployment and rollback plan; test evidence; and decision log. Good architecture is reviewable and can be revised when evidence changes.

**Design judgment:** Do not default to microservices. Separation improves independent scaling and ownership but adds network, authentication, deployment, consistency, and observability complexity.
