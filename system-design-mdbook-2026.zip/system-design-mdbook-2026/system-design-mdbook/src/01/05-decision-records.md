# Make and Defend Architecture Decisions

A design opinion should be conditional: **under these constraints, choose X because Y, accepting cost Z, and reconsider when W changes**. Architectural decisions are hypotheses that must be validated.

## Architecture Decision Record (ADR)

```markdown
# ADR-007: Use a task queue for document extraction
Status: Accepted
Date: 2026-11-05
Context: 100 jobs/min; inference takes 3–15 seconds; API p95 goal 300 ms.
Decision: Persist job plus outbox record, publish to RabbitMQ,
          process via a bounded worker pool.
Alternatives: Direct synchronous calls; database polling only; streaming log.
Consequences: More operations and duplicate-message handling; workers scale
              separately; queue age becomes a critical metric.
Validation: Kill workers and publisher; verify no accepted jobs disappear.
Revisit when: Sustained load, replay requirements, or fan-out changes substantially.
```

## Compare solutions on multiple axes

| Choice | Helps with | Adds risk/cost | Do not use when |
|---|---|---|---|
| Read replica | Read scaling, isolation | Replica lag, failover complexity | Small read workload; strong read-after-write required without routing |
| Redis cache | Reduce repeat reads | Staleness, invalidation, hot keys | Queries are already fast/infrequent |
| Kafka-style event log | Replay, independent consumer groups | Partition/retention/ops complexity | Only a small task queue needed |
| Microservices | Independent ownership/deploy | Network and distributed data complexity | Small cohesive team, tightly coupled transactions |
| Active-active regions | Regional survivability, lower local latency | Conflict management, cost | Single-region SLA is enough |

## Review using a failure and cost lens

Ask: What fails first under 10× traffic? What happens if a dependency is down for ten minutes? Which fields contain sensitive data? Can the design be deployed and rolled back safely? How much standby capacity is paid for? What happens when someone retries an operation? How will an on-call engineer know the customer-visible symptom?

**Design exercise:** Decide whether to add a Redis cache for `GET /jobs/{id}` at only 25 RPS when the PostgreSQL query takes 3 ms p95 and is indexed. Your recommendation should include expected benefit, additional failure modes, cost, and the traffic level that would change your opinion.
