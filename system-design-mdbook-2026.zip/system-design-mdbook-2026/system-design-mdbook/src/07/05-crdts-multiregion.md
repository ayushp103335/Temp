# CRDTs, Multi-Region Consistency, and Conflict Resolution

Multi-region active-active writing becomes simpler when data can be **merged without violating invariants**. A Conflict-Free Replicated Data Type (CRDT) is designed so concurrent operations can converge under specified delivery/order assumptions without centralized coordination.

## Mergeable vs non-mergeable operations

A grow-only counter can merge independent increments; an observed-remove set can track additions/removals with causality metadata. But "deduct $100 from an account with only $100" cannot be resolved by naïvely merging two concurrent withdrawals without potentially overdrawing. CRDTs do not eliminate every business invariant or solve arbitrary distributed transactions.

## Per-key ownership

An alternative is route each account or patient record to an authoritative home region. Reads can be regional with documented lag, but writes go to the owner. This reduces conflict surface at the expense of cross-region write latency and failover complexity. Ownership changes require fencing and a careful migration protocol.

## Geo-partitioned services

For a system with European and Asian user data, legal residency and access requirements may necessitate keeping specific records in designated regions. Geo-routing, audit logs, key-management residency, analytics replication, and backup geography must be reviewed separately. Data "residency" is not solved by CDN geography alone.

## Conflict resolution policy

Specify conflict rules by field: concurrent tags may be merged; address edits may require user review; a financial ledger may use serialization; a profile bio may use last-write-wins with visible history. Record conflict metadata for auditing and repair.

**Design judgment:** Active-active is often best implemented as regional read-serving plus carefully partitioned write ownership, not unrestricted concurrent writes to every business field.
