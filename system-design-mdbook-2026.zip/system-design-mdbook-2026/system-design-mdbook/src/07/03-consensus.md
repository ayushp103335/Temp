# Consensus, Raft, Quorums, and Leader Election

**Consensus** allows distributed nodes to agree on a sequence or decision despite failures under a specified model. It is used for leader election, metadata, state machines, and coordination. A majority quorum helps prevent conflicting committed decisions when groups overlap.

## Simplified Raft intuition

Raft uses terms (epochs), leader elections, replicated logs, and commitment rules. A leader accepts commands and replicates log entries; under its protocol, a committed entry is preserved across legitimate leadership changes. A follower may have uncommitted entries that are later replaced. The actual safety proof depends on election restrictions and commit rules, not merely "two of three nodes replied."

```text
3 voters: Node A, Node B, Node C
Quorum = 2
A and B connected: may form a quorum
C isolated: cannot independently commit conflicting quorum decisions
```

With five voters, quorum is three. More voters can increase failure tolerance but add coordination cost; do not add voters arbitrarily. A two-node quorum configuration often has poor availability under a single-node failure; an odd voter count is a common practical choice, though witness designs exist.

## Leader election and fencing

An old leader that loses contact may continue acting unless consumers reject stale epochs/terms. A **fencing token** is a monotonically increasing generation number attached to operations. A storage layer can reject writes from earlier generations to prevent stale leader effects.

## Consensus is not replication alone

Two databases copying changes bidirectionally do not necessarily agree on a single transaction order. Consensus coordinates authoritative order/leadership; replication copies data. Distinguish logical replication, synchronous replicas, quorum systems, and full replicated state machines.

**Technical application:** A scheduled billing close should have one active coordinator per accounting period. A distributed lease without fencing may be insufficient if a paused coordinator resumes after expiry and acts on outdated ownership.

**Design judgment:** Prefer a proven coordination service or database mechanism. Implementing a consensus protocol from scratch is an educational exercise, not a reasonable default for production.
