# Two-Phase Commit, Sagas, and Cross-Service Invariants

A local ACID transaction protects operations in one transactional system. A cross-service workflow can span independently committed databases and third-party APIs, making atomicity much harder.

## Two-phase commit (2PC)

A coordinator asks participants to **prepare**, then directs them to **commit** or abort. It can provide atomic commit across cooperating participants, but introduces blocking/recovery complexity and reduces availability when the coordinator or participants are unavailable. Many modern cloud and service APIs do not support generalized 2PC.

## Saga alternative

An order service reserves inventory; a payment service authorizes funds; a shipping service creates delivery. Each performs a local transaction. On failure, orchestrate compensations: release reservation, void authorization, or schedule refund. Compensations can be delayed, fail, or be irreversible; design a durable saga state machine and human escalation path.

## Invariants vs consistency of projections

A customer's money balance must preserve ledger invariants. A reporting dashboard may lag the ledger by a minute. Do not weaken authoritative transaction correctness merely because a projection is eventually consistent. Separate command model (write authority) from reporting/search/read models when useful.

## Distributed lock caveats

Distributed locks often have leases, which expire. A suspended worker can resume after its lease has expired and still try to perform an operation. Use fencing tokens in the protected resource or transactional conditional updates; a lock alone may not enforce correctness. With external side effects, consider resource-specific idempotency and approval workflows.

**Exercise:** Design a cross-service workflow for booking a scarce appointment slot, authorizing payment, and sending a confirmation. Specify reservation expiry, duplicate handling, unknown outcomes, compensations, and user-visible states.
