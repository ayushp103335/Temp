# Why Distributed Systems Are Hard

A distributed system has independent processes communicating over networks. Unlike one program sharing memory, components may fail separately, messages may be lost/delayed/duplicated/reordered, clocks disagree, and one node cannot instantly know whether another is dead or merely slow.

## Partial failure

An API calls a billing service, which writes an invoice, but the response packet disappears. From the API's perspective the operation is *unknown*, not necessarily failed. Retrying can duplicate the invoice unless the write is idempotent. This is the central distinction between local function calls and remote calls: local failures are relatively observable; remote outcomes can be ambiguous.

## Eight useful fallacies to challenge

The network is not always reliable; latency is not zero; bandwidth is not infinite; the network is not always secure; topology changes; there is not necessarily one administrator; transport cost is not zero; and networks are not homogeneous. These are widely taught distributed-computing fallacies and useful checklist prompts, not a formal proof of an architecture.

## Latency fan-out

If a request fans out to 20 independent services and waits for all of them, its latency is the maximum of those responses. Even if each service independently meets a 99th-percentile latency threshold, the probability that *all* 20 are below that threshold is `0.99^20 ≈ 81.8%` under the strong assumption of independence. Correlated slowdowns can make the situation worse. Bound fan-out, prefer bulk APIs or parallel calls with timeouts, and return partial results when product rules permit.

## Failure detectors and timeouts

A timeout cannot reliably distinguish a crashed server from a delayed packet. Heartbeats/leases provide practical approximations subject to timing assumptions. Avoid assuming one missed heartbeat proves a process is dead. A failover controller must prevent two leaders from acting simultaneously despite delayed failure detection.

**Exercise:** At time T, a client sends a fund-transfer request. It times out. List every possible state (not received; received/not committed; committed/response lost; processing) and a safe client/server protocol for recovery.
