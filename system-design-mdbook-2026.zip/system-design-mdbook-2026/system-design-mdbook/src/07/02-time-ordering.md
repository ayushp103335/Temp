# Clocks, Logical Time, Ordering, and Event IDs

Distributed computers have independent wall clocks that can drift or jump when synchronized. A server timestamp is not a guaranteed global ordering mechanism. For audit data, capture time, sequence/order identifiers, and source context separately.

## Physical vs logical time

Physical clocks approximate real time using synchronization, but may drift. A **Lamport logical clock** establishes: if event A causally happens before B, then clock(A) < clock(B). The converse is not guaranteed. **Vector clocks** can detect some concurrent events but grow with participant count and operational complexity.

## Example: out-of-order profile updates

Region A sees `email=v2` at 12:00:00.100; Region B writes `email=v3` at 12:00:00.050 on a clock 200 ms behind. Last-write-wins based on wall-clock timestamp could overwrite v3 with v2. For authoritative user contact changes, use version/ETag compare-and-set, one write authority, or an explicit conflict-resolution workflow.

## Event IDs and monotonic sequences

A monotonically increasing database sequence offers straightforward local order but may be a centralized bottleneck for globally distributed ID generation. Snowflake-like IDs encode time plus worker/sequence fields, allowing roughly sortable unique IDs with known clock-skew and worker-ID risks. UUIDv4 provides broad uniqueness without global ordering; time-ordered UUID variants improve index locality but do not magically provide cross-region total order.

**Design judgment:** Define which order matters: per account, per document, per conversation, or global. Most business systems need per-entity order and stable idempotency keys, not an expensive total order across all events.
