# Cloud Design, Cost, Sustainability, and Build vs Buy

Cloud systems are constrained by **cost** as well as latency and availability. The AWS Well-Architected Framework identifies six lenses: operational excellence, security, reliability, performance efficiency, cost optimization, and sustainability. Apply them as trade-off questions, not a score that can be maximized independently.

## Cost model

```text
monthly cost ≈ compute runtime + DB capacity/storage + object storage
             + data transfer/egress + requests + observability
             + external APIs/model tokens + backup + operations
```

A 100 TB object archive may cost relatively little compared with moving 100 TB/month out of a cloud region or performing expensive inference on every object. Estimate network egress and cross-region replication separately. "Serverless" may reduce idle cost but can incur per-invocation and duration expenses, cold starts, and limits.

## Autoscaling economics

If eight workers handle demand for 2 hours/day, paying for them continuously wastes potential savings. Yet scaling to zero may violate 100 ms latency targets or model warmup requirements. Compare baseline warm pool plus autoscale versus all-on and consider job deadlines.

## Build vs buy

A managed queue/database shifts certain operations (patching, hardware failover) to the provider but does not outsource application correctness, schema design, access controls, or disaster recovery decisions. Self-hosting can reduce unit spend at large scale but adds staffing, security, and on-call responsibilities.

## Sustainable design

Reduce unnecessary computation and duplicated data, right-size capacity, choose efficient batch processing, optimize retention and data transfer, and consider location/energy profiles where practical. Sustainability goals interact with availability and latency—for example, spare-region capacity consumes resources but may be essential for agreed recovery requirements.

**Exercise:** Compare a deployment with always-on 20 worker slots against an 8-slot warm pool plus burst autoscaling. State the unknowns required for a credible cost and SLO comparison.
