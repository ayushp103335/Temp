# CI/CD, Deployment Strategies, and Safe Change

**Continuous integration** tests and validates each code change. **Continuous delivery/deployment** automates artifact promotion and, when approved, releases. A robust pipeline tests code, dependencies, infrastructure definitions, schemas, and operational safety—not only whether compilation succeeds.

## Release strategies

- **Rolling:** replace instances gradually; requires compatibility during overlap.
- **Blue-green:** maintain old and new environments and switch traffic; fast rollback for app code, but irreversible DB changes remain risky.
- **Canary:** send a controlled percentage of traffic to new version; compare SLIs and correctness before ramping.
- **Feature flag:** control behavior independently of deployment, with lifecycle governance.
- **Shadow traffic:** mirror read requests for comparison without making visible side effects; privacy and vendor cost apply.

## Database migrations

Use expand/backfill/contract, backwards-compatible schemas, idempotent migration scripts, and planned rollback. Never assume rolling back binaries safely reverts a destructive database migration. Handle old and new event consumers simultaneously during phased deployments.

## Supply-chain and infrastructure hygiene

Pin dependencies; generate/verify software bill of materials (SBOM) and attestations where required; scan images; use least-privilege CI credentials; protect artifact signing and deployment promotion. Infrastructure-as-Code (Terraform or equivalent) supports reproducible infrastructure but still needs drift detection, code review, and secrets discipline.

## Test pyramid for architecture

Unit tests prove local logic; integration tests validate DB/broker behavior; contract tests prove producer/consumer compatibility; load tests exercise bottlenecks; fault-injection tests verify failure recovery; security tests verify trust boundaries. None replace production telemetry.

**Design judgment:** Safe change velocity is a reliability feature. A complicated deployment that cannot be reliably rolled back is an architectural liability even if normal throughput is excellent.
