# Observability: Logs, Metrics, Traces, and Instrumentation

**Monitoring** checks known signals; **observability** is the ability to infer internal state from exposed signals. The common pillars are structured logs, numeric metrics, and distributed traces. OpenTelemetry supplies vendor-neutral instrumentation conventions, SDKs, and collectors; it is not itself a metric database or visualization UI.

## Structured logs

```json
{
  "timestamp":"2026-11-05T11:12:13Z",
  "level":"ERROR",
  "service":"ocr-worker",
  "request_id":"req-8",
  "job_id":"j-9",
  "attempt":2,
  "error_code":"MODEL_RATE_LIMIT"
}
```

Use stable fields, structured severity, correlation IDs, and redaction. Avoid logging PHI, tokens, full prompts, or arbitrary user-generated text in unprotected telemetry.

## Four golden signals and RED/USE

**Latency, traffic, errors, saturation** are common user-facing signals. **RED**: rate, errors, duration for services. **USE**: utilization, saturation, errors for resources. High CPU without customer impact may not warrant paging; high job-age despite low CPU can indicate queue or vendor bottlenecks.

## Distributed tracing

A trace joins spans along one request: `API -> job DB -> outbox publisher -> broker -> worker -> inference API`. For asynchronous messages, propagate trace context with appropriate link semantics; some workflows span multiple traces. Sampling controls cost, but rare errors may require tail-based or targeted retention.

## Cardinality warning

Metrics labels such as `job_id` or `user_id` can create millions of time series, overwhelming storage. Put high-cardinality IDs in logs/traces and use metrics dimensions like `service`, `region`, `status`, and bounded error type.

**Exercise:** Define the minimum signals that distinguish (a) database slow query, (b) queue backlog, (c) model-provider rate limit, and (d) cache stampede.
