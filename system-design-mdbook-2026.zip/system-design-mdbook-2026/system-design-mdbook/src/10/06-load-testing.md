# Load Testing, Tail Latency, and Performance Modeling

Load tests verify how a system behaves across expected, peak, and failure workloads. A single successful benchmark with 10 requests is not evidence of scalability.

## Test types

- **Baseline:** latency and resource use at normal load.
- **Load:** sustained expected workload with production-like data shape.
- **Stress:** increase until an SLO breaks, then explain the failure mode.
- **Spike:** sudden burst and recovery, including autoscaling lag.
- **Soak:** multi-hour/daily load to reveal memory leaks, disk growth, stale connections.
- **Failure under load:** kill nodes, isolate DB, throttle vendors during ongoing requests.

## Open-loop vs closed-loop traffic

A closed-loop benchmark sends the next request only after one completes. When the system slows, the generator may unintentionally send fewer requests, hiding overload (**coordinated omission**). Open-loop tests attempt arrivals according to a target schedule independent of completions; they need sufficient generator resources and accurate dropped/requested accounting. Understand the selected load tool's model and sampling methods.

## Percentiles and errors

Record p50, p95, p99, p99.9, request failures/timeouts, arrival and completion throughput, queue wait, database waits, and resource saturation. p99 based on a tiny sample is unstable; run enough representative requests. Validate data correctness after the test, not only response statuses.

## Test environment realism

A 5 GB DB with uniform data will not reproduce a production database with 10 TB, tenant skew, and large cold indexes. Cache warm-up can make runs incomparable. Keep workload, dataset, feature flags, node types, and deployment version recorded so results can be reproduced.

## Scaling experiment

1. Run a controlled 100 RPS baseline.
2. Double API replicas without changing DB; compare throughput and DB waits.
3. Hold API count fixed, optimize worst SQL query; compare again.
4. Disable cache under steady traffic; measure DB overload and fallback behavior.
5. Inject broker pause; measure oldest-message age and recovery drain time.

**Design judgment:** Scale only the tier that constrains the business SLO. A benchmark result must include context and correctness evidence or it is not an architecture justification.
