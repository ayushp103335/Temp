# Monitoring, Alerting, SLO Burn, and Incident Response

Telemetry has value only when it changes decisions. Design dashboards and alerts around symptoms users notice, then add component metrics for diagnosis.

## Monitoring categories (roadmap checklist)

- **Health:** are processes healthy and dependencies reachable?
- **Availability:** are legitimate requests/jobs succeeding within the definition?
- **Performance:** p50/p95/p99 latency, throughput, queue wait, saturation.
- **Security:** failed authorizations, anomalous access, integrity and policy events.
- **Usage:** active users, feature adoption, per-tenant quotas, cost drivers.
- **Instrumentation:** standardized events, traces, labels, propagation.
- **Visualization & alerts:** actionable dashboards, paging, escalation and silencing policy.

## p95 and p99

A p99 of 1,500 ms means 99% of the measured population completed at or below that latency, under the percentile computation and sampling approach used. It says nothing about how far above 1,500 ms the slowest 1% were. An average of 200 ms can coexist with a terrible p99, especially under contention or fan-out.

## Multi-window burn-rate alerts

Instead of paging on every single HTTP 500, use a threshold indicating that the error budget is being consumed too quickly over both a short and long window. Choose sensitivity based on service impact, traffic volume, and on-call capacity. Synthetic probes are useful but cannot replace real-user or real-job SLIs.

## Incident workflow

1. Detect and declare impact/severity.
2. Assign incident commander, communications owner, and technical lead for larger incidents.
3. Mitigate customer impact first (rollback, route failover, reduced features, load shedding).
4. Preserve relevant evidence and track timeline.
5. Validate recovery using customer-facing SLIs and integrity checks.
6. Write a blameless postmortem with owners and deadlines for follow-up.

**Design judgment:** Every paging alert needs an actionable runbook and clear owner. A page for a non-actionable warning creates fatigue and delays important responses.
