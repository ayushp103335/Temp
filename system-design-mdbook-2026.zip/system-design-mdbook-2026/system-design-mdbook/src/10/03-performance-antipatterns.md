# Performance Antipatterns and Systematic Tuning

The roadmap explicitly names ten common antipatterns. They are symptoms of architectural choices that conflict with the workload.

| Antipattern | Technical example | Better approach |
|---|---|---|
| Improper instantiation | Create a DB connection per HTTP request | Bound pooled connections |
| Monolithic persistence | One SQL DB handles hot transactions, full-text search and analytics | Read models/search/warehouse where justified |
| Noisy neighbor | One tenant runs 100K report jobs and blocks all others | Quotas, fair scheduling, cells |
| Synchronous I/O | API blocks 15 s on AI inference | Durable async job with status |
| Extraneous fetching | Load full 5 MB record for one status field | Projection/select only required fields |
| Busy database | N+1 queries plus unindexed filters | Batch queries, indexes, plan profiling |
| Busy frontend | Heavy bundle and render work blocks browser main thread | Code splitting, virtualization, efficient rendering |
| Chatty I/O | 50 RPCs per checkout | Batch/coarse APIs, concurrency reduction |
| Retry storm | 10K clients retry 503 immediately | Backoff + jitter + retry budgets |
| No caching | Repeat immutable metadata DB query 1M times | Appropriate TTL/edge/app cache |

## Tuning order

1. Establish real user-visible performance baseline with load and data shape.
2. Identify bottleneck using traces, query plans, profiling, and utilization.
3. Form a hypothesis with expected improvement and side effects.
4. Change one thing; run controlled benchmarks with warm/cold-cache considerations.
5. Compare throughput, p95/p99, errors, resource cost, and data correctness.

**Technical example:** A dashboard triggers 50 SQL queries, each with 10 ms network/database time. Sequentially that creates ~500 ms before rendering. A batched aggregate query may reduce round trips, but a huge single query can itself be slow. Test actual plans and dataset sizes.

**Exercise:** Explain how a cache can hide the "busy database" antipattern during tests and fail catastrophically after a correlated cache eviction.
