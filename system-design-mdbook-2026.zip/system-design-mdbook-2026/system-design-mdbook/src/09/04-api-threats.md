# Web/API Security: OWASP, IDOR, Injection, and Abuse Protection

OWASP's web application and API risk lists are useful prioritization frameworks. As of this book's edition, the web Top 10 has a 2025 release, while the dedicated API list has a 2023 edition; consult official links for future revisions.

## Essential attack classes and controls

| Vulnerability | Technical attack example | Primary architectural control |
|---|---|---|
| Broken object-level authorization (IDOR/BOLA) | Change `/claims/101` to `/claims/102` | Check ownership/policy on every object |
| Broken function-level authorization | Low-privilege caller invokes `/admin/export` | Role and context enforcement server-side |
| SQL injection | `id='1 OR 1=1'` appended to SQL | Parameterized queries, least-privileged DB accounts |
| SSRF | Import URL points to `http://169.254.169.254` | Egress restrictions, validation, block metadata services |
| Mass assignment | Client sets `is_admin=true` in JSON | Explicit allowlisted request models |
| Credential stuffing | Repeated stolen credential logins | MFA, anomaly detection, rate controls |
| Unbounded upload | 20 GB file to OCR endpoint | Size/type checks, streaming limits, quarantine |
| Webhook spoofing | Fake `payment_succeeded` JSON | Provider signature + replay protections |
| XSS | Unescaped user input in HTML | Contextual output encoding, CSP, safe templating |
| Supply chain compromise | Malicious dependency release | Provenance, scanning, pinned versions, SBOM |

## Request-level defenses

Validate length, type, schema, authorization, and quotas **at the trust boundary**. Use generic error messages where detailed failures leak internal data, but keep diagnostic codes in protected logs. Protect API consumers from abuse with rate limiting per authenticated tenant and endpoint. Distinguish business-level rate limits from volumetric DDoS mitigation at the edge.

## Failure behavior is security behavior

If the authorization service times out, should a sensitive API permit the request? Usually **fail closed** for privileged access, while other workflows may allow a carefully bounded cached policy decision. A fallback must be specified per risk. Never silently bypass authorization merely to improve availability.

**Exercise:** Review a code path that fetches `document_id` by URL and checks only for a valid token. Write the missing tenant/object authorization test cases.
