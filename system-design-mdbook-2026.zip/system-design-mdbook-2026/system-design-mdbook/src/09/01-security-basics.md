# Security From First Principles: CIA, Threat Models, and Trust Boundaries

Security is part of architecture, not a late testing phase. The **CIA triad** represents confidentiality (prevent unauthorized disclosure), integrity (prevent unauthorized modification), and availability (keep service usable). A system can be available and still violate confidentiality if one tenant can read another tenant's data.

## Build a threat model

1. List assets: PDFs, patient identities, credentials, object-store keys, ledger records, and model prompts.
2. Draw trust boundaries: browser to API, API to DB, vendor to webhook, worker to object store, engineer to production.
3. Identify actors and entry points; include malicious insiders and compromised service accounts.
4. Apply **STRIDE** categories: spoofing, tampering, repudiation, information disclosure, denial of service, elevation of privilege.
5. Estimate severity, exploitability, and blast radius; choose controls and tests.
6. Revisit after new features, integrations, and infrastructure changes.

## Threats in a real API path

```text
Internet -> WAF/edge -> auth gateway -> patient API -> SQL DB
           |             |               |          |
           DDoS       token abuse        IDOR      injection
                      misconfig          logic     stolen DB creds
```

**Confidentiality:** require TLS, server-side per-resource authorization, least privilege, encryption at rest where appropriate, and redaction. **Integrity:** parameterized SQL, signed webhooks, transactional constraints, immutable audit events, checksums. **Availability:** resource limits, DDoS protections, rate limiting, backups, failover, and overload behavior.

## Zero trust

Zero trust does not mean "no users are trusted"; it means network location alone is not proof of authority. Authenticate and authorize subjects, devices, and services for protected resources, verify continuously as risk changes, and limit implicit trust. See NIST SP 800-207 and 800-207A in References.

**Exercise:** Threat-model `POST /patient/{id}/document`: what happens if an attacker changes `id`, steals a bearer token, alters a webhook payload, uploads a 5 GB file, or replays a request?
