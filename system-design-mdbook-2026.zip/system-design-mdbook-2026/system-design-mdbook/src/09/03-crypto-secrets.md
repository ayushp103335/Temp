# Encryption, Hashing, TLS, Secrets, and Key Management

**Encryption** transforms plaintext into ciphertext that authorized holders can decrypt. **Hashing** is a one-way digest used for integrity or identifiers; it is not encryption. **Digital signatures/MACs** authenticate integrity and provenance under an appropriate key model. **Password hashing** requires slow, salted password-specific algorithms such as Argon2id rather than general hashes such as SHA-256 alone.

## In transit vs at rest

TLS protects data between transport endpoints, using authenticated key agreement and symmetric encryption. Database/object-store encryption at rest reduces risks from raw storage exposure but does not prevent an authorized application or stolen live credentials from reading plaintext. Confidential data may also require application-level field encryption and carefully managed searchable representations.

## Key hierarchy

A cloud KMS or hardware security module (HSM) can protect master keys and authorize limited key operations. Envelope encryption creates a data-encryption key to encrypt data, then protects that key with a master/key-encryption key. Audit decrypt operations, rotate keys appropriately, and test whether data encrypted under old keys remains accessible during rotation.

## Webhook signature verification

A provider may sign `timestamp + raw_body` with an HMAC secret. The receiver should verify against **raw request bytes**, compare signatures in constant time, reject stale timestamps, and store event IDs for replay protection. JSON reserialization changes bytes and can invalidate signatures. Never rely on the presence of a `signature` header without cryptographic verification.

## Secret handling

Secrets do not belong in logs, frontend bundles, images, tickets, shell history, or source control. Use scoped access, runtime injection, rotation, and alerting for unexpected reads. A "private" IP address is not a secret and does not make credentials optional.

**Exercise:** Design a safe webhook receiver for payment updates. Include the trusted provider key, signature verification, replay window, event deduplication, error responses, and audit metadata.
