# Authentication, Authorization, Sessions, OAuth, and OIDC

**Authentication (AuthN)** proves an identity; **authorization (AuthZ)** decides whether that identity may perform this operation on this object; **accounting/auditing** records security-relevant actions. Logging in successfully never implies permission to view every record.

## Browser sessions

A typical web app exchanges credentials or a federated login result for a server-managed session ID stored in a `Secure`, `HttpOnly`, appropriately `SameSite` cookie. The session store tracks expiry, revocation, and principal. Use CSRF defenses for cookie-authenticated state-changing requests. Do not put long-lived session secrets in URLs.

## Access tokens and JWTs

A signed JWT carries claims such as subject, audience, issuer, expiry, and scope. Verify signature with trusted keys, issuer, audience, expiry, and allowed algorithm. Never treat decoded but unverified claims as trusted. Revocation is difficult for self-contained long-lived tokens: prefer short TTLs, refresh-token rotation, or server-side revocation checks according to risk.

## OAuth 2.0 vs OpenID Connect

OAuth 2.0 is an authorization framework for delegated access. OIDC adds standardized user authentication/identity (ID tokens) over OAuth. An OIDC authorization-code flow with PKCE is common for interactive applications. The client exchanges an authorization code for tokens with a trusted identity provider; access tokens are intended for APIs with the correct audience and scopes.

## RBAC vs ABAC

**RBAC:** role-based access (`billing_admin`). **ABAC:** attribute-based policy (`user.clinic_id == patient.clinic_id && purpose == treatment`). Real systems often combine both. Policies should be enforced at the API/data access layer and tested for cross-tenant IDOR vulnerabilities.

```python
def can_read_document(user, document):
    return (user.active and
            user.tenant_id == document.tenant_id and
            "document:read" in user.permissions)
```

This is a minimal illustration; production checks also handle delegation, emergency access, expiry, audits, and resource-specific constraints. A database row-level-security policy can provide defense in depth when correctly managed.

## Service identities

Use workload/service identity, short-lived credentials, mTLS or signed tokens as appropriate. Avoid embedding permanent API keys in repository files or client code. Rotate credentials with overlap and automated health checks.

**Design judgment:** An API gateway may validate a token, but downstream services remain responsible for domain authorization and auditability.
