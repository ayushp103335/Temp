# Data Classification, Privacy, Audit, Compliance, and Retention

Architecture must account for where sensitive data is stored, how long it lives, who may access it, how it can be deleted, and which jurisdictions apply. Healthcare and finance impose particularly strict integrity, access, audit, and retention expectations. Regulatory applicability is fact-specific; consult legal/compliance specialists and current law rather than treating a generic architecture diagram as compliance certification.

## Data lifecycle

```text
collect -> validate -> classify -> encrypt/store -> use/share -> retain -> archive/delete
```

Attach classifications (public, internal, confidential, regulated) to fields/data sets. Do not copy production patient data into debugging logs, analytics dumps, or model prompts unless there is a documented lawful and necessary purpose with suitable protections. Define sensitive-value redaction for logs/traces; pseudonymization is not the same as anonymization.

## Multi-tenant isolation

Approaches range from a shared DB with `tenant_id` to separate schemas, separate DBs, or per-tenant cells. The trade-off is cost vs isolation and operational overhead. Whatever the model, enforce tenant scoping in APIs, jobs, search indexes, object paths, cache keys, event consumers, backups, and observability pipelines.

## Audit logging

Security audit records should capture subject, action, target ID, timestamp, outcome, source, request/correlation ID, and policy basis where appropriate. Prevent ordinary users and compromised app accounts from rewriting protected audit history. Avoid logging raw secrets or full sensitive payloads; verify clock and identity accuracy.

## Deletion and retention

Deleting a DB row may leave copies in caches, replicas, search indexes, event streams, backups, analytics, and model stores. Some backups cannot be rewritten without destroying integrity; define retention/deletion procedures consistent with applicable law and business requirements. Prefer data minimization to storing data "just in case."

**Design judgment:** Security controls must follow data across components and disaster-recovery copies. Region-specific compute alone does not guarantee data residency when logs and backups leave that region.
