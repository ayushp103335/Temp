# Database Replication, Failover, and Read Consistency

![Database Replication, Failover, and Read Consistency architecture diagram](../assets/replication.svg)

**Replication** maintains multiple copies of data for availability, recovery, and/or read distribution. **Backup** is a historical, restorable copy. Replication is not backup: deleting the wrong row can replicate the deletion immediately.

## Primary-replica (leader-follower)

```text
                  write
Client/API ------------------> Primary DB
                               | WAL/log shipping
                               +---> Replica A (reads)
                               +---> Replica B (reads)
```

With asynchronous replication, the primary can acknowledge a commit before replicas have it. A client writing a new appointment then reading from a replica might see stale data. Solutions include read-your-writes routing to primary, session consistency tokens, waiting for a replication position, or synchronous replication where warranted.

## Synchronous vs asynchronous

Synchronous replication waits for required replica acknowledgment before a write is considered committed. It can reduce acknowledged-write loss under specified failure models but adds latency and can reduce write availability during network partitions. **Quorum-based replication** depends on read/write quorum sets and conflict-resolution protocol, not merely the arithmetic `R+W>N` in isolation.

## Failover and fencing

When the primary fails, select/promote a replacement and ensure the old primary cannot continue accepting conflicting writes. **Fencing** and consensus/lease mechanisms prevent split-brain. DNS alone cannot guarantee safe write leadership. Automatic promotion depends on topology, state, monitoring, and tolerated RPO.

## Multi-leader replication

Multiple leaders accept writes and replicate to each other, enabling regional locality or offline changes but requiring conflict handling. A replicated counter can sometimes merge increments; a unique username collision or financial account balance is harder. Last-write-wins can lose valid updates, and wall-clock times are not reliable global order.

**Worked scenario:** A regional API writes job `j-7` to Region A and gets success. Region A fails 50 ms later, before async replica B received the row. B may be promoted without `j-7`. If the product requires zero acknowledged job loss for this failure class, the system needs stronger write acknowledgment, multi-region synchronous durability, or another durable acceptance mechanism; simply adding a replica is insufficient.

**Design judgment:** State explicitly whether the system prioritizes write availability, read freshness, latency, or near-zero data loss. Never claim all four without explaining the mechanism and network assumptions.
