# Schema Evolution, CDC, ETL, Search, and Geo-Indexing

A production database changes while old and new application versions coexist. A migration is safe when reads and writes from both versions are compatible during rollout.

## Expand-migrate-contract

To rename `patient_name` to `full_name`: (1) add new nullable field; (2) deploy code capable of writing/reading both as necessary; (3) backfill in controlled batches; (4) verify checksums and completeness; (5) switch reads; (6) stop old writes; (7) remove old field only after all consumers have migrated. Avoid a single destructive deployment that breaks running old code.

## Change data capture (CDC)

CDC publishes committed row changes from a database log or equivalent source. It can build search indexes, analytical tables, or service projections. Consumers need offsets/checkpoints, replays, schema handling, and idempotence. **Do not equate CDC with a transactional outbox**: CDC may carry all table changes, whereas the outbox records intentional domain events written in the same transaction as business state.

## ETL, ELT, and analytic stores

**ETL** transforms before loading a destination; **ELT** loads data then transforms inside the destination. OLTP databases optimize small transactions; OLAP warehouses and columnar formats optimize scans/aggregations. Event-time and ingestion-time differ and must be represented separately for analytics.

## Full-text and geo queries

Search engines use inverted indexes to map terms to documents. A search result can be stale when asynchronous indexing lags. Implement reindexing and compare search-index counts against source-of-truth records. For location queries, geohashes, quadtrees, R-trees, H3, or S2 can create spatial candidates; precise distances/polygons require further filtering. Beware of uneven density, boundaries, privacy, and rapidly moving points.

**Example:** A location service finds active ambulances within 5 km. Index coarse cells for fast candidate lookup, then calculate accurate distance; treat last-seen timestamp and movement updates as first-class fields, and do not claim a position is "live" when last updated 20 minutes ago.

**Design judgment:** The right data architecture often has one authoritative store and several asynchronous read/search/analytics projections, each with documented freshness and recovery guarantees.
