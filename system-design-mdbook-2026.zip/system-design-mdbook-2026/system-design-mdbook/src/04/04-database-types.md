# SQL vs NoSQL: Document, Key-Value, Graph, Wide Column, Search, and Time Series

"NoSQL" is not one technology. It describes several data models that optimize different workloads and trade-offs.

| Model | Typical query | Useful example | Design concern |
|---|---|---|---|
| Relational | Joins + transactions | Billing, inventory, user accounts | Scaling writes/complex joins |
| Key-value | `GET(key)` | Session state, rate-limit counter | Weak ad hoc query support |
| Document | Query fields inside JSON-like records | Variable-form metadata | Cross-document constraints/index planning |
| Wide column | Partition-key/time-range access | High-volume telemetry | Hot partitions, query-first modeling |
| Graph | Multi-hop relationship traversal | Fraud rings, recommendations | Large-graph/transaction cost |
| Search index | Full-text/aggregation | Document search | Async index freshness, relevance tuning |
| Time series | Time-window aggregation | Metrics, IoT sensor data | Cardinality, retention, downsampling |
| Vector index | Approximate nearest-neighbor | Embedding retrieval for RAG | Recall, filtering, updates, evaluation |

## Document-oriented example

```json
{
  "document_id": "doc-21",
  "tenant_id": "clinic-2",
  "fields": {"payer": "Acme", "claim_id": "C-1"},
  "quality_flags": ["MISSING_SIGNATURE"]
}
```

This record fits a document store if field structure evolves and the dominant access pattern reads a document as a unit. If every request must join records to many relational financial tables with strict cross-record transactions, a relational source of truth may be simpler.

## Graph example

Find accounts connected through shared devices and payment instruments: a graph DB can optimize variable-depth traversals. But for one-hop patient-to-appointment joins, SQL usually handles the problem well. Define query shape first.

## Search and analytical systems

A transactional SQL DB is often a bad substrate for heavy full-text search or minute-by-minute aggregations over billions of events. A search index and an analytical columnar warehouse can be derived from the transactional system using a CDC pipeline. The derived index is a **projection**, not automatically authoritative.

**Design judgment:** Choose based on query patterns, required transactions, indexability, operational risk, recovery and team expertise. Polyglot persistence brings synchronization complexity; add another engine only when its value is measurable.
