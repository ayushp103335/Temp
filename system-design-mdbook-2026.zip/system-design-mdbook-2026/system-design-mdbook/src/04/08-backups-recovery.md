# Backups, PITR, Disaster Recovery, and Active-Active Databases

A backup strategy is an engineering process, not a nightly copy command. It must specify recovery granularity, encryption, offsite isolation, retention, and frequent restoration verification.

## Backup mechanisms

- **Full backup:** a complete consistent snapshot of a data set.
- **Incremental/differential:** capture changes relative to a prior backup; restore chains and retention must be tested.
- **Point-in-time recovery (PITR):** restore from base backup plus continuously archived transaction logs to a chosen time.
- **Snapshot:** storage- or database-consistent image; application-level integrity may require coordination.

Protect backups from ransomware and accidental deletion through separate permissions/accounts, immutable retention or object locks where available, and encryption key management. A replica is valuable for failover but doesn't replace a recoverable previous state.

## RPO/RTO worked example

Requirements: RPO = 5 minutes, RTO = 30 minutes for a regional disaster. A daily backup alone allows up to 24 hours of data loss and therefore fails the RPO. Continuous log archive plus frequent snapshots can potentially meet RPO if logs are copied and recoverable within five minutes. Test full restore duration; 40 TB of data cannot necessarily be restored in 30 minutes. Consider warm standby, smaller recovery units, and workload-specific failover.

## Active-passive vs active-active

**Active-passive:** one writer region serves traffic, another region is ready for takeover. Simplifies write consistency, but requires detection, promotion, traffic switching, and recovery of stale clients.

**Active-active for stateless APIs:** multiple regions actively accept requests, but may still route every write to one database region; this is active-active **application serving**, not automatically multi-writer data.

**Active-active multi-writer database:** regions concurrently accept writes to shared logical data. Requires explicit conflict-resolution semantics, coordination, or carefully partitioned write ownership. Last-write-wins is unacceptable for many financial/clinical invariants. Some workloads use strongly coordinated writes across regions, trading latency and availability. Others use CRDTs or per-region ownership for mergeable data.

## Split-brain and promotion

Two nodes each claiming to be the write leader can corrupt data even while both appear healthy. Fencing (ensuring an old leader cannot continue writes), quorum election, and validated promotion workflows are essential. A recovery drill must simulate stale DNS, in-flight writes, divergent replicas, credentials, and rollback.

**Failure drill:** Stop the primary DB, promote standby, replay an accepted-but-not-replicated transaction, and verify observed data loss. Repeat with a faulty app that keeps writing to the old primary. Record actual RPO/RTO rather than assuming target values.
