# Partitioning, Sharding, Consistent Hashing, and Federation

**Partitioning** splits data into segments. A database may partition one table across files/disks within one server. **Sharding** distributes data across different database nodes or administrative units. **Federation** splits data by business function/domain into separate databases; it is not necessarily horizontal sharding of the same table.

## Route by shard key

Suppose `student(student_id, name, grade)` is split into four database shards. If `student_id` is a uniformly distributed integer and routing uses `student_id % 4`, then `student_id=103` routes to shard 3 (using shard numbers 0–3).

```python
def shard_for_student(student_id: int, shard_count=4):
    return student_id % shard_count
```

But query `SELECT * FROM student WHERE name = 'Chirag'` does not contain `student_id`, so the router cannot directly know the shard. Options: query all four shards (scatter-gather), maintain a global `name -> student_id` lookup index (with non-unique names handled properly), or choose a shard key aligned with the query pattern. Scatter-gather is sometimes acceptable at four shards but may become expensive at hundreds. An index inside each shard does not magically tell the router which shard to visit.

## Resharding

A naïve modulo hash `key % N` remaps many keys when N changes, so adding a fifth shard is disruptive. **Consistent hashing** or indirection through virtual shards reduces movement; for example, map keys to 1,024 stable logical buckets and map those buckets to physical servers. Even with better routing, migration requires data copy, change capture/dual-write or controlled cutover, checksums, and rollback plans.

## Hot shards

Sharding by hospital ID can put 40% of traffic on one very large tenant. Sharding by date can hotspot the newest partition. Hash-based keys distribute uniform accesses better but make global range queries difficult. Composite partitioning may use `tenant_id + hashed document_id`, or physically isolate very large tenants. Query routing and tenant isolation must be explicit.

## Distributed transactions and joins

A join across shards may require fan-out, network transfer, or precomputed read models. A transaction that updates two shards may require coordination or a saga with compensation. Avoid arbitrary cross-shard joins in the hot path. Support `GET by id` with shard-aware identifiers or a routing map where possible.

**When not to shard:** A 100,000-row indexed table with low write rate is not a sharding problem. Optimize SQL, indexes, connection pools, replicas, and vertical capacity before accepting application-managed sharding complexity.

**Exercise:** Design shard routing for a multi-tenant EHR with very uneven tenant size. Explain how patient-ID lookups, tenant-scoped search, and cross-tenant administrative reports are served.
