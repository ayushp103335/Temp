# Indexes, B-Trees, LSM Trees, and Query Optimization

An index is an auxiliary data structure that reduces how much data a query must inspect. It consumes storage and adds work to writes. A common disk-oriented index is a **B-tree/B+tree**, organizing keys in sorted pages. An **LSM tree** (log-structured merge tree) batches writes to sorted structures; compaction and read amplification become important trade-offs.

## Composite index behavior

For queries `WHERE tenant_id = ? AND status = ? ORDER BY created_at DESC`, an index on `(tenant_id, status, created_at DESC)` may permit a narrow ordered scan. But an index on `(status, tenant_id)` is not always equally useful for queries filtering tenant alone. Exact optimizer behavior depends on database and statistics.

```sql
EXPLAIN ANALYZE
SELECT document_id, created_at
FROM jobs
WHERE tenant_id = 77 AND status = 'FAILED'
ORDER BY created_at DESC LIMIT 50;
```

Look at actual rows scanned, index vs table access, sorting, buffer/cache reads, and execution time. An index-only scan may require the index to contain referenced fields and visibility conditions to be satisfied.

## N+1 query pathology

An API loads 100 claims, then queries each claim's line items separately: 101 queries rather than one batch query or two set-based queries. Under 100 requests/s, this can create 10,100 DB round trips/s. Fix through joins/batching, targeted projections, or materialized read models; do not solve it first by adding CPU cores.

## Storage engine intuition

B-tree-oriented row stores favor predictable point/range reads and in-place-ish page updates; LSM-based engines favor sequential write paths and background compaction. This is a simplification: engines combine WALs, buffers, caches, indexes, and recovery protocols in different ways. Choice depends on access patterns, read/write amplification, operational model, and consistency.

## Tuning workflow

Capture slow queries and plans; validate indexes against representative data; examine connection pool saturation, lock waits, buffer cache hit ratio, IOPS, checkpoint stalls, and compaction. Re-test after changes: adding an index can improve one query and slow every write.

**Exercise:** A 20M-row table has `(tenant_id, created_at, id)` and queries by `WHERE id = ?`. Which index should answer the lookup and why? Why might an index on a low-cardinality Boolean flag be unhelpful by itself?
