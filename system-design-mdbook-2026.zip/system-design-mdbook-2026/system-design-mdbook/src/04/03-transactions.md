# ACID, Transactions, Locks, and Isolation Levels

A **transaction** groups operations. ACID describes four properties: atomicity (all-or-nothing effects), consistency (declared invariants preserved by valid transactions), isolation (concurrent transactions behave according to a defined model), and durability (committed data survives the failure classes the database promises to survive).

## Money transfer example

```sql
BEGIN;
UPDATE accounts SET balance = balance - 100 WHERE id = 'A' AND balance >= 100;
-- Check affected row count; abort if zero.
UPDATE accounts SET balance = balance + 100 WHERE id = 'B';
INSERT INTO ledger(tx_id, from_account, to_account, amount)
VALUES ('transfer-901', 'A', 'B', 100);
COMMIT;
```

Make `ledger.tx_id` unique to prevent duplicate logical transfers, and use appropriate row-level locking/transaction isolation. Real payment systems use immutable accounting entries with precise currency handling; this is a simplified within-one-database example.

## Isolation anomalies

- **Dirty read:** one transaction sees another's uncommitted changes.
- **Non-repeatable read:** same row queried twice yields different committed values during one transaction.
- **Phantom:** repeating a predicate query sees a different set of rows.
- **Lost update:** concurrent updates overwrite one another.
- **Write skew:** transactions read a shared invariant and modify different rows, violating a cross-row constraint.

Common SQL isolation names include Read Uncommitted, Read Committed, Repeatable Read, and Serializable; actual guarantees vary among implementations. Snapshot isolation is useful but does not automatically prevent all write skew. **Serializable** provides the strongest transactional isolation model but may require abort/retry and carry throughput costs.

## Optimistic and pessimistic concurrency

Optimistic locking uses versions:

```sql
UPDATE documents
SET state = 'DONE', version = version + 1
WHERE document_id = 19 AND version = 3;
```

If zero rows change, another writer modified the document; reload and resolve. Pessimistic locking uses `SELECT ... FOR UPDATE` where supported, potentially reducing conflicts at the expense of waits/deadlocks.

## WAL and durability

A write-ahead log (WAL) records transactional changes before corresponding data pages are persisted. On crash, the DB can replay or roll back according to its recovery design. Durability still depends on settings such as synchronous commit and on storage reliability; analyze what failures the claimed guarantee covers.

**Design judgment:** Transactions are a first-class design tool. Do not replace local atomic transactions with message queues simply because the application uses microservices elsewhere.
