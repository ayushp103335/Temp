# Relational Databases, Modeling, and SQL

A relational database stores data as tables with defined columns, constraints, and relationships. SQL expresses what data to retrieve or change; the database planner chooses an execution strategy. A **primary key** identifies a row, a **foreign key** enforces a relationship, and constraints protect invariants even when application bugs occur.

## Model a small business workflow

```sql
CREATE TABLE tenants (
  tenant_id BIGINT PRIMARY KEY,
  name VARCHAR(100) NOT NULL
);
CREATE TABLE documents (
  document_id BIGINT PRIMARY KEY,
  tenant_id BIGINT NOT NULL REFERENCES tenants(tenant_id),
  object_key VARCHAR(500) NOT NULL,
  state VARCHAR(20) NOT NULL CHECK (state IN ('NEW','DONE','FAILED'))
);
CREATE INDEX ix_docs_tenant_state ON documents(tenant_id, state);
```

A document belongs to a tenant. Storing `tenant_id` in a table supports scoping all access checks, but every query and mutation still needs tenant authorization. Domain keys should usually be stable; avoid embedding mutable business names into primary keys.

## Normalization and denormalization

**Normalization** reduces redundant facts and update anomalies. For example, store `patients` once and reference `patient_id` from `appointments`; otherwise one corrected phone number may need updating across 1,000 appointment rows. **Denormalization** duplicates or precomputes data to accelerate access; use it when reads justify consistency-maintenance complexity.

A read model `appointment_summary` might copy patient name and latest visit status. After a name update, asynchronous projections may temporarily be stale. Define acceptable staleness and reprocessing strategy.

## Joins and query plans

```sql
SELECT d.document_id, t.name
FROM documents d
JOIN tenants t ON t.tenant_id = d.tenant_id
WHERE d.tenant_id = 7 AND d.state = 'DONE';
```

The planner may use the composite index to find document rows and join to tenant. Inspect `EXPLAIN`/`EXPLAIN ANALYZE` where supported; distinguish estimates from actual timings. A query that is fast with 50 rows may behave differently with 50 million rows and skewed data.

## Relational consistency

Constraints and transactions protect **within-database** integrity. A foreign key does not protect data in an external object store or message queue. Atomic DB commit plus remote object upload requires a workflow: upload to temporary object, transactionally mark ready only after verification, and garbage-collect abandoned temporary objects.

**Design judgment:** Use relational databases for transactional invariants and rich joins unless the workload or organizational constraints justify another model. "NoSQL scales" is not sufficient evidence.

**Exercise:** Design tenant-scoped `jobs`, `job_attempts`, and `results` tables with indexes for fetching newest pending jobs and recent failures.
