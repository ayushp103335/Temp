# Data Integrity, Reconciliation, and Multi-Store Repair

Modern architectures frequently store one logical operation across SQL, object storage, a search index, and a message broker. These systems do not share one transaction. Reliability therefore depends on explicit **invariants**, **reconciliation**, and **repairability**.

## Example: a job with a missing PDF

SQL row `jobs(j-100, status=PENDING, object_key=uploads/j-100.pdf)` exists, but the referenced object is absent due to upload failure or accidental deletion. The DB row is internally valid yet the business operation is broken.

A reconciliation task can periodically scan newly accepted jobs, verify object existence/size/checksum, and transition invalid jobs to a recoverable state. It should be rate-limited to avoid producing an object-store request storm, and be idempotent so repeated scans don't double-apply actions.

## Cross-store invariant checklist

- Every accepted `job_id` has one authoritative job record.
- Every `READY` job references a verified, accessible object matching expected checksum/version.
- Every `SUCCEEDED` job has one valid result version and provenance.
- Every committed business event eventually reaches relevant projections or is flagged for replay.
- Search/index views may lag but can be rebuilt from authoritative data.
- Access revocation propagates to every serving path, including caches and presigned capabilities as far as platform semantics permit.

## Reconciliation approaches

**Periodic scan:** easy to implement, bounded by scan performance and detection latency. **CDC log offset verification:** compare committed event positions with consumer checkpoints. **Merkle/checksum comparison:** efficiently detect divergences across large data sets. **Read repair:** verify/repair on access; insufficient if an item is never read. **Operator replay:** safe, auditable procedure for exceptional cases.

## Handling orphan data

A PDF upload succeeds but API crashes before creating its job row. Store uploads in a temporary prefix, record creation timestamps, and garbage-collect objects not referenced by finalized jobs after a safe retention window. Be conservative about deleting data where pending work may legitimately reference it.

## Schema and version integrity

A result created under extractor schema v2 may not be compatible with API expecting v3. Store schema version, model version, normalization rules, source document version, and processing timestamp. Make conversions explicit and test them. Reprocessing should not silently overwrite previously approved results without audit.

**Design judgment:** When two stores cannot share one transaction, define observable repair paths. "Eventually consistent" without a repair strategy is an unfinished design.
