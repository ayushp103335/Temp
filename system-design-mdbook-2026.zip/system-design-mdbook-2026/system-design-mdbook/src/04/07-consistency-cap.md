# Consistency Models, CAP Theorem, and PACELC

**Consistency** is overloaded: ACID consistency means transactions preserve specified invariants; distributed consistency describes what values clients can observe after concurrent/replicated operations. Always name the exact model.

## Distributed visibility guarantees

- **Linearizability / strong single-object consistency:** operations appear to take effect atomically in real-time order. If a write completes before a later read starts, the read observes that write (subject to the specific object/model).
- **Sequential consistency:** all operations have a single order consistent with each client's program order, but not necessarily real time.
- **Causal consistency:** effects respect causal dependencies, while independent updates may be observed in differing orders.
- **Eventual consistency:** if updates cease and delivery continues, replicas converge; no fixed freshness bound is implied.
- **Weak consistency:** umbrella term for fewer guarantees; specify which anomalies are acceptable.

Read-your-writes, monotonic reads, monotonic writes, and writes-follow-reads are **session guarantees** useful in user-facing systems.

## CAP without the common misconception

CAP states that during a network partition, a distributed system cannot simultaneously guarantee **linearizable consistency** and **availability** (every request to a non-failed node gets a non-error response) under its formal model. Partition tolerance is not an optional switch for a real network. A CP system may reject writes without quorum; an AP system may accept local writes and reconcile conflicts. "CA databases" often describes a single-site or no-partition assumption, not a third category that defeats the theorem.

A healthcare medication order may require a strong write authority to avoid conflicting prescriptions; a presence indicator may accept temporary divergence. CAP does not state "choose any two always" without specifying a partition, nor does it replace transaction design.

## PACELC

PACELC adds: **if Partition (P), trade Availability (A) vs Consistency (C); Else (E), trade Latency (L) vs Consistency (C)**. Even when the network is healthy, synchronous cross-region coordination increases latency. Different operations of one database can have different choices.

**Example:** A global profile service lets users update a display name in their nearest region and merges eventually. Profile read latency is low, but conflicting edits need resolution. A payment ledger should not use blind last-write-wins for balances; stronger coordination or single-writer routing better protects financial invariants.

**Design judgment:** Specify correctness properties at the *operation* level. Some data can be stale for 30 seconds; other data cannot be inconsistent for a single transaction.
