# Modern ML/AI Serving Architecture and Capacity

ML inference is a compute service with unusual resource characteristics: model loading can be expensive, accelerator memory limits concurrency, outputs may stream over seconds, and token-based cost changes with input/output length. Traditional web-scaling principles still apply: quantify capacity, isolate failures, monitor latency, and protect private data.

## Production inference path

```text
Client -> API/auth/quotas -> model router -> inference worker pool
                                 |              |
                                 |         model + tokenizer
                                 |              |
                                 +<- streamed output/result
                 -> usage meter -> observability + billing
```

An inference service should bound prompt size, output length, concurrent requests, memory, and vendor spend. Large prompts affect processing time and context use. Batching can improve throughput for compatible workloads but may increase per-request latency; dynamic batching requires a fair scheduler and timeout constraints.

## Inference capacity math

Suppose one model deployment handles **4 requests/s** at a required output-size distribution and p95 target. For sustained arrival of 60 requests/s at 70% target utilization, estimated replicas ≈ `60 / (4 × 0.7) = 21.43`, so plan at least 22 equivalent model replicas and validate the workload. This calculation is a simplified rate model: token output length, prefill cost, batch size, GPU memory, cache hits, and concurrency often dominate real throughput.

## Async vs streaming

Interactive chat often benefits from token streaming and low time-to-first-token. Batch document extraction may accept asynchronous processing with status callbacks. A voice agent has additional speech-to-text and text-to-speech latency budgets; a slow external tool can make conversation unnatural even if eventual result correctness is high.

## Model routing and fallback

Route by task (OCR, search, reasoning), language, cost, policy, and measured accuracy. A cheaper model may be suitable for high-confidence classification while a stronger model handles ambiguous pages. Fallback must preserve privacy restrictions, response schema, tenant quotas, and user expectations. Avoid silently using a different provider for sensitive workloads without approval.

**Design judgment:** AI is not a replacement for deterministic business checks. Validate field types, bounds, cross-field consistency, and authorization outside the model.
