# Emerging Design Areas: Serverless, Edge, Wasm, eBPF, and Platform Engineering

This chapter adds modern concepts absent or lightly represented in the original roadmap. Do not adopt them simply because they are newer; assess whether they solve a present constraint.

## Serverless and event-based compute

Functions-as-a-Service can scale event handlers without managing servers, but cold starts, concurrency quotas, execution limits, network egress, and per-invocation cost affect design. For small sporadic webhooks, a function can be economical; for a continuous 24/7 model inference fleet, dedicated compute may be more cost-efficient.

## Edge compute and WebAssembly (Wasm)

Edge functions can run limited logic closer to users—for example, normalize request headers or enforce coarse routing—but they still need remote authoritative data for transactional state. Wasm provides a portable sandboxed execution model used in certain runtimes, plugins, and edge environments; its security depends on the host's capabilities and isolation design.

## eBPF and kernel observability

Extended Berkeley Packet Filter (eBPF) can instrument selected kernel/network events with controlled programs. It enables low-overhead telemetry and networking use cases but requires privileged management, compatibility testing, and strict controls. It is an operations/infrastructure tool, not a substitute for request-level business tracing.

## Platform engineering and internal developer platforms

A platform team can provide self-service templates, paved-road deployments, identity integration, golden telemetry, and policy checks. This reduces cognitive load on product teams if it avoids over-centralized bureaucracy. Measure onboarding time, deployment frequency, change-failure rate, and product-team satisfaction rather than merely counting Kubernetes clusters.

## Digital sovereignty and data gravity

Large regulated datasets can be expensive to move between regions/clouds. Design workloads around data locality, legal constraints, backup topology, and cross-region egress before promising global availability. Compute is sometimes easier to move than the data it processes.

**Exercise:** Decide whether an API that runs a 25-minute GPU-intensive batch extraction is a good serverless candidate; state your assumptions about startup, duration limits, provider support, cost, and fault recovery.
