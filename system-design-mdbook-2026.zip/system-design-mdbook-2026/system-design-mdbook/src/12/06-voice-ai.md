# Voice AI and Multimodal Real-Time System Design

A voice agent combines telephony/media transport, speech recognition, dialogue decisions, tool calls, and speech synthesis. Its primary system-design challenge is a *latency and safety-critical streaming workflow*, not a single request-response LLM call.

## Signal path

```text
Caller/PSTN -> telephony provider -> media stream -> VAD/ASR
                                           -> dialogue state + LLM/tool router
                                           -> TTS -> media stream -> caller
```

**Voice activity detection (VAD)** estimates speech boundaries. **ASR/STT** transcribes audio. **TTS** synthesizes speech. Barge-in means the user interrupts while the agent is speaking; the controller must cancel or supersede old speech and avoid acting on partial or outdated intent.

## Latency budget

For a responsive turn, measure speech-end detection, ASR finalization/streaming, model time-to-first-token, tool-call round trips, TTS first audio, and carrier/network delays independently. A ten-second claim-status lookup cannot be hidden by a fast TTS engine. Use acknowledgement phrases or callback/hold workflows where appropriate.

## Tool and state safety

For a pharmacy refill assistant, identify and verify patient identity before exposing records, then obtain the medication/quantity, confirm details, and save a refill request only with proper authorization. Avoid interpreting phone caller ID alone as proof of identity. Store call state durably enough to handle dropped calls; mark externally submitted actions with idempotency keys to avoid duplicate prescriptions/refills after reconnect.

## Operational design

Media paths require jitter buffering, transport security, codec compatibility, latency monitoring, silence handling, multilingual transcription accuracy, transfer to humans, and consent/recording policy. A carrier failure should lead to an intelligible fallback rather than an agent pretending the action succeeded.

## Testing

Use scripted audio with accents, background noise, interruptions, false starts, language switches, long silences, and invalid patient details. Evaluate task completion and safety separately from conversational fluency. Verify outbound dialing policies, consent, recording disclosures, and privacy obligations for the applicable jurisdiction.

**Design judgment:** An AI phone agent should be treated as a stateful, permissioned workflow controller with streaming speech I/O—not as free-form text generation that can call unrestricted tools.
