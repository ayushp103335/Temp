# AI Reliability, LLM Security, Guardrails, and Production Evals

AI correctness is partly probabilistic, so reliable AI systems need deterministic controls around inference plus continuous evaluation. Do not infer truth from a model's own confidence text.

## Threat categories

As of August 2026, OWASP published an updated GenAI LLM Top 10; consult the current [official OWASP GenAI repository](https://github.com/GenAI-Security-Project/GenAI-LLM-Top10). Risk themes include prompt injection, sensitive information leakage, insecure integrations, excessive tool agency, poisoned retrieval sources, and resource/cost exhaustion. A model can hallucinate a precise-looking citation or claim ID.

## Layered defenses

- **Input layer:** authentication, input limits, file scanning, source trust classification, abuse quotas.
- **Retrieval layer:** tenant/ACL filters, metadata validation, data freshness and provenance checks.
- **Tool layer:** explicit allowlist, typed schemas, independent authorization, approval for high-risk side effects.
- **Output layer:** schema validation, deterministic domain rules, citation verification, refusal/abstention on missing evidence.
- **Operational layer:** prompt/model versioning, tracing with redaction, eval suites, cost/latency/error budgets, rollout and rollback.

## Evaluation harness

Define labeled test cases before deployment: exact extraction fields, normalization requirements, missing-field cases, handwritten/low-resolution images, contradictory multi-page data, language variants, long PDFs, injection attempts, and tool timeout scenarios. Report false positives/negatives, field-level exact match, calibration, completion latency, token cost, and per-segment failure rates.

A strong offline evaluation set should be supplemented by monitored online quality, human review of uncertain outputs, and procedures for dataset drift. Do not use actual patient records in unrestricted model evaluations without approved data handling.

## Safeguard application invariant

For an invoice extraction pipeline, let the LLM propose amount fields but verify mathematically: `sum(line paid amounts)` should reconcile to claim totals within allowed rules/tolerances; missing amounts should remain missing rather than invented. For clinical recommendations, use professional oversight and appropriate scope—not an agent inventing diagnoses from partially retrieved notes.

**Design judgment:** In safety-critical domains, model output is a candidate interpretation requiring validation and traceable evidence, not an authoritative write by default.
