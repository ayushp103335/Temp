# RAG, Embeddings, Vector Search, Hybrid Retrieval, and Evaluation

![RAG, Embeddings, Vector Search, Hybrid Retrieval, and Evaluation architecture diagram](../assets/rag-pipeline.svg)

**Retrieval-Augmented Generation (RAG)** retrieves relevant information from external sources and supplies it to a language model at answer time. It can improve grounding, but a fluent answer is not proof of correctness, completeness, or authorized access.

## Ingestion pipeline

```text
Authorized source DB/files
 -> extract/parse -> normalize/chunk -> classify + ACL metadata
 -> embed chunks -> vector index + text index
 -> version/provenance and deletion/update pipeline
```

**Chunking** splits documents into retrievable units. Poor boundaries can separate a lab result from its test name or date. Store source URI, record ID, tenant, access restrictions, timestamps, model version, and ingestion/checksum status. An embedding is a vector representation; semantically related content may be nearby in vector space, but vector similarity is not a substitute for precise clinical/date/ID filtering.

## Query pipeline

```text
User question -> authenticate -> determine allowed sources
 -> lexical BM25 + vector ANN search + metadata filters
 -> rerank -> verify evidence permissions and currency
 -> construct grounded prompt -> generate answer + citations
 -> validate answer policy/format -> log quality and latency
```

**Approximate nearest-neighbor (ANN)** methods such as HNSW trade exactness for speed/memory. **Hybrid search** combines keyword precision (names, codes, dates) with semantic similarity. A query "latest HbA1c before surgery" requires accurate timestamps and possibly a structured SQL/FHIR query; pure embeddings may retrieve a semantically similar but wrong-time record.

## Access-control trap

Never retrieve all tenants' chunks and trust the LLM to ignore unauthorized passages. Enforce source ACL filters in retrieval and recheck permissions before displaying citations. Revoke/delete updates must propagate to vector index, text index, caches, summaries, and retention-managed archives.

## Evaluation

Measure retrieval **recall@k**, precision@k, ranking quality, evidence freshness, hallucination/factual accuracy, citation support, answer abstention when evidence missing, sensitive-data leakage, cost, and latency. Build a representative labeled evaluation set, including negative cases and adversarial documents. Track changes whenever embedding model, chunking, reranker, prompt, or LLM changes.

**Technical example:** A clinician asks "What was the last potassium result?" Search structured lab observations by patient, code, effective time, and status first; use a model only to summarize authorized results. This is safer than semantic search over 20 years of unstructured notes as the sole source.
