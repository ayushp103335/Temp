# Caching Fundamentals, Hierarchies, and Eviction

A cache stores a copy or derived result nearer to its consumer to reduce repeated computation or network/storage access. Caches improve latency and throughput *when repeated work exists*; they introduce staleness, invalidation, memory cost, and failure modes.

## Where caches can live

- **Client/browser cache:** static assets, HTTP responses under defined caching directives.
- **CDN edge cache:** public/versioned objects close to users.
- **Reverse-proxy/web-server cache:** repeatable HTTP responses at an ingress layer.
- **Application local cache:** process-memory lookup; fast but inconsistent across replicas.
- **Distributed cache:** Redis or equivalent shared cache for services.
- **Database buffer/cache:** DB pages and query engine memory; often automatic.

## Hit ratio and Amdahl-style limitation

If 90% of 1,000 incoming GET/s are cache hits, only about 100/s reach the database *for that read path* under simplified uniform assumptions. But if a single hot key expires and 500 clients concurrently miss, the DB may receive a sudden wave of expensive queries. A high average hit ratio hides a tail-latency problem.

## TTL, eviction, and invalidation

**TTL** limits freshness duration; eviction removes entries under memory pressure. Popular policies include LRU (least recently used), LFU (least frequently used), and variants. An LRU algorithm may perform poorly for large scans that displace useful entries. TTL does not provide a hard correctness guarantee for all caching systems if invalidation races or stale replicas exist.

**Cache key design:** include tenant, locale, permissions or data-version identifiers where response varies by them. If `profile:123` is shared across tenants, one user's cached response could leak. Never assume the application-layer authorization check automatically applies to a CDN response served before the request reaches the API.

## Technical example

Cache the count of completed jobs per tenant for 20 seconds. Key: `tenant:17:completed-count:v3`; value: `431`; TTL: `20`. A new job completion might not appear immediately. This is acceptable for a dashboard if the UI labels it as approximate/recent. It is **not** acceptable for a financial statement that requires an exact committed balance.

**Design judgment:** Measure DB query time and frequency before adding a cache. A 3 ms indexed query at 20 RPS may not justify another operational dependency.
