# Cache Stampedes, Hot Keys, and Consistency

A cache is another distributed system component and can become the bottleneck. Avoid treating it as a magical shield for the database.

## Failure patterns

- **Cache stampede:** many clients concurrently recompute an expired entry.
- **Hot key:** a single key receives disproportionate traffic, saturating one cache shard.
- **Cache penetration:** repeated requests for nonexistent keys bypass caching (mitigate with short-lived negative caching and authorization-aware safeguards).
- **Cache avalanche:** correlated TTL expiry or a cache cluster outage sends a surge to the database.
- **Stale data:** delayed invalidation or replicas return incorrect values for a sensitive workflow.

## Techniques

Single-flight/coalescing allows only one refill per key while other requests wait or receive stale-but-allowed data. Add TTL jitter to avoid synchronized expiry; bound cache misses per service; use stale-while-revalidate for content where outdated data is safe; prewarm critical keys judiciously; use bulkheads and DB admission control when the cache is unavailable.

```text
key expires at 12:00:00
5,000 clients miss -> 5,000 DB queries (bad)
with single-flight -> 1 DB query + waiters (if implementation is correct)
```

A distributed lock for cache refill must have bounded lease/fencing considerations; single-flight within one process does not deduplicate misses across replicas. Be careful caching errors: a temporary `503` should not become a long-lived "not found" response.

## Cache correctness contract

Specify max staleness by field. An item detail image might tolerate 5 minutes. An access revocation often demands immediate or tightly bounded enforcement; every service cannot rely on a 30-minute positive authorization cache after privileges change. Design invalidation messages, short TTLs, or request-time policy evaluation accordingly.

**Failure drill:** Turn off Redis for five minutes under 500 RPS and measure origin DB load, error rate, p99 latency, and recovery after cache restoration. If the fallback collapses the DB, the cache merely hid a capacity risk.
