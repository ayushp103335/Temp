# Cache-Aside, Write-Through, Write-Behind, and Refresh-Ahead

Caching patterns differ in which component performs writes and what guarantees are lost during failure.

## Cache-aside (lazy loading)

```text
GET key -> cache hit -> return
        -> miss -> DB -> populate cache -> return
```

On write, update the DB then invalidate affected cache entries. The ordering has races: an old read can populate stale data after an invalidation. Strategies include versioned keys, bounded TTL, cache write locks, or version checks. Cache-aside is a common default because the DB remains authoritative.

## Write-through

A write is applied to the cache and the backing store as part of the write path, according to a defined order/acknowledgment contract. Simple diagrams often imply both succeed atomically, but most cache+DB combinations cannot guarantee atomicity across systems. If the DB commit fails after cache update, rollback or invalidation is necessary. Define the exact failure behavior.

## Write-behind (write-back)

The cache accepts a write and asynchronously persists it to storage. This can batch writes and reduce foreground latency, but an acknowledgment before durable persistence risks data loss when the cache fails. It is inappropriate for critical financial/clinical records unless the "cache" has suitable durable logging and recovery guarantees.

## Refresh-ahead

An application refreshes popular entries before TTL expiry. It avoids hot-key misses but can waste work on data no longer requested; a failed refresh must not silently extend the freshness of obsolete data. Use refresh windows, single-flight per key, and max-stale rules.

## Compare the patterns

| Pattern | Read miss | Write behavior | Common trade-off |
|---|---|---|---|
| Cache-aside | App reads DB and fills cache | DB write plus invalidation | Stale windows, duplicate fills |
| Write-through | Reads cache after population | Sync cache/backing-store path | Write latency and cross-system failure |
| Write-behind | Usually reads cache | Async persistence | Potential acknowledged-write loss |
| Refresh-ahead | Preemptively refreshes | Often combined with cache-aside | Wasted refresh and race complexity |

**Exercise:** Design `GET /drug-catalog/{id}` caching (updates hourly) versus `GET /account/balance` (needs exact committed balance). Decide TTL, invalidation, authoritative store, and fallback when Redis fails.
