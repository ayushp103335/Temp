# Glossary: Key Terms for Beginners and Architects

The definitions below are deliberately concise; each linked concept is explained through technical examples in the main chapters.

### A–D

- **ACL (Access Control List):** explicit permissions applied to an object, directory, or network rule.
- **ACID:** atomicity, consistency, isolation, durability; transaction properties.
- **ADR:** architecture decision record capturing context, alternatives, choice, consequences.
- **Agent:** model-driven controller that proposes and executes bounded tool actions via a policy layer.
- **ANN:** approximate nearest-neighbor search; faster approximate vector retrieval.
- **API:** contract through which software components exchange requests and responses.
- **AP (CAP):** a system favoring availability of non-failed nodes under partition, accepting weaker consistency.
- **Atomicity:** an operation's transactional effects commit or abort as a unit.
- **Availability:** fraction of eligible time or requests that meet a defined success condition.
- **Backpressure:** downstream capacity constraint signaled/enforced against upstream producers.
- **BFF:** Backend for Frontend; adapter specialized for a client experience.
- **Blast radius:** portion of users/services affected by a failure or change.
- **Broker:** middleware delivering messages between producers and consumers.
- **B-tree/B+tree:** ordered index tree optimized for storage-page traversal.
- **Cache-aside:** app reads cache first and populates on miss from authoritative store.
- **Cache stampede:** many consumers simultaneously miss and recompute one item.
- **CAP:** consistency, availability, partition-tolerance trade-off under a partition.
- **CDC:** change data capture from committed database mutations.
- **CDN:** geographically distributed caching/delivery network.
- **Cell:** semi-isolated workload unit serving assigned traffic/tenants.
- **Circuit breaker:** failure-aware gate that temporarily stops requests to a sick dependency.
- **Consistency model:** formal expectations for observable read/write ordering or freshness.
- **Consumer group:** cooperating consumers sharing partitions/work for a subscription.
- **Container:** isolated process environment sharing host kernel.
- **CQRS:** separate command and query models for different access needs.
- **CRDT:** mergeable replicated data structure designed for convergence under concurrency.
- **Cursor pagination:** fetch pages based on stable ordered positions, rather than large offsets.
- **Dead-letter queue:** destination for messages that cannot be processed under retry policy.
- **Denormalization:** purposeful duplication/precomputation for faster reads.
- **Deployment stamp:** repeatable, isolated deployment unit of workload resources.
- **DNS:** domain name system resolving resource names to records such as IPs.
- **Durability:** committed data survives defined failure conditions.

### E–L

- **Edge:** network/cloud infrastructure closer to request origin; often CDN/ingress.
- **ETL/ELT:** transform-before-load / load-before-transform data pipelines.
- **Event sourcing:** authoritative state reconstructed from a sequence of domain events.
- **Event time:** timestamp when an event occurred in the source domain.
- **Failover:** transition traffic/leadership to a replacement after failure.
- **Fencing token:** generation number preventing stale lease holders from acting.
- **Federation (DB):** division of data across domain-specific databases.
- **Gateway:** entry point for routing/edge policy, possibly protocol translation.
- **Geode:** regional symmetrical deployment pattern for geo-distributed service.
- **gRPC:** RPC framework commonly using HTTP/2 and Protocol Buffers.
- **HLD:** high-level architecture design of components and interactions.
- **Horizontal scaling:** add parallel instances to increase service capacity.
- **Hot key:** disproportionately accessed key saturating a cache/shard.
- **HTTP:** application protocol with methods, statuses, headers, and bodies.
- **HTTP/3:** HTTP over QUIC/UDP transport.
- **Idempotency:** repeating a logical operation has the same intended observable effect as one execution.
- **Index:** auxiliary structure accelerating access at storage/write cost.
- **Ingress:** entry path through which network traffic reaches a workload.
- **Isolation level:** guarantee controlling visibility/interference between concurrent transactions.
- **JWT:** signed/encoded token format whose claims require verification.
- **Keyset pagination:** pagination using indexed ordering/cursor predicates.
- **KMS:** key-management system for scoped cryptographic key operations.
- **L4/L7:** transport/application layers, often used to describe load balancing.
- **Lamport clock:** logical mechanism for respecting happens-before causal order.
- **Latency:** time required for an operation, often measured by percentiles.
- **Lease:** time-limited ownership of a task or resource.
- **Little's Law:** `L = lambda × W` in a stable queueing system.
- **LLD:** low-level design of classes, operations, state machines, and data rules.
- **Load shedding:** reject lower-priority requests to protect service under overload.
- **LSM tree:** storage-engine structure balancing writes, compaction and reads.

### M–R

- **Materialized view:** stored precomputed query result, periodically or incrementally refreshed.
- **mTLS:** mutual TLS authentication between both TLS peers.
- **Multi-leader:** replication topology where multiple nodes accept writes and reconcile.
- **N+1 query:** repeated per-item fetches generating excessive DB round trips.
- **NoSQL:** family of non-relational models, including document/key-value/graph/wide-column.
- **Object storage:** service storing blobs addressed by keys rather than relational rows.
- **OLAP:** online analytical processing optimized for scans and aggregations.
- **OLTP:** online transaction processing optimized for frequent small updates/queries.
- **Outbox:** event records committed atomically with business state for reliable publish.
- **P95/P99:** latency threshold at or below which 95%/99% of measured operations finish.
- **PACELC:** partition availability/consistency; else latency/consistency trade-off framing.
- **Partition:** division of a logical data set by key/range/time/etc.
- **PITR:** point-in-time recovery using backup plus replayable logs.
- **Primary-replica:** leader-authoritative write topology with replicated followers.
- **Quorum:** overlapping group of votes/acks required for consensus or configured operations.
- **Rate limiting:** cap operations by rate/window and scope.
- **RAG:** retrieval-augmented generation combining authorized evidence retrieval and model output.
- **RDBMS:** relational database management system.
- **Read replica:** copy optimized to serve reads, often with replication lag.
- **Read-your-writes:** session guarantee that later reads observe own acknowledged writes.
- **Replication:** maintain copies of data across nodes.
- **Retry storm:** runaway retries that amplify failure load.
- **RPO:** maximum tolerated recoverable data-loss window.
- **RTO:** maximum tolerated recovery time after disruption.

### S–Z

- **Saga:** cross-service workflow with local commits and compensating actions.
- **Saturation:** degree to which finite service resources are exhausted.
- **Schema:** declared shape/types/constraints of records or messages.
- **Service discovery:** map logical service names to reachable instances.
- **Shard:** data partition hosted on a distinct database unit/node.
- **Sidecar:** colocated auxiliary process/container providing network/log features.
- **SLI:** service level indicator, measured user-impact signal.
- **SLO:** service level objective, target value for an SLI.
- **SLA:** service level agreement with contractual terms/remedies.
- **Snowflake ID:** time/worker/sequence-based unique ID scheme with clock considerations.
- **Split-brain:** two leaders act as authoritative concurrently.
- **SSE:** server-sent events, one-way HTTP event stream to clients.
- **Strong consistency:** vague shorthand; specify linearizability or other exact model.
- **Tail latency:** behavior at high percentiles such as p99/p99.9.
- **Tenant:** isolated customer/account context in a shared platform.
- **Throttling:** restricting admitted throughput/concurrency to protect resources.
- **TLS:** authenticated encrypted transport protocol.
- **Token bucket:** limiter with refill rate and burst capacity.
- **Trace:** connected spans explaining one request's cross-component work.
- **Transaction:** atomic or isolation-controlled unit of database changes.
- **Two-phase commit:** coordinator-mediated prepare/commit protocol across participants.
- **WAL:** write-ahead log used for storage recovery and replication.
- **Watermark:** estimate of event-time progress in stream processing.
- **WebSocket:** bidirectional message transport over a long-lived connection.
- **Write skew:** concurrent transactions modify separate rows to violate a shared invariant.
- **Zero trust:** security approach not granting implicit trust based only on network location.
