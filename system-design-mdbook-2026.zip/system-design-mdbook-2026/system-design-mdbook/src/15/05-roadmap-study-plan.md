# Structured Study Plan, Mastery Milestones, and Architecture Review Template

This is a self-paced plan. The week counts below assume roughly 7–9 focused hours/week; extend difficult sections rather than skipping exercises.

| Weeks | Read and practice | Proof of learning |
|---|---|---|
| 1–2 | Parts 00–01 | Trace a request, write FR/NFRs, capacity table |
| 3–4 | Part 02 | Diagnose DNS/TCP/TLS/LB outage on paper |
| 5–6 | Part 03 | Design modular monolith + API contracts |
| 7–10 | Part 04 | SQL/index plan, sharding math, backup restore, CAP argument |
| 11 | Part 05 | Choose safe cache keys/invalidation; failure scenario |
| 12–13 | Part 06 | Implement idempotent outbox and backpressure |
| 14–15 | Part 07 | Draw Raft quorum, conflict policy, distributed transaction |
| 16–17 | Part 08 | SLO, active/passive DR, chaos runbook |
| 18–19 | Parts 09–10 | Threat model, telemetry dashboard, canary plan |
| 20–21 | Part 11 | Select patterns and reject unnecessary ones |
| 22–23 | Part 12 | Design evaluated RAG/agent architecture with access controls |
| 24–26 | Parts 13–14 | Complete 3 full system designs and capstone lab |

## Architecture review template

```markdown
# Design review: <system>
## 1. Context and business purpose
## 2. Functional operations and excluded scope
## 3. Users, traffic assumptions, peak/average, data volume
## 4. Invariants, SLOs, data classification, RTO/RPO
## 5. API/event contracts and ownership
## 6. Architecture: context, component, sequence, deployment diagrams
## 7. Database schema, indexes, transactions, consistency model
## 8. Capacity math and bottleneck analysis
## 9. Security, privacy, tenant isolation, threat model
## 10. Failure-mode matrix, retry/dedup/DR
## 11. Observability, alerting, runbooks, operator workflows
## 12. Deployment, migration, rollback, test evidence
## 13. Cost and alternatives
## 14. ADRs and reconsideration triggers
## 15. Open questions, risks, owners, deadlines
```

## Final milestone examination

Pick three systems with different dominant constraints: (1) high-read URL shortener, (2) highly correct payment ledger, (3) high-volume asynchronous AI extraction. For each, design a v1 for 1,000 users and v2 for 10 million users. Explain which components change, which do not, and which new failure modes arise.

In a final architecture defense, expect your reviewer to ask: "What if your DB primary dies between COMMIT and replica acknowledgment?", "What if your queue delivers twice?", "What if one tenant contributes 90% of load?", "What if this data cannot leave the region?", "What if your model is confidently wrong?", and "Which component would you delete to simplify operations?"

**Mastery criterion:** You can give a reasoned opinion on each item of the coverage matrix, including measurable requirements, internals, alternative, fault behavior, and evidence required to validate your claim.
