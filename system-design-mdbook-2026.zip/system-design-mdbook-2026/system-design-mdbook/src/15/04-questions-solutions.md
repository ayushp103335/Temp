# Scenario Questions, Worked Reasoning, and Self-Assessment

Use these questions to develop an architectural opinion rather than memorizing vendor names. For each, state assumptions, draw a diagram, calculate capacity, identify failure modes, and say why you rejected alternatives.

## Foundation and network (1–8)

1. An HTTP server process is running, but requests time out. **Answer outline:** check bind address/port, DNS, route, firewall, TLS, load balancer readiness, thread/connection exhaustion, downstream dependency, and tracing. Process health alone is insufficient.
2. Does adding eight API instances always multiply throughput by eight? **No:** shared DB/locks/vendor quotas or shared CPU/network constraints may be limiting; test capacity per tier and failure margin.
3. CDN cache hit ratio is 98%, but p99 is high. **Look at:** cold miss latency, cache stampede, hot keys, origin tail, TLS and geography; averages hide a small set of severe misses.
4. Why does an HTTP timeout not prove payment failure? **Because:** server might have committed before response was lost; query or retry with same idempotency key.
5. What does a reverse proxy do that DNS alone does not? **Answer:** per-request/connection health-aware routing, termination, headers, policy and balancing; DNS resolves names but does not guarantee safe instant failover.
6. Is UDP always unreliable? **Answer:** UDP itself doesn't guarantee delivery, but QUIC on UDP implements reliable streams; design at the actual protocol level.
7. Can TLS protect patient names if an attacker captures traffic on a cable? **In transit between TLS endpoints, yes** with proper config; not if an endpoint is compromised or if plaintext exists after termination.
8. How do you prevent a disconnected switch from taking 100 users offline? **Answer:** redundant physical paths, port/link monitoring, failover topology (e.g., LACP/MLAG/appropriate routing), tested network convergence, correct spanning-tree design, and realistic failure-domain planning.

## Database and distributed consistency (9–18)

9. A student table is sharded by ID; user searches by name. **Answer:** scatter-gather or maintain a name->IDs search/routing index, then fetch by ID; name may be non-unique and authorization must still apply.
10. Why can `key % 5` make resharding expensive after `key % 4`? **Answer:** remaps many keys. Use stable logical buckets/consistent hashing and a versioned migration protocol.
11. What can be lost when an async primary fails? **Answer:** acknowledged writes not replicated before failure. State RPO and choose commit acknowledgment semantics deliberately.
12. Why is a replica not a backup? **Answer:** bad deletes/corruption can replicate; backup restores earlier consistent states.
13. What is write skew? **Answer:** two concurrent transactions read an invariant then update different rows, each individually valid but collectively violating a shared condition under insufficient isolation.
14. Why is "CAP: choose any two" misleading? **Answer:** partition is a condition, and C/A have precise meanings; specify operation and network-failure model.
15. Is active-active application routing the same as multi-writer database replication? **No:** apps may serve both regions while all writes go to one primary; data conflict semantics differ enormously.
16. When would a CRDT be suitable? **Answer:** mergeable data such as counters/sets with defined invariants; not generic money balance decrements.
17. What if an old lease holder resumes after failover? **Answer:** require fencing token/resource checks; time-limited lock alone may not enforce safety.
18. Why can serializable isolation increase retries? **Answer:** transactions may abort to preserve a serializable order; application must safely retry with a budget and stable logical IDs.

## Messaging, caching, and reliability (19–30)

19. DB job row commits, broker publish fails. **Answer:** outbox/reconciler; return success only for durable accepted state.
20. Worker commits DB update then crashes before ack. **Answer:** broker can redeliver; idempotent consumer should avoid duplicate effects.
21. Is Kafka exactly-once across an arbitrary payment API? **No:** broker guarantees don't automatically make external side effects atomic; use provider idempotency, durable state and reconciliation.
22. A queue grows 100 messages/s indefinitely. **Answer:** permanent capacity mismatch; rate-limit intake, add capacity, reduce work, or relax contract; infinite buffering impossible.
23. Redis fails at 1,000 RPS. **Answer:** load-shed/coalesce fallback reads, protect DB, recover cache without avalanche; test this path before incident.
24. User loses access but a cache holds a 30-min positive authorization. **Answer:** invalidation or short-lived verified entitlement; privacy/security cannot rely on stale positive decisions without bounded risk.
25. Why is write-behind dangerous for settled balances? **Answer:** ack precedes durable source update; cache failure can lose acknowledged financial writes.
26. What is the difference between retry and compensation? **Answer:** retry attempts intended action again; compensation adds a new business action to mitigate committed previous step.
27. How to prevent a slow batch job from blocking urgent requests? **Answer:** fair scheduling/priority queues, workload isolation, worker reservations, bounded concurrency; manage starvation.
28. How do you calculate time-based 99.9% monthly downtime for 30 days? **Answer:** `0.001 × 43,200 = 43.2 minutes`.
29. Two 99.9% services are required in sequence. Combined availability? **Illustrative independent case:** `.999^2 ≈ 99.8001%`; real correlated failures worsen predictions.
30. Why does a breaker not replace a timeout? **Answer:** breaker opens after observed failures; each attempt still needs a bounded deadline and cancellation policy.

## Security, operations, and AI (31–40)

31. A signed JWT is valid, but user accesses another tenant's data. **Answer:** signature verifies identity/claims, not per-record authorization; enforce tenant/object policy at service/data boundary.
32. What is the difference between encryption and hashing? **Answer:** decryption is possible with keys; a cryptographic hash is not intended to be reversed; password storage needs password-specific salted KDF.
33. Why is logging a full inference prompt risky? **Answer:** sensitive data/credentials can leak to telemetry vendors/long retention; log redacted structured metadata instead.
34. A deployment is green but user requests fail. **Answer:** readiness/health may not check actual workflow; use SLIs, trace, synthetic transaction and roll back if budget burns.
35. Why are metric labels with `user_id` risky? **Answer:** unbounded cardinality creates huge time-series count; use logs/traces for high-cardinality IDs.
36. A clinician asks for the most recent lab result. Pure vector search? **Answer:** structured observation query with patient, code, time/status is typically safer; retrieve textual evidence only where needed.
37. A RAG index is tenant-filtered but answer cites an unauthorized old note. **Answer:** enforce ACL at ingestion, retrieval and output, version/expire indexes, recheck source permissions and test cross-tenant access.
38. Can an LLM choose to call a payment tool with arbitrary parameters? **Answer:** only through a deterministic policy layer that validates schema, authorization, action scope, limits and approval requirements.
39. What if a model provider returns 429 for one minute? **Answer:** bounded retries/backoff, rate/concurrency limits, queue-age monitoring, approved fallback or explicit degraded status; avoid retry amplification.
40. A multi-region design promises RPO=0 with async replication. **Answer:** unsupported for regional disaster of primary before replication; change durability/ack model or correct requirement.

## Self-grading rubric

For each question, rate 0 (cannot define), 1 (definition only), 2 (explains technical mechanism), 3 (handles failure and trade-offs), or 4 (designs, measures, tests, and defends). Aiming for **3+ across all major categories** is a more useful objective than memorizing 100 definitions. Explain your answer aloud and deliberately challenge it with a changed constraint.
