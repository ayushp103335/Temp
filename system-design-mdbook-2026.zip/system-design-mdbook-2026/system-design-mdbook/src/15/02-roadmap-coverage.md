# Complete roadmap.sh Topic Coverage Matrix

**Scope:** This table maps the topics visible in the official [roadmap.sh System Design Roadmap PDF](https://roadmap.sh/pdfs/roadmaps/system-design.pdf), reviewed November 2026, to chapters in this book. The roadmap repeats several patterns under different families; the book explains the concept once and maps every appearance. Some names such as *master-slave* are legacy terms; current chapters use *primary-replica* or *leader-follower*. Each entry is a **coverage pointer**, not a claim that every vendor-specific implementation is exhaustively documented.

## Foundations, performance, consistency, availability

| Roadmap node or subtopic | Covered in |
|---|---|
| What is System Design; How to approach System Design | [Method](../01/01-how-to-design.md), [Requirements](../01/02-requirements.md) |
| Performance vs Scalability | [Capacity](../01/03-capacity-math.md), [Load Balancing](../02/04-load-balancers.md) |
| Latency vs Throughput | [Capacity](../01/03-capacity-math.md), [Performance](../10/03-performance-antipatterns.md) |
| Availability vs Consistency | [Consistency](../04/07-consistency-cap.md), [SLOs](../08/01-availability-slos.md) |
| Weak Consistency; Eventual Consistency; Strong Consistency | [Models](../04/07-consistency-cap.md) |
| CAP Theorem; AP Availability+Partition Tolerance; CP Consistency+Partition Tolerance | [CAP](../04/07-consistency-cap.md) |
| 99.9% Availability — three 9s; 99.99% — four 9s | [Availability math](../08/01-availability-slos.md) |
| Availability in Parallel vs Sequence; Availability in Numbers | [Availability math](../08/01-availability-slos.md) |
| Fail-Over; Active-Active; Active-Passive | [Failover](../08/02-failover.md), [Backups/DR](../04/08-backups-recovery.md) |
| Replication; Master-Slave; Master-Master | [Replication](../04/05-replication.md), [Multi-region](../07/05-crdts-multiregion.md) |

## Jobs, network, application, data and caching

| Roadmap node or subtopic | Covered in |
|---|---|
| Background Jobs; Event-Driven; Schedule-Driven; Returning Results | [Background Jobs](../06/01-background-jobs.md) |
| Domain Name System | [DNS](../02/02-dns-routing.md) |
| Content Delivery Networks; Pull CDNs; Push CDNs | [CDNs](../02/05-cdn-edge.md) |
| Load Balancers; LB vs Reverse Proxy; Load Balancing Algorithms | [DNS/proxies](../02/02-dns-routing.md), [LB](../02/04-load-balancers.md) |
| Layer 7 Load Balancing; Layer 4 Load Balancing; Horizontal Scaling | [LB](../02/04-load-balancers.md) |
| Application Layer; Microservices; Service Discovery | [Architecture styles](../03/02-architecture-styles.md), [Discovery](../02/02-dns-routing.md) |
| Databases; SQL vs NoSQL | [SQL](../04/01-relational.md), [Database types](../04/04-database-types.md) |
| NoSQL Key-Value Store; Document Store; Wide Column Store; Graph Databases | [Database types](../04/04-database-types.md) |
| RDBMS Replication; Sharding; Federation; Denormalization; SQL Tuning | [Replication](../04/05-replication.md), [Sharding](../04/06-sharding.md), [SQL](../04/01-relational.md), [Indexes](../04/02-indexes-plans.md) |
| Caching; Refresh Ahead; Write-behind; Write-through; Cache Aside | [Cache patterns](../05/02-cache-patterns.md) |
| Client Caching; CDN Caching; Web Server Caching; Database Caching; Application Caching | [Cache hierarchy](../05/01-cache-fundamentals.md) |
| Asynchronism; Back Pressure; Task Queues; Message Queues | [Queues](../06/02-queues-vs-streams.md), [Backpressure](../06/05-backpressure-streams.md) |
| Communication; HTTP; TCP; UDP; RPC; gRPC; REST; GraphQL | [Networks](../02/01-network-layers.md), [HTTP/TLS](../02/03-http-tls.md), [API contracts](../03/03-api-contracts.md) |
| Idempotent Operations | [Delivery/idempotency](../06/03-delivery-idempotency.md) |

## Performance, monitoring, and cloud patterns

| Roadmap node or subtopic | Covered in |
|---|---|
| Improper Instantiation; Monolithic Persistence; Noisy Neighbor | [Performance antipatterns](../10/03-performance-antipatterns.md) |
| Synchronous I/O; Extraneous Fetching; Busy Database; Busy Frontend | [Performance antipatterns](../10/03-performance-antipatterns.md) |
| Chatty I/O; Retry Storm; No Caching | [Performance antipatterns](../10/03-performance-antipatterns.md) |
| Health Monitoring; Availability Monitoring; Performance Monitoring | [Monitoring](../10/02-slo-alerts-incidents.md) |
| Security Monitoring; Usage Monitoring; Instrumentation; Visualization & Alerts | [Observability](../10/01-observability.md), [Alerts](../10/02-slo-alerts-incidents.md) |
| Strangler Fig; Sidecar; Static Content Hosting; Leader Election | [Implementation patterns](../11/01-implementation-patterns.md) |
| CQRS; Pipes & Filters; Ambassador; Gateway Routing | [Implementation patterns](../11/01-implementation-patterns.md) |
| Gateway Offloading; Gateway Aggregation; External Config Store | [Implementation patterns](../11/01-implementation-patterns.md) |
| Compute Resource Consolidation; Backends for Frontend; Anti-Corruption Layer | [Implementation patterns](../11/01-implementation-patterns.md) |
| Valet Key; Static Content Hosting (data management) | [Data patterns](../11/02-data-patterns.md) |
| Sharding; Materialized View; Index Table | [Data patterns](../11/02-data-patterns.md) |
| Event Sourcing; CQRS (data management); Cache-Aside (data management) | [Data patterns](../11/02-data-patterns.md) |
| Sequential Convoy; Scheduling Agent Supervisor | [Messaging patterns](../11/03-messaging-patterns.md) |
| Queue-based Load Leveling; Publisher/Subscriber; Priority Queue | [Messaging patterns](../11/03-messaging-patterns.md) |
| Pipes and Filters; Competing Consumers; Choreography | [Messaging patterns](../11/03-messaging-patterns.md) |
| Claim Check; Async Request Reply | [Messaging patterns](../11/03-messaging-patterns.md) |
| Deployment Stamps; Geodes; Throttling; Health Endpoint Monitoring | [Reliability/security patterns](../11/04-reliability-security-patterns.md) |
| Queue-Based Load Leveling (availability/high availability) | [Reliability/security patterns](../11/04-reliability-security-patterns.md) |
| Bulkhead; Circuit Breaker | [Reliability patterns](../11/04-reliability-security-patterns.md) |
| Compensating Transaction; Leader Election; Retry | [Reliability patterns](../11/04-reliability-security-patterns.md) |
| Scheduler Agent Supervisor (resiliency) | [Reliability patterns](../11/04-reliability-security-patterns.md) |
| Federated Identity; Gatekeeper; Valet Key (security) | [Reliability/security patterns](../11/04-reliability-security-patterns.md), [Auth](../09/02-authn-authz.md) |

## Extra chapters beyond the roadmap

The original roadmap alone is not sufficient for zero-prerequisite through modern production architecture. Additional material covers: [processes/OS](../00/01-computers.md), [data formats](../00/02-programming-data.md), [TLS/HTTP3](../02/03-http-tls.md), [DB isolation](../04/03-transactions.md), [schema migration/CDC](../04/09-data-evolution.md), [consensus](../07/03-consensus.md), [SLOs/error budgets](../08/01-availability-slos.md), [zero trust](../09/01-security-basics.md), [CI/CD](../10/04-ci-cd-migrations.md), [AI-native serving](../12/01-ml-inference.md), [RAG](../12/02-rag-search.md), [agent security](../12/03-agents-mcp.md), [hands-on labs](../14/01-lab-setup.md), and [complete architecture cases](../13/01-url-shortener.md).

## Self-audit method

For each table row ask: **Can I define it? Trace its request/data path? Describe how it fails? Compare it with an alternative? Test it? State when not to use it?** If not, mark it as an active learning gap and revisit the linked chapter; the existence of a topic in a table is not evidence of mastery.
