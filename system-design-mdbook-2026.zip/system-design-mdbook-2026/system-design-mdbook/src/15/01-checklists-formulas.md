# Architect's Checklists, Equations, and Decision Tables

Use this as a practical design-review reference after studying the chapters. It is not a substitute for reasoning about requirements.

## One-page requirements checklist

- [ ] Actors, roles, tenant boundaries, authorization, sensitive-data classification.
- [ ] Functional operations, API/event contracts, error conditions, idempotency.
- [ ] Peak and average RPS/jobs/s; payload size distribution; read/write ratio.
- [ ] End-user latency objective (p95/p99), job-deadline objective, consistency model.
- [ ] Availability SLO/SLI, RTO, RPO, data durability, recovery geography.
- [ ] Data model, keys, indexes, joins, hot partitions, retention, legal constraints.
- [ ] Capacity of API, DB, cache, queue, workers, network, and vendors.
- [ ] Partial failures, overload, retries, deduplication, compensation, DR.
- [ ] Observability (logs/metrics/traces), alerts, dashboards, on-call runbooks.
- [ ] Deploy, migrate, rollback, security tests, load tests, restore drills.
- [ ] Cost model, operational staffing, vendor lock-in, reconsideration triggers.

## Critical formulas

| Calculation | Formula | Caveat |
|---|---|---|
| Average RPS | `daily requests / 86,400` | Only appropriate for 24-hour even traffic |
| CPU demand | `RPS × CPU sec/request` | CPU work is different from wall-clock I/O wait |
| Concurrency (Little's Law) | `L = lambda × W` | Stable system with consistent units |
| Nominal parallel-worker throughput | `slots / seconds_per_job` | Assumes slots fully occupied; ignores retries/variation |
| Queued backlog growth | `(arrival_rate - service_rate) × duration` | While input exceeds output |
| Monthly unavailability budget | `(1 - availability_target) × minutes/month` | Time-based availability definition only |
| Series availability | `product(component availabilities)` | Assumes independence and every component required |
| Parallel redundancy | `1 - product(failure_probabilities)` | Assumes independent failures and successful failover |
| Raw data bytes | `items × average bytes/item` | Add indexing, versions, replicas, metadata |
| Network bits/s | `bytes/s × 8` | Overhead, retransmits, congestion excluded |
| Cache misses/s | `RPS × (1-hit_ratio)` | Distribution/hot-key effects ignored |
| SLO permitted bad requests | `eligible requests × (1-SLO)` | Respect error classification |
| Target workers | `arrival_rate × occupancy_time / target_utilization` | Must validate with service-time distribution |

## Decision rules worth memorizing

1. **Correctness before optimization:** define invariants and allowable staleness.
2. **Measure before scaling:** adding capacity to non-bottleneck tiers is wasted.
3. **Durability is end-to-end:** a message in a volatile queue may not mean a recoverable job.
4. **Retries duplicate effects unless controlled:** design idempotency and unknown-outcome handling.
5. **Queues smooth bursts, not permanent overload.**
6. **Replication is not backup.**
7. **Active-active APIs are not the same as active-active multi-writer databases.**
8. **An authenticated user is not necessarily authorized for the requested row.**
9. **Cache keys are authorization-sensitive and invalidation is a correctness problem.**
10. **A healthy process is not proof of a healthy business workflow.**
11. **Global ordering, strong consistency, and zero RPO carry real costs.**
12. **The simplest design satisfying measured requirements is often the best.**

## A design answer in five sentences

"Our required operations are X and Y, with peak load Z and correctness invariant I. The initial architecture uses A as authoritative data and B for asynchronous work. We can meet latency target L by tuning Q and scaling workers while keeping writes consistent. Failures F and G are handled with idempotency, retries, recovery, and tested rollback; metrics M prove whether those measures work. If sustained traffic, recovery requirements, or regional constraints change by threshold T, we will revisit design choice D."
