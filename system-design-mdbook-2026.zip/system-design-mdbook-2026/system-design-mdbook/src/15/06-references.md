# Authoritative References, Edition Notes, and Update Policy

This book is self-contained for conceptual learning. Links below give standards, current specifications, implementation guides, and deeper research. External documentation can change after publication; revisit it when deploying production systems.

## Primary taxonomy and mdBook

- [roadmap.sh System Design Roadmap](https://roadmap.sh/system-design?fl=1) and [official visual PDF](https://roadmap.sh/pdfs/roadmaps/system-design.pdf) — core taxonomy and topic coverage reference; reviewed November 2026.
- [mdBook official guide](https://rust-lang.github.io/mdBook/) — `book.toml`, `SUMMARY.md`, build/serve, and Markdown behavior; reviewed November 2026.

## Networking and data protocols

- [RFC 9110 — HTTP Semantics](https://www.rfc-editor.org/rfc/rfc9110)
- [RFC 9114 — HTTP/3](https://www.rfc-editor.org/rfc/rfc9114)
- [RFC 9000 — QUIC Transport](https://www.rfc-editor.org/rfc/rfc9000)
- [RFC 8446 — TLS 1.3](https://www.rfc-editor.org/rfc/rfc8446)
- [RFC 1034/1035 — DNS](https://www.rfc-editor.org/rfc/rfc1034)
- [OpenAPI Specification](https://spec.openapis.org/oas/latest.html)
- [Protocol Buffers Developer Guide](https://protobuf.dev/overview/)

## Databases and distributed systems

- [PostgreSQL manual: Transactions and Concurrency](https://www.postgresql.org/docs/current/mvcc.html)
- [PostgreSQL: EXPLAIN](https://www.postgresql.org/docs/current/using-explain.html)
- [Martin Kleppmann: Designing Data-Intensive Applications](https://dataintensive.net/) — deeper conceptual study (commercial book; this book does not reproduce its text).
- [Raft consensus publication](https://raft.github.io/)
- [Apache Kafka documentation](https://kafka.apache.org/documentation/)
- [RabbitMQ documentation](https://www.rabbitmq.com/docs)
- [Redis documentation](https://redis.io/docs/latest/)

## Cloud, SRE, patterns, and telemetry

- [Microsoft Cloud Design Patterns](https://learn.microsoft.com/en-us/azure/architecture/patterns/) — detailed source for the pattern family reflected in the roadmap.
- [AWS Well-Architected Framework](https://docs.aws.amazon.com/wellarchitected/latest/framework/the-pillars-of-the-framework.html) — six architecture pillars.
- [Google Cloud Well-Architected Framework](https://docs.cloud.google.com/docs/get-started/well-architected-framework) — cloud-wide best practices.
- [Google Site Reliability Engineering books](https://sre.google/books/) and [SRE Workbook](https://sre.google/workbook/) — service objectives, error budgets, on-call and change safety.
- [OpenTelemetry documentation](https://opentelemetry.io/docs/) — vendor-neutral logs, metrics, traces, and instrumentation.
- [Kubernetes documentation](https://kubernetes.io/docs/home/) — container orchestration and workload primitives.

## Security and modern AI

- [OWASP Top 10:2025 Web](https://top10.owasp.org/2025/) and [OWASP API Security Top 10:2023](https://owasp.org/API-Security/editions/2023/en/0x00-header/) — application/API risks current as of this edition.
- [NIST SP 800-207 — Zero Trust Architecture](https://www.nist.gov/publications/zero-trust-architecture) and [SP 800-207A](https://csrc.nist.gov/pubs/sp/800/207/a/final).
- [NIST AI RMF Generative AI Profile](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence).
- [OWASP GenAI LLM Top 10, 2026 release](https://github.com/GenAI-Security-Project/GenAI-LLM-Top10) — current source, published August 4, 2026 as reported by the project.
- [Model Context Protocol specification](https://modelcontextprotocol.io/specification/) — consult latest transport, security, and authorization rules.
- [Google Cloud: RAG overview](https://cloud.google.com/use-cases/retrieval-augmented-generation).

## Editorial and maintenance policy

**Edition cut-off:** November 5, 2026. This is an independently authored technical learning text based on publicly documented engineering principles; it is not endorsed by roadmap.sh or the vendors above. Numeric workloads are explicitly illustrative unless cited. Product pricing, cloud limits, legislation, authentication standards, and model/provider behavior change rapidly: verify against primary sources before implementing.

**Change procedure:** For every major revision, (1) compare the current roadmap to the coverage matrix, (2) update standards and security versions, (3) run all labs/tests, (4) validate internal navigation and outbound references, (5) review technical examples for correctness and privacy assumptions, and (6) record a dated changelog entry. No educational text can permanently contain every future system-design concept; systematic review is part of making it a reliable reference.
