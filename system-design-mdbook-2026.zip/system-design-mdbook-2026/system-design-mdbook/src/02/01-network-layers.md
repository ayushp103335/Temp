# Networks, IP, TCP, UDP, QUIC, and OSI

Network communication is the movement of bytes between programs on different computers. A **packet** is a bounded unit transferred through a network; a **socket** is an OS interface through which a process communicates. An IP address identifies a network endpoint; a port number identifies a service on that endpoint.

## Layered communication

The seven-layer OSI reference model is useful for debugging even though the Internet commonly uses the TCP/IP stack. The rough correspondence is: OSI 1 physical (cables, radio), 2 data link (Ethernet/Wi-Fi and MAC), 3 network (IP and routing), 4 transport (TCP/UDP), 5–6 session/presentation functions (often part of the app or TLS), and 7 application (HTTP, DNS, SMTP, gRPC).

```text
App JSON -> HTTP frame/message -> TLS encryption -> TCP segments
         -> IP packets -> Ethernet frames -> electrical/optical/radio signals
```

For HTTP/3 the transport path differs: `HTTP/3 -> QUIC -> UDP -> IP`. A reverse proxy can terminate TLS and create a *new* connection to the backend. Therefore a client-to-edge TLS session does not imply encrypted edge-to-backend traffic unless you configure it.

## TCP details

TCP provides an ordered byte stream with retransmission, flow control, and congestion control. A connection typically starts with a SYN, SYN-ACK, ACK handshake. It does **not** preserve application message boundaries: if the client writes two JSON strings, the receiver may read one chunk, two chunks, or partial chunks. Application protocols need delimiters or lengths.

TCP sequence numbers detect missing/reordered bytes. Receivers acknowledge data and maintain windows; senders adapt to congestion. Packet loss causes latency, and head-of-line blocking can slow dependent streams, notably with HTTP/2 over TCP. TCP reliability does not guarantee an HTTP operation happened exactly once; a timeout may occur after the server committed a write.

## UDP and QUIC

UDP sends datagrams without built-in delivery guarantees or ordering. It is useful for DNS, media transport, and as the substrate for QUIC. **QUIC** implements encrypted reliable streams, congestion control, and connection setup on top of UDP; HTTP/3 uses QUIC. Do not assume "UDP is always unreliable" means applications built on UDP cannot provide reliable data transfer.

## IP, routes, NAT, and subnets

IPv4 addresses are 32 bits; IPv6 addresses are 128 bits. `192.168.10.0/24` describes an IPv4 subnet with 256 total addresses (with addresses reserved/allocated according to the network). Routing tables determine where IP packets go next. Network Address Translation (NAT) maps addresses/ports, often allowing private servers to reach public networks. Firewalls and security groups filter traffic; they do not replace application authorization.

**Technical failure case:** API returns `503` only across zones. Test DNS resolution, destination port, TCP handshake, TLS, route tables, security groups, load-balancer health, and application logs, rather than assuming the database is slow.

**Design judgment:** Select protocols based on reliability, latency, interoperability, transport behavior, and operational constraints. Moving from TCP to UDP is not a generic performance fix.
