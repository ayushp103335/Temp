# HTTP, HTTPS, TLS, HTTP/2, and HTTP/3

HTTP defines messages and semantics used by web applications. A request has a method, path, headers, and optional body. A response has a status, headers, and optional body.

```http
POST /v1/jobs HTTP/1.1
Host: api.example.com
Content-Type: application/json
Idempotency-Key: 27a9d5...

{"object_key":"uploads/x.pdf"}
```

Common HTTP verbs: `GET` reads a representation, `POST` performs processing or creates resources, `PUT` replaces a resource, `PATCH` modifies fields, and `DELETE` removes a resource. Safe methods should not intentionally cause application state changes. HTTP idempotent-method semantics are separate from an application's implementation of a particular request.

## HTTP version evolution

- **HTTP/1.1:** persistent connections, text-based message format; concurrent requests typically require multiple connections or pipelining with restrictions.
- **HTTP/2:** binary framing and multiple multiplexed streams on one TCP connection; HPACK header compression; loss at the TCP layer can affect all streams.
- **HTTP/3:** QUIC transport with separate streams over UDP and TLS 1.3 integrated into QUIC; often improves connection behavior under loss/mobility, subject to environment.

## TLS is not optional for sensitive APIs

TLS authenticates the server certificate chain and encrypts in-transit application data. A certificate contains a public key and hostname identity; the private key must be protected. Proper validation includes hostname, trust chain, expiry, and relevant protocol policy. For internal connections, **mTLS** additionally authenticates client certificates. Encryption in transit prevents passive observers from reading plaintext *between TLS endpoints*; it does not protect data on a compromised endpoint or stop an authorized but malicious client.

## Timeouts, retries, and status codes

A client timeout means the client **does not know** whether the operation completed. Consider `POST /payments`: the server commits a payment but the response is dropped. Automatically retrying with a new payment identifier can double charge the customer. Use idempotency keys and server-side stable deduplication.

| Code | Typical meaning | Architecture implication |
|---|---|---|
| 200 | Success with response | Return controlled representation |
| 201 | Created | Usually supply location or resource ID |
| 202 | Accepted for async handling | Persist recoverable request first |
| 400 | Invalid client request | Do not blindly retry |
| 401/403 | Unauthenticated/forbidden | Distinct identity vs authorization |
| 404 | Resource not found | May intentionally hide unauthorized IDs |
| 409 | State conflict | Handle optimistic concurrency |
| 429 | Rate limited | Respect bounded retry hints |
| 500/503 | Server failure/unavailable | Retry only if safe and budgeted |

**Security example:** Never log `Authorization` headers or raw patient payloads. Use request IDs, structured status codes, and scrubbed metadata. Avoid caching authenticated content in a shared edge cache unless the cache key and authorization model are designed for it.

**Exercise:** Explain why a load balancer terminating HTTPS must also protect traffic to backend servers, and why `200 OK` from `/health` is insufficient to prove the database workflow works.
