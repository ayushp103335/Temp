# DNS, Routing, Proxies, and Service Discovery

DNS maps names to records used for routing. `api.example.com A 203.0.113.10` is an **illustrative documentation address** (RFC 5737), not a reachable application. An `AAAA` record points to IPv6, `CNAME` aliases to another domain name, and `MX` identifies mail exchangers. DNS resolvers cache answers subject to TTL and policy; DNS changes are not instantaneous across the internet.

## Resolution path

```text
client stub resolver -> recursive resolver -> root/TLD/authoritative servers
                  <- cached or authoritative records
client -> destination IP + port
```

A recursive resolver may have an answer cached and therefore skip the full chain. DNS is not a real-time health detector by itself. Even a 30-second TTL cannot guarantee every client instantly stops using an unavailable endpoint; resolvers, OS caches, and existing connections behave differently.

## Forward vs reverse proxies

A **forward proxy** acts on behalf of clients, e.g., an enterprise egress proxy that applies policy. A **reverse proxy** receives requests on behalf of servers, e.g., Nginx terminating TLS and forwarding requests to FastAPI. A **load balancer** chooses among multiple targets; many modern reverse proxies are also load balancers. Their conceptual functions overlap.

```text
Client --> edge LB/reverse proxy --> API-A
                             +-----> API-B
                             +-----> API-C
```

Layer 4 balancing chooses destinations based on transport metadata (IP/port and connection state); Layer 7 can inspect HTTP methods, hostnames, paths, headers, and cookies. L7 can route `/billing/*` separately from `/search/*` but parses higher-level protocol data and changes the trust model.

## Internal discovery

At 20 app instances, hard-coded IP lists are brittle. **Service discovery** maps a logical service (`claims-api`) to healthy endpoints. Options include DNS-based Kubernetes Services, a service registry with heartbeats, or platform-native discovery. A registry is a control-plane dependency: if discovery becomes unavailable, existing connections may continue but new instances or requests may fail depending on client behavior.

**Example:** `POST /claims` routes to a claims service. Deployment replaces three instances. A readiness probe first checks that an instance can accept new work; a liveness probe determines whether it needs restarting. Misusing liveness for transient DB problems can trigger a restart storm.

**Exercise:** Explain why changing a DNS record is not always a sufficient failover strategy, and compare it with proxy-level health-based failover.
