# WebSockets, SSE, Polling, and Real-Time Communication

"Real-time" means a bounded delay between a change and a user's awareness of it, not automatically zero latency. A client may poll, hold a server-sent event (SSE) stream, or use a WebSocket.

| Method | Direction | Typical use | Limitation |
|---|---|---|---|
| Polling every 5 s | Client requests repeatedly | Job status | Stale until next poll; wasteful at scale |
| Long polling | Server holds request until update/timeout | Legacy event delivery | Repeated HTTP request lifecycle |
| SSE | Server-to-client HTTP event stream | Live progress, notifications | Primarily one-way; reconnect/resume design |
| WebSocket | Bidirectional long-lived connection | Chat, multiplayer collaboration | Stateful connections, reconnection and fan-out |
| WebRTC | Real-time media/data pathways | Calls and peer communication | Signaling, NAT traversal, media complexity |

## Chat example

For a 100,000-connection chat service, one gateway process cannot store all conversation state exclusively in its RAM. Connections may be spread across many gateways. Messages can be persisted to a message store, then delivered to online users through routing/fan-out. Offline users need durable unread state. Redis pub/sub alone does **not** provide durable delivery to disconnected consumers.

```text
Sender -> WS gateway -> message store/sequence ID -> fan-out bus
                                                 -> recipient gateway -> recipient
```

Use client-generated message IDs to deduplicate reconnect retries. Decide whether ordering is per conversation or global; global ordering is expensive and often unnecessary. A gateway failure drops WebSocket connections, but clients can reconnect and fetch missed messages from durable history using a cursor.

## Reconnect and backpressure

A slow mobile client may not consume all live updates. Put limits on outbound buffers; drop replaceable typing indicators, not persisted messages. Heartbeats help detect broken connections. Use exponential backoff with jitter on reconnect so a region recovery does not produce millions of simultaneous handshakes.

**Design judgment:** Use polling for infrequent and non-urgent job state changes; add SSE for one-way progress streams; use WebSockets when the application truly needs bidirectional low-latency interaction.
