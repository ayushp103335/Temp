# Load Balancing, Scaling, and Health Checks

![Load Balancing, Scaling, and Health Checks architecture diagram](../assets/load-balancing.svg)

A load balancer spreads connections or requests across instances. It improves *distribution* and can enable failover, but does not create CPU, database capacity, or healthy backends.

## Algorithms

| Algorithm | Good for | Risk |
|---|---|---|
| Round robin | Similar, short-lived requests | Slow requests can accumulate unevenly |
| Least connections | Long-lived connections | Connection count ≠ active work |
| Weighted round robin | Heterogeneous capacity | Wrong weights cause hotspots |
| Random/power-of-two choices | Large pools, simple routing | Needs observed load/consistent implementation |
| Consistent hash | Cache locality, sticky partition mapping | Hot keys and uneven shard loads |
| Latency-aware / least response time | Variable health/load | Delayed metrics and oscillation |

## L4 vs L7

At L4, a TCP connection is selected using transport information. At L7, a proxy can route `Host: clinic.example.com` to one pool and `/api/v2` to another, enforce request size, terminate TLS, and apply authentication/rate limits. L7 offers richer control with more parsing and configuration complexity.

## Vertical, horizontal, and data scaling

**Vertical scale:** increase CPU/RAM on a machine; simple but limited and may require restarts. **Horizontal scale:** add identical stateless app instances; requires a load balancer and shared/externalized state. **Data scaling:** replicate or partition data as separate problem. Moving from one to eight API servers does not help if all 8 send too many queries to one underprovisioned database.

```text
100 requests/s -> 4 instances -> 25 requests/s/instance (ideal)
                       |
                       +--> one shared DB: potentially 100+ queries/s
```

## Health checks and graceful shutdown

A **liveness** check answers whether a process is irrecoverably stuck; a **readiness** check answers whether it should receive new traffic. During deploy, remove a server from ready targets, stop accepting new work, let existing requests drain, then terminate within a bounded grace period. Long-lived WebSocket connections may require reconnect or transfer behavior.

**Capacity example:** If each API instance can sustain 150 RPS at the desired p99 and peak is 500 RPS, four instances nominally support 600 RPS. That leaves little room for one instance failure (three × 150 = 450), so plan extra margin and verify with load tests. A target of five instances provides 750 RPS nominal and 600 RPS after one fails, but this is only valid if shared dependencies keep up.

**Design judgment:** Start with metrics. Use an L7 load balancer where request-aware routing/security is required; prefer L4 when preserving transport and lightweight connection distribution are sufficient.
