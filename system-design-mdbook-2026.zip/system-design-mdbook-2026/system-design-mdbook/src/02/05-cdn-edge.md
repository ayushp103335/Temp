# CDNs, Edge Caching, and Global Latency

A **content delivery network (CDN)** serves cacheable content closer to clients through distributed edge nodes. This reduces round trips to the origin and shields it from repeat requests, but cache invalidation, authorization, and data residency become design concerns.

## Pull vs push CDN

- **Pull CDN:** the first request for `/assets/app.8ce3.js` misses at the edge and fetches the file from origin; subsequent eligible requests are served from edge until freshness expires.
- **Push CDN:** the publisher proactively uploads content to edge/provider storage, useful where origin access is undesirable or predictable pre-distribution is needed.

A CDN may use an origin shield and tiered caches. A cache hit reduces origin traffic, but an expired entry can cause multiple concurrent clients to fetch the same object: the **thundering herd** problem. Request coalescing and stale-while-revalidate policies can mitigate it.

## Static files, APIs, and signed content

Versioned JS/CSS bundles are excellent cache candidates: `/static/app.abcd1234.js` can have long TTLs because the filename changes on deploy. Authenticated `GET /patient/123` is not automatically safe to share across viewers. Use appropriate `Cache-Control`, cache keys, and private cache behavior. Signed URLs for object storage grant scoped, time-limited permission; treat them as bearer capabilities, protect the signing key, and bound permissions/expiry.

## Geography and edge limits

Round-trip time depends on distance, routing, congestion, and protocol setup. A CDN reduces static content latency but may not shorten a highly dynamic API that always calls a distant origin. Regional read replicas, regional APIs, or edge compute may help, but stale data, cross-region writes, data residency, and operational cost complicate the design.

**Technical example:** A web application serves 250 KB of versioned JS to 10,000 daily users in one region. At 100% origin delivery, that's ~2.5 GB/day; with 95% edge hit ratio, origin fetch traffic for those same assets may be ~125 MB/day under simplified assumptions. Billing and latency depend on provider and real cache behavior.

**Exercise:** Design caching headers for (a) hashed CSS, (b) a public product photo, (c) a private medical test result, and (d) a short-lived API configuration response. Explain expected cache invalidation.
