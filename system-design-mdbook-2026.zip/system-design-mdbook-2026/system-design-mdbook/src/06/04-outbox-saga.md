# Transactional Outbox, Inbox, Saga, and Choreography

A database transaction cannot ordinarily atomically commit both an application row and a message in an unrelated broker without coordination. **Transactional outbox** solves this by writing business state and an outgoing event record in the same DB transaction.

## Outbox sequence

```sql
BEGIN;
INSERT INTO jobs(id,status) VALUES ('j-9','PENDING');
INSERT INTO outbox(id,event_type,payload)
VALUES ('evt-9','JobAccepted','{"job_id":"j-9"}');
COMMIT;
```

A publisher reads unsent outbox rows and sends messages, recording publication progress. It can crash after sending but before recording success, causing **duplicate publish**. Consumers must be idempotent. CDC can publish outbox records from the DB log rather than periodic polling.

## Inbox pattern

Consumers keep a `processed_messages` table with unique `(consumer_id, message_id)` and commit both the deduplication marker and local business state together. The inbox doesn't automatically make remote side effects atomic.

## Saga pattern

A saga is a series of local transactions with compensating actions when downstream steps fail. In an order workflow:

```text
Reserve inventory -> Authorize payment -> Create shipment
        |                    |                  |
        +---- release <------+---- void auth <--+ (if later step fails)
```

A compensation is not always a perfect inverse. A shipped item cannot be "unshipped"; returning/refunding is a new business action. Choose **orchestration** (one coordinator tracks steps) when central visibility/control matters; **choreography** when services react to events and coupling remains manageable. Choreography can turn opaque when many services exchange circular events.

## Failure and timeout policies

Persist saga state, stable operation IDs, retry policy, compensations, and terminal states. Design for duplicate, delayed, reordered, and poison events. A timeout can mean "unknown" rather than "failed"; query provider state before compensating if needed.

**Exercise:** Design a claim payment workflow that writes a ledger record, calls an external payment API, and emails a receipt. Which steps require strict atomicity? Which can be eventually consistent? How do you reconcile uncertain payment outcomes?
