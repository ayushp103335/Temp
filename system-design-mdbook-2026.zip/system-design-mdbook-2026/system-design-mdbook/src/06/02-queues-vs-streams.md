# Task Queues, Message Brokers, Pub/Sub, and Streaming Logs

A **task queue** distributes units of work among competing consumers. A **pub/sub topic** routes one event to multiple interested subscriptions. A **streaming log** retains ordered events per partition and permits consumers to read/replay based on offsets. Products have overlapping features; examine guarantees instead of relying on labels.

## Compare common usage

| Need | Candidate | Design implication |
|---|---|---|
| Distribute 10,000 independent OCR tasks | RabbitMQ / managed task queue | Per-message ack, retry, worker pools |
| Replay click events from yesterday | Kafka-like retained log | Consumer offsets and retention |
| Send user notifications to three services | Pub/sub topic with independent subscriptions | Each subscriber processes independently |
| Trigger nightly reconciliation | Scheduler + task queue | Idempotent period key, bounded job windows |

RabbitMQ acknowledgments indicate broker delivery/processing responsibility under configured semantics; they do not automatically mean a business transaction is atomically committed. Kafka offers retention, partitions, ordered records per partition, consumer offsets, and specific producer/transactional features; it does not magically provide end-to-end exactly-once effects in external databases.

## Partitioning and ordering

If orders are keyed by `order_id`, all records for one order can be sent to the same partition to preserve per-order log order. Different orders can process in parallel. A single "global order" across all partitions is not ordinarily available. Consumer groups divide partitions among instances; scaling consumers beyond partition count may add idle instances for that topic/group.

## Operational controls

Use dead-letter queues only with clear replay and retention practices. Monitor oldest message age, ready/unacked counts, partition lag, retry rate, downstream API errors, and schema validation failures. Encryption, access controls, and PII minimization apply to messages too.

**Exercise:** One business event `ClaimApproved` must update a dashboard, email a user, and update a data warehouse. Which consumers should share a competing-consumer group, and which need independent subscriptions?
