# Background Jobs, Schedulers, and Async Request-Reply

A background job is work deliberately completed outside a client's immediate request lifecycle. Typical tasks include image/PDF extraction, sending emails, aggregating data, and running scheduled maintenance.

## Three ways to launch work

- **Event-driven:** a durable `DocumentUploaded` event starts extraction.
- **Schedule-driven:** a scheduler queues an end-of-day reconciliation task at a specified time zone.
- **Async request-reply:** `POST /jobs` returns `202` and a status URL; a worker later produces the result.

Do not perform a 60-second remote inference call inside an HTTP handler if the product can tolerate eventual completion. Instead persist a job, return a reference, and let a bounded worker fleet process it. Users can poll, subscribe via SSE, or receive a signed callback/webhook.

## Scheduler correctness

A distributed scheduler may run twice after leader failover. Make scheduled work idempotent; represent the business period in the job key (`tenant-17:daily-report:2026-11-05`). Account for daylight-saving transitions and local-time schedules. A scheduler firing "at midnight" is not a guarantee that the entire operation executes exactly once.

## State model and leases

```text
PENDING -> CLAIMED -> RUNNING -> SUCCEEDED
              |          |
              | lease expires -> RETRYABLE
              +----------------> DEAD (after retry budget)
```

Workers need a lease or equivalent ownership mechanism, heartbeats for long tasks, bounded attempts, cancellation semantics, and an operator replay policy. Track both `queue_wait_seconds` and `processing_seconds`; the first measures overload, the second measures worker/service performance.

**Design judgment:** Use background work when asynchronous completion fits business requirements. A user opening a 20 ms profile request does not need a queue; placing every operation on a queue can increase latency and reduce debuggability.
