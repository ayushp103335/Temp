# Backpressure, Rate Limiting, Stream Processing, and CDC

**Backpressure** means a downstream component signals or enforces that producers must slow down, buffer within bounds, or shed load. Unlimited queues are not a capacity strategy: they convert overload into growing latency and resource exhaustion.

## Arrival vs service rate

If requests arrive at 1,000/s and workers complete 700/s for 60 seconds, the backlog increases by `300 × 60 = 18,000` tasks, ignoring drops and retries. If arrival remains greater than service rate indefinitely, no finite queue can save the system. Use admission control, batching, throttling, new capacity, or producer behavior changes.

## Rate limiting algorithms

- **Token bucket:** tokens replenish at fixed rate up to burst capacity; each accepted request consumes one.
- **Leaky bucket:** smooths output rate or models a bounded draining queue.
- **Fixed window:** cheap but allows boundary bursts (two windows' worth near boundary).
- **Sliding window:** tracks usage over a moving interval; can be exact or approximate.

For distributed limits, require atomic updates in the shared counter store; a read followed by write is race-prone. Define scope (`tenant`, API key, IP, endpoint), whether over-limit means `429`, and whether requests are delayed or rejected.

## Stream-processing concepts

**Event time** is when an event actually occurred; **processing time** is when the pipeline handled it. Late data can arrive after a time window appears complete. A watermark estimates progress in event time. Window types include tumbling (fixed non-overlapping), sliding (overlapping), and session (activity-gap based). Define lateness policy and correction/upsert behavior.

**Example:** A claims dashboard counts approvals per 5-minute window. An approval recorded at 10:02 arrives at 10:09 after a mobile/network retry. If the window finalized at 10:07, should the system revise 10:00–10:05 totals or record it in an adjustment stream? Choose explicitly.

## CDC vs events

CDC exports database changes; domain events express business meaning. A row's `status=APPROVED` may be enough to rebuild a projection, but `ClaimApprovedByReviewer` can contain essential business context. Make schemas/versioning compatible, and track consumer lag and replay progress.

**Design judgment:** Backpressure is an end-to-end property: an API should not acknowledge unlimited work that no downstream worker or vendor can complete within the stated SLO.
