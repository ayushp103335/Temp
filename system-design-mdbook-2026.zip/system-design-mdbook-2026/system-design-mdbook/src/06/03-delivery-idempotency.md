# At-Most-Once, At-Least-Once, Deduplication, and Idempotency

Message delivery semantics are about **how many times a message may be delivered**; business-effect semantics are about **how many times a logical action changes state**. Keep them separate.

- **At-most-once delivery:** messages may be lost but are not intentionally redelivered.
- **At-least-once delivery:** messages are retried until acknowledged (subject to configuration); duplicates are possible.
- **Exactly-once semantics:** possible in constrained systems/transactions, but not a blanket promise across arbitrary external APIs and databases.

## The classic crash window

```text
Consumer receives message M
  1. DB transaction commits claim status = APPROVED
  2. Process crashes before acknowledging M
Broker redelivers M
```

Without idempotent handling, the second execution could send the same payout twice. Mitigation: store the unique logical event/action ID with a uniqueness constraint and perform the corresponding state change in the same transaction.

```sql
BEGIN;
INSERT INTO processed_events(consumer_name, event_id)
VALUES ('payout-worker','evt-99')
ON CONFLICT DO NOTHING;
-- If no row inserted, treat the event as already processed and stop.
-- Otherwise perform the payout-intent state transition in this transaction.
COMMIT;
```

The exact syntax above is PostgreSQL-style. The code **must check affected row count** and ensure the protected business effect is in the same transactional boundary; this is a teaching sketch, not a complete payout implementation.

## Idempotent HTTP requests

Client sends `Idempotency-Key: abc`. Server stores the key, authenticated principal/scope, request hash, result/status, and expiry using a uniqueness constraint. Repeated identical requests return the same logical operation's outcome. Reuse of the key with a different body should be rejected. Scope must prevent one tenant from guessing another's key.

## External side effects

If calling a payment provider, pass the same provider-supported idempotency key across retries. If a provider lacks idempotent operations, store durable intent, use reconciliation/query-before-retry where supported, and accept that some failure cases require manual handling. Do not fabricate an exactly-once guarantee merely by wrapping your local DB writes in a transaction.

**Design judgment:** Prefer at-least-once delivery plus idempotent consumer effects. Define the deduplication retention window and replay/recovery semantics explicitly.
