# Stream Log Deep Dive: Partitions, Consumer Offsets, and Rebalancing

Kafka-like logs store ordered records per partition, retain records according to policy, and let consumers independently track progress. Understanding these mechanics prevents false assumptions about ordering and exactly-once behavior.

## Topic, partition, offset

```text
Topic: claims-events
Partition 0: offset 0 [ClaimCreated(C1)]
             offset 1 [ClaimPaid(C1)]
Partition 1: offset 0 [ClaimCreated(C2)]
             offset 1 [ClaimDenied(C2)]
```

If records are partitioned by claim ID, all updates for C1 route to partition 0 and preserve their append order there, assuming correct producer sequencing. There is no single total order across partitions 0 and 1. Increasing partitions can change key-to-partition mapping for future events and threaten per-key ordering unless the migration strategy accounts for it.

## Consumer group assignments

With 12 partitions and four consumers, a balanced assignment yields about three partitions per consumer. If one consumer crashes, remaining consumers rebalance and process assigned partitions. During rebalances, messages may be replayed from last committed offsets. Consumer code must be safe for repeated records.

## Offset vs business commit

If a consumer commits its offset **before** successfully writing a database projection, a crash can lose the business effect. If it writes the DB first and commits offset later, a crash can replay the same event. Prefer idempotent projections and carefully ordered commits. Some streaming runtimes can atomically coordinate supported internal outputs, but do not assume that extends to arbitrary external systems.

## Retention and replay

A stream retaining seven days of records cannot automatically replay data older than that. Historical recovery may require archived raw events in object storage or new snapshots. Large backfills compete with live traffic; use isolated consumer groups, quotas, and observability.

## Schema evolution

Use versioned Avro/Protobuf/JSON schema conventions. Add optional fields first, avoid reusing semantic names/numbers, and run compatibility tests against real consumers. A broker will happily transport syntactically valid but semantically wrong records unless applications validate them.

**Exercise:** Design replay of 50 million events after rebuilding the search index while ensuring live event processing continues and a late old event cannot overwrite a newer entity version.
