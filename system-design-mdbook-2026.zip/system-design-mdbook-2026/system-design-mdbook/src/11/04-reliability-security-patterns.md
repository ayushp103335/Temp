# Reliability, Availability, and Security Patterns: Complete Catalog

## Deployment Stamps

Repeat a complete isolated workload unit per tenant group/region. Useful for bounded blast radius and repeatable deployment; costs include routing, over-provisioning, and operational complexity.

## Geodes

Deploy active regional units near users while managing regional data access and failover. Useful for global latency and regional resilience; risks include cross-region consistency and residency. See Part 08.

## Throttling

Constrain accepted calls by tenant/client and service capacity. Respond `429` or defer with bounded queues. Protect expensive inference endpoints and fair shared use; a limiter must operate atomically enough to withstand concurrent instances.

## Health Endpoint Monitoring

Expose separate liveness/readiness/dependency indicators and run external synthetic checks. Monitoring only a process heartbeat can miss a corrupted DB query or failing authorization dependency. Protect sensitive health details from public disclosure.

## Bulkhead

Separate resource pools, concurrency limits, or cells so a tenant's batch processing does not block clinical search. Costs: some capacity may sit idle; policies need tuning.

## Circuit Breaker

Stop repeatedly calling a demonstrably failing downstream dependency; probe recovery after a controlled interval. Risks: breakers can open erroneously or hide partial regional failures. Distinguish failure classes and timeout budgets.

## Compensating Transaction

Execute a new domain action that mitigates a previously committed action in a saga. `PaymentCaptured` may require `RefundIssued`; deleting the original ledger entry would damage auditability. Compensation can fail and may require human review.

## Retry

Retry transient, safe/idempotent operations with exponential backoff, jitter and a total retry budget. Do not retry non-idempotent writes with new IDs; bound amplification across service layers.

## Leader Election

Ensure one active coordinator for work that requires a single actor. Use consensus/leases plus fencing. Monitor term changes and pause/resume anomalies.

## Queue-Based Load Leveling / Scheduler-Agent-Supervisor

These patterns are also reliability controls: smoothing bursts reduces overload; durable checkpoints allow long workflows to resume after failures. But indefinite queue growth or duplicate supervisor execution can still violate the service objective.

## Federated Identity

Delegate authentication to a trusted identity provider using standards such as OIDC, with appropriately validated issuer, audience, signatures, and delegated claims. Authorization still belongs to the service's resource policy.

## Gatekeeper

Use a deliberately narrow trusted component to mediate access to protected resources. A sensitive export service might enforce policy, authorization, audit, and data minimization before providing a scoped capability. A gatekeeper is not permission to centralize every business rule or create a single untested point of failure.

## Valet Key

Give a client a temporary, minimal-capability token or presigned URL for one resource/operation. Use short expiry and restrict object/path/verb/size as feasible. Never embed root cloud credentials in clients.

**Pattern review:** For an urgent appointment availability API, justify circuit breaker, throttle, bulkhead, and retry behavior. Explain which errors are safe to retry and how to avoid a retry storm during a database failover.
