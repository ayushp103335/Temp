# Messaging Patterns: Queue Leveling, Consumers, Claim Check, Choreography, and More

## Queue-Based Load Leveling

**Problem:** traffic bursts exceed worker/service capacity. **Mechanism:** bounded durable queue buffers acceptable bursts while consumers work at controlled rate. **Case:** 600 PDF submissions during a short spike enter a durable queue and finish over minutes. **Watch:** sustained overload, queue expiry/size, oldest-message age, and business deadlines.

## Competing Consumers

**Problem:** distribute independent tasks. **Mechanism:** multiple workers consume from a queue; each delivery generally goes to one consumer at a time, subject to redelivery. **Case:** 20 OCR workers process separate PDFs. **Watch:** prefetch, fairness, acknowledgment, crash duplication, poison jobs.

## Publisher/Subscriber

**Problem:** an event should inform multiple independent systems. **Mechanism:** each subscription receives its own copy/log position. **Case:** `ClaimPaid` feeds email, analytics, and compliance audit subscribers. **Watch:** schema compatibility and independent retry/failure isolation.

## Priority Queue

**Problem:** high-urgency work must finish ahead of lower-value work. **Mechanism:** separate queues or broker-supported priority ordering and reserved worker capacity. **Case:** urgent eligibility checks versus overnight historical reprocessing. **Watch:** starvation of low-priority queues, priority inversion and fairness quotas.

## Pipes and Filters

**Problem:** multi-stage document transformation. **Mechanism:** each stage consumes validated input and produces versioned output; stages can be chained synchronously or asynchronously. **Watch:** duplicates, stage coordination, partial progress, schema changes, large payloads.

## Choreography

**Problem:** workflow across domains without a central controller. **Mechanism:** services react to events: `OrderPlaced -> InventoryReserved -> PaymentAuthorized`. **Watch:** event loops, unclear ownership, hidden dependencies, error reconciliation. Use an orchestrator when multi-step workflow visibility is vital.

## Claim Check

**Problem:** large payloads make messages expensive and brittle. **Mechanism:** put 20 MB PDF in object storage, send only `object_key` and checksum on the queue; worker fetches it. **Watch:** object access expiry, orphan cleanup, retention, integrity, and least privilege. The queue must never contain a URL allowing broad, long-lived access.

## Async Request-Reply

**Problem:** long operation exceeds HTTP request budget. **Mechanism:** return `202` with job ID; client polls/callbacks. **Watch:** status retention, cancellation, duplicate submissions, client expiration, and permission checks on result URLs.

## Scheduler-Agent-Supervisor

**Problem:** long-running workflows need coordination and progress. **Mechanism:** scheduler plans tasks; agents execute; supervisor detects stalled/failed steps and reassigns or compensates. **Case:** month-end billing close across 100 tenants, each with checkpoints. **Watch:** authoritative step state, leases, recovery and duplicate side effects.

## Sequential Convoy (antipattern)

**Problem:** one slow task blocks a queue/ordered partition, delaying unrelated work. **Example:** a 20-minute document holds the only worker while hundreds of short tasks wait. **Mitigate:** separate queues by job size, fair scheduling, more partitions where ordering allows, or head-of-line avoidance. **Warning:** strict ordering may make some convoys unavoidable; don't break business guarantees solely to improve throughput.

**Exercise:** Classify 500 KB status messages, 50 MB PDFs, and daily urgent alerts into message payload, blob pointer, priority queue, and retention strategies.
