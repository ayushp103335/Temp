# Data Management Patterns: Materialized View, Event Sourcing, Index Tables, Sharding

## Cache-Aside

**Problem:** repeated reads overload an authoritative database. **Mechanism:** read from cache; on miss query source and populate. **Case:** cache drug catalog details for 30 seconds. **Watch:** stale reads, thundering herd, tenant-aware keys. See Part 05 for failure analysis.

## Materialized View

**Problem:** complex aggregates are expensive per query. **Mechanism:** precompute and store a derived representation that is refreshed on schedule or incrementally. **Case:** `claim_totals_by_payer_day` serves dashboard queries. **Watch:** lag, invalidation, backfill, and reconciliation to authoritative transactions. Some databases implement native materialized views; custom read models provide similar architectural behavior.

## Index Table

**Problem:** a store's primary data access path doesn't support a needed lookup. **Mechanism:** maintain a second table keyed by alternate attribute. **Case:** primary `claims_by_id` plus `claim_ids_by_member_id`. **Watch:** dual-write consistency and repair; a native secondary index may be simpler when available.

## Event Sourcing

**Problem:** preserve an auditable history of state transitions and reconstruct state. **Mechanism:** store domain events as the authoritative log, derive current state by replay/snapshots. **Case:** `ClaimSubmitted`, `ClaimReviewed`, `ClaimAdjusted`, `ClaimPaid` form a claim lifecycle. **Watch:** event schema evolution, data deletion/retention, projection rebuild cost, legal sensitivity, and irreversible events. Not every app requires event sourcing.

## CQRS as data pattern

A transactional command model may emit events that asynchronously update a denormalized search model. Reads may be stale. Use `version` or watermark fields to expose freshness, and define error behavior if projection falls behind. CQRS and event sourcing are independent choices.

## Sharding

**Problem:** one DB node reaches storage, IO, or write throughput limit. **Mechanism:** partition records by a chosen key to separate nodes, with shard-aware routing. **Case:** partition multi-tenant claims by tenant plus subshard. **Watch:** resharding, cross-shard transactions, hot tenants, and global aggregations.

## Valet Key

**Problem:** clients need direct restricted access to large blobs without routing bytes through the API. **Mechanism:** API issues short-lived presigned object-store URL scoped to an allowed object and operation. **Case:** browser uploads a 20 MB PDF directly to object storage. **Watch:** URL leakage, object-name validation, content limits, expiry, malware scanning, and finalize/verify step.

## Static Content Hosting (data angle)

Store and deliver immutable artifact versions using object storage plus CDN. Separate sensitive patient documents from publicly cacheable website assets. Apply retention, encryption and audit.

**Exercise:** Design a claim-analytics system. Identify authoritative write storage, projected dashboard store, and what happens when CDC lag rises to two hours.
