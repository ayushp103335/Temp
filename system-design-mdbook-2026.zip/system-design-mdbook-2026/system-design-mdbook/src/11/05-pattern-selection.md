# Choosing Patterns Without Overengineering

A pattern is correct only relative to workload and constraints. Use a decision table, not pattern-name accumulation.

| Problem | First option to test | Escalate when | Dangerous shortcut |
|---|---|---|---|
| Slow repeated reads | Query/index improvement | DB load due to true repetition | Cache all user-sensitive responses |
| 30-second task | Async job with status | Need replay/multi-subscriber | Long synchronous HTTP wait |
| Repeated vendor failures | Timeout + bounded retry | Sustained failure threatens requests | Retry at every service layer |
| Uneven tenant usage | Per-tenant rate limits | Noisy neighbor still dominates | Immediately split into 100 cells |
| Expensive dashboard | Better SQL/aggregates | Read patterns incompatible with OLTP | Denormalize without update plan |
| Legacy replacement | Modular facade/strangler | Capability can be safely migrated | Big-bang migration with no rollback |
| Need audit history | Domain audit/ledger | Event replay is a product requirement | Event source everything by default |
| Regional outage SLO | Tested passive failover | RTO/latency require active serving | Active-active multi-writer with LWW |

## One end-to-end worked choice

A document platform receives 200 jobs/min, each averaging 10 seconds, while status API needs p95 under 150 ms. A queue plus worker pool separates acceptance and processing. A transactional outbox prevents durable jobs from being stranded between DB commit and publish. A claim-check pattern stores PDFs in object storage rather than queue payloads. Competing consumers scale OCR processing. A small read-only dashboard projection may be optional. A cache is optional until measurements show repeat query pressure. A service mesh, event-sourced ledger, multi-region active-active, and cross-shard CQRS are *not yet justified*.

## Validation checklist

For every adopted pattern, document: (1) before/after bottleneck; (2) correctness invariant; (3) failure behavior; (4) deployment/migration cost; (5) telemetry; (6) rollback; (7) condition for removal/reassessment.

**Exercise:** Take a system you know. Remove three components from its architecture while preserving requirements. Explain why each removed component was unnecessary—or prove its necessity with a concrete failure scenario.
