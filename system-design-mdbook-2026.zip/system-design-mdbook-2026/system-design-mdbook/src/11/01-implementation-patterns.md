# Design & Implementation Cloud Patterns: Complete Catalog

Patterns are reusable solutions to recurring problems, **not** mandatory building blocks. For each entry, identify the problem, implementation mechanism, and cost.

## Strangler Fig

**Problem:** Replace a legacy application without a risky big-bang rewrite. **Mechanism:** Put a router/facade in front, move one endpoint/capability to the new service, measure behavior, repeat. **Technical case:** requests to `/claims/v2/*` go to a new claims service while old claim history remains in a legacy monolith. **Watch:** ownership of writes, duplicate effects, shadow-data divergence, and rollback.

## Sidecar

**Problem:** Apply a shared runtime concern without embedding it in every application. **Mechanism:** colocate a proxy/log collector alongside the app container. **Case:** an Envoy sidecar enforces mTLS and exports request traces for a claim API. **Watch:** resource overhead, proxy failures, version skew, and observability of the sidecar itself.

## Static Content Hosting

**Problem:** Serve immutable assets efficiently. **Mechanism:** publish versioned JS/CSS/images to object storage behind a CDN. **Case:** `app.a13f.js` served with long cache lifetime; HTML references updated hash on deployment. **Watch:** access control for private documents, CDN invalidation, origin permissions, and content integrity.

## Leader Election

**Problem:** Only one coordinator should execute a global action. **Mechanism:** quorum election or managed leases plus fencing. **Case:** elect a reconciliation job scheduler. **Watch:** an expired leader may resume after a pause; reject stale fencing tokens at the protected resource.

## CQRS (Command Query Responsibility Segregation)

**Problem:** Read/query models differ significantly from write models. **Mechanism:** commands modify authoritative state while read projections serve denormalized queries. **Case:** write order transactions to SQL; project customer order timeline into a search-friendly store. **Watch:** projection lag, rebuild, ownership, and command/query consistency. CQRS does **not** require event sourcing or microservices.

## Pipes and Filters

**Problem:** Process content through independent transformations. **Mechanism:** compose bounded steps such as upload validation -> PDF normalization -> extraction -> quality checking -> persistence. **Watch:** schema contracts, retries, duplicate messages, privacy, and errors at stage boundaries. A single process can also use pipes and filters.

## Ambassador

**Problem:** Standardize network access from a service to a remote dependency. **Mechanism:** a colocated outbound proxy adds retries, credentials, discovery, and instrumentation. **Case:** every model worker calls a vendor through a common egress proxy with approved domains. **Watch:** central proxy outage, side-effect-safe retries, secrets, and whether a simpler SDK suffices.

## Gateway Routing

**Problem:** Route incoming calls to multiple backend services. **Mechanism:** gateway dispatch by host/path/version. **Case:** `/claims` to claims API, `/eligibility` to eligibility API. **Watch:** path collisions, auth bypass, and backend protocol compatibility.

## Gateway Offloading

**Problem:** Avoid implementing common edge concerns in every backend. **Mechanism:** gateway handles TLS termination, request size caps, WAF controls, and possibly auth verification. **Watch:** do not assume edge checks replace object-level authorization or encrypted internal transport.

## Gateway Aggregation

**Problem:** Mobile client needs data from three services with few network round trips. **Mechanism:** gateway/BFF fetches customer info, eligibility and documents concurrently into one response. **Watch:** p99 fan-out amplification, aggregate failure policy, cache boundary, and gateway becoming business-logic monolith.

## External Configuration Store

**Problem:** Update configuration consistently without rebuilding images. **Mechanism:** centrally versioned config with scoped read access, validation, rollback, and local caching. **Case:** update per-tenant OCR model selection with staged rollout. **Watch:** secret separation, malformed changes, and control-plane outage.

## Compute Resource Consolidation

**Problem:** Low-utilization tasks each have expensive dedicated compute. **Mechanism:** combine compatible background tasks onto shared compute/worker pools. **Case:** use shared short-job workers for thumbnail and metadata extraction. **Watch:** noisy-neighbor contention; do not consolidate workloads with incompatible security/trust or latency requirements.

## Backend for Frontend (BFF)

**Problem:** Browser, mobile, and partner clients need different data composition. **Mechanism:** a thin BFF per client channel tailors responses. **Case:** mobile returns five compact claim fields; web dashboard returns advanced filters and aggregations. **Watch:** duplicated business rules and authorization divergence.

## Anti-Corruption Layer

**Problem:** A legacy or third-party system has incompatible domain terminology. **Mechanism:** adapter translates data semantics at the integration boundary. **Case:** legacy claim codes mapped into stable new-domain statuses with tested mappings, rather than leaking raw legacy values across the architecture. **Watch:** incorrect mappings, version drift, and data loss from one-way transformations.

**Pattern exercise:** For a legacy EHR undergoing incremental modernization, select at most four patterns above. Explain what measurable risk each reduces; reject the others until justified.
