# Summary

[Welcome](README.md)

---

# Start Here — No prerequisites

- [How Computers Execute Software](00/01-computers.md)
- [Programming, Data Formats, and Databases From Scratch](00/02-programming-data.md)
- [Follow One Request: Browser to Database and Back](00/03-first-request.md)
- [Absolute Beginner Programming Primer: Learn to Read System Code](00/04-programming-primer.md)
- [Terminals, Git, Tests, and HTTP Debugging for First-Time Developers](00/05-terminal-git-testing.md)

---

# Architectural Thinking

- [A Repeatable System Design Method](01/01-how-to-design.md)
- [Requirements, Quality Attributes, and Constraints](01/02-requirements.md)
- [Capacity Planning and Back-of-the-Envelope Math](01/03-capacity-math.md)
- [HLD, LLD, Diagrams, and Architectural Boundaries](01/04-models-diagrams.md)
- [Make and Defend Architecture Decisions](01/05-decision-records.md)
- [Bottleneck Reasoning and Trade-Off Workshop](01/06-bottleneck-workshop.md)

---

# Networking and the Web

- [Networks, IP, TCP, UDP, QUIC, and OSI](02/01-network-layers.md)
- [DNS, Routing, Proxies, and Service Discovery](02/02-dns-routing.md)
- [HTTP, HTTPS, TLS, HTTP/2, and HTTP/3](02/03-http-tls.md)
- [Load Balancing, Scaling, and Health Checks](02/04-load-balancers.md)
- [CDNs, Edge Caching, and Global Latency](02/05-cdn-edge.md)
- [WebSockets, SSE, Polling, and Real-Time Communication](02/06-realtime.md)

---

# Application Architecture

- [Concurrency, Threads, Async I/O, and Race Conditions](03/01-processes-concurrency.md)
- [Monolith, Modular Monolith, Microservices, and SOA](03/02-architecture-styles.md)
- [REST, GraphQL, gRPC, RPC, and API Contracts](03/03-api-contracts.md)
- [API Gateways, BFFs, Service Mesh, and Configuration](03/04-gateways-discovery.md)
- [Containers, Kubernetes, and Deployment Topology](03/05-containers-kubernetes.md)
- [Application Servers, Connection Pools, and Backpressure Internals](03/06-web-servers-connections.md)

---

# Data and Storage

- [Relational Databases, Modeling, and SQL](04/01-relational.md)
- [Indexes, B-Trees, LSM Trees, and Query Optimization](04/02-indexes-plans.md)
- [ACID, Transactions, Locks, and Isolation Levels](04/03-transactions.md)
- [SQL vs NoSQL: Document, Key-Value, Graph, Wide Column, Search, and Time Series](04/04-database-types.md)
- [Database Replication, Failover, and Read Consistency](04/05-replication.md)
- [Partitioning, Sharding, Consistent Hashing, and Federation](04/06-sharding.md)
- [Consistency Models, CAP Theorem, and PACELC](04/07-consistency-cap.md)
- [Backups, PITR, Disaster Recovery, and Active-Active Databases](04/08-backups-recovery.md)
- [Schema Evolution, CDC, ETL, Search, and Geo-Indexing](04/09-data-evolution.md)
- [Data Integrity, Reconciliation, and Multi-Store Repair](04/10-data-integrity-repair.md)

---

# Caching

- [Caching Fundamentals, Hierarchies, and Eviction](05/01-cache-fundamentals.md)
- [Cache-Aside, Write-Through, Write-Behind, and Refresh-Ahead](05/02-cache-patterns.md)
- [Cache Stampedes, Hot Keys, and Consistency](05/03-stampede-resilience.md)

---

# Queues, Events and Streams

- [Background Jobs, Schedulers, and Async Request-Reply](06/01-background-jobs.md)
- [Task Queues, Message Brokers, Pub/Sub, and Streaming Logs](06/02-queues-vs-streams.md)
- [At-Most-Once, At-Least-Once, Deduplication, and Idempotency](06/03-delivery-idempotency.md)
- [Transactional Outbox, Inbox, Saga, and Choreography](06/04-outbox-saga.md)
- [Backpressure, Rate Limiting, Stream Processing, and CDC](06/05-backpressure-streams.md)
- [Stream Log Deep Dive: Partitions, Consumer Offsets, and Rebalancing](06/06-kafka-partitions.md)

---

# Distributed Systems

- [Why Distributed Systems Are Hard](07/01-distributed-failures.md)
- [Clocks, Logical Time, Ordering, and Event IDs](07/02-time-ordering.md)
- [Consensus, Raft, Quorums, and Leader Election](07/03-consensus.md)
- [Two-Phase Commit, Sagas, and Cross-Service Invariants](07/04-distributed-transactions.md)
- [CRDTs, Multi-Region Consistency, and Conflict Resolution](07/05-crdts-multiregion.md)

---

# Reliability and Scale

- [Availability, SLOs, SLIs, SLAs, and Error Budgets](08/01-availability-slos.md)
- [High Availability, Active-Passive, Active-Active, and DR](08/02-failover.md)
- [Retries, Circuit Breakers, Bulkheads, Throttling, and Timeouts](08/03-resilience-patterns.md)
- [Cells, Deployment Stamps, Geodes, and Blast Radius](08/04-cells-geodes.md)
- [Fault Injection, Runbooks, Restore Drills, and Postmortems](08/05-chaos-recovery.md)
- [Disaster Recovery Workshop: Single Region, Two Zones, and Two Regions](08/06-regional-dr-workshop.md)

---

# Security and Privacy

- [Security From First Principles: CIA, Threat Models, and Trust Boundaries](09/01-security-basics.md)
- [Authentication, Authorization, Sessions, OAuth, and OIDC](09/02-authn-authz.md)
- [Encryption, Hashing, TLS, Secrets, and Key Management](09/03-crypto-secrets.md)
- [Web/API Security: OWASP, IDOR, Injection, and Abuse Protection](09/04-api-threats.md)
- [Data Classification, Privacy, Audit, Compliance, and Retention](09/05-data-governance.md)

---

# Operations and Performance

- [Observability: Logs, Metrics, Traces, and Instrumentation](10/01-observability.md)
- [Monitoring, Alerting, SLO Burn, and Incident Response](10/02-slo-alerts-incidents.md)
- [Performance Antipatterns and Systematic Tuning](10/03-performance-antipatterns.md)
- [CI/CD, Deployment Strategies, and Safe Change](10/04-ci-cd-migrations.md)
- [Cloud Design, Cost, Sustainability, and Build vs Buy](10/05-cloud-cost.md)
- [Load Testing, Tail Latency, and Performance Modeling](10/06-load-testing.md)

---

# Cloud Design Pattern Catalog

- [Design & Implementation Cloud Patterns: Complete Catalog](11/01-implementation-patterns.md)
- [Data Management Patterns: Materialized View, Event Sourcing, Index Tables, Sharding](11/02-data-patterns.md)
- [Messaging Patterns: Queue Leveling, Consumers, Claim Check, Choreography, and More](11/03-messaging-patterns.md)
- [Reliability, Availability, and Security Patterns: Complete Catalog](11/04-reliability-security-patterns.md)
- [Choosing Patterns Without Overengineering](11/05-pattern-selection.md)

---

# AI-Native and Emerging Architectures

- [Modern ML/AI Serving Architecture and Capacity](12/01-ml-inference.md)
- [RAG, Embeddings, Vector Search, Hybrid Retrieval, and Evaluation](12/02-rag-search.md)
- [Agentic Systems, Tool Execution, MCP, and Safe Autonomy](12/03-agents-mcp.md)
- [AI Reliability, LLM Security, Guardrails, and Production Evals](12/04-ai-security-evaluation.md)
- [Emerging Design Areas: Serverless, Edge, Wasm, eBPF, and Platform Engineering](12/05-emerging.md)
- [Voice AI and Multimodal Real-Time System Design](12/06-voice-ai.md)

---

# End-to-End Case Studies

- [Case Study: Design a URL Shortener](13/01-url-shortener.md)
- [Case Study: Robust High-Volume AI Document Processing](13/02-document-processing.md)
- [Case Study: Payments and an Immutable Ledger](13/03-payments.md)
- [Case Study: Global Chat and Presence](13/04-chat.md)
- [Case Study: Multi-Tenant Global SaaS With Regional Failover](13/05-global-saas.md)
- [Case Study: A Reliable Notification Platform](13/06-notifications.md)
- [Case Study: EHR Search and Pre-Charting AI](13/07-healthcare-rag.md)
- [Case Study: Clickstream and Real-Time Analytics](13/08-analytics-streaming.md)
- [Case Study: Media Upload, Transcoding, and CDN Delivery](13/09-video-media.md)
- [Case Study: Distributed API Rate Limiter](13/10-rate-limiter.md)
- [Case Study: Location Search and Ride Dispatch](13/11-ride-hailing.md)

---

# Hands-On Labs

- [Lab Environment and the Experimental Method](14/01-lab-setup.md)
- [Lab 1: Build, Call, and Break an HTTP Service](14/02-http-experiment.md)
- [Lab 2: Prevent Overselling With Transactions](14/03-transactions-experiment.md)
- [Lab 3: Shard Routing and Resharding](14/04-sharding-experiment.md)
- [Lab 4: Make Duplicate Message Delivery Harmless](14/05-outbox-experiment.md)
- [Lab 5: Capacity, Queues, and Token Buckets](14/06-capacity-rate-limits.md)
- [Capstone: Design, Implement, Test, and Review a Production-Style Service](14/07-capstone.md)

---

# Review, Glossary and References

- [Architect's Checklists, Equations, and Decision Tables](15/01-checklists-formulas.md)
- [Complete roadmap.sh Topic Coverage Matrix](15/02-roadmap-coverage.md)
- [Glossary: Key Terms for Beginners and Architects](15/03-glossary.md)
- [Scenario Questions, Worked Reasoning, and Self-Assessment](15/04-questions-solutions.md)
- [Structured Study Plan, Mastery Milestones, and Architecture Review Template](15/05-roadmap-study-plan.md)
- [Authoritative References, Edition Notes, and Update Policy](15/06-references.md)

