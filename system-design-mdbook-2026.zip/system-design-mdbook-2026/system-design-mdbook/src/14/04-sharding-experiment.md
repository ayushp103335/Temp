# Lab 3: Shard Routing and Resharding

**Objective:** See how a routing function determines database placement and why changing shard count causes data movement.

### Run

```sh
python labs/shard_router.py
```

For 10,000 synthetic keys, a naïve hashed modulo router changes from 4 to 5 physical shards. Roughly 80% of keys may remap. A versioned virtual-bucket map can instead reassign approximately 20% of buckets to the new node. Actual percentages vary with sample distribution; the built-in test checks that the bucket-map approach moves fewer keys.

### The routing contract

For an ID lookup, both writers and readers must use the **same current mapping version**. During migration, a stale reader might query the old shard while a writer stores data on the new shard. Introduce migration states (copy, verify, dual-read/controlled forwarding, cutover, retire), ownership epochs, and an authoritative mapping registry.

### Exercise A: Why name search is harder

The key is `patient_id`, but a user searches by `name='Asha'`. The name could correspond to many IDs on different shards. Options: scatter to all shards, query a global lookup/search index with access checks, or remodel partitioning if name search dominates. A search index can return candidate IDs and still needs shard-aware record fetches.

### Exercise B: Hot partitions

Simulate 90% of queries targeting one key. Uniform hashing of *keys* does not guarantee uniform traffic if key popularity is skewed. Add an application-level cache for read hot spots, isolate large tenants, or split data by a more appropriate composite key. Never blindly duplicate writes to the same authoritative logical record.

### Exercise C: Composite key

Design a router using `(tenant_id, patient_id)` while supporting tenant-scoped joins and global audit queries. Write down which queries are local, which require fan-out, and which need derived indexes.

**Architecture decision prompt:** At what measured database CPU/IO/write rate would you start evaluating sharding rather than simply adding indexes, adjusting SQL, or moving analytical reads off the OLTP database?
