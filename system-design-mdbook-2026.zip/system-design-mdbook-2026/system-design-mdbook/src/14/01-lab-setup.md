# Lab Environment and the Experimental Method

The book includes six self-contained runnable Python labs under `labs/`. They require Python 3.11+ and only the Python standard library. Run the tests from the extracted book root:

```sh
python -m unittest discover -s labs/tests -v
```

These labs intentionally simplify production features so one behavior can be measured in isolation. You will see how HTTP works, how transactions protect a race, how sharding moves data, how a queue can deliver duplicate messages, and how rate limits/capacity operate. A production system needs additional security, availability, tests, retries, observability, and operational controls.

## Practice workflow

1. State one hypothesis: e.g., "Without an atomic conditional update, two buyers may both purchase one unit."
2. Read the script and predict output *before* executing it.
3. Run the experiment at least three times, with altered concurrency/inputs.
4. Change one variable, observe and record the result.
5. Explain the invariant and what the toy example omits.
6. Write an architecture decision and a failure test derived from the experiment.

## Repository structure

```text
system-design-mdbook/
  book.toml
  src/                 # all textbook chapters and diagrams
  labs/
    http_server.py
    atomic_inventory.py
    shard_router.py
    outbox_demo.py
    token_bucket.py
    capacity_sim.py
    tests/test_labs.py
```

## Tool prerequisites for optional production extensions

You can use Docker, PostgreSQL, Redis, and RabbitMQ for further investigation, but none is necessary for core exercises. When using real infrastructure, bind local development services to loopback where practical, never use real credentials/PHI, and isolate experiments from business systems. Avoid copying sample `password=admin` settings into public deployments.

## Minimal data notebook

For every lab record `input`, `output`, `assumption`, `correctness result`, `observed bottleneck`, `changed design`, and `remaining risk`. This engineering notebook matters more than merely seeing a green test.

**Check yourself:** Why do we compare p99 and correctness as well as mean latency? How can a performance improvement introduce a data integrity regression?
