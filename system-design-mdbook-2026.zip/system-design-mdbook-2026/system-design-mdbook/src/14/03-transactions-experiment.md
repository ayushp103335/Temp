# Lab 2: Prevent Overselling With Transactions

**Objective:** Demonstrate that a data invariant can be protected even when two buyers submit at nearly the same time.

### Run

```sh
python labs/atomic_inventory.py
```

The experiment creates a temporary SQLite database with one item `A` and `count=1`. Two independent SQLite connections attempt a purchase through separate threads. `BEGIN IMMEDIATE` acquires a SQLite write transaction before the conditional update. Only one purchase can succeed; the result order varies.

Expected invariant:

```text
successful purchases = 1
remaining stock = 0
recorded purchases = 1
```

### Why it works

The `UPDATE stock SET count=count-1 WHERE sku='A' AND count>0` statement is atomic under the transaction. The code checks affected rows, creates a purchase record only when the decrement succeeded, and commits both changes together. A second writer cannot decrement below zero because it re-evaluates the predicate after the first transaction, and the table's `CHECK` constraint adds defense in depth.

### Experiments

1. Increase initial stock to 3; launch 10 concurrent buyers. Predict and verify the number of successful purchases.
2. Remove the `count>0` predicate but keep the DB check constraint. What exception or rollback occurs on overdraw?
3. Implement an unsafe read-then-write without transaction and try to provoke inconsistent results. SQLite's locking may lead to lock errors rather than a textbook lost update; explain why the DB matters.
4. Add a `version` field and update with `WHERE version=?` to implement optimistic concurrency.

### Production lesson

This lab demonstrates local DB atomicity, not how to safely reserve inventory across three warehouses or call a payment provider. For that, study isolation levels, idempotency, saga state, and compensations. A lock that protects a Python variable would fail to synchronize independently deployed API processes.

**Architecture decision prompt:** Explain why moving an atomic one-database inventory update to multiple microservices can increase correctness risk.
