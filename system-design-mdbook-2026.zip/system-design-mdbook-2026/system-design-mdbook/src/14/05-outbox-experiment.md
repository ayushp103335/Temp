# Lab 4: Make Duplicate Message Delivery Harmless

**Objective:** Understand the atomic outbox and idempotent consumer pattern without needing an external broker.

### Run

```sh
python labs/outbox_demo.py
```

The script creates SQLite tables `jobs`, `outbox`, `processed_events`, and `effects` in memory. `accept_job()` stores job state and an outbox event in one transaction. `handle_event()` is then deliberately invoked **twice** with the same event ID to simulate broker redelivery after a worker crash.

Expected:

```text
first: processed
second: duplicate: no effect
effect_count: 1
status: DONE
```

### Read the critical invariant

The deduplication marker `(consumer, event_id)` is unique. The handler inserts it and applies the business effect inside the **same SQLite transaction**. If it has already been inserted, it returns without repeating the effect.

### Failure injection exercises

1. Add `raise RuntimeError('crash')` after the processed-marker insert but before the effects insert. Verify transaction rollback prevents a misleading "already processed" marker.
2. Add a simulated broker dispatcher that first calls the handler, then raises before marking the outbox message sent. Restart dispatcher and redeliver; confirm exactly one local effect.
3. Make two different consumer names subscribe to the event. They should each process once because deduplication is per consumer.
4. Modify the event schema and introduce a version field; test old-consumer compatibility.

### What the toy model doesn't solve

The example does not contain a real broker, multiple processes, provider-side charges, network partitions, or real durable queues. External API calls cannot be rolled back by the SQLite transaction. For an expensive model call, add a durable outcome/operation ID to avoid repeated spend where provider semantics allow it.

**Architecture decision prompt:** Explain why an outbox can prevent lost accepted jobs while still producing duplicate messages, and why this is expected rather than a defect.
