# Lab 1: Build, Call, and Break an HTTP Service

**Objective:** See the boundary between an OS process, TCP port, HTTP message, and client.

### Run

From the project root:

```sh
python labs/http_server.py
```

In another terminal:

```sh
curl -i http://127.0.0.1:8080/health
curl -i http://127.0.0.1:8080/does-not-exist
```

Expected: first request returns `HTTP/1.0 200 OK` (the teaching handler inherits the Python server's default protocol) with `{"status":"ok","process":"single service"}`; second returns 404. Python's `http.server` is a learning tool, not a hardened production server.

### Inspect the mechanics

The server binds port 8080 on `127.0.0.1`, meaning it is reachable only from the local machine through the loopback interface. `ThreadingHTTPServer` handles concurrent connections using threads. Each request creates a handler that writes headers followed by body bytes. `Content-Length` describes body size in bytes; not Python string characters.

### Break it

- Stop the process and retry `curl`: expect connection refused or another transport error.
- Change port from 8080 to 8081 and observe that `curl` pointed at 8080 fails.
- Add `time.sleep(2)` before responding and send concurrent requests; compare wall time and active threads.
- Change the bind address to `0.0.0.0` only in a controlled local environment and explain why this expands exposure.

### Design interpretation

An external load balancer can distribute requests to multiple instances, but each instance must run on a reachable port and pass readiness. A healthy process with an unavailable database can still return a broken business response. Add dependency-aware synthetic checks to detect full-path failures without turning transient failures into restart storms.

**Advanced extension:** Add `X-Request-ID` support, structured logging, a `GET /status` endpoint, and unit tests for 404. Do not log authentication tokens if you add auth later.
