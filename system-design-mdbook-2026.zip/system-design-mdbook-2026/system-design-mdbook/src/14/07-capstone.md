# Capstone: Design, Implement, Test, and Review a Production-Style Service

**Project:** Create a tenant-scoped document-processing API with durable acceptance, asynchronous work, idempotency, and observable recovery. You may implement it with Python/FastAPI, PostgreSQL/SQLite for a prototype, RabbitMQ for task dispatch, and filesystem/object storage. Avoid sensitive or real patient data.

## Functional contract

- `POST /v1/documents` obtains an upload capability or accepts a small teaching file.
- `POST /v1/jobs` accepts an idempotency key and returns `202 + job ID` after durable record creation.
- `GET /v1/jobs/{id}` returns tenant-authorized status.
- `GET /v1/jobs/{id}/result` returns the result or appropriate pending/error state.
- An operator-safe endpoint/command replays a failed job without a duplicate visible result.

## Non-functional goals (for local testing)

- No lost accepted job when API, publisher, or worker process is killed individually.
- No duplicate visible effects after redelivery; state transitions remain valid.
- 99% of trivial status requests finish within a chosen measured target under 20 RPS local load.
- Observability: request ID, job ID, status transition, retry count, queue age, and failures.
- No cross-tenant access in automated tests; no secrets or payloads in logs.

## Required artifacts

1. Requirements and assumptions with traffic/capacity estimates.
2. System context + component + sequence diagram.
3. Tables and indexes, event schema, and idempotency contract.
4. Failure-mode analysis and tested recovery sequence.
5. Benchmark results: mean, p95/p99, error rate, CPU/IO, queue age.
6. ADR comparing synchronous design against async queue design.
7. Basic runbook and tested restore instructions.

## Acceptance tests

- Send same idempotency key twice; obtain one logical job.
- Terminate process after DB commit before publishing; reconciler eventually publishes.
- Terminate worker after result write before ack; duplicate is detected.
- Disable model adapter; retry budget exhausted and job becomes operator-reviewable.
- Flood one tenant; other tenant remains within defined fairness target.
- Rotate signing secret/service token without allowing unauthorized access.
- Restore DB backup and object metadata; reconcile cross-store references.

## Architecture-review scoring

Assign 0–4 points each for requirements, correctness, capacity math, failure handling, security, observability, deployment/recovery, and cost clarity (32 points). A design scoring highly only on diagrams but poorly on recovery is not production-ready.

**Final question:** Which three components would you remove in a much smaller 10-jobs/day deployment, and why? This tests whether you can *simplify* architecture, not only add complexity.
