# Lab 5: Capacity, Queues, and Token Buckets

**Objective:** Prove that a queue does not increase worker capacity and that a rate limiter must define burst allowance explicitly.

### Part A: Queue simulation

```sh
python labs/capacity_sim.py
```

The default generates 100 arrivals in 60 seconds, with 8 worker slots and 8-second service time. Long-run maximum throughput ≈ `8 slots / 8s = 1 job/s = 60 jobs/min`, compared with 100 arrivals/min. The simulation reports increasing wait times.

**Experiments:** change slots to 20; change service time to 3 seconds; generate a 300/min burst for 60 seconds followed by a lower rate. Explain steady-state versus transient backlog and why average service time does not guarantee p95 queue delay.

### Part B: Token bucket

```sh
python labs/token_bucket.py
```

The limiter starts with 3 tokens, refills at 2 tokens/s, and consumes one token per accepted request. Four simultaneous requests at t=0 allow three and reject one. After 0.5s, one token replenishes.

**Experiments:** change capacity to 10 with same refill rate; explain burst vs sustained throughput. Call it from multiple processes and explain why the local Python object would not enforce a global tenant quota. Design an atomic Redis-based shared limiter, including failure policy if Redis is unavailable.

### System-level overload decision

If the backend processes 60 jobs/min but clients submit 100/min indefinitely, no finite cache or queue fixes the mismatch. Choices include higher capacity, reducing work, tiered quotas, faster inference, explicit rejection, or lower completion commitments.

**Architecture decision prompt:** Should a request return `429`, `202`, or `503` under overload? The answer depends on whether it was durably accepted, whether backpressure is temporary, and how clients should retry.
