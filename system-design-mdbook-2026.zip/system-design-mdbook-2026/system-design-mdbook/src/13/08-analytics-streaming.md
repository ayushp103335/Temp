# Case Study: Clickstream and Real-Time Analytics

**Goal:** Ingest 2M events/s at peak, compute per-minute dashboards, support historical recomputation, and retain raw events for 30 days. This is an intentionally large-scale teaching scenario.

## Data and rate

Assume mean event size 500 bytes, so peak raw input ≈ 1 GB/s before replication/compression/headers. At continuous peak, 86.4 TB/day; do **not** assume this is the average without measured traffic. An intake layer should validate schema, apply per-producer quota, and use a scalable partitioned event log.

## Architecture

```text
SDKs -> collector API -> partitioned log -> stream processor -> aggregates store
                          |        |             |
                          |        |          late-event correction
                          |        +-> archive object storage (raw)
                          +-> poison-event quarantine
Batch engine -> archived data -> recompute aggregates
```

Partition by user ID/event key if per-user ordering is valuable and reasonably balanced. Choose retention and partition count based on throughput, consumer parallelism, recovery/replay windows, and broker limits. Use Avro/Protobuf/JSON with schema compatibility; reject or quarantine invalid event versions.

## Event-time windows

For a dashboard of purchases per five minutes, use event time and watermark policies. A purchase event occurring 09:59 but received 10:07 should update the correct historical window or produce a tracked correction. Idempotent sinks prevent duplicates after stream processor restarts. Exactly-once-internal processing guarantees require careful integration with the external aggregate DB.

## Reliability and governance

Backpressure should shed/slow nonessential telemetry before damaging production transactions. Support consumer replay, offset checkpointing, per-topic lag monitoring, schema migration, and privacy deletion requests across raw and derived data. Use downsampling and retention tiers to control long-term storage cost.

**Design verdict:** A streaming event log is justified here because replay, multiple independent consumers, and very high sustained event volume are core requirements.
