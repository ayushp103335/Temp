# Case Study: Multi-Tenant Global SaaS With Regional Failover

**Goal:** Support 5,000 businesses/tenants, heavy tenant-size skew, and defined data-residency and disaster-recovery requirements. Assume application p95 < 250 ms for regional reads and RTO ≤ 30 minutes for region loss.

## Context and architecture

```text
Global DNS/traffic steering
    |           |
Region A     Region B
 ingress      ingress
  |            |
 tenant-cell  tenant-cell
  |            |
 DB owner A   DB owner B
    \         /
  approved cross-region event/backup mechanisms
```

A global tenant-routing directory maps `tenant_id -> home_region -> cell`. The directory is a critical control plane; cache stable routing at edge and APIs, protect it from unauthorized edits, and design an outage behavior. Geo-routing by user IP alone can violate data-residency requirements when a traveling user accesses a tenant's records.

## Isolation choices

Small tenants may share a database with tenant-keyed partitions and strict authorization; large tenants can move to dedicated databases/cells. Use live migration with backfill, source/destination consistency, cutover barrier, and rollback. Cell placement must consider noisy-neighbor CPU, database IO, broker capacity, and regional quotas.

## Active-active nuance

Multiple app regions can accept **reads** while all authoritative writes for a tenant route to its home region. During regional failure, promoting a replica requires RPO validation and stale-leader fencing. Allowing independent multi-region writes changes the consistency model and conflict policy for every field.

## Failure scenarios

- Routing directory outage: existing sessions continue using cached signed mapping for a bounded time.
- Hot tenant saturates one cell: enforce quota or reassign tenant without affecting others.
- Cross-region replication lag: report stale data; block or reroute strict-read operations.
- Entire region failure: invoke tested failover and explicitly account for incomplete replication.
- Tenant deletion: propagate to object storage, caches, logs, search projections and backups under applicable policy.

**Design verdict:** Start with region-affine write ownership plus well-tested DR. Introduce concurrent cross-region writes only for fields whose conflicts can be safely resolved.
