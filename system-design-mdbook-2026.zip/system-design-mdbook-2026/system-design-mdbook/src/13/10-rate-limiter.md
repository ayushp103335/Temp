# Case Study: Distributed API Rate Limiter

**Goal:** Protect a multi-tenant public API with 100 requests/second per tenant, permit short bursts of 200, and return predictable `429` responses even with 20 API replicas.

## Contract

A **token bucket** with refill rate 100 tokens/s and capacity 200 permits a new/idle tenant to send 200 immediately, then sustains roughly 100/s as tokens refill. Decide whether different endpoints consume different weights (e.g., expensive AI inference costs 10 tokens).

## Architecture

```text
Client -> edge/API gateway -> atomic limiter store -> application
                           |  tenant_id + route scope
                           +-> allowed/rejected decision + quota metadata
```

A local in-process dictionary will not enforce global quotas: each of 20 replicas could independently permit 200, allowing 4,000 in aggregate. Use a shared atomic store or another well-defined distributed quota algorithm, with time source and failure policy.

## Atomicity

In Redis, a Lua script or transactionally atomic primitive can update the bucket's tokens and timestamp in one operation. A naïve `GET -> compute -> SET` across concurrent replicas loses updates. Distributed limits can introduce cross-region latency and partial failures; some systems use a local fast allowance with periodic reconciliation, knowingly allowing bounded overshoot.

## Security and fairness

The `tenant_id` must come from authenticated identity, not an unverified client header. Limit anonymous traffic separately, protect against cardinality attacks that create millions of quota keys, and define memory/TTL cleanup. Account for abusive retries and bots at edge before expensive authentication/model operations where appropriate.

## Failure choice

If limiter storage fails, a read-only public documentation API might temporarily fail open with strict local emergency caps. A costly billable AI operation or security-sensitive endpoint might fail closed. Document per-route policy and alert on fallback activation.

**Challenge:** Design a limiter for a customer using both Region A and B without requiring every request to synchronously contact one distant global Redis instance. State acceptable quota overshoot and reconciliation behavior.
