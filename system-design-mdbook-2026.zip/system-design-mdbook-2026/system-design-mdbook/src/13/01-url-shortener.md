# Case Study: Design a URL Shortener

**Goal:** Accept a long URL, return a short code, redirect users, and measure clicks. This is the introductory architecture case: high read-to-write ratio, unique identifiers, caching, basic abuse defenses.

## Requirements and assumptions

- `POST /links` creates short code; `GET /{code}` redirects; optional owner analytics.
- Assume 1M new links/day, 100M redirects/day, average link record 300 bytes, and 3 years retention. These are **illustrative**, not measured traffic.
- Need low redirect latency, durable mappings, abuse detection, and configurable expiration.

Average writes ≈ 11.6/s; average reads ≈ 1,157/s; peaks may be 5–10×. Mapping storage ≈ `1M/day × 365 × 3 × 300 B ≈ 328.5 GB` before indexes, replicas, metadata and analytics. Redirect requests dominate.

## API and data model

```http
POST /v1/links
{"destination":"https://docs.example.com/a","expires_at":null}

201 {"code":"aZ09Qb","short_url":"https://s.example/aZ09Qb"}
```

```sql
CREATE TABLE links (
  code VARCHAR(16) PRIMARY KEY,
  destination TEXT NOT NULL,
  owner_id BIGINT,
  expires_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL
);
```

Choose a random code with collision check, or allocate IDs then base62 encode. Base62 with six characters yields `62^6 ≈ 56.8 billion` possible codes, but collision behavior, predictability, abuse, and reserved words require consideration. Avoid relying on short sequential IDs if link enumeration is a privacy concern.

## Architecture

```text
              [create] -> API -> SQL/Key-value mapping store
Client -> CDN/LB
              [redirect] -> cache -> mapping store on miss -> 302 Location
                            |
                            +-> async click event -> analytics stream/warehouse
```

A redirect may use `302` while allowing destination changes; `301` can be aggressively cached by clients. Protect against phishing/malware URLs and open redirects under the chosen product policy. Keep analytics off the redirect critical path when possible; click counting may be eventually consistent.

## Failure and scale

If Redis fails, mapping reads should fall back to the durable DB with admission control to prevent collapse. Cache hot codes; use negative caching cautiously for invalid codes. Partition mappings by hashed code only when write/storage volume and measured DB limits justify sharding. A global CDN may help popular redirect codes, but cache invalidation is harder if destinations can change.

**Design verdict:** Start with one durable mapping DB, stateless API replicas, Redis/CDN when repeated redirects justify it, and async analytics. Do not start with distributed consensus, multi-writer databases, and 40 microservices.

**Challenge:** What changes if links must be editable with immediate global consistency and deletion for security takedowns?
