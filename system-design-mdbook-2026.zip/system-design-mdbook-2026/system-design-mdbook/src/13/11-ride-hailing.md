# Case Study: Location Search and Ride Dispatch

**Goal:** Match a rider to a nearby available driver while drivers update positions frequently. This case emphasizes geospatial indexing, rapidly changing state, concurrency, and bounded decision latency.

## Functional flow

1. Driver app sends location/availability updates with timestamps.
2. Rider sends pickup coordinates and service class.
3. Dispatch service finds eligible nearby drivers and ranks by estimated pickup time.
4. System sends short-lived offers; a driver accepts; dispatch commits assignment.
5. Rider and driver receive updates, and trip proceeds through a state machine.

## Architecture

```text
Driver GPS -> location ingest -> fresh geo index / TTL state
                                   |
Rider API -> dispatch planner -> geo candidates -> route/ETA estimate
                                   |
                         offer/accept coordinator -> trip DB transaction
                                   |
                             notification streams
```

A geo index might use H3/S2/geohash cells to narrow candidate set, then compute road-network ETA rather than straight-line distance. GPS updates are ephemeral and often tolerate slight staleness; trip assignment cannot tolerate two riders being assigned the same exclusive driver simultaneously.

## Atomic assignment

Store driver availability with a version/lease. Dispatch attempts a conditional update from `AVAILABLE` to `RESERVED` with expected version; only one competing rider wins. Use reservation expiry when the offer times out and guard against a driver accepting an expired offer.

## Location data safety

Location history is sensitive. Scope collection, retention, and access; limit how much precision is stored for telemetry; prevent public enumeration of active driver positions. Add abuse and fraud checks for spoofed GPS signals and implausible transitions.

## Capacity and resilience

Suppose 100,000 online drivers send one update every 5 seconds: average 20,000 location updates/s, before retries and spikes. Partition ingest by driver ID; update geo indexes with bounded TTL; minimize expensive global sorting. Track location freshness, dispatch p95, offer acceptance rate, double-assignment errors, and routing API rate limits.

**Challenge:** A driver disconnects after accepting but before the rider sees confirmation. Explain which state source is authoritative and how both clients recover without duplicate trips.
