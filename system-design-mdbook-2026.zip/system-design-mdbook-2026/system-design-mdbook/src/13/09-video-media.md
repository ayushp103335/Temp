# Case Study: Media Upload, Transcoding, and CDN Delivery

**Goal:** Accept user-uploaded videos, create multiple playback renditions, and deliver content with predictable latency worldwide.

## Data path

```text
Client -> API grants scoped upload capability
Client -> object storage (multipart upload)
Upload completed -> event/outbox -> transcode job queue
                                -> workers produce bitrates/formats
                                -> manifest + media segments in origin
Viewer -> CDN -> manifests/segments -> adaptive player
```

Keep large video bytes out of the API and message broker. Multipart upload requires checksum/part validation and a finalization step. Transcoding is CPU/GPU intensive; batch workers can scale separately from the control-plane API. Store media metadata, ownership, moderation state, and rendition progress in a database.

## Playback architecture

Adaptive bitrate streaming (HLS/DASH-style) splits media into segments and manifests that allow the player to select appropriate quality. Use versioned, cacheable segment URLs and strong control on access to paid/private content. Signed CDN cookies/URLs and token renewal must be designed to avoid accidentally sharing a private manifest.

## Operational concerns

Handle partial uploads, duplicate transcode events, poison media, storage lifecycle and copyright/moderation policy. Track time to first playable rendition, encoding failures, storage/egress costs, cache hit ratio, and viewer startup/buffering time.

**Challenge:** A 2 GB upload completes in object storage, but the notification to queue is lost. Design a reconciliation scan that discovers and safely re-enqueues the missing transcode job.
