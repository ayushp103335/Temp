# Case Study: Payments and an Immutable Ledger

**Goal:** Transfer value between accounts without duplication, preserve an auditable ledger, and handle uncertain third-party payment outcomes. This case emphasizes **correctness over casual availability**.

## Requirements

- Idempotent transfers; no double debit; exact balance invariant; traceable external provider interactions.
- Strong consistency for internal ledger commit; eventually consistent dashboard/notifications allowed.
- Assume 2,000 transfer requests/s peak; define realistic account skew and bank/provider throughput separately.

## Domain model

Represent money using integer minor units or fixed decimal, never binary floating point for financial accounting. Use immutable ledger postings with balanced debits and credits within one transaction:

```text
transfer_id=t-1001; currency=USD; amount_minor=1250
posting: account A  -1250
posting: account B  +1250
sum(postings) = 0
```

Enforce unique `(tenant_id, transfer_id)` and balance/reservation invariants. The business meaning of negative/positive depends on debit/credit conventions; define it consistently.

## Architecture

```text
Client -> Payment API -> authenticated idempotency store
                   |-> ledger DB transaction -> outbox event
                   |                         -> reconciliation worker
                   +-> provider operation (with stable idempotency token)
Notification/analytics subscribe to committed events
```

If the provider times out, mark the transfer `UNKNOWN_EXTERNAL_OUTCOME` and query/reconcile the provider by stable ID before attempting another charge. Do **not** assume timeout means failure. A saga may compensate authorized/captured payments, but a refund is a separate auditable transaction, not deletion of history.

## Scale and partition choice

One SQL database may suffice well beyond initial volume if carefully indexed/partitioned. Sharding accounts creates hard cross-shard transfers. Evaluate per-account hot keys, contention, and ledger integrity before sharding. A leader/consensus mechanism may be warranted for authoritative write ownership under regional failover.

## Disaster recovery

Asynchronous regional replication could lose acknowledged ledger entries on failover. If the contract forbids this, use a durability strategy whose acknowledgment semantics cover the defined failure class; document latency/availability trade-offs and verify by killing the primary during committed transfers.

**Challenge:** A customer resends the same transfer after a 15-second timeout using a new idempotency key. What server-side business key or external reconciliation prevents duplication?
