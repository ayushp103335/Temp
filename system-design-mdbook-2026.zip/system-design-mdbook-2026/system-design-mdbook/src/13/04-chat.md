# Case Study: Global Chat and Presence

**Goal:** Deliver text messages to online/offline recipients, display ordered conversation history, and maintain approximate presence/typing indicators.

## Requirements

- Assume 1M daily active users and 100K simultaneous WebSocket connections, with 100M messages/day.
- Messages durable, ordered within each conversation; presence may be eventually consistent and ephemeral.
- Multi-device sync, reconnect, offline delivery, abuse controls and media attachment support.

## Architecture

```text
Mobile/Web -> regional WS gateways -> message service -> durable message DB
                    |                   |
                    |             events keyed by conversation_id
                    |                   |
                    +<- fan-out bus <----+
                    |
             per-device delivery acknowledgments / reconnect cursors
```

**Storage:** `messages(conversation_id, sequence, message_id, sender_id, content_ref, created_at)` with suitable per-conversation ordering. Separate `read_cursor` or delivery state per participant/device; don't mark read just because a gateway wrote bytes to a socket. Attachments go into secured object storage, not directly into every chat event payload.

## Ordering and duplication

A server-assigned monotonic sequence within a conversation makes replay/pagination stable. `message_id` is unique for client retries. Multiple gateways may receive messages concurrently; sequence assignment must be coordinated by the chosen data/partition owner. Cross-conversation global ordering is unnecessary.

## Presence

Heartbeats can update TTL-based ephemeral presence. A lost connection may leave a user "online" briefly until TTL expiry; this is often acceptable. Presence is not stored with the same strict durability as message history. A one-way pub/sub channel is insufficient for durable offline messages.

## Scale hazards

100K WebSocket connections distribute across gateways. If one node holds 10K connections and fails, clients should reconnect with jitter, authenticate again, and fetch messages after their last acknowledged sequence. Monitor connections, fan-out lag, per-gateway memory, failed deliveries, and reconnect storms.

**Design verdict:** Separate durable message truth from ephemeral real-time transport. A WebSocket connection is not a database commit.
