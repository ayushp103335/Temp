# Case Study: EHR Search and Pre-Charting AI

**Goal:** Let an authenticated clinician answer clinical questions across structured observations and unstructured notes without leaking another patient's data or inventing missing findings.

## Source strategy

Structured sources: encounters, allergies, medications, labs, vitals, immunizations, diagnoses, procedures, appointments. Unstructured sources: notes, scanned PDFs, discharge summaries, and reports. Each item carries patient ID, tenant/clinic scope, encounter/time, source, access rules, and data freshness.

## Architecture

```text
FHIR/clinical APIs -> change feed -> normalized structured store
Document repository -> parser/OCR -> permission-tagged chunks
                              |        |
                          search + vector index
                              |
Clinician -> auth -> query planner -> structured SQL/FHIR + hybrid retrieval
                              -> evidence merge/rerank -> LLM summary
                              -> cite source/time -> validated response
```

The first decision is **which source is authoritative for which question**. "Most recent sodium" should prefer structured lab results with proper code/time/status filtering, not a similarity search that finds an older note mentioning sodium. "Summarize reasons for recent referrals" may require searching notes and signed referral documents.

## Permission enforcement

Retrieve only records in the clinician's authorized tenant/patient context; revalidate authorization when showing citations. Do not rely on model instructions like "do not expose unauthorized results". Cache keys, vector filters, database views, and tool credentials must honor the same policy.

## Correctness and drift

Use evidence-linked answers and abstain when the source does not support an assertion. Evaluate date accuracy, unit conversion, contradictory notes, missing records, procedure context, negative findings, and citation validity. Detect extraction failures and index lag. Restrict generated clinical suggestions to an approved scope with human review.

## Reliability design

If vector search is down, allow a deterministic subset of structured queries when safe. If the source system is down, identify the age of locally indexed data instead of claiming it is current. Audit all access to sensitive patient records and control prompt retention/vendor processing.

**Design verdict:** A high-quality clinical search system is a data governance, query planning, retrieval, and validation architecture—not merely "connect an LLM to the EHR".
