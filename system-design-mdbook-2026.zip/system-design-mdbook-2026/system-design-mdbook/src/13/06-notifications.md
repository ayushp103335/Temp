# Case Study: A Reliable Notification Platform

**Goal:** Send email, SMS, and push notifications from domain events while respecting preferences, provider quotas, retries, and opt-out requirements.

## API / events

```json
{
  "event_id":"evt-77",
  "tenant_id":"t-4",
  "notification_type":"APPOINTMENT_REMINDER",
  "recipient_id":"u-900",
  "template_version":"v3",
  "scheduled_at":"2026-11-10T10:00:00Z"
}
```

Do not place raw patient details or phone numbers in broad event topics unnecessarily. Keep recipient lookup and template rendering inside a controlled service with access policy.

## Architecture

```text
Clinical API -> outbox -> event topic -> notification scheduler
                                      -> preference/consent check
                                      -> channel queues (email/SMS/push)
                                      -> provider adapters
                                      -> webhook delivery status
                                      -> state store and audit
```

Use a unique notification intent key (`appointment_id + reminder_type + scheduled_date`) to avoid duplicate reminders after retries. Delivery semantics differ: provider accepted is not necessarily handset delivered, and an email delivered event does not prove user read it. Store clear states.

## Provider failure

If SMS provider returns 429, apply rate limits, backoff, and possibly an approved secondary provider. Avoid automatically sending twice when first provider's outcome is unknown. Respect opt-out/consent and quiet hours according to applicable policy. Prioritize urgent security alerts separately from marketing messages.

## Metrics

Measure event-to-send delay, provider error rates, user opt-outs, duplicate-send rate, per-channel cost, dead-letter count, and delivery-failure resolution. Use bounded retention and redacted payloads.

**Challenge:** Provider A times out on send but later reports delivered. How does your system prevent Provider B from also sending the same reminder?
