# Case Study: Robust High-Volume AI Document Processing

![Case Study: Robust High-Volume AI Document Processing architecture diagram](../assets/async-documents.svg)

**Goal:** Accept multi-page PDFs, extract structured results, process in live/batch mode, expose progress, never silently lose an accepted job, support external inference limits and audited access.

## Requirements and assumption set

- 100 accepted jobs/min sustained, 300/min burst for five minutes.
- Average 8 MB input (real distributions are heavy-tailed); 8 seconds average active worker occupancy; sensitive documents; output JSON with per-field provenance/quality flags.
- API p95 < 300 ms for acceptance; processing SLO: 95% of accepted non-pathological jobs within 120 seconds under designed load.

Minimum steady-state worker slots at 70% utilization ≈ `(100/60 × 8)/0.7 ≈ 19.05`, so plan 20+ equivalent slots plus burst/overhead. At 300 jobs/min and 20 slots each 8 seconds, capacity ≈ 150/min; five-minute burst adds ~750 jobs backlog, before retries. That backlog itself requires ~5 minutes to drain at 150/min once arrival stops; with ongoing 100/min, net drain is 50/min, taking ~15 minutes. This conflicts with a universal 120-second completion SLO—negotiate burst exceptions or add substantially more capacity.

## Architecture

```text
Browser -> authenticated API -> presigned upload URL -> object storage
                    |
             job DB + outbox (one transaction)
                    |
              event publisher -> durable broker -> bounded OCR workers
                                               -> model provider
                                               -> validation
                                               -> results DB/object store
Browser -> status API -> job DB <- worker state transitions
```

## Tables and invariants

`jobs(job_id, tenant_id, request_hash, object_key, status, created_at, lease_until, attempt)`; `outbox(event_id, payload, published_at)`; `job_results(job_id, schema_version, result_uri, completed_at)`; unique `(tenant_id, idempotency_key)` where applicable. Upload finalization verifies object existence, checksum, accepted MIME/size policy, and quarantine scan before enqueueing.

A worker claims a job via atomic state transition and lease. It enforces per-provider rate limits, calls inference, validates Pydantic/JSON schema and cross-page consistency, writes result transactionally, then acknowledges the message. Crashes cause safe redelivery and repeat execution. Persist enough work state to avoid unnecessary repeated expensive inference where feasible.

## Non-functional choices

**Security:** tenant-scoped object keys, least-privilege service credentials, encryption, audited accesses, retention. **Reliability:** outbox, DLQ/replay, idempotent writes, backups and restore tests. **Cost:** batch inference, dynamic model selection, quotas, input size limits. **Observability:** oldest pending job age, throughput, worker utilization, model token cost, p95/p99 completion, field correctness, retry rate and distribution.

## Failure simulation

1. Kill API after DB transaction before HTTP response: client retry must return same job.
2. Kill publisher after broker ack before outbox mark: duplicate message is safe.
3. Kill worker after result DB commit: redelivery does not create second result.
4. Force model `429` and prove intake throttles before queue becomes operationally infinite.
5. Lose object: mark job as repairable error; do not fabricate extraction output.

**Design verdict:** A queue solves request/processing separation, not capacity, authorization, correctness, or durability by itself.
