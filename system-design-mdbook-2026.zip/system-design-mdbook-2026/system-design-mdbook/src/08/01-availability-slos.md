# Availability, SLOs, SLIs, SLAs, and Error Budgets

**Availability** can mean fraction of time service is available or fraction of valid requests that succeed. Always define it from the user's perspective. A **service level indicator (SLI)** is a measured metric such as successful requests divided by eligible requests; an **SLO** is a target; an **SLA** is a contractual commitment with defined remedies.

## Availability arithmetic

Assume a 30-day month (43,200 minutes). A 99.9% monthly availability objective permits approximately `(1-.999)*43,200 = 43.2 minutes` of unavailability. At 99.99%, it permits 4.32 minutes. At 99.999%, it permits 25.92 seconds. These are arithmetic budgets under a **time-based** definition and month assumption; a request-based SLO may count bad requests differently.

For *independent* components in a strict series path, total availability is the product: if two required services each have 99.9% availability, end-to-end is approximately `.999^2 = .998001` = 99.8001%. For redundant parallel components with independent failures and perfect failover, availability may approximate `1-(1-A1)(1-A2)`. Real failures are correlated (shared cloud control planes, DNS, power, configuration), so these textbook formulas can greatly overestimate practical reliability.

## Error budgets

A 99.9% request-success SLO over one million eligible requests allows 1,000 errors under simplified accounting. A rapid burn of that budget may justify pausing risky releases. Error budgets align reliability investment and feature velocity; they are not permission to ignore security or data loss.

## SLI selection

For document extraction, choose separate indicators: job acceptance success rate, accepted-job durability, result correctness, result completion within 90 seconds, and API latency. A `200` from `/health` says little about whether users receive accurate outputs.

**Exercise:** A service receives 5 million eligible requests/month with a 99.95% success SLO. Calculate permitted errors and discuss whether successful-but-wrong results should count as good requests.
