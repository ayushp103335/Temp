# Fault Injection, Runbooks, Restore Drills, and Postmortems

A system is not resilient merely because its design diagram has redundant components. Test the failure modes in controlled environments and, where justified and safely governed, in production.

## Failure tests

- Kill one API process during traffic; measure error spikes and connection draining.
- Kill one queue consumer after DB commit but before acknowledgment; check duplicates.
- Cut the database's replica network link; observe read freshness and write availability.
- Simulate disk full, high latency, expired certificates, and exhausted connection pools.
- Restore an object and its metadata from backup; verify checksum and access permissions.
- Exercise whole-region failover without violating data residency and safety constraints.

## Runbook structure

```text
Alert: oldest_job_age_seconds > 120 for 10 minutes
Impact: processing SLO threatened
Check: incoming rate, worker count, vendor 429s, failed publishes, DB waits
Mitigation: cap intake, recover failed workers, reduce concurrency if vendor limited
Verification: oldest age falling; no accepted jobs missing; error budget stable
Escalation: service owner, on-call platform, vendor operations
Rollback: reverse latest deploy after validating schema compatibility
```

## Postmortem practice

Document timeline, customer impact, triggering change, contributing conditions, detection gaps, mitigation, recovery, and prioritized follow-up actions. Avoid simplistic "human error" as a root cause; investigate why guardrails, tests, and rollback did not contain the event.

**Design judgment:** Choose failure experiments that answer a concrete question. "We ran chaos testing" is not useful unless you can state what broke, whether objectives were met, and what improved.
