# High Availability, Active-Passive, Active-Active, and DR

![High Availability, Active-Passive, Active-Active, and DR architecture diagram](../assets/multi-region.svg)

High availability reduces customer-visible downtime under expected failures. Disaster recovery (DR) plans restoration from severe events such as a whole region outage or data corruption. They overlap but are not identical.

## Active-passive

```text
Client -> Region A (active app + write DB) ---> async Region B standby
                  X outage                         |
Client -> traffic failover -----------------------> Region B promoted
```

Advantages: one write authority, simpler consistency. Costs: standby expense, regional latency, failover testing, possible RPO>0. The standby must actually be able to handle load; backups and the ability to promote are not enough.

## Active-active

```text
Clients -> geo traffic router -> Region A apps -> shared/owned data
                              -> Region B apps -> shared/owned data
```

Advantages: regional serving and faster regional continuity. Risks: global routing dependence, split-brain, conflicting writes, data residency, synchronization, increased operational cost. Active-active **apps** may use an active-passive **DB**; label them separately.

## Database vs application failover

Stateless app failover can be quick if routing and session handling allow it. Database failover must consider committed write position, quorum, in-flight transactions, old leader fencing, replica consistency, and recovery of durable logs. An application can be operational in two regions while still depending on one database that is a single point of failure.

## Test failure assumptions

Write an explicit scenario: "Lose all Region A network connectivity at 14:00 while 300 writes/s are in flight." Decide which writes were acknowledged, how to identify replay-safe requests, how traffic routes to Region B, what users see, and what reconciliation occurs after A returns.

**Design judgment:** Choose active-active only when business continuity/latency objectives justify the additional data-correctness and operational complexity. A proven active-passive design may offer better net reliability for smaller systems.
