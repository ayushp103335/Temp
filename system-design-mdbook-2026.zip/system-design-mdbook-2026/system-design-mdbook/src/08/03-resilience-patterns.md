# Retries, Circuit Breakers, Bulkheads, Throttling, and Timeouts

Retries recover some transient faults but can overload an already failing dependency. The goal is to preserve service under degraded conditions, not to turn every error into repeated load.

## Timeouts and budgets

Use an overall request deadline and allocate child deadlines. Suppose an API has 800 ms end-to-end budget, with 100 ms for authentication and 150 ms for DB work. A downstream call should not independently get a five-second timeout. Account for queueing, retries, and network latency inside the overall budget.

## Exponential backoff with jitter

Without jitter, 10,000 clients can retry at exactly 1, 2, and 4 seconds, causing a **retry storm**. Randomized delay spreads retries. Retry only safe/idempotent operations or requests protected by stable idempotency keys; respect `Retry-After` when meaningful. Define a retry budget, maximum attempts, and a dead-letter/reconciliation path.

## Circuit breaker

```text
CLOSED (normal) -- failure threshold --> OPEN (fail fast)
OPEN -- wait interval --> HALF_OPEN (limited probes)
HALF_OPEN -- success --> CLOSED
HALF_OPEN -- failure --> OPEN
```

A circuit breaker reduces futile attempts against a failing dependency; it does not restore the dependency. Avoid opening on client validation errors or unrelated failures. Protect breakers from misconfiguration that blocks healthy traffic.

## Bulkheads and load shedding

A **bulkhead** isolates resources: separate worker pools for premium tenants and batch jobs, preventing one flood from consuming all capacity. **Throttling** limits accepted work. **Load shedding** intentionally rejects lower-priority requests rather than allowing every request to time out. **Hedged requests** send a duplicate read to mitigate slow-tail behavior, but increase load and must be used cautiously (never casually for side-effecting writes).

**Exercise:** A model provider returns `429` for 30 seconds. Design per-tenant fair queuing, bounded retries, worker admission control, and a degraded API response without making the provider overload worse.
