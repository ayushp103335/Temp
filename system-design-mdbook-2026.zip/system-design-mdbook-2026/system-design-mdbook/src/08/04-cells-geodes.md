# Cells, Deployment Stamps, Geodes, and Blast Radius

A large shared cluster allows efficiency but creates a big **blast radius**: a bad deploy, hot tenant, or noisy neighbor can affect everyone. Cell-based architectures divide traffic/data into smaller semi-independent operational units.

## Cells and deployment stamps

A **cell** serves an assigned subset of tenants/users; it has its own quota boundaries and may contain its own APIs/queues/cache/database partition. A **deployment stamp** is a repeatable deployment of workload resources. A routing/control plane maps a tenant to a stamp. This reduces cross-tenant impact if cells are properly isolated; it increases placement, balancing, observability, and upgrade complexity.

```text
control plane: tenant -> cell mapping
                |
       +--------+---------+
       |        |         |
     Cell A   Cell B    Cell C
     tenants  tenants   tenants
     1-100    101-200   201-300
```

Do not make the routing control plane itself an unplanned global single point of failure. Cache stable routing information and make failure behavior explicit.

## Geodes and regional symmetry

A **geode** pattern deploys symmetrical nodes/regions serving user subsets, often with geo-distributed replicated data or regional ownership. Traffic routing may favor the nearest healthy region. Define how data is read/written, which locality constraints apply, and whether a failed region's tenants can be safely served elsewhere.

## Shuffle sharding

Assign each tenant a subset of workers or partitions rather than one shared pool. With sufficiently different subsets, one tenant's outage affects fewer other tenants. Mapping and capacity sizing matter; overlaps still exist.

**Design judgment:** Use isolation to bound incidents once noisy-neighbor risk justifies the cost. At 50 tenants and a few hundred RPS, sophisticated cell routing may be unnecessary.
