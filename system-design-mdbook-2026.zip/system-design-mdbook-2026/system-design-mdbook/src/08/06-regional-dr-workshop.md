# Disaster Recovery Workshop: Single Region, Two Zones, and Two Regions

Consider an insurance-claims API with a relational source of truth, encrypted object storage, durable broker, worker fleet, and an SLA requirement. Three topologies provide different failure coverage.

## Topology A: Single server and local disk

One VM runs API, database, and worker; PDFs are stored locally. It is cheap and easy to debug but one disk/VM loss can remove service and data. Nightly copy is a weak backup if today's uploads are critical. **Use when:** only low-risk prototypes or disposable data and minimal availability commitments.

## Topology B: One region, multiple availability zones

Deploy stateless API and workers across zones, use a multi-zone managed SQL database/queue where supported, and regional object storage. A single node/zone failure may be survivable. A full-region network outage or mistaken data deletion can still cause a major incident. **Use when:** a single-region RTO/RPO is acceptable and multi-zone protection meets most risk.

## Topology C: Two regions

Secondary region has provisioned compute or tested rapid provisioning, replicated/archived data, independent network paths and credentials. A failover runbook promotes DB, routes traffic, and reconciles accepted writes. **Key problem:** if replication is asynchronous, the standby may not have the last acknowledged transactions.

## Step-by-step DR drill

1. Define RTO=30 min and RPO=5 min for a regional outage.
2. Record last committed transaction marker/LSN in primary before fault injection.
3. Cut primary region connectivity; verify which writes reached secondary.
4. Promote standby with split-brain protection; switch routing and verify auth/secrets.
5. Resume processing of surviving queued jobs; deduplicate client retries.
6. Compare missing objects, DB rows, outbox records, and result versions.
7. Restore old region in read-only/quarantined mode until divergence is resolved.
8. Measure elapsed recovery time and acknowledged-data loss, publish evidence.

## Realistic architecture choices

Paying for warm standby may cost less than losing two hours of claims intake. Conversely, fully active-active multi-writer replication can add substantial conflict and latency risk. Use RTO/RPO and financial impact to justify architecture, not the prestige of a topology label.

**Exercise:** A backup takes 45 minutes to restore. Can this system meet a 15-minute RTO using backups alone? What warm data/service state would change the answer?
