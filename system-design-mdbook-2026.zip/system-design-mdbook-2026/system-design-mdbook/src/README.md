# System Design: From Zero to Production Architect

**A complete, example-driven learning reference — November 2026 edition**

This book teaches the complete reasoning process required to design software systems: from a single program running on one computer to globally distributed applications, databases, queues, security boundaries, observability, and AI-native platforms.

You need **no prior programming or infrastructure knowledge**. The book starts with files, memory, processes, IP addresses, APIs, and databases; introduces each term before using it; then builds increasingly complex systems. **Every analogy is technical**: a database query, a browser request, a queue worker, a transaction, a production incident, or a deployable example.

## What you will be able to do

- Trace a user request through DNS, networking, a load balancer, an API, a database, and back.
- Translate product requirements into security, latency, reliability, data, and capacity constraints.
- Select architecture, data models, caches, queues, failure handling, and deployments with explicit trade-offs.
- Explain replication, sharding, CAP, consistency, idempotency, durability, and active-active failover rigorously.
- Design and review modern systems: e-commerce, messaging, claims processing, streaming analytics, SaaS, RAG, and agentic workflows.
- Conduct architecture reviews, estimate costs, plan migrations, and defend choices with measurements.

## How to read the book

**Beginners:** Follow every chapter in order. Run the technical examples; write down outputs; revisit each *Design judgment* section and defend the opposite decision.

**Working developers:** Skim Part 00 but complete the diagnostic questions. Work through Parts 01–12 and the cases in Part 13.

**Architects/team leads:** Use the pattern catalog, decision records, checklists, failure-mode analyses, and coverage matrix as an architecture reference.

## The recurring example

A document-processing platform receives PDF files, stores them, extracts structured fields, and lets users view results. It begins as one service and evolves into an API, durable job database, message broker, worker pool, object storage, monitoring, security, and disaster recovery. All data and traffic figures are **clearly labeled assumptions**, not facts about any real company.

**One consistent practice:** before naming a product such as Kubernetes, Kafka, Redis, MongoDB, or PostgreSQL, write down the problem it must solve. A tool is not an architectural requirement.

> **Reading convention:** `code` is literal technical syntax. Code fences contain commands, JSON, SQL, or Python. "Illustrative" means a simplified example for teaching. An actual production configuration requires threat modeling, tests, and deployment-specific tuning.

Start with [How computers execute software](00/01-computers.md), or use the chapter sidebar. The [coverage matrix](15/02-roadmap-coverage.md) is an auditable map against the [roadmap.sh system design roadmap](https://roadmap.sh/system-design?fl=1).
