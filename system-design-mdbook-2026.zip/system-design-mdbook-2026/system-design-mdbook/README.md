# System Design: From Zero to Production Architect

**Edition:** November 2026. **Audience:** beginners with no software background through developers and architects. **Format:** mdBook source (Markdown + `book.toml`).

## Read

**Fastest:** open `OFFLINE_READER.html` in a browser. It is fully self-contained and searchable, even without internet access or the mdBook CLI. The canonical source remains the chapter Markdown files.

1. Open `src/README.md`, then follow `src/SUMMARY.md` in order.
2. For the native mdBook interface, install the [official mdBook CLI](https://rust-lang.github.io/mdBook/guide/installation.html) and run `mdbook serve --open` from this folder.
3. For an offline static site, run `mdbook build`, then open `book/index.html` or serve the `book/` folder locally.
4. The `labs/` folder contains executable learning exercises. `scripts/assemble.py` re-generates `src/` from the authored chapter drafts in `drafts/`.

**Editorial rule:** Every technical concept must answer: *what problem does it solve, how does it work, what fails, what are the alternatives, and when should it not be used?* Numerical examples are illustrative unless a source is cited.

The coverage matrix in Part 15 maps the complete roadmap.sh system-design topic list to chapters; modern additions include cloud-native platforms, multi-region design, streaming, vector search, GenAI and agent systems. The book is an educational technical reference, not a guarantee that every future technology is covered. Validate product and regulatory specifics against current vendor/regulator documentation before deploying.

## Quality and limitations

The authored source contains 99 navigable chapters across 16 parts, six SVG architecture diagrams, runnable no-dependency Python learning labs, a comprehensive roadmap coverage matrix, and current-source references. The included offline reader is **not** output of the native mdBook CLI; install mdBook to run `mdbook build` or `mdbook serve --open`.

## License and attribution

Explanations, labs and diagrams in this book were authored for this deliverable. The taxonomy references roadmap.sh; this is **not** an official roadmap.sh book. External references and links are listed in the References chapter.
