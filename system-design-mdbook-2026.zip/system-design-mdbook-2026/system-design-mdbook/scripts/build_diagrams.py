#!/usr/bin/env python3
from pathlib import Path
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parents[1]
ASSET=ROOT/'src/assets'; ASSET.mkdir(parents=True,exist_ok=True)

def box(x,y,w,h,title,subtitle='',fill='#eff6ff',stroke='#4b78ad'):
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{fill}" stroke="{stroke}" stroke-width="2"/>'
            f'<text x="{x+w/2}" y="{y+26}" text-anchor="middle" font-family="Arial,sans-serif" font-size="17" font-weight="700" fill="#14243a">{escape(title)}</text>'
            f'<text x="{x+w/2}" y="{y+49}" text-anchor="middle" font-family="Arial,sans-serif" font-size="12" fill="#4f637a">{escape(subtitle)}</text>')

def line(x1,y1,x2,y2,label='',dashed=False):
    stroke=f' stroke-dasharray="7,5"' if dashed else ''
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#4677a6" stroke-width="2.5" marker-end="url(#arrow)"{stroke}/>'
           +(f'<text x="{(x1+x2)/2}" y="{(y1+y2)/2-9}" text-anchor="middle" font-size="12" font-family="Arial" fill="#475569">{escape(label)}</text>' if label else ''))

def title(t):
    return f'<text x="30" y="34" font-family="Arial" font-size="23" font-weight="700" fill="#14243a">{escape(t)}</text>'

def svg(name,w,h,nodes):
    text=(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">' +
          '<defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0 0 L9 3 L0 6Z" fill="#4677a6"/></marker></defs>'+ 
          f'<rect width="{w}" height="{h}" fill="#ffffff" rx="16"/>' +nodes+'</svg>')
    (ASSET/name).write_text(text,encoding='utf-8')

svg('request-flow.svg',1120,192, title('Request path: trace each dependency') +
  ''.join(box(x,70,176,66,t,st) for x,t,st in [(25,'Browser','HTTP client'),(244,'DNS','Name resolution'),(463,'Edge','TLS + routing'),(682,'API process','Auth + business logic'),(901,'Database','Indexed SQL read')]) +
  ''.join(line(x,103,x+39,103) for x in [201,420,639,858]))
svg('load-balancing.svg',1040,270,title('Layer-7 routing to stateless API replicas')+
    box(30,107,160,68,'Client','HTTPS request')+ box(278,104,194,74,'L7 Load Balancer','Routing + health')+
    ''.join(box(652,y,212,62,f'API instance {i}','Own process / port') for i,y in [(1,47),(2,119),(3,191)])+
    line(190,140,275,140)+''.join(line(472,140,648,y+31) for y in [47,119,191])+
    '<text x="480" y="242" font-size="13" fill="#495d73" font-family="Arial">Each instance requires independent capacity and readiness.</text>')
svg('replication.svg',1120,265,title('Leader / replica database: read freshness is not automatic')+
  box(40,99,218,76,'Write-authoritative DB','Region A / primary','#dcfce7','#16a34a')+
  box(470,48,230,76,'Read replica A','Async or sync replication')+
  box(470,158,230,76,'Read replica B','May lag behind primary')+
  box(836,103,230,76,'Application reader','Consistency routing rule')+
  line(258,132,468,85,'log')+line(258,142,468,192,'log')+
  line(700,85,835,132,'reads')+line(700,191,835,150,'reads'))
svg('multi-region.svg',1140,300,title('Multi-region app failover and primary/standby data')+
    box(50,75,244,70,'Region A app','Active serving','#dcfce7','#16a34a')+
    box(50,189,244,70,'Region A DB','Primary writer','#dcfce7','#16a34a')+
    box(807,75,244,70,'Region B app','Standby or active reads')+
    box(807,189,244,70,'Region B DB','Replica until promoted')+
    box(433,83,230,70,'Traffic controller','Health + policy')+
    line(549,153,292,110,'normal')+line(663,119,804,110,'failover',True)+
    line(171,145,171,186)+line(929,145,929,186)+line(294,222,804,222,'replication',True))
svg('rag-pipeline.svg',1140,290,title('RAG: authorization spans ingestion, retrieval and output')+
    box(30,70,223,76,'Source documents','FHIR + notes + PDFs')+
    box(315,70,218,76,'Ingestion','Parse / chunk / ACL tags')+
    box(607,70,223,76,'Search indexes','Text + vectors + metadata')+
    box(877,70,218,76,'Retriever','Auth filters + rerank')+
    box(615,199,223,70,'Model','Grounded generation')+
    box(308,199,223,70,'Validation','Citations + schema + policy')+
    line(253,108,312,108)+line(533,108,604,108)+line(830,108,874,108)+line(986,146,986,231)+line(986,231,839,231)+line(615,233,534,233))
svg('async-documents.svg',1140,357,title('Durable asynchronous document-processing reference architecture')+
    box(25,75,170,74,'Client','Upload / status')+
    box(259,75,190,74,'API','Auth + acceptance')+
    box(531,75,204,74,'Job DB + outbox','Atomic commit')+
    box(824,75,220,74,'Durable queue','At-least-once delivery')+
    box(824,218,220,74,'Worker pool','Leases + retry + validate')+
    box(531,218,204,74,'Result store','Source of truth')+
    box(259,218,190,74,'Object storage','PDF bytes + checksum')+
    line(195,112,255,112)+line(449,112,528,112)+line(735,112,820,112)+
    line(934,149,934,215)+line(824,255,738,255)+line(824,264,452,264,'fetch object',True)+
    line(354,149,354,215))
print('Generated 6 vector architecture diagrams')
