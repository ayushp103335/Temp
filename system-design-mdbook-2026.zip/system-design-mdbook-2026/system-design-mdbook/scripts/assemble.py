#!/usr/bin/env python3
"""Build mdBook src/ from authored chapter drafts and verify navigation."""
from pathlib import Path
import re, sys, json, shutil
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'
PARTS={
 '00':'Start Here — No prerequisites',
 '01':'Architectural Thinking',
 '02':'Networking and the Web',
 '03':'Application Architecture',
 '04':'Data and Storage',
 '05':'Caching',
 '06':'Queues, Events and Streams',
 '07':'Distributed Systems',
 '08':'Reliability and Scale',
 '09':'Security and Privacy',
 '10':'Operations and Performance',
 '11':'Cloud Design Pattern Catalog',
 '12':'AI-Native and Emerging Architectures',
 '13':'End-to-End Case Studies',
 '14':'Hands-On Labs',
 '15':'Review, Glossary and References'
}
DIAGRAMS={
 '00/03-first-request.md':'request-flow.svg',
 '02/04-load-balancers.md':'load-balancing.svg',
 '04/05-replication.md':'replication.svg',
 '08/02-failover.md':'multi-region.svg',
 '12/02-rag-search.md':'rag-pipeline.svg',
 '13/02-document-processing.md':'async-documents.svg',
}
# Include runnable source next to HTML for offline access to the labs.
for f in (ROOT/'labs').glob('*.py'):
    dst=SRC/'assets'/'labs'/f.name
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(f,dst)
chapters=[]
for file in sorted((ROOT/'drafts').glob('*.txt')):
    raw=file.read_text(encoding='utf-8')
    chunks=re.split(r'^@@ CHAPTER (.+?) \| (.+?)\s*$', raw, flags=re.M)
    if len(chunks)==1: continue
    if chunks[0].strip(): raise ValueError(f'Unparsed preface in {file}')
    for p,title,body in zip(chunks[1::3],chunks[2::3],chunks[3::3]):
        path=SRC/p.strip()
        if not body.strip(): raise ValueError(f'Empty chapter {p}')
        path.parent.mkdir(parents=True,exist_ok=True)
        diagram=DIAGRAMS.get(p.strip())
        prefix=(f'![{title.strip()} architecture diagram](../assets/{diagram})\n\n' if diagram else '')
        path.write_text('# '+title.strip()+'\n\n'+prefix+body.strip()+'\n',encoding='utf-8')
        chapters.append({'path':p.strip(),'title':title.strip(),'words':len(body.split())})
chapters.sort(key=lambda c:c['path'])
summary='# Summary\n\n[Welcome](README.md)\n\n'
for part,label in PARTS.items():
    subset=[c for c in chapters if c['path'].startswith(part+'/')]
    if not subset: continue
    summary+='---\n\n# '+label+'\n\n'
    for c in subset:
        summary+=f'- [{c["title"]}]({c["path"]})\n'
    summary+='\n'
(SRC/'SUMMARY.md').write_text(summary,encoding='utf-8')
readme=SRC/'README.md'
if not readme.exists():
    readme.write_text('# System Design: From Zero to Production Architect\n\nSee the first chapter to begin.\n',encoding='utf-8')
# Validate internal links in chapters; excludes URL and heading-only references.
missing=[]
for c in chapters:
    p=SRC/c['path']
    raw=p.read_text(encoding='utf-8')
    if not raw.lstrip().startswith('# '): missing.append((c['path'],'missing h1'))
    for m in re.finditer(r'(?<!!)\[[^\]\n]+\]\(([^)]+)\)',raw):
        url=m.group(1).split(' ')[0].split('#')[0]
        if url and not url.startswith(('http://','https://','mailto:','#')) and not (p.parent/url).exists():
            missing.append((c['path'],f'bad link: {url}'))
if missing:
    for x in missing: print('CHECK',x)
    sys.exit(2)
(ROOT/'chapter_stats.json').write_text(json.dumps({'chapters':len(chapters),'words':sum(c['words'] for c in chapters),'parts':{k:len([c for c in chapters if c['path'].startswith(k+'/')]) for k in PARTS},'chapters_list':chapters},indent=2),encoding='utf-8')
print(f"Assembled {len(chapters)} chapters, {sum(c['words'] for c in chapters):,} body words, {len(PARTS)} parts")
