#!/usr/bin/env python3
"""Build a self-contained offline HTML reader from mdBook Markdown chapters.

mdBook source in src/ remains canonical. This preview is not a substitute for
an actual mdBook build; it avoids requiring the mdBook CLI to read the book.
"""
import base64, html, json, re
from pathlib import Path
import mistune
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'
meta=json.loads((ROOT/'chapter_stats.json').read_text(encoding='utf-8'))
chapters=[{'path':'README.md','title':'Welcome'}]+meta['chapters_list']
idmap={c['path']:'ch-'+re.sub('[^a-z0-9]+','-',c['path'].lower()).strip('-') for c in chapters}
renderer=mistune.create_markdown(escape=False,plugins=['table','strikethrough','url','task_lists'])


def resolve_links(raw,current):
    def img(m):
        alt,path=m.group(1),m.group(2)
        filepath=(SRC/current).parent/path
        if filepath.exists() and filepath.suffix.lower()=='.svg':
            b64=base64.b64encode(filepath.read_bytes()).decode('ascii')
            return f'![{alt}](data:image/svg+xml;base64,{b64})'
        return m.group(0)
    raw=re.sub(r'!\[([^\]]*)\]\(([^)]+\.svg)\)',img,raw)
    def replace(m):
        label,url=m.group(1),m.group(2)
        clean=url.split('#')[0]
        if clean.startswith(('http://','https://','mailto:','data:','#')) or not clean.endswith('.md'):
            return m.group(0)
        target=(SRC/current).parent/clean
        try: key=target.resolve().relative_to(SRC.resolve()).as_posix()
        except ValueError: return m.group(0)
        if key in idmap: return f'[{label}](#{idmap[key]})'
        return m.group(0)
    return re.sub(r'(?<!!)\[([^\]]+)\]\(([^)]+)\)',replace,raw)

sections=[];nav=[];docidx=[]
for i,c in enumerate(chapters):
    path=c['path']; raw=(SRC/path).read_text(encoding='utf-8')
    transformed=resolve_links(raw,path)
    rendered=renderer(transformed)
    sections.append(f'<article class="chapter" id="{idmap[path]}"><div class="chapter-number">Chapter {i} of {len(chapters)-1}</div>{rendered}<a class="backtop" href="#top">Back to table of contents ↑</a></article>')
    section=path.split('/')[0] if '/' in path else '00'
    nav.append((section,idmap[path],c['title']))
    txt=re.sub(r'[`*#|>\[\]()]',' ',raw)
    docidx.append({'id':idmap[path],'title':c['title'],'content':txt[:120000]})

parts={
 '00':'Start Here', '01':'Architectural Thinking', '02':'Networking',
 '03':'Application Architecture', '04':'Databases & Storage', '05':'Caching',
 '06':'Queues, Events & Streams', '07':'Distributed Systems', '08':'Reliability',
 '09':'Security', '10':'Operations & Performance', '11':'Design Patterns',
 '12':'Modern AI & Emerging', '13':'Case Studies', '14':'Hands-On Labs', '15':'Review & Glossary',
}
navhtml=[]
for part,label in parts.items():
    elems=[(id,title) for p,id,title in nav if p==part]
    if not elems:continue
    navhtml.append(f'<details class="part" open><summary>{html.escape(label)}</summary><ul>')
    for id,t in elems:
        navhtml.append(f'<li class="toc-item" data-id="{id}"><a href="#{id}" onclick="closeOnMobile()">{html.escape(t)}</a></li>')
    navhtml.append('</ul></details>')

css=r'''
:root{color-scheme:light;--bg:#f7f9fc;--fg:#16243a;--muted:#5a6b7c;--surface:#fff;--line:#dce5ef;--link:#0877a3;--head:#102a43;--code:#0b1730;--code-fg:#d7e8f7;--nav:#fff}
html{scroll-behavior:smooth}body{margin:0;background:var(--bg);font:16px/1.7 system-ui,-apple-system,'Segoe UI',sans-serif;color:var(--fg)}
body.dark{color-scheme:dark;--bg:#0d1523;--fg:#d8e5f1;--muted:#9db0c4;--surface:#121e30;--line:#2b3e57;--link:#80cdec;--head:#e7f0ff;--nav:#111d30}
.top{position:fixed;z-index:20;left:0;right:0;top:0;height:58px;background:var(--surface);border-bottom:1px solid var(--line);display:flex;align-items:center;gap:16px;padding:0 18px;box-sizing:border-box}
.top .brand{font-weight:750;color:var(--head);letter-spacing:-.02em}.top small{color:var(--muted);margin-left:auto}.top button{background:transparent;color:var(--fg);border:1px solid var(--line);border-radius:6px;padding:6px 10px;cursor:pointer}
.layout{display:grid;grid-template-columns:315px minmax(0,1fr);padding-top:58px}
.sidebar{height:calc(100vh - 58px);overflow-y:auto;position:sticky;top:58px;padding:17px 16px 30px;background:var(--nav);border-right:1px solid var(--line);box-sizing:border-box}
.sidebar h2{font-size:13px;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);margin:4px 0 13px}
.sidebar input{width:100%;border:1px solid var(--line);background:var(--surface);color:var(--fg);border-radius:8px;padding:11px;box-sizing:border-box;outline:none}
.sidebar .hint{font-size:11px;color:var(--muted);margin:5px 0 12px}.part{margin:9px 0}.part summary{cursor:pointer;color:var(--head);font-weight:700;font-size:13px;padding:7px 5px}.part ul{list-style:none;margin:0 0 10px;padding:0 0 0 8px}
.toc-item a{display:block;padding:4px 9px;text-decoration:none;border-left:2px solid transparent;color:var(--muted);font-size:12.3px;line-height:1.45}.toc-item a:hover,.toc-item a.active{color:var(--link);background:rgba(54,121,167,.09);border-color:var(--link)}
main{max-width:980px;width:100%;box-sizing:border-box;padding:10px 30px 90px;margin:0 auto}.chapter{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:26px 36px;margin:20px 0 28px;scroll-margin-top:74px;box-shadow:0 3px 14px #081c2f07}
.chapter-number{font-size:12px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.08em}h1,h2,h3,h4{line-height:1.27;color:var(--head);margin-top:1.5em;scroll-margin-top:75px}h1{font-size:1.8rem;letter-spacing:-.03em;margin-top:.4em}h2{font-size:1.25rem}h3{font-size:1.09rem}p{margin:.85em 0}a{color:var(--link)}a:hover{text-decoration:underline}ul,ol{padding-left:1.6em}li{margin:2px 0}blockquote{margin:16px 0;border-left:4px solid var(--link);padding:5px 15px;background:rgba(80,150,190,.07);border-radius:2px 6px 6px 2px}
pre{overflow-x:auto;border-radius:8px;background:var(--code);color:var(--code-fg);padding:17px 19px;font-size:12.4px;line-height:1.55;border:1px solid #294362}code{font-family:'Cascadia Code',Consolas,Menlo,monospace}p code,li code,td code{background:rgba(112,137,180,.14);padding:2px 4px;border-radius:4px;color:var(--head);font-size:.87em}
table{width:100%;border-collapse:collapse;font-size:.89rem;line-height:1.5;display:block;overflow-x:auto}th,td{padding:10px 11px;border:1px solid var(--line);text-align:left;vertical-align:top;min-width:90px}th{background:rgba(83,147,193,.13);color:var(--head)}tr:nth-child(even){background:rgba(80,130,170,.045)}img{max-width:100%;border:1px solid var(--line);border-radius:8px;background:white}hr{border:none;border-top:1px solid var(--line);margin:28px 0}.backtop{display:block;text-align:right;border-top:1px solid var(--line);padding-top:12px;font-size:12px;text-decoration:none;margin-top:30px}
.chapter:first-of-type{border-top:5px solid #4d9bc2}#result-count{font-size:11px;color:var(--muted);margin-top:4px}
@media(max-width:900px){.layout{display:block}.sidebar{position:fixed;z-index:15;top:58px;left:0;width:305px;transform:translateX(-110%);transition:transform .2s;box-shadow:3px 0 15px #0002}.sidebar.open{transform:translateX(0)}main{padding:8px 12px}.chapter{padding:20px 18px}.top small{display:none}}
@media(min-width:901px){#menu-toggle{display:none}}
@media print{.top,.sidebar,.backtop{display:none!important}.layout{display:block;padding:0}main{max-width:none;padding:0}.chapter{box-shadow:none;border:0;page-break-before:always}.chapter:first-of-type{page-break-before:auto}pre,table{break-inside:avoid}}
'''
js='''
const docs=DOCS;
const input=document.getElementById('search');
const results=document.getElementById('result-count');
input.addEventListener('input',()=>{
  const q=input.value.trim().toLowerCase();let n=0;
  document.querySelectorAll('.toc-item').forEach(item=>{
    const doc=docs.find(x=>x.id===item.dataset.id);
    const hit=!q||doc.title.toLowerCase().includes(q)||(q.length>=3 && doc.content.toLowerCase().includes(q));
    item.hidden=!hit;if(hit)n++;
  });
  document.querySelectorAll('details.part').forEach(part=>{
    const matches=part.querySelectorAll('li:not([hidden])').length;
    part.hidden=matches===0;
    if(q&&matches)part.open=true;
  });
  results.textContent=n+' matching chapters';
});
function closeOnMobile(){document.querySelector('.sidebar').classList.remove('open');}
document.getElementById('menu-toggle').addEventListener('click',()=>document.querySelector('.sidebar').classList.toggle('open'));
document.getElementById('theme-toggle').addEventListener('click',()=>document.body.classList.toggle('dark'));
const observer=new IntersectionObserver(entries=>{
  for (const e of entries){if(e.isIntersecting){document.querySelectorAll('.toc-item a.active').forEach(x=>x.classList.remove('active'));
   const active=document.querySelector('.toc-item[data-id="'+e.target.id+'"] a');if(active)active.classList.add('active');}}
},{rootMargin:'-70px 0px -75% 0px'});
document.querySelectorAll('.chapter').forEach(x=>observer.observe(x));
'''
body='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>System Design — From Zero to Production Architect (Offline Reader)</title><style>'''+css+'''</style></head><body id="top">
<header class="top"><button id="menu-toggle" aria-label="Toggle chapter navigation">☰</button><div class="brand">SYSTEM DESIGN <span style="font-weight:400;color:var(--muted)">/ Handbook</span></div><small>November 2026 · Single-file offline reader · '''+str(len(chapters)-1)+''' chapters</small><button id="theme-toggle" aria-label="Toggle light/dark theme">◐ Theme</button></header>
<div class="layout"><aside class="sidebar"><h2>Table of Contents</h2><input id="search" type="search" placeholder="Search all chapter text…" aria-label="Search chapters"><div class="hint">Filter topics below · Browser Ctrl+F searches full text</div><div id="result-count"></div>
'''+''.join(navhtml)+'''</aside><main>'''+''.join(sections)+'''</main></div><script>const DOCS='''+json.dumps(docidx,ensure_ascii=False).replace('</','<\\/')+';'+js+'''</script></body></html>'''
out=ROOT.parent/'system-design-offline-reader.html'
out.write_text(body,encoding='utf-8')
print(f'Offline reader: {out} ({out.stat().st_size:,} bytes), {len(chapters)-1} chapters')
