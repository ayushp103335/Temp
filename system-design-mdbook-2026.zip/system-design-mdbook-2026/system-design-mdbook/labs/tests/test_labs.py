import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import atomic_inventory, shard_router, outbox_demo, token_bucket, capacity_sim

class TestLabs(unittest.TestCase):
    def test_atomic_inventory(self):
        _, remaining, purchased = atomic_inventory.run()
        self.assertEqual((remaining, purchased), (0,1))
    def test_outbox_duplicate(self):
        result = outbox_demo.run()
        self.assertEqual(result[2], 1)
    def test_shard_migration(self):
        mod, buckets = shard_router.migration_demo()
        self.assertGreater(mod,buckets)
    def test_token_bucket(self):
        self.assertEqual(sum(token_bucket.run()), 5)
    def test_capacity(self):
        self.assertTrue(capacity_sim.simulate()['queue_was_overloaded'])

if __name__=='__main__':
    unittest.main()
