# D · PostgreSQL, queries and caching

Use a local PostgreSQL database with synthetic rows. A relational database stores facts in tables and enforces rules even when two clients write concurrently. Keep executable examples together in one disposable schema.

## D1 · Model relationships and ask useful questions

Beginner · 3 hours · Requires A1.

**Objective.** Design tenant and document tables, then return the newest document for each tenant.

A primary key identifies a row. A foreign key ensures a referenced row exists. Separate the tenant name from documents so changing it requires one update. This is a practical reason for normalization. A join combines related rows; a left join retains the left side even when the right side is empty.

GROUP BY collapses rows into groups. A window computes a value for each original row. A CTE gives an intermediate query a name. A subquery can test existence. The count below deliberately counts a nullable right-side column so an empty tenant receives zero.

```sql
CREATE TABLE tenant (id integer PRIMARY KEY, name text NOT NULL);
CREATE TABLE document (
    id integer PRIMARY KEY, tenant_id integer NOT NULL REFERENCES tenant(id),
    title text NOT NULL, created_at timestamptz NOT NULL
);
INSERT INTO tenant VALUES (1,'Blue'),(2,'Gold');
INSERT INTO document VALUES
 (10,1,'Setup','2026-01-01T09:00:00Z'),(11,1,'Access','2026-01-02T09:00:00Z');

SELECT t.name, count(d.id) AS documents
FROM tenant t LEFT JOIN document d ON d.tenant_id=t.id GROUP BY t.id,t.name;

WITH ranked AS (
  SELECT d.*, row_number() OVER
    (PARTITION BY tenant_id ORDER BY created_at DESC,id DESC) AS pos
  FROM document d
)
SELECT tenant_id,title FROM ranked WHERE pos=1;
```

**Common failure and working practice.** COUNT(*) on a left join counts the unmatched placeholder. Ordering only by timestamp leaves ties ambiguous. Include a unique tie-breaker.

**Exercise.** Return tenants without documents using NOT EXISTS. Add two documents at the same time and predict their order.

**Build and check.** Build a dashboard query returning counts and latest title for both tenants. Expected initial counts are 2 and 0; Gold's latest title is NULL.

**Interview rehearsal.** How does WHERE differ from HAVING? WHERE filters rows before aggregation; HAVING applies a condition to groups.

## D2 · Read a plan and protect a concurrent write

Intermediate · 3 hours · Requires D1.

**Objective.** Read an execution plan, select a useful index and enforce a state transition atomically.

An index stores an ordered or otherwise searchable structure alongside table data. A composite B-tree beginning with tenant_id can serve a tenant-scoped ordered query. Index maintenance consumes writes and storage. A small table may be cheaper to scan.

ACID groups changes atomically, enforces declared constraints, isolates concurrent operations and preserves committed work under the database's durability settings. PostgreSQL Read Committed normally takes a fresh snapshot per statement. Repeatable Read keeps a transaction snapshot; Serializable can abort conflicting transactions, so retry the entire transaction when appropriate.

```sql
CREATE INDEX document_tenant_recent
  ON document (tenant_id, created_at DESC, id DESC);
EXPLAIN (ANALYZE, BUFFERS)
SELECT id,title FROM document WHERE tenant_id=1
ORDER BY created_at DESC,id DESC LIMIT 20;

CREATE TABLE job (id integer PRIMARY KEY, state text NOT NULL);
INSERT INTO job VALUES (7,'queued');
UPDATE job SET state='running' WHERE id=7 AND state='queued'
RETURNING id;
```

**Common failure and working practice.** A separate SELECT then UPDATE can let two workers act on stale state. A guarded UPDATE has a single winner. EXPLAIN ANALYZE actually executes the statement; use the read query shown.

**Exercise.** Run the claim in two sessions, commit the winner and inspect the other result. Generate a larger document table, run ANALYZE and compare estimated vs actual rows and buffers.

**Build and check.** Produce a migration that adds a nullable field, backfills in batches and tightens constraints only after verification. Limit DB connections across all processes: four workers × five connections = twenty before admin headroom.

**Interview rehearsal.** Why can a useful index go unused? The planner may estimate a scan is cheaper for a small table or a low-selectivity predicate.

## D3 · Add Redis without turning stale data into authority

Intermediate · 90 minutes · Requires D2.

**Objective.** Use a cache-aside read path and choose keys that isolate tenants.

Redis is an in-memory data store often used for short-lived values. On a miss, load an authorized value from PostgreSQL, cache it briefly and return it. A TTL bounds reuse time. Eviction or a restart must leave the authoritative data intact.

Put tenant, permission/version scope, query and data version in a key for shared search results, or cache only public/tenant-invariant data. An update can race with a slow reader repopulating the previous value. Versioned keys make stale fills invisible to newer reads.

```text
read current authorized version → look up versioned key
miss → query database for that version → SET key value EX 60
write → commit new version → subsequent reads select new version
```

**Common failure and working practice.** Caching a denial or a sensitive response under a shared URL can give users the wrong result. Do access checks before reusing a value and keep invalidation behavior explicit.

**Exercise.** Simulate a Redis miss, then a Redis outage. Confirm correct database results in both cases. Compare cache latency to the cost of a hit.

**Build and check.** Deliver a tiny read-through wrapper with a fake clock, expiry tests and two tenant IDs. Explain your tolerance for stale results.

**Interview rehearsal.** What happens when a popular key expires? Many requests can hit the database together. Coalesce concurrent loads and add expiry jitter when appropriate.

## Module exit and revision

Write the two-tenant dashboard unaided, read one EXPLAIN plan, demonstrate one-winner claiming and show correct behavior with Redis unavailable.

**Further reading** · [PostgreSQL tutorial](https://www.postgresql.org/docs/current/tutorial.html) · [Isolation levels](https://www.postgresql.org/docs/current/transaction-iso.html) · [Redis cache-aside](https://redis.io/learn/howtos/solutions/microservices/caching)

