# Summary

# Start here

- [Your career switch, from the first commit to the offer](00-read-first.md)
- [Choose your role and audit your experience](01-strategy.md)
- [Read the hiring evidence](02-market.md)
- [The 24-week plan](18-roadmap.md)
- [First-week workbench · From a blank folder to a tested change](27-workbench.md)

# Engineering curriculum

- [A · Programming and computer science foundations](03-foundations.md)
- [B · Python engineering](04-python.md)
- [C · Sixteen coding interview patterns](05-dsa.md)
- [D · PostgreSQL, queries and caching](06-sql.md)
- [E · Design and operate FastAPI services](07-backend.md)
- [F · From tokens to a dependable AI feature](08-generative-ai.md)
- [G · Retrieval-augmented generation](09-rag.md)
- [H · Agent workflows with controlled tools](10-agents.md)
- [I · System design under real constraints](11-design.md)
- [J · Deploy, observe and restore](12-cloud.md)
- [K · Review, test and improve software](13-practices.md)

# Build the portfolio

- [Practical lab · A tenant-filtered RAG endpoint](14-lab.md)
- [P1 · Build an enterprise document search platform](15-portfolio-rag.md)
- [P2 · Build an approval-based AI workflow](16-portfolio-workflow.md)
- [P3 · Operate a production-style AI application](17-portfolio-infra.md)

# Interview and career practice

- [Interview studio · Coding, backend, AI and design](19-interviews.md)
- [Worked exercises · Three stretch problems and a database review](26-worked-exercises.md)
- [Résumé, LinkedIn, GitHub and portfolio](20-brand.md)
- [Find roles, apply early and follow up](21-search.md)
- [Working from India for an international team](22-remote.md)
- [Negotiate and compare offers](23-pay.md)
- [Speak clearly about technical work](24-english.md)
- [Track evidence, interviews and applications](25-track.md)
