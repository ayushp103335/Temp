# K · Review, test and improve software

A well-reviewed 100-line change can say more about an early-career engineer than a demo with ten frameworks. Use these habits throughout the portfolio.

## K1 · Draw boundaries that make behavior testable

Intermediate · 2 hours · Requires B2 and E1.

**Objective.** Separate business rules from transport, pick test levels, and review changes.

Clean architecture keeps policy independent of its delivery mechanism. A FastAPI handler translates an HTTP request. A service decides whether a document may be published. A repository persists the result. SOLID prompts five questions: does this unit have one reason to change; can a stable contract support extensions; are implementations substitutable; does each client need its interface; and do business rules depend on abstractions?

Use a Strategy for interchangeable rankers, an Adapter around a provider's SDK and a Repository for persistence when those boundaries buy independent tests. A unit test exercises one rule. An integration test uses a real database or vector store. An end-to-end test exercises the deployed user path. Record the configuration so failures reproduce.

```python
def publish_if_ready(doc_id, chunks, store):
    if not chunks:
        raise ValueError("empty extraction")
    store(doc_id, tuple(chunks))

def test_publish():
    saved = {}
    publish_if_ready("a", ["p1"], saved.__setitem__)
    assert saved == {"a": ("p1",)}
```

**Common failure and working practice.** Mocking every database behavior can hide broken SQL or permission filters. Use real dependency tests for boundary risks. Add abstractions only when a second implementation or an isolation benefit exists.

**Exercise.** Refactor an endpoint into a pure rule and an adapter while keeping its public response stable. Ask a reviewer to name one failure path.

**Build and check.** Create a short branch, show failing behavior, change the smallest unit, document the API and include regression evidence in the pull request.

**Interview rehearsal.** What should reviewers inspect first? Correctness of the contract, data access boundaries, failure behavior and tests. Cosmetic changes come after those.

## K2 · Debug an incident and preserve what you learned

Intermediate · 90 minutes · Requires K1 and J3.

**Objective.** Distinguish symptom from cause, gather a profile and restore service safely.

Start with impact and scope. Is it all searches, one tenant or one document revision? Compare a failing trace with a healthy trace and the last deployment. Stabilize first with a reversible mitigation. Use a CPU profile for CPU-bound work and timing spans for waiting. A profiler reports where time went, not which change is safe.

For example, parse time stays flat while API latency rises. SQL execution time is 20 ms, yet the database span takes 1.5 s. Measure time waiting for a pool connection. A missing release in a failure path can starve the pool. Reproduce with controlled concurrent failures; fix using managed connection lifetime, add a regression and verify pool wait falls under the same load.

```bash
python -m cProfile -s cumulative importer.py
python -m pip check
```

**Common failure and working practice.** An incident report that blames the last commit without testing alternatives will not prevent recurrence. Track dependency versions, security updates and rollout risk. Do not put sensitive prompts in public issues.

**Exercise.** Draft a timeline with first symptom, detection, mitigation, verification and one unknown. Choose a regression test and an alert with a named owner.

**Build and check.** Write a one-page synthetic postmortem. Attach a before/after trace, anonymized logs and a date to review the follow-up.

**Interview rehearsal.** What do you say if you have never handled a live incident? State that directly. Explain a reproducible lab failure and distinguish your simulated response from work in production.

## Module exit and revision

Review a real diff, run unit and integration tests, profile one slow path, perform one reversible refactor and explain a fault without overstating your experience.

**Further reading** · [Python profiling](https://docs.python.org/3/library/profile.html) · [Google code review guide](https://google.github.io/eng-practices/review/) · [Google SRE postmortems](https://sre.google/sre-book/postmortem-culture/)

