# J · Deploy, observe and restore

Learn enough infrastructure to explain where your code executes, how it gets credentials, where durable data lives and what you do when a release fails. Do the local stages before spending money on cloud resources.

## J1 · Run a service in a container

Beginner · 2 hours · Requires E1.

**Objective.** Package a process, expose a port and preserve data outside the container.

Linux gives each running process an ID, a user, a working directory, file descriptors and an exit status. Use pwd, ls, ps, ss and logs to identify which process listens on which port. A shell script can chain checks and return nonzero on failure. An image is a versioned filesystem plus runtime metadata. A container is a running instance with isolation.

Docker Compose describes a local stack. Services on its network resolve each other by service name; localhost inside the API points to that API container. A named volume persists data when the container is replaced. Inject config using environment variables and secrets through a secret store or mounted file. Keep credentials out of build context and image layers.

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
USER 10001:10001
CMD ["python", "-m", "uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

```bash
docker build -t word-api:local .
docker run --rm -p 127.0.0.1:8000:8000 word-api:local
```

**Common failure and working practice.** A published port on every interface can expose a development store. Bind local demos to loopback. Record tested base image digests and lock dependencies for the published release.

**Exercise.** Containerize E1 and curl the endpoint. Restart the API; verify which data is lost and which Postgres records survive a container recreation.

**Build and check.** Build a Compose stack where API can resolve db, and prove a named volume survives docker compose down/up. Document reset commands separately from normal startup.

**Interview rehearsal.** Why can the app reach a database from the host but fail in Docker? The name, address, port, credentials and network namespace may differ. Check service DNS, listening address and connection errors in order.

## J2 · Release with a rollback and limited credentials

Intermediate · 3 hours · Requires J1 and Git.

**Objective.** Map AWS primitives to the service and automate a reversible release.

IAM defines who can perform which operations on specific resources. EC2 runs a VM, S3 stores objects, RDS operates a relational database, and Lambda runs bounded event-driven code. For a small portfolio start with one containerized app and worker, private object storage and PostgreSQL. Decide whether managed RDS fits the budget. Avoid provisioning resources simply to check a box.

In GitHub Actions run tests and build an immutable image on pull requests. On a reviewed release, obtain short-lived cloud credentials through OIDC with repository/branch restrictions; deploy the exact digest to staging. Apply additive migrations, smoke-test an authorized and unauthorized query, then promote. Terraform providers manage resources from a declared target; review plan, protect state, and serialize applies.

```yaml
# GitHub Actions test job; add deployment as a separately permissioned job.
name: checks
on: [push, pull_request]
permissions:
  contents: read
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: python -m pip install -r requirements-dev.txt
      - run: python -m pytest -q
```

**Common failure and working practice.** A rollback cannot undo a destructive migration after traffic has written incompatible data. Use expand → deploy compatible readers/writers → verify → contract later. For a hardened repository pin approved action commits.

**Exercise.** Sketch the permissions that let the worker read one S3 prefix and write index status. Review a terraform plan for a proposed replacement of a database.

**Build and check.** Release two image versions and roll back while preserving records. Record the digest, smoke results and teardown/budget checks.

**Interview rehearsal.** When choose Lambda? Short event-driven tasks with suitable time, memory and networking limits fit. Sustained model serving or long parsing jobs may suit a worker.

## J3 · Diagnose latency before scaling

Intermediate · 2 hours · Requires J2 and I1.

**Objective.** Correlate telemetry, choose an alert and explain basic Kubernetes objects.

A log describes an event, a metric aggregates measurements and a trace follows a request across spans. OpenTelemetry instruments and exports signals. Prometheus scrapes time series; Grafana visualizes them. Monitor request rate, errors, latency and resource saturation. Add queue age, model time and cost per successful answer for AI services.

In Kubernetes, a Pod runs one or more related containers, a Deployment manages replica rollout, and a Service supplies stable routing. ConfigMaps hold ordinary configuration; Secrets require access restrictions and appropriate encryption at rest. Helm packages templated manifests and release values. Learn to read these resources before attempting cluster administration.

```bash
# With access to your own configured cluster:
kubectl get deployments,pods,services
kubectl describe deployment word-api
kubectl logs deployment/word-api --tail=40
```

**Common failure and working practice.** Document IDs and user IDs as metric labels create unbounded cardinality. Put a redacted request ID in logs/traces. Verify readiness separately from process liveness.

**Exercise.** For a p95 jump from 400 ms to 2 s, inspect request traces, DB pool wait, queue age, model latency and release time. Name one observation that would disprove each hypothesis.

**Build and check.** Build one dashboard and an alert tied to user impact. Run a synthetic slowdown, document diagnosis and recovery, and verify the alert clears.

**Interview rehearsal.** What if more replicas increase errors? Each replica may open more database connections or consume provider quota. Inspect saturation before changing replicas again.

## Module exit and revision

Deploy once, see a trace, roll back a release and restore a saved database into a separate environment. Stop optional cluster work when those four demonstrations are reproducible.

**Further reading** · [Docker Compose](https://docs.docker.com/compose/) · [AWS IAM](https://docs.aws.amazon.com/IAM/latest/UserGuide/introduction.html) · [Terraform](https://developer.hashicorp.com/terraform/intro) · [Kubernetes concepts](https://kubernetes.io/docs/concepts/) · [OpenTelemetry signals](https://opentelemetry.io/docs/concepts/signals/)

