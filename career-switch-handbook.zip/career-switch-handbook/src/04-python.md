# B · Python engineering

Create a virtual environment with `python -m venv .venv`. Activate with `source .venv/bin/activate` on Linux/macOS or `.venv\Scripts\activate` on Windows. Use Python 3.11+ and install pytest and Pydantic 2 in this environment.

## B1 · Transform records without losing information

Beginner · 2 hours · Requires A1.

**Objective.** Choose collections, stream a file and validate records.

A string is immutable. A list preserves order, a tuple can describe a fixed record, a set tracks unique values, and a dictionary maps hashable keys to values. A comprehension builds a result immediately. A generator remembers its position and yields on demand.

Let the caller own the file in a with block so it closes even if iteration stops early. Hints communicate expectations; Pydantic enforces constraints at runtime. Validate at the system boundary and keep transformations independent of the transport.

```python
from collections.abc import Iterable, Iterator
from pydantic import BaseModel, Field

class Document(BaseModel):
    title: str = Field(min_length=1)
    pages: int = Field(gt=0)

def titles(lines: Iterable[str]) -> Iterator[str]:
    for line in lines:
        if value := line.strip():
            yield value

clean = list(titles([" Guide ", "", "Memo"]))
sizes = {item: len(item) for item in clean}
initials = {item[0] for item in clean}
ordered = sorted(clean, key=lambda item: (len(item), item))
assert ordered == ["Memo", "Guide"]
```

**Common failure and working practice.** A generator is exhausted after one pass. Decide whether the caller needs repeated access before converting to a list.

**Exercise.** Read lines with explicit UTF-8 encoding. Reject missing pages and print a human-readable validation error with the line number.

**Build and check.** Build a JSON-lines importer. Check blank input, invalid JSON and a valid document; identify the exact row that failed.

**Interview rehearsal.** What is saved by a generator? Only its state and current data must stay live. Collecting all results in a list removes that advantage.

## B2 · Measure and test a function

Intermediate · 2 hours · Requires B1.

**Objective.** Write a decorator, produce diagnostic logs and isolate failures.

A decorator receives a function and returns its replacement. A closure retains the surrounding function's variables. A context manager defines setup and cleanup. A try/finally block protects cleanup even when a call fails.

Keep conversion logic pure and observe duration at its boundary. Run python -m pytest -q on a file named test_pages.py. When an assertion fails, use the smallest reproducing input and inspect it with breakpoint().

```python
import logging
from functools import wraps
from time import perf_counter
import pytest

def timed(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        start = perf_counter()
        try:
            return fn(*args, **kwargs)
        finally:
            logging.info("%s elapsed_s=%.4f", fn.__name__, perf_counter()-start)
    return wrapper

@timed
def pages(value: str) -> int:
    n = int(value)
    if n < 1:
        raise ValueError("pages must be positive")
    return n

@pytest.mark.parametrize("value", ["0", "-1", "missing"])
def test_invalid(value):
    with pytest.raises(ValueError):
        pages(value)
```

**Common failure and working practice.** Logging the full input can expose private documents. Log operation IDs, duration and outcome. Keep dependency declarations in pyproject.toml and record a resolved dependency set for repeatable installs.

**Exercise.** Add a positive case and a leading-zero case. Inspect the traceback for a malformed input.

**Build and check.** Package the importer as a small module and CLI; reinstall it in a clean environment and rerun the tests.

**Interview rehearsal.** Why return the result inside the wrapper? Otherwise success silently returns None. The finally block still records errors.

## B3 · Choose concurrency by bottleneck

Intermediate · 2½ hours · Requires B1 and A3.

**Objective.** Choose threads, processes or coroutines and bound concurrent I/O.

A coroutine pauses at await so an event loop can schedule other work. Threads share process memory. Processes have separate address spaces. In ordinary GIL-enabled CPython, one thread executes Python bytecode at a time per interpreter; I/O and some native libraries release the lock. Free-threaded builds change this assumption.

Overlap waiting on documents with an async client. For CPU-heavy pure Python, compare a process pool after accounting for serialization costs. CPython primarily uses reference counting and a cyclic garbage collector. An object retained by an unbounded cache is still reachable.

```python
import asyncio

async def fetch(key, slots):
    async with slots:
        async with asyncio.timeout(1):
            await asyncio.sleep(0.01)  # simulated I/O
            return key.upper()

async def batch():
    slots = asyncio.Semaphore(2)
    async with asyncio.TaskGroup() as group:
        tasks = [group.create_task(fetch(k, slots)) for k in ("a", "b", "c")]
    return [task.result() for task in tasks]

assert asyncio.run(batch()) == ["A", "B", "C"]
```

**Common failure and working practice.** Blocking SDK calls stall an event loop. Use an async client or bounded thread offload for blocking I/O. Creating a million pending tasks also consumes memory; use a fixed worker pool and bounded queue.

**Exercise.** Time serial and concurrent simulated waits, then introduce a timeout. Explain TaskGroup cancellation. Compare two tracemalloc snapshots for growing lists.

**Build and check.** Build a bounded batch importer; show one timeout, one successful batch and output ordering.

**Interview rehearsal.** Does async make parsing faster? It overlaps waiting. CPU work needs separate measurement and often a different execution strategy.

## Module exit and revision

Read 1,000 synthetic records, test failure cases, explain a traceback and compare concurrency limits. Record the data size and machine before claiming a speedup.

**Further reading** · [Python asyncio](https://docs.python.org/3/library/asyncio.html) · [pytest](https://docs.pytest.org/en/stable/) · [Python packaging](https://packaging.python.org/en/latest/tutorials/packaging-projects/) · [Pydantic](https://docs.pydantic.dev/latest/)

