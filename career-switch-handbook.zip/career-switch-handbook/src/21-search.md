# Find roles, apply early and follow up

## Search strings and sources

Use quoted phrases and Boolean operators in LinkedIn or a web search engine. Some boards handle Boolean syntax poorly; on those, enter each quoted title as a separate saved search and apply the location and experience filters in the UI. Add Ahmedabad, Bengaluru, Hyderabad, Pune, India remote or relocation options according to your actual preferences.

| Target | Exact search query | First filter |
|---|---|---|
| Primary | ("backend engineer" OR "software engineer I" OR "SDE 1") AND Python AND (AI OR LLM OR retrieval) | India; entry/associate; recent |
| Secondary | ("applied AI engineer" OR "AI software engineer" OR "generative AI engineer") AND (RAG OR evaluation OR FastAPI) | India; junior/associate; inspect required years |
| Backup | ("Python backend engineer" OR "Python developer" OR "backend developer") AND (FastAPI OR Django OR Flask) AND (SQL OR PostgreSQL) | India; early-career |
| Agent/automation adjacent | ("AI automation engineer" OR "agent engineer" OR "agentic AI engineer") AND (Python OR API) | Check coding percentage, review and ownership |
| International watch | ("backend engineer" OR "applied AI engineer") AND ("remote India" OR "remote (IN)" OR "worldwide") AND Python | Confirm country in employer JD |

| Platform | How to use it | Evidence or next check |
|---|---|---|
| LinkedIn Jobs and Naukri | Alerts for distinct locations and title variants; verify role ID and experience on company site | [LinkedIn Jobs](https://www.linkedin.com/jobs/) · [Naukri](https://www.naukri.com/) |
| Cutshort and Instahyre | Product/startup matching; state notice period and demonstrable skills honestly | [Cutshort](https://cutshort.io/) · [Instahyre](https://www.instahyre.com/) |
| Wellfound | Read the “Hires remotely in” field and open the role's salary and work policy | India remote listings observed on 19 Nov 2026. [Example listing](https://wellfound.com/jobs/5067375-software-engineer) |
| YC Jobs | Filter role, location and experience. Open the company-authored role; “Remote (IN)” is meaningful | M4 and M5 in the market chapter. [Startup jobs](https://www.ycombinator.com/jobs) |
| Remote OK and We Work Remotely | Search India/Asia/worldwide and verify eligibility on the original application page. Treat board salary estimates as unverified | India-specific pages observed on 19 Nov 2026. [Remote OK India example](https://remoteok.com/remote-jobs/remote-junior-software-engineer-statusneo-1133251) · [WWR India](https://weworkremotely.com/jobs-in-remote-location-india) |
| Company careers, foundit and international startup boards | Use aggregators for discovery, then apply once through the employer. For Europe read country lists before preparing a take-home | [foundit](https://www.foundit.in/) · [Canonical careers](https://canonical.com/careers) · [ADEL careers](https://www.weareadel.ai/careers) |

## Triage one job in ten minutes

1. Check eligible residence, work authorization, graduation cohort, years, employment type, notice period and required overlap. A hard restriction takes priority over skill match.
2. Mark each requirement as independently demonstrated, adjacent, or unproven. Separate minimum requirements from preferences. Identify the top two outcomes the person will own.
3. Write a two-row match: “tenant-safe retrieval → P1 wrong-tenant test” and “service operations → P3 restore drill.” Use completed artifacts only. If a small gap is learnable, put it in the study backlog. If the core scope is senior ownership, file it as a future benchmark.
4. Tailor the opening summary, project order and two bullets. Keep the original, save the submitted version, submit once and log the external requisition ID. Request the interview format and whether tools are allowed.
5. Follow up once after about five to seven business days unless the employer gives a timeline. A referral is an introduction, not an assurance about fit. Continue applying while awaiting replies.

**Operating targets.** Start at two qualified applications in week 1 and reach four to six per week from week 5. Reach out to one to three people per week as the roadmap specifies. Count real conversations separately from messages sent. If you see no screens after roughly 20 well-matched applications, review the first third of your résumé, eligibility and targets with a peer before increasing volume.

## Messages to customize

**Recruiter:** “Hi [Name], I saw [role and ID]. I’m a Programmer Analyst in Ahmedabad and have worked on [verified contribution]. My [public demo] shows [relevant capability]. Is the team considering India-based candidates at my experience level? Thank you, [Name].”

**Referral:** “Hi [Name], your team’s work on [specific feature] caught my attention. I’m applying to [role ID]. I’ve attached a one-page résumé and a short demo of [relevant behavior]. If you feel the fit is appropriate, would you be comfortable referring me? I’d also value candid feedback.”

**Hiring manager:** “Hello [Name], I tried [public product feature] and was interested in how your team handles [specific engineering question]. For [role ID], my closest example is [artifact and test]. I’d be glad to walk through the design and its limitations in ten minutes.”

**Follow-up:** “Hi [Name], I applied for [role ID] on [date]. I remain interested in [specific responsibility]. Here is [one relevant demo or result]. Is there an updated timeline for next steps?”

**Application email:** Subject — Application for [role ID] | Python backend and AI applications. “Dear [Team], I’m applying for [role]. At Meditab I contributed to [verified work]. My independent [project] demonstrates [specific tested behavior]. My résumé is attached and the demo is at [link]. I’m based in Ahmedabad and my verified notice period is [period]. Thank you for considering my application.”

**International remote:** “Hi [Name], I’m based in India and can overlap [verified hours in both time zones]. My sample design note and reproducible demo are at [link]. Does this requisition support employment or contracting from India, and which entity would issue the agreement?”

**Exit check.** Save three searches, classify two listings with different eligibility rules, tailor one résumé variant, submit one application and record its follow-up date.

