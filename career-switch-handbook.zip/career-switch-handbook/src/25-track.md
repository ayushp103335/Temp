# Track evidence, interviews and applications

## One place to record the work

Keep one private working copy of this chapter in the mdBook source. Replace example rows with real entries. In the offline HTML reader the **Private notes** field at the end of each chapter also accepts dated rows. Export a copy before changing browsers, moving the reader or clearing browser data. Keep recruiters’ details and compensation notes private. A public portfolio should contain only the artifacts you intentionally publish.

**Daily checklist.** [ ] Set one testable outcome. [ ] Read or recall one concept. [ ] Commit or explain one example. [ ] Practice spoken English for 15 minutes. [ ] Log the first obstacle and tomorrow's first action.

**Weekly checklist.** [ ] Run the roadmap assessment. [ ] Re-solve one DSA problem cold. [ ] Update project evidence and résumé claims. [ ] Compare applications and replies. [ ] Complete one timed explanation. [ ] Schedule the highest-priority correction.

| Tracker | Fields to update | Example format (illustrative only) |
|---|---|---|
| Topic | Week, lesson, starting level, artifact, independent re-test date, pass/fail | W7 · E2 · guided → independent · denial test · [date] |
| DSA | Pattern, problem, first hint, time, failing case, complexity, next cold solves | C4 · longest substring · moved left backwards · abba · 2/7/21 days |
| Project | Milestone, owner, measurable acceptance, demo/commit, blocker, next action | P2 · concurrent approvals · one effect · [test link] |
| Interview | Type, interviewer, score by rubric, first gap, correction, next mock | Design · 3/2/3/2 · no capacity estimate · recompute peak |
| Résumé | Claim, proof, approved wording, public-safe, version, date | P1 recall claim · [evaluation artifact] · [yes/no] |
| Applications | Employer, req ID/URL, checked date, country eligibility, type, band, evidence match, version, applied, stage, next action/date | [Company] · [ID] · India confirmed · applied · follow up [date] |
| Networking | Contact and role, genuine reason, message date, reply, follow-up, consent to referral | [Name] · [team] · asked about review practice · [date] |
| English | Topic, recording duration, listener takeaway, grammar correction, replay date | Cache expiry · 75 s · listener understood TTL · past tense |
| Offers | Currency, fixed, variable, equity, one-time, costs, leave, notice, overlap, questions | Normalize fixed/year and write unknowns before comparing |

## Module completion gates

| Module | Mark independent only when you can demonstrate this without copying |
|---|---|
| A | Trace a function and alias, make a Git change and explain DNS/TLS/HTTP on a request. |
| B | Stream and validate records, test failures and compare concurrency choices. |
| C | Solve unseen easy/medium variants with a correct invariant, boundary test and justified cost. |
| D | Query empty/full tenants, explain a plan, and show one winner in a concurrent write. |
| E | Build, test and deploy a validated service with auth, scoped access, bounded work and status reporting. |
| F | Explain attention and sampling, validate output and choose a model from measurements. |
| G | Re-index a revision, isolate tenants, cite the source page and explain a held-out retrieval failure. |
| H | Pause and resume a run, reject stale approval and show single effect under a simulated retry. |
| I | Estimate peak load and storage and defend a consistency/recovery policy for two operations. |
| J | Deploy, observe, roll back and restore; verify one user path after recovery. |
| K | Review a diff, isolate a bottleneck, add a regression and write a factual incident timeline. |

## Weekly review template

1. What did I learn that I can now explain with the book closed?
2. What did I build? Add a commit, test, demo or written result.
3. What did I struggle with? Identify the first failing step.
4. What should I revise and which example will show improvement?
5. How many qualified jobs did I apply to? How many were explicitly India-eligible?
6. What feedback did I receive, from whom, and at which interview stage?
7. What one change will I make next week? When will I verify it?

**Funnel decisions.** Compare stages using a common application cohort. A screen rate is screens divided by qualified applications old enough to receive a response. A technical-pass rate uses completed technical rounds as its denominator. At week 8, if a peer cannot run your demo, prioritize the README and setup. At week 16, if screens arrive but coding rounds stall, exchange one project extension for timed mocks. If there are few screens after a well-matched sample, revise targeting and résumé evidence. At week 24, assess written offers against your fixed-pay floor and role quality, or start a four-week cycle aimed at the measured bottleneck.

**Revision notes · 19 November 2026.** Recheck job links on application day; refresh salary evidence monthly and date every observation. Re-run package examples when major versions change. Recalculate years of experience only from verified dates. Keep dated evaluation fixtures and model versions so a better result can be reproduced.

