# Speak clearly about technical work

## A 15-minute daily practice

Pick one thing you actually changed today. Spend 3 minutes listening to a short segment of an engineering talk with a transcript, 3 minutes copying the speaker's phrasing, 5 minutes recording your own explanation, and 4 minutes replaying and rewriting one unclear sentence. On a 30-minute day, add a partner follow-up (10 minutes) and re-record (5 minutes). Measure clarity, accurate terminology and completion within time. Your accent does not need a score.

| Day | Grammar and vocabulary | Speaking task | Self-check |
|---|---|---|---|
| Monday | Present simple for system behavior: “The worker reads the queue.” | Explain one request in 45 seconds | Can a listener name the input and output? |
| Tuesday | Past simple for a completed change: “I added a test.” | Describe yesterday's bug and your action | Separate “I” from “we.” |
| Wednesday | Cause and effect: because, therefore, as a result | Explain why a job was repeated | Did you give an observation supporting the cause? |
| Thursday | Compare trade-offs: faster, cheaper, more consistent | Compare dense and lexical retrieval | Give one case where each helps. |
| Friday | Future and conditional: “If the provider times out, we will…” | Give a 60-second status update | End with a next action or decision you need. |
| Saturday | Clarification: “When you say scale, do you mean users or requests per second?” | Run a mock interview and ask one clarification | Did you restate the problem before solving it? |
| Sunday | Revision: choose three words you used imprecisely | Repeat Monday's talk without notes | Compare recordings and identify one clearer sentence. |

Keep a vocabulary card with **word / meaning / your own sentence / confusing neighbor**. Example: *latency* is time for one request, *throughput* is completed work per unit time. “At five requests per second, our p95 latency was [measured time].” Practice short sentences before joining them. Say “I have worked on the interface since [month]” only when the dates support it. Say “I worked on the interface in [period]” for a finished assignment.

## Technical explanations to practice aloud

**RAG:** “Before generating an answer, the service searches documents the user is allowed to read. It gives selected passages to the model and returns references. If the passages do not answer the question, the service can say it needs more information.”

**Async:** “Our API waits for another service. While one request is waiting, the event loop can work on another. A long CPU calculation on that same loop delays everyone.”

**Idempotency:** “The client sent the same request twice because the first response was lost. Both requests carried the same key. We returned the existing job, so the user saw one job.”

**Stand-up:** “Yesterday I added [behavior]. I tested it with [case]. Today I’m checking [next step]. I need [specific decision] by [time].” **Code review:** “I read this branch as [meaning]. What should happen if [edge case]? I can add a test once we agree.” **Recruiter call:** “I’m in Ahmedabad. My official title is Programmer Analyst. My closest experience is [verified work]. Could you clarify the team’s coding responsibilities and the approved range?”

**When stuck:** “I’m unsure about the library method name. The algorithm needs [operation]; I would verify the API in the docs.” Then continue reasoning. During a meeting, summarize the decision and who owns the follow-up. Send a short written recap when useful.

**Exit check.** Record a two-minute project walkthrough, answer two unexpected follow-ups, and ask a listener to repeat the architecture back to you. If they miss the decision or result, shorten the setup and try again.

