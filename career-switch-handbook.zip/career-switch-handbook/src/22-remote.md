# Working from India for an international team

## Establish eligibility before estimating pay

Ask the recruiter to confirm in writing the authorized work location, legal employer or client, currency, pay cycle, expected overlap, travel, benefits and notice. A US product team may employ you through an Indian entity and pay in INR. A European “remote” requisition can require residence in a named country. Use M4, M6, M9 and M10 for contrasting examples.

| Arrangement | Who signs and pays | What to establish |
|---|---|---|
| Direct employment | Company or its Indian employing entity | Payslips, withholding, benefits, leave, equipment, working hours and applicable local arrangements. For an overseas employer without an Indian entity, ask how payroll and obligations will be fulfilled. |
| Employer of Record (EOR) | A local employer employs you and runs payroll; the client directs day-to-day work | Identify both parties, payslip and benefits issuer, local contract, probation, termination and contact if the client ends the assignment. |
| Independent contractor | You invoice a client under a services agreement | Define deliverables, acceptance, invoicing currency, payment deadline, bank fees, liability, equipment, time off and how unpaid invoices are handled. |
| Freelance-to-full-time | Paid trial contract first, conversion under a later written agreement | Bound hours, rate, scope and ownership; agree a review date and conversion criteria. Evaluate the trial on its own terms while conversion is uncertain. |

## Estimate spendable income

An **illustration** with invented exchange rates and no claim about current rates: USD 30/hour × 30 billable hours/week × 46 paid weeks = USD 41,400. At ₹82/USD this is ₹33.948 lakh gross receipts; at ₹78/USD it is ₹32.292 lakh. At the first rate, a 1% conversion/payment cost is about ₹33,948. If you budget ₹1.2 lakh per year for equipment, insurance and administration, the remaining amount is about **₹32.41 lakh before personal taxes**. The 46 paid weeks already account for unbilled time; subtracting the same leave twice would understate the result. A slower month or unpaid invoice changes it again. Repeat the calculation with a EUR offer and the actual credited rate.

A salary pays on the contractual payroll cycle; an invoice pays when accepted and settled. Ask for payment history, contract entity and bank details through verified channels. Use milestones, invoice numbers and written acceptance; reconcile invoiced amount, FX rate, fees and credited amount. Keep contracts, invoices, bank advice, expense records and any tax-withholding certificate.

## Indian taxes and cross-border contract review

Tax residence, income characterization and the relevant tax year affect Indian obligations. The Income-tax Act, 2025 defines scope of total income for residents and exceptions for residents not ordinarily resident. A foreign client or foreign currency alone does not determine tax treatment. Before accepting, have an Indian chartered accountant model employee versus professional income, advance tax, permissible expenses, foreign withholding and any treaty/foreign-tax-credit documentation for your facts. The illustration above deliberately stops before tax. [Income-tax Act, 2025, section 5, published 2025](https://egazette.gov.in/WriteReadData/2025/265620.pdf) · [Income Tax Department, residential status](https://wm.incometaxindia.gov.in/w/residential-status)

For a contractor, ask the accountant about GST registration, place of supply, whether the service meets export conditions, invoicing, permitted receipt arrangements, and the LUT route if applicable. A foreign billing address alone does not establish export treatment. Ask your bank which remittance records it supplies. Rates, thresholds and return obligations require a current review for your situation. [CBIC export-of-services clarification, September 2021](https://cbic-gst.gov.in/pdf/Circular-No-161-14-2021-GST.pdf) · [CBIC LUT circular, October 2017](https://cbic-gst.gov.in/pdf/Final_Master_circular_LUT_Bond_04102017.pdf)

Before signing, check governing law and dispute venue, assignment of intellectual property, pre-existing personal projects, confidentiality, liability caps, background verification consent, references, notice on both sides, termination for convenience, cure periods, final invoices and when access/benefits end. Confirm who supplies equipment and insurance. A local professional can review unusual liability or IP terms. Verify your current notice period against your own contract before promising a start date.

## Make remote collaboration visible

Provide a two-minute demo, a short decision record with alternatives, a small PR responding to review, and a written Friday update that says what shipped, what failed and what you need. Specify overlap precisely: 18:30–20:30 IST is 13:00–15:00 UTC; that is 08:00–10:00 US Eastern standard time or 09:00–11:00 during Eastern daylight time. European and US daylight-saving transitions differ. Put the proposed calendar dates into a time-zone-aware invitation.

**Exit check.** Compare an India payroll offer and a contractor quote on one annual basis. Identify who pays, where you can work, the guaranteed component, costs you must fund and the questions still requiring written answers.

