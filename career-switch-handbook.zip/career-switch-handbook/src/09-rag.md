# G · Retrieval-augmented generation

A support agent needs an answer with the exact policy page they can inspect. RAG retrieves external evidence at request time and supplies it to the generator. The worked lab in the appendix connects a real FastAPI route to Qdrant; the portfolio specification then expands it into a multi-format platform.

## G1 · Make a document searchable and deletable

Beginner · 2½ hours · Requires B1, D1 and F1.

**Objective.** Turn a revision of a document into stable, traceable chunks.

Parse a text PDF page by page. A scanned page may contain only an image; detect absent/poor text and route it to OCR. Normalize whitespace while preserving page and section boundaries. A chunk is a passage indexed as one retrievable unit. Overlap repeats boundary text to protect context at the cost of storage and duplicate hits.

Store tenant, visibility group, document ID, revision, page number, heading, chunk index, content hash, parser version and embedding version. The vector and payload live in Qdrant, while the authoritative revision and permissions remain in the database. Index a new revision, verify expected chunk count, then publish the revision pointer. Remove stale vectors and deny access immediately when permissions change.

```python
def chunks(words, size=8, overlap=2):
    if not 0 <= overlap < size:
        raise ValueError("overlap must be smaller than size")
    start = 0
    while start < len(words):
        yield words[start:start+size]
        if start+size >= len(words):
            break
        start += size-overlap

assert list(chunks("a b c d e".split(),3,1)) == [["a","b","c"],["c","d","e"]]
```

**Common failure and working practice.** Word windows are a baseline. Tables can lose row/column associations and OCR can change an identifier. Store extraction confidence or review state where relevant. Never publish empty extraction as a successful index.

**Exercise.** Chunk the same two-page policy by page, by heading and by fixed window. For five questions mark whether one chunk contains sufficient evidence.

**Build and check.** Build an importer for TXT and text PDFs with repeatable chunk IDs, per-page provenance and a scanned-page fallback. Re-ingesting a revision must leave the active count unchanged.

**Interview rehearsal.** Why can large overlap reduce answer quality? Near-duplicate passages consume candidate slots and context; fewer independent sources reach the answer.

## G2 · Retrieve, combine and rerank evidence

Intermediate · 3 hours · Requires G1 and F1.

**Objective.** Choose lexical, semantic or hybrid retrieval based on query failures.

Dense retrieval compares learned vectors; cosine compares direction, dot product combines direction and magnitude, and Euclidean distance measures separation. Keep embedding models and metric compatible. Sparse search represents term weights and usually helps with literal codes. A reranker scores candidate query-passage pairs more carefully than the first retrieval stage.

Apply trusted tenant and visibility filters inside each search. Retrieve dense and sparse candidate lists independently. Reciprocal rank fusion sums 1/(k+rank) across lists; it works when their raw scores have different scales. Rerank a bounded candidate set, deduplicate, select diverse passages and truncate to the token budget. Query rewriting can clarify a follow-up; preserve identifiers and evaluate it against the actual question.

```python
from collections import defaultdict

def fuse(lists, k=60):
    score = defaultdict(float)
    for ranked in lists:
        for rank, item in enumerate(dict.fromkeys(ranked), start=1):
            score[item] += 1/(k+rank)
    return sorted(score, key=lambda item: (-score[item], item))

assert fuse([["doc-a","doc-b"],["doc-b","doc-c"]])[0] == "doc-b"
```

**Common failure and working practice.** Filtering only after top-k can underfill results and expose unauthorized text downstream. Filter before candidate generation and enforce authorization again when dereferencing a citation.

**Exercise.** Use a query with a literal error code and a paraphrase with no shared keyword. Log dense/sparse/fused ranks for each. Run the appendix lab.

**Build and check.** Return cited passages with document, page and revision. Test two tenants with nearly identical docs and an unanswerable question.

**Interview rehearsal.** When can reranking fail to help? It cannot promote an absent passage. Improve candidate recall or ingestion before spending more on ranking.

## G3 · Evaluate retrieval separately from generation

Intermediate · 2½ hours · Requires G2.

**Objective.** Locate the first failing stage and make a measurable release decision.

For each held-out question label relevant chunk IDs and whether the corpus can answer it. Recall@k is the fraction of all labeled relevant chunks retrieved in the first k. Hit@k asks whether any was found. Reciprocal rank rewards finding the first relevant chunk early. Answer evaluation separately measures factual support, completeness, citation accuracy and appropriate refusal.

Suppose relevant chunks are A and D and top three are B, A, C. Recall@3 is 1/2, hit@3 is 1 and reciprocal rank is 1/2. If A supports the whole answer, generation may still succeed. Evaluate exact codes, paraphrases, obsolete revisions, no-answer and unauthorized cases. Freeze the dataset before comparing releases.

```python
def retrieval_scores(ranked, relevant, k):
    if not relevant:
        raise ValueError("score unanswerable cases separately")
    top = ranked[:k]
    hits = set(top) & relevant
    reciprocal = next((1/i for i,x in enumerate(top,1) if x in relevant),0)
    return len(hits)/len(relevant), bool(hits), reciprocal

assert retrieval_scores(["B","A","C"], {"A","D"}, 3) == (0.5,True,0.5)
```

**Common failure and working practice.** A single average hides failures on small groups. Never mix tuning queries into held-out results. Human-review a sample of any model-judge decisions. Log IDs and timing; redact text and limit access to evaluation traces.

**Exercise.** Take one wrong answer and classify the first failure as parsing, retrieval, ranking, context assembly or generation. Change one variable and measure again.

**Build and check.** Publish baseline and candidate results with sample size, per-slice scores, latency and cost. Gate on zero cross-tenant disclosure on the fixture and review every regression.

**Interview rehearsal.** Recall improved but answers got worse. Why? More marginal passages can crowd out useful evidence or introduce conflicting revisions. Inspect the exact assembled context.

## Module exit and revision

Rebuild the index, compare dense/sparse/fused runs on identical data, demonstrate tenant isolation and reproduce the first failure on a saved query. Use the practical lab and P1 acceptance criteria.

**Further reading** · [Qdrant filtering](https://qdrant.tech/documentation/search/filtering/) · [Qdrant hybrid queries](https://qdrant.tech/documentation/hybrid-queries/) · [PyMuPDF text extraction](https://pymupdf.readthedocs.io/en/latest/recipes-text.html)

