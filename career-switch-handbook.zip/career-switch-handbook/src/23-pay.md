# Negotiate and compare offers

Treat ₹25+ LPA as a target and distinguish it from guaranteed recurring cash. First decide privately what role, fixed pay, mentorship, work hours, location and runway you can accept. Request the approved compensation band near the first recruiter call, then negotiate details after the team has assessed fit and before signing.

## Normalize the numbers

These are **hypothetical offers**, not market salary estimates. For simplicity the employee examples omit statutory employer contributions; obtain the real itemized CTC sheet. Exclude uncertain equity from guaranteed cash.

| Example | Guaranteed recurring gross | Conditional or one-time | Interpretation |
|---|---:|---|---|
| A · ₹25 L headline | ₹18 L fixed | ₹3 L target variable + ₹2 L joining + ₹2 L quoted annual equity | ₹20 L first year if the joining amount is paid and retained. ₹18 L recurring fixed. Ask about payout history and clawback. |
| B · ₹24 L headline | ₹22 L fixed | ₹2 L target variable | More recurring fixed cash than A. Compare mentorship, scope, on-call and commute before deciding. |
| C · ₹16 L engineering role | ₹15 L fixed | ₹1 L target variable | Possible intermediate step when the team offers review, meaningful ownership and a credible progression path. Get scope and review cycle in writing. |
| D · foreign contractor | No employee salary; example ₹33.95 L gross receipts | Billable hours and FX vary; insurance, downtime, fees and taxes are personal inputs | Compare with the worksheet in Working from India. Use a downside FX and utilization case as well as the baseline. |

CTC can include employer contributions and benefits that do not arrive as monthly cash. Fixed annual gross divided by 12 gives a starting gross monthly number; payroll deductions change bank credit. A joining bonus is one-time and may be repayable. An ESOP is an option with strike price, vesting, exercise window and uncertain liquidity. An RSU settles subject to its vesting and settlement conditions; price can change. Ask for grant size, valuation basis, vesting schedule and treatment on exit. Keep a separate upside case for equity.

## Conversations you can actually use

**Current CTC:** “My current CTC is [verified amount], with [verified fixed component]. For this move I’m evaluating the scope and the band for this role. Could you share the fixed and total range?” Use the exact figure if choosing to disclose. Never inflate pay or invent a competing offer.

**Expectation:** “For a role where I own Python services and evaluated AI features, I’m targeting around ₹25 lakh or above in total annual compensation. The fixed portion, role scope and growth path matter to me. How is the band structured?” If ₹25 lakh is your fixed-pay target, say **fixed** explicitly instead.

**Low offer:** “Thank you for the offer. I’m interested in the team’s work on [specific feature]. The recurring fixed component is [X]. Given the responsibilities and the evidence we discussed, is there room to move it toward [Y]? If fixed pay is capped, could we review the level, joining component or written review timeline?”

**Competing offers:** “I have a written offer with a decision date of [real date]. Your team is attractive because [specific reason]. Could you clarify the fixed component and whether your process can complete by then?” Share only terms you are permitted and comfortable to disclose. Confirm the final figure and conditions in the revised letter.

**International:** “Is this budget annual employee gross or contractor invoices? What currency, paid leave, minimum hours, notice and benefits does it assume?” Make one counterproposal with a reason, allow the recruiter to respond, and document what changed. A promised future raise has no guaranteed cash value today.

**Decision worksheet.** Assign weights before seeing the largest number: example 35% recurring fixed, 25% engineering scope, 20% manager/mentoring, 10% work schedule, 10% risk/benefits. Score each 1–5, multiply and sum. Record deal-breakers separately. If both offers meet the floor, ask the prospective manager who reviews your first PR, what a successful first 90 days looks like and how incidents are handled. Wait for written terms and resolved contingencies before making a resignation decision.

