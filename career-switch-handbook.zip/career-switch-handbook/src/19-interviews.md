# Interview studio · Coding, backend, AI and design

## Run a 45-minute mock

Spend 5 minutes clarifying input, scale and failure semantics, 20 minutes coding or designing, 10 minutes testing and 10 minutes explaining trade-offs. Score each of correctness, reasoning, testing and communication from 0 to 4. A 0 means blocked, 1 means heavy prompting, 2 means partial, 3 means independent with a small correction, and 4 means independent with a justified alternative. Revisit the first point at which your reasoning stopped being sound. Use C1–C16 for hints, worked Python solutions and complexity.

## Oral question bank with answer checkpoints

| Interview question | A strong answer demonstrates |
|---|---|
| Why does a default list collect values across calls? | Defaults are evaluated when the function is defined. Use None then allocate per call and test two invocations. |
| When is an iterator better than a list? | Single-pass processing and bounded memory; demonstrate exhaustion and closing resources. |
| What does a decorator change? | Binds a name to a wrapper; forward arguments, result and exceptions, preserve metadata. |
| Composition or inheritance for model providers? | Depend on a small interface and compose an adapter. Inherit only with substitutable behavior. |
| Why can memory rise after a request ends? | A cache or task may still reference objects. Compare tracemalloc snapshots; distinguish live objects from allocator reuse. |
| Threads, asyncio or processes for PDF processing? | Identify waiting versus CPU work and SDK behavior. Offload bounded blocking calls; measure serial and concurrent throughput. |
| Why can a fast Python function still cause p95 latency? | Event-loop blocking, pool waits, queueing or a slow dependency. Use a trace and profile the relevant boundary. |
| How would you test a timeout deterministically? | Inject a client or clock that produces the failure; add one real integration test for the adapter contract. |
| How does FastAPI DI help tests? | Override the principal/repository dependency. Retain integration tests for authentication and query filters. |
| When should POST return 202? | After durable acceptance, with a status resource. Explain replay, idempotency and terminal failure. |
| Where does a JWT-based API enforce access? | Verify signature/issuer/audience/expiry, then authorize the resource and action in server-controlled scope. |
| Why is my SQL query slow despite an index? | Examine selectivity, estimated/actual rows, sort, buffers, pool wait and index column order. |
| How do you paginate concurrent inserts? | Order by an immutable unique tuple, use a cursor and state the consistency guarantee. |
| Can we put an answer in Redis? | Define access scope, TTL, invalidation and fallback; measure hit rate and stale behavior. |
| How do you reproduce a cross-tenant regression safely? | Create two synthetic tenants and test allowed and denied reads in each public endpoint. |
| Why can two relevant-sounding chunks produce a bad answer? | Obsolete or contradictory revision, lost table structure, token truncation or unsupported inference. Inspect exact context. |
| Cosine, sparse search or hybrid? | Explain semantic similarity and literal identifiers. Compare recall@k on paraphrases and codes; fuse rankings and test. |
| What does Qdrant store? | Point ID, vector(s) and payload. Version model dimensions and filter tenant/visibility before retrieval. |
| How should chunk size be selected? | Use answer spans and section boundaries; tune on a development set and validate on held-out questions. |
| Why rerank? | Higher-cost relevance comparison over a small candidate set; quantify quality benefit and latency cost. |
| How do you compare two LLMs? | Same prompts, holdout, context and budget; record model/version, errors, time to first token, completion time and cost per success. |
| How does prompt injection affect an agent? | Data can contain instructions that conflict with the task. The host validates tool permissions and arguments and authorizes effects. |
| Why can a retry create two tickets? | External side effect may succeed before acknowledgement. Use a stable operation key or reconciliation and an unknown state. |

## Three solved design interviews

### Design a multi-tenant RAG service

**Clarify.** Ask whether a revoked user may receive a cached answer, how fresh revisions must be, which file formats matter, and what the p95 target includes. Assume no access after revocation, two-minute index freshness for small PDFs, and a separate first-token target. **Estimate.** At 12,000 queries in 10 hours with 12× peak, plan for 4/s; a two-second average implies roughly eight in flight. Confirm per-model concurrency quotas. **Contract.** POST a document revision, return an indexing job; POST a question returns evidence or an abstention. **Data path.** Object storage → parser → chunk/index → verified active revision. On a query, check membership, filter candidates, rerank, generate, revalidate references. **Failure.** If the vector store is unavailable, show an explicitly degraded authorized lexical result if available; otherwise return a retryable failure. Revocations bypass stale caches. **Measurement.** Track recall@5, citation validity, p95, cost and denial tests. Split the worker when parsing begins to delay serving; show the P1 diagram.

### Design an assistant that remembers a conversation

**Clarify.** A returning user wants to resume a conversation, delete it and see cited sources. Assume 1,000 active conversations/day, 20 turns each, 2 KB of application text per turn: roughly 40 MB/day before indexes, logs and replication. **Contract.** POST /conversations creates an owner-scoped record; POST /conversations/{id}/turns carries a unique client turn key and expected conversation version. Persist user turn and pending assistant turn atomically. **Data path.** Fetch recent authorized turns, build a bounded summary and retrieve current documents with P1 permissions. Stream deltas while keeping a final durable answer status. **Concurrency.** Version checks serialize conflicting turns; a reconnect loads by turn ID instead of re-issuing the prompt. **Failure.** On upstream cancellation mark the answer interrupted and distinguish partial text from final. Deletion removes or invalidates summaries, caches and retained transcripts according to policy. **Measurement.** Track time to first token, duplicate turns, citation entitlement and deletion completion. Prefer a modular API until throughput justifies extraction.

### Design an approval-based automation service

**Clarify.** A draft may wait days. Only a manager of the same tenant may approve. Assume 100 runs/hour, two read calls and at most one write per run. Two reads per run average roughly 0.056/s; bursts and provider rate limits matter more than the mean. **Contract.** POST /runs returns 202. A versioned approval refers to an immutable proposal hash. **Storage.** Persist proposals, decisions, operation keys and an append-only transition log. Write next-state/outbox atomically. **Execution.** The worker looks up policy, validates a proposal, pauses and resumes after verified approval. **Failure.** Enforce per-run deadlines and reconcile ambiguous external outcomes; require review when reconciliation is impossible. **Measurement.** Test double-click approval and crash after provider commit; count actual effects. Show P2's graph and P3's restore evidence. Explain why a replay-safe mock provider gives a stronger guarantee than a provider without idempotency.

## Explain all three projects

Use a 90-second answer: user problem (15 s), your contribution (20 s), one design choice (20 s), one failure and test (20 s), result and limitation (15 s). Use the following as **rehearsals after building**, changing details to match your evidence.

- **P1.** “Two teams had different answers to the same support question. I indexed synthetic policies with tenant and revision metadata. I applied the tenant filter before retrieval, then compared dense and hybrid search on the same labels. One identifier query failed because [observed reason]. The report shows [actual result] and includes the remaining misses.”
- **P2.** “A model can draft a ticket, but review must precede the write. I persisted a proposal and bound approval to its version. My test interrupted the worker after the fake provider had accepted a ticket. On retry [observed outcome]. A provider without reconciliation would require manual review.”
- **P3.** “I made the service reproducible from an image digest and a migration version. I measured [endpoint, load and model mode], then injected [fault]. A trace pointed to [measured cause]. I restored into a separate environment and verified [actual check]. This was a staging drill.”

## Behavioral interview workshop

STAR means **Situation, Task, Action, Result**. State the context and goal briefly, spend most of the answer on your action, and finish with evidence or an honest open question. The bracketed items must be replaced with facts. Do not turn the following into claims until they are true.

| Prompt | STAR-shaped answer frame |
|---|---|
| Tell me about yourself | S: I studied Computer Engineering at VGEC and work as a Programmer Analyst. T: My work exposed me to support applications. A: I contributed to [verified scope] and practiced [independent project]. R: I can demonstrate [evidence], and I’m looking to own more of a Python service. |
| Explain your current role | S: Our team works on [approved product description]. T: I was assigned [specific item]. A: I implemented/reviewed [verified action] with [collaboration]. R: We verified it through [test or review]. |
| Why switch? | S: I have early exposure to AI applications. T: I want deeper engineering ownership. A: I have been building [actual example]. R: I’m seeking a team where I can ship and operate services with review and mentoring. |
| What have you built? | S: A user needed [problem]. T: I owned [scope]. A: I chose [design] because [constraint]. R: Here is a working demo and one remaining limitation. |
| Biggest technical challenge? | S: [Observed failure]. T: I needed to explain why. A: I isolated [two competing causes] with [experiment]. R: The evidence supported [finding] and I changed [one thing]. |
| Production issue? | S: If applicable, name a real incident. Otherwise say “I haven’t owned a production incident yet.” T/A/R: describe a staging fault, your hypothesis, observation and recovery test, explicitly as a drill. |
| Strength and weakness? | S: [Project example]. T: I needed to explain [idea]. A: I used [strength]; I noticed my first spoken explanation omitted [detail] and began recording short summaries. R: [Specific change observed]. |
| Why hire you? | S: Your role needs [JD requirement]. T: The early-career work matches [scope]. A: In my repo I built [feature] and tested [failure]. R: You can evaluate [demo]; the area I’m still developing is [gap]. |
| Why this company? | S: I tried/read [specific public product feature]. T: I wanted to understand [customer problem]. A: I compared it to [relevant work]. R: I would like to contribute to [team goal] and learn how you measure [outcome]. |

**Exit check.** Complete one coding, one project and one design mock with a second person. Keep the rubric, a follow-up question that surprised you and a revised 90-second answer.

