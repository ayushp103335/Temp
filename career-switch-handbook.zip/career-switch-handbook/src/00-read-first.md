# Your career switch, from the first commit to the offer

**A field guide for a Programmer Analyst in Ahmedabad · Research edition 19 November 2026**

Start with a small piece of work you can defend in an interview. Can you turn three lines of support-document metadata into a Python function, test it, and explain what happens when a line is missing? That exercise tells you where to begin more accurately than a list of tools on a résumé.

## Your route through the book

1. Read **Choose your role** and **Read the hiring evidence** once. Pick two suitable job descriptions. Keep them beside your code.
2. Follow **The 24-week plan** one week at a time. The letter and number beside a task identify its module and lesson. The first seven days are written out below.
3. Build the three portfolio projects in sequence. Reuse a public, synthetic support-document corpus across all three. You can demonstrate the first project while the others are in progress.
4. Use the interview questions immediately after each lesson with the book closed. Record a short answer in English. On Sunday, update the trackers and choose one correction for the following week.
5. Apply in week 1. At weeks 8, 16 and 24, use actual interview feedback and your working artifacts to adjust the mix of roles.

**How to read offline.** The single HTML reader has navigation, full-book browser search (Ctrl/Cmd+F) and chapter links. The ZIP contains Markdown source, diagrams, labs, a built HTML reader, and rebuild instructions. The PDF is for printing or annotating. All three editions follow one table of contents.

## Your first seven days

| Day | Work alongside your job | Evidence to keep |
|---|---|---|
| Monday | Verify employer, title, joining month and graduation year against your own records. Install Python 3.11+ and Git. Read A1 and predict its output before running it. | One private fact sheet and your first passing assertion |
| Tuesday | Write a function that trims document titles, ignores empty titles and counts duplicates. Trace it on paper before coding. | One commit and three test inputs |
| Wednesday | Read A2. Draw the trip from a browser to the support API. Record 60 seconds about the part of the interface you personally handled. | A diagram and a recording you can understand on playback |
| Thursday | Compare one India-based junior role and one India-eligible remote role. Underline location, experience and the first three responsibilities. | Two dated tracker rows with URLs and gaps |
| Friday | Draft your one-page résumé. Pick one listing you qualify for and submit a tailored application. Start P1 with two synthetic documents and stable IDs. | Application receipt and a public-safe corpus |
| Saturday | Spend 90–120 minutes on Two Sum, a Git branch and a small test. Explain what belongs in a dictionary key. | Working solution with a duplicate-value test |
| Sunday | Apply to a second suitable role, contact one person about the team and replay your introduction. Review the week. | Two applications total, one outreach and next week's first task |

## Personal information still to confirm

The working profile comes from your brief: Computer Engineering at VGEC, GTU, Programmer Analyst at Meditab Private Limited, Ahmedabad, approximately 1+ year of experience, and ₹3–5 LPA CTC. A matching résumé or employment record was unavailable. Keep exact dates, degree wording, graduation cohort, notice period, fixed/variable pay, public URLs, location flexibility and time-zone preferences blank until verified. Confirm the spelling of the masked Node/Express entry and which project version used Streamlit or Vue. Write down each contribution, who reviewed it, how it was tested, and whether you can describe it publicly. Obtain figures from reproducible measurements before adding numbers to a résumé.

**Study assumptions.** The recommended track uses roughly 10–12 hours a week including applications and English, with a lighter track for busy weeks. The 24-week window ends near the six-month goal. Four months is the first serious decision point. An offer depends on role fit, openings, interview performance and the employer's band.

