# P1 · Build an enterprise document search platform

## The problem and the shipping criteria

Support teams need answers traceable to the current policy. A tenant uploads PDF, TXT or Markdown, waits for indexing, asks a question, and opens the cited page. Build from the public-safe policies in the lab; add no company documents.

**Functional requirements.** Users can upload, see status, search, read citations, remove a revision and receive an insufficient-evidence response. Operators can replay failed indexing and compare retrieval releases. A small React or Vue interface has an upload form, progress state, answer pane and clickable page references. Use the frontend you can explain best.

**Nonfunctional targets.** Start with 30 answerable and 10 unanswerable labeled queries across two tenants; reserve a holdout before tuning. Targets for the demo: zero cross-tenant results, every displayed citation resolves to an authorized current revision, and a declared p95 search target on named hardware. Report the measured value even if the target was missed.

## Architecture and contracts

![P1 · Build an enterprise document search platform architecture](assets/p1.svg)

FastAPI serves contracts, PostgreSQL owns membership and revision state, object storage preserves originals, Qdrant indexes vectors and metadata, and a separate worker parses and embeds. A dense-only baseline precedes lexical retrieval, RRF and a reranker. Keep the generator replaceable.

**Data design.** tenant(id), membership(user_id,tenant_id,role), document(id,tenant_id), revision(id,document_id,checksum,status), chunk(id,revision_id,page,offset), index_job(id,tenant_id,key,state), eval_case(id,expected_sources). Enforce unique (tenant_id,key) on jobs, foreign keys on revisions and a single active revision per document. Keep chunk payload and citation authorization consistent.

**API contract.** POST /v1/documents → 201 and revision; POST /v1/index-jobs → 202 with status URL; GET /v1/jobs/{id}; POST /v1/search → ranked passages; POST /v1/answers → answer, source IDs and evidence status; DELETE /v1/documents/{id} → revoke and schedule purge. Add a reference-data version to answers.

**Repository layout.** api/routes · domain/permissions · ingest/parsers · retrieval/rankers · evals/cases · ui · migrations · tests/isolation · ops

## Development and release

1. W1–W4: seed corpus, hand-label expected page IDs, show text ingestion locally.

2. W5–W8: persist metadata, add upload/status API, implement trusted identity and denial tests.

3. W9–W12: integrate embeddings, hybrid ranking and citations; compare with dense-only.

4. W13: publish a short demo, evaluation report and known limitations.

**Tests and security.** Unit-test chunking and permissions, integration-test Qdrant filters, and run an end-to-end upload/question/delete flow. Simulate failure between embedding and activation. Reject oversized files and unsupported formats; quarantine untrusted parsing jobs, restrict network egress and purge stale vectors. Test access after permissions change.

**Deployment and monitoring.** Run locally with Compose, promote the P3 container build to staging, and serve the UI over TLS. Monitor extraction failures, first-token latency, empty retrieval, citation validity, answer abstentions and per-tenant cost. Roll back model/prompt/index versions independently.

## Turn the build into evidence

Organize the README as problem → quick start → architecture → sample request → failure demonstration → reproducible results → limitations → next decision. Include a clean-clone command, pinned versions, synthetic fixture, screenshot and one way to verify the result. Show the first failure before the fix. Explain your role and name any borrowed component.

**Résumé bullet after verification.** “Built [public corpus size]-document retrieval service with tenant-scoped search and page citations; measured [baseline] versus [candidate] recall@5 on [n] held-out questions.”

**Interview rehearsal.** Why pick overlap X? Where is the permission predicate applied? How do you replace an embedding model without mixing vector spaces? Show a real miss and the evidence that changing ranking helped.

**Exit check.** A peer can follow the README on a clean machine, observe one success and one intentional failure, and find the data behind your résumé sentence.

