# Choose your role and audit your experience

**Primary — backend engineer on an AI product.** Your support-bot experience gives you a concrete user problem to discuss. The highest-return next step is to own the path from request to result: validate an input, retrieve authorized evidence, persist state, return a useful answer and measure failure. Search for Software Engineer I and Backend Engineer as well as AI titles.

**Secondary — applied AI engineer focused on retrieval and evaluation.** Favor teams that build and evaluate applications. **Backup — Python backend engineer.** Keep the same APIs, SQL, tests and deployment story. A role with code review, production ownership and mentoring can compound even if the first offer lands below ₹25 LPA.

## Why these three

These are advisory scores for this candidate on a 1–5 scale. Weights are existing fit 30%, feasibility of closing gaps in six months 25%, accessible roles 20%, ability to demonstrate work independently 15%, and portability across employers 10%. Higher is better on every dimension. Scores and interview difficulty are judgments, not vacancy counts or salary estimates. M1–M9 refer to the following chapter. Unobserved pay remains unknown. The backup gives broader search coverage; the secondary preserves your AI specialization.

| Role | Fit, gap, access, proof, portability | /100 | Work and interview | Market and compensation evidence | Preparation |
|---|---|---:|---|---|---|
| Backend engineer on AI products | 5 / 5 / 4 / 5 / 4 | 94 | Own ingestion, APIs, permissions and reliable model calls. Junior/early-mid; medium–high, API design + coding. | India examples overlap AI software; explicit India remote example M4. Stretch pay M4. | Build P1 retrieval and P3 operations. |
| Applied AI engineer | 5 / 4 / 4 / 4 / 4 | 86 | Turn model behavior into a measured product feature. Early to experienced; high, evaluation and error analysis. | India M2/M3; global offers depend on residence. M3 ₹20–50L at 3+ years. | Build labeled evals and explain failed queries. |
| Python backend engineer | 4 / 4 / 5 / 4 / 4 | 84 | Design APIs, transactions, data access and worker jobs. Junior to senior; medium–high, Python, SQL and DSA. | India M7; international engineering route M6. Pay undisclosed in M7. | Demonstrate P3 with no model dependency. |
| AI software engineer | 4 / 4 / 4 / 4 / 4 | 80 | Ship AI features across API, model and user interface. Early to mid; high, broad software and model questions. | India M2 shows mid-level bar; remote M4 overlaps. Pay undisclosed M2. | Show traces from browser through retrieval. |
| Generative AI engineer | 4 / 4 / 3 / 4 / 3 | 74 | Build generation, structured outputs and evaluations. Graduate to experienced; medium–high, model trade-offs. | India M1; foreign junior eligibility unverified in this sample. Pay undisclosed M1. | Compare two prompts against a fixed baseline. |
| LLM engineer | 3 / 2 / 2 / 4 / 3 | 54 | Depending on team, serve models or train/adapt them. Specialist; high, inference, training or GPU systems. | Narrower search filter; no junior India/remote salary sample. | Learn token budgets first; defer GPU kernels. |
| AI automation engineer | 3 / 4 / 3 / 3 / 3 | 65 | Automate a business process and handle exceptions. Entry varies; medium, integrations and operations. | India-remote M5 at 3+ years, ₹12–16L. Ask about coding share. | Prove retries and durable execution in P2. |
| AI agent engineer | 4 / 3 / 2 / 4 / 3 | 65 | Build tools, state machines, policies and replay. Often product-specific; high, state and failure recovery. | India M8 historical lead; M3 adjacent. No separate junior band. | Show approval, budgets and a measured completion rate. |
| AI solutions engineer | 3 / 3 / 3 / 3 / 3 | 60 | Discover customer needs, integrate and demonstrate systems. Early-mid and above; medium–high, live explanation. | India remote M9 is 2–5 years; Amsterdam/London openings separate. Pay unknown. | Practice a discovery call and integration demo. |
| MLOps / AI platform engineer | 2 / 2 / 2 / 4 / 3 | 48 | Operate inference, registries, rollout and telemetry. Usually requires operations evidence; high, infra troubleshooting. | No entry-level country-specific band established here; check on-call. | Measure P3 recovery and spend before specializing. |
| DevOps / cloud engineer | 2 / 2 / 3 / 3 / 3 | 49 | Provision services, ship changes and restore service. Junior through senior; medium–high Linux/network/debug screen. | Use India cloud/software searches; M6 adjacent, no comparable pay band. | Learn IAM, deployment and restore; defer certification. |

If you consistently enjoy evaluating answers more than designing APIs, compare the secondary track using three actual interviews. If location rules eliminate foreign leads, shift those hours into local product teams. Do not spend a month learning Kubernetes to qualify for an API role that asks for container basics.

## What you can say about your work

| Project | Evidence and attribution today | Improvement and interview use |
|---|---|---|
| Smart Support / QuickCap | Your brief reports frontend and some backend learning, PDF metadata, Qdrant and Streamlit streaming. A related QuickCap archive has a README describing ingestion and generation, FastAPI and Qdrant dependencies, a Vue manifest and backend test documentation. The relationship between versions and your commits is unverified. | Trace one response from input to UI. Explain whether incremental display comes from provider chunks or client animation. Bring an approved diagram, name the exact change you owned and credit the team for the rest. |
| ID Analyzer | Title supplied. Inputs, architecture, ownership and results unknown. | Reproduce a single public-safe example with synthetic identifiers, state expected output and show failure handling. Include only after you can explain data retention and one test. |
| Employee Management System | MERN project reported. No matching source reviewed. | Demonstrate role-based access and pagination with fake employees. Show a denied cross-user action and one database constraint. Use as secondary evidence for full-stack roles. |
| Wanderlust | Clone listed, depth unknown. | Identify starter-code provenance and one independent change, such as a booking conflict check. Give it résumé space only if it adds evidence absent elsewhere. |

Use four skill labels privately: **observed**, **implemented with guidance**, **implemented independently**, **operated and debugged**. Record one verifiable example beside every label. An archive proves that components exist. It cannot establish who built them.

