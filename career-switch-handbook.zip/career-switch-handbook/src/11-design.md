# I · System design under real constraints

In a design interview, ask for a user, workload, failure policy and budget before drawing boxes. A support platform that accepts a file and answers questions has a write-heavy ingestion path and a latency-sensitive read path. They should have separate capacity estimates.

## I1 · Estimate a service and choose the first architecture

Intermediate · 2½ hours · Requires E3 and D2.

**Objective.** Turn requirements into numbers and identify the first bottleneck.

Functional requirements describe actions such as upload, search and delete. Nonfunctional requirements give measurable conditions such as availability, freshness and p95 latency. Start with a modular monolith and one datastore when one team can operate them. Separate a worker when its scaling or failure behavior differs. Microservices add network calls, deployment coordination and distributed state.

Illustrative capacity: 12,000 queries across a ten-hour working day average 0.33 requests/s. A 12× peak gives 4/s. At 2 seconds average service time, steady-state concurrency is about 8 requests by Little's law. For 6,000 pages/day × 5 chunks/page × 768 dimensions × 4 bytes, raw vectors require about 92 MB/day before metadata, replicas and indexes. Replace assumptions with measurements.

```text
peak requests/s = daily requests / active seconds × measured peak factor
in-flight work ≈ arrival rate × average time in system
raw vector bytes = chunks × dimensions × bytes per component
```

**Common failure and working practice.** Percentiles cannot be added to get a mathematically exact end-to-end percentile. Measure the complete path. A gateway handles TLS, routing and quotas; object authorization belongs in the application.

**Exercise.** Increase arrival rate to 8/s with a model allowance of 5/s. Compute backlog growth over one minute and design admission control.

**Build and check.** Produce a one-page design with API contracts, ownership of writes, a latency budget, one load test and a graceful response to overload.

**Interview rehearsal.** Vertical or horizontal scaling? A larger node is simple but bounded. More stateless replicas behind a load balancer help only if the shared database or model quota can carry the added load.

## I2 · Reason about partitions, retries and availability

Intermediate · 3 hours · Requires I1 and D2.

**Objective.** Choose consistency for a concrete operation and show recovery boundaries.

During a network partition, a distributed service cannot guarantee both linearizable reads/writes and a successful response to every request at non-failing nodes. For permissions, refuse or defer when authority cannot be established. For a public search index, an older verified revision may be acceptable. State the decision separately for each operation.

Read replicas improve read capacity but may lag. Sharding distributes data by key; a tenant key routes one tenant query efficiently yet a hot tenant can still overload one shard. Queues decouple arrival from service and commonly redeliver. Event-driven consumers need a stable key, deduplication and replay semantics. High availability serves through failures; backups and restore tests handle corruption or deletion.

```text
If a worker handles 2 jobs/s and arrivals reach 5/s for 60 s,
backlog grows by 180 jobs. After arrivals return to 1/s,
the same worker needs about 180 s to catch up.
```

**Common failure and working practice.** Adding workers cannot fix a saturated external quota. Enforce per-tenant tokens and fairness, bound queue age, track dead letters and avoid synchronous cascades. Backups sharing the same failure domain need independent recovery copies.

**Exercise.** For the RAG query, permission revocation, and approved ticket write, choose stale-read tolerance and retry behavior. Explain the cost to one user.

**Build and check.** Design three failure drills: index unavailable, worker crash and database restore. Record RTO (time to restore service) and RPO (acceptable data-loss window).

**Interview rehearsal.** Can an active replica replace a backup? Replication may faithfully copy bad deletes. A restore point from before the error, and a tested restore process, answer a different failure mode.

## Module exit and revision

Present a ten-minute system design with workload arithmetic, one schema, one diagram, a failure timeline and a reversible rollout. Apply it to all three solved cases in Interview studio.

**Further reading** · [Google SRE book](https://sre.google/sre-book/table-of-contents/) · [PostgreSQL high availability](https://www.postgresql.org/docs/current/high-availability.html) · [Dynamo paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf)

