# C · Sixteen coding interview patterns

**C1–C16 · Beginner to interview level · 35–65 minutes per pattern on the first pass.** Prerequisites A1 and B1. The objective for each lesson is to recognize the contract, derive an invariant (a statement that stays true during the loop), implement it and test a boundary. V and E denote vertices and edges. Auxiliary space excludes the returned output unless stated.

For each problem, use two minutes to restate input and output, five to draw a small case, and fifteen to implement. Before reading the hint, try the stated problem. The implementation is the worked solution. Your mini-project is a tested function plus one sentence about its bound. Re-solve without notes after 2, 7 and 21 days. The practice ladder names searchable problems; the last column is often a stretch. Do a hard extension only after the core pattern is reproducible.

## C1 · Arrays and strings

**Problem.** Deduplicate adjacent sorted IDs in place. For [2,2,5], the valid prefix should be [2,5].

**Hint and reasoning.** A Python list gives indexed access; strings are immutable. Keep a write cursor behind the read cursor. The prefix before it contains each observed value once. Use a list of pieces then join when building a long string.

```python
def compact(ids):
    write = 0
    for item in ids:
        if write == 0 or item != ids[write-1]:
            ids[write] = item
            write += 1
    return write

items = [2, 2, 5]
assert items[:compact(items)] == [2, 5]
```

**Complexity.** O(n) time, O(1) extra space for in-place compaction. **Common mistake.** Sorting unsorted input changes order and adds cost.

**Practice ladder.** Remove Duplicates from Sorted Array → String Compression → First Missing Positive.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C2 · Hash maps and sets

**Problem.** Return two different indices that sum to a target.

**Hint and reasoning.** Store a value you have already seen and its position. Look up its complement before inserting the current value. A set suffices when only membership matters.

```python
def pair(nums, target):
    seen = {}
    for i, value in enumerate(nums):
        if target-value in seen:
            return seen[target-value], i
        seen[value] = i
    return None

assert pair([3, 3], 6) == (0, 1)
assert pair([3], 6) is None
```

**Complexity.** Expected O(n) time, O(n) space; hashing costs depend on key size. **Common mistake.** Inserting first can reuse one index.

**Practice ladder.** Two Sum → Group Anagrams → Longest Consecutive Sequence (medium extension).

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C3 · Two pointers

**Problem.** Does a sorted list contain a pair with a given sum?

**Hint and reasoning.** Start at both ends. If the sum is too small, pairing the left value with anything else can only reduce it. Discard that left value. Reverse the reasoning when the sum is too large.

```python
def has_pair(values, target):
    left, right = 0, len(values)-1
    while left < right:
        total = values[left] + values[right]
        if total == target:
            return True
        if total < target:
            left += 1
        else:
            right -= 1
    return False

assert has_pair([1, 4, 9], 10)
```

**Complexity.** O(n) time, O(1) space for sorted input. **Common mistake.** The discard proof fails on unsorted data.

**Practice ladder.** Valid Palindrome → 3Sum → Trapping Rain Water.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C4 · Sliding window

**Problem.** Find the longest substring with no repeated character.

**Hint and reasoning.** Track the last index of each character. When it repeats, move the left boundary just past its previous occurrence, if that occurrence is inside the window.

```python
def longest_unique(s):
    last = {}
    left = best = 0
    for right, char in enumerate(s):
        left = max(left, last.get(char, -1)+1)
        best = max(best, right-left+1)
        last[char] = right
    return best

assert longest_unique("abba") == 2
```

**Complexity.** Expected O(n) time, O(min(n, alphabet size)) space. **Common mistake.** Moving left backward makes abba appear to have length three.

**Practice ladder.** Maximum Average Subarray I → Longest Substring Without Repeating Characters → Minimum Window Substring.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C5 · Prefix sums

**Problem.** Answer repeated half-open range-sum queries on token counts.

**Hint and reasoning.** Store the sum before each index. Subtract the earlier prefix from the later one; all earlier terms cancel. This works even with negative numbers.

```python
def prefixes(values):
    result = [0]
    for value in values:
        result.append(result[-1]+value)
    return result

p = prefixes([4, -2, 8])
assert p[3]-p[1] == 6
```

**Complexity.** O(n) construction, O(1) query, O(n) space. **Common mistake.** Mixing inclusive ends with exclusive ends loses the final element.

**Practice ladder.** Range Sum Query – Immutable → Subarray Sum Equals K → Count of Range Sum.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C6 · Linked lists

**Problem.** Reverse a singly linked list while retaining every node.

**Hint and reasoning.** Each node points to its successor. Save the next node before changing its link. The processed prefix points backward, and the remaining suffix still points forward.

```python
from dataclasses import dataclass

@dataclass
class Node:
    value: int
    next: "Node | None" = None

def reverse(head):
    prev = None
    while head is not None:
        following = head.next
        head.next = prev
        prev, head = head, following
    return prev

assert reverse(Node(1, Node(2))).next.value == 1
```

**Complexity.** O(n) time and O(1) auxiliary space. **Common mistake.** Changing next before saving it loses the rest of the chain.

**Practice ladder.** Reverse Linked List → Reorder List → Reverse Nodes in k-Group.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C7 · Stacks

**Problem.** Check whether nested brackets are balanced.

**Hint and reasoning.** A stack is last-in, first-out. The most recent unclosed opening bracket must match the next closing one.

```python
def balanced(text):
    match = {")": "(", "]": "[", "}": "{"}
    stack = []
    for char in text:
        if char in "([{":
            stack.append(char)
        elif char in match and (not stack or stack.pop() != match[char]):
            return False
    return not stack

assert balanced("x([])")
assert not balanced("([)]")
```

**Complexity.** O(n) time and O(n) space. **Common mistake.** Counting brackets misses bad nesting, e.g. ([)].

**Practice ladder.** Valid Parentheses → Daily Temperatures → Largest Rectangle in Histogram.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C8 · Queues and BFS

**Problem.** Find minimum unweighted hops from a document to a linked document.

**Hint and reasoning.** A queue is first-in, first-out. BFS processes distance d before distance d+1. Mark a vertex when enqueuing so it enters once.

```python
from collections import deque

def hops(graph, start, end):
    queue = deque([(start, 0)])
    seen = {start}
    while queue:
        node, d = queue.popleft()
        if node == end:
            return d
        for child in graph.get(node, []):
            if child not in seen:
                seen.add(child)
                queue.append((child, d+1))
    return None

assert hops({"a":["b","c"],"b":["c"]}, "a","c") == 1
```

**Complexity.** O(V+E) time for adjacency lists, O(V) extra space. **Common mistake.** Using list.pop(0) shifts the list. BFS hop count ignores edge weights.

**Practice ladder.** Flood Fill → Rotting Oranges → Word Ladder.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C9 · Binary search

**Problem.** Find the first latency greater than or equal to a threshold in sorted data.

**Hint and reasoning.** Maintain [lo, hi) containing the insertion boundary. If mid is too small, discard it and the smaller half. Otherwise retain mid as a possible answer.

```python
def lower_bound(a, target):
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo+hi)//2
        if a[mid] < target:
            lo = mid+1
        else:
            hi = mid
    return lo

assert lower_bound([1,4,4,8], 4) == 1
assert lower_bound([], 3) == 0
```

**Complexity.** O(log n) time, O(1) extra space. **Common mistake.** Returning mid after the loop fails on empty input and duplicates.

**Practice ladder.** Binary Search → Find First and Last Position → Median of Two Sorted Arrays.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C10 · Sorting and greedy choice

**Problem.** Select the most nonoverlapping meetings when touching endpoints are allowed.

**Hint and reasoning.** Sort by earliest finish time. An optimal schedule's first meeting can be exchanged for the earliest-finishing one without ruling out its remaining meetings. Continue on the remaining interval.

```python
def schedule(intervals):
    chosen = []
    for start, end in sorted(intervals, key=lambda p: p[1]):
        if not chosen or start >= chosen[-1][1]:
            chosen.append((start, end))
    return chosen

assert len(schedule([(0,9),(0,2),(2,5)])) == 2
```

**Complexity.** O(n log n) time and O(n) space for sorted copy. **Common mistake.** Choosing shortest duration can block two other meetings. Validate start < finish.

**Practice ladder.** Assign Cookies → Non-overlapping Intervals → Course Schedule III.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C11 · Trees and recursion

**Problem.** Find the maximum depth of a binary tree.

**Hint and reasoning.** A tree has a root and children. A recursive call solves the same question on a smaller subtree. Empty depth is zero; otherwise add one to the deeper child. A frame stores each unfinished call.

```python
def depth(node):
    if node is None:
        return 0
    value, left, right = node
    return 1 + max(depth(left), depth(right))

assert depth((8, (2, None, None), None)) == 2
```

**Complexity.** O(n) time, O(h) stack space for height h. **Common mistake.** A chain may exceed Python's recursion limit. Use an explicit stack for deep trees.

**Practice ladder.** Maximum Depth of Binary Tree → Diameter of Binary Tree (easy extension) → Binary Tree Maximum Path Sum.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C12 · Binary search trees

**Problem.** Look up a key using the ordering property of a BST.

**Hint and reasoning.** Every key in the left subtree is smaller than its root, and every right key larger under our unique-key contract. Discard an entire subtree each step.

```python
def contains(node, target):
    while node:
        key, left, right = node
        if key == target:
            return True
        node = left if target < key else right
    return False

assert contains((4,(2,None,None),(7,None,None)), 7)
```

**Complexity.** O(h) time, O(1) working space; h can reach n. **Common mistake.** Validating only the immediate children misses deeper violations. Carry ancestor bounds when validating.

**Practice ladder.** Search in a Binary Search Tree → Validate Binary Search Tree → Serialize and Deserialize Binary Tree.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C13 · Heaps

**Problem.** Keep the k highest retrieval scores from a stream.

**Hint and reasoning.** A min-heap puts the smallest retained value at index zero. At size k replace that value only when a better candidate arrives. The heap is partially ordered.

```python
import heapq

def top_k(scores, k):
    if k <= 0:
        return []
    heap = []
    for score in scores:
        if len(heap) < k:
            heapq.heappush(heap, score)
        elif score > heap[0]:
            heapq.heapreplace(heap, score)
    return sorted(heap, reverse=True)

assert top_k([1,8,4,9], 2) == [9,8]
```

**Complexity.** O(n log(k+1)) processing, O(k) memory; final sort O(k log k). **Common mistake.** Popping the maximum from a min-heap discards the wrong candidate.

**Practice ladder.** Last Stone Weight → Kth Largest Element in an Array → Merge k Sorted Lists.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C14 · Graphs and DFS

**Problem.** Find all pages reachable from a starting page.

**Hint and reasoning.** A graph can contain cycles and disconnected components. Depth-first search explores the newest unfinished branch first. Track seen vertices to terminate on cycles.

```python
def reachable(graph, start):
    seen, stack = {start}, [start]
    while stack:
        for node in graph.get(stack.pop(), ()):
            if node not in seen:
                seen.add(node)
                stack.append(node)
    return seen

assert reachable({1:[2],2:[1],3:[]}, 1) == {1,2}
```

**Complexity.** O(V+E) time, O(V) extra space when marking on push. **Common mistake.** One traversal from a vertex cannot visit disconnected components.

**Practice ladder.** Find if Path Exists in Graph → Number of Islands → Critical Connections in a Network.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C15 · Dynamic programming

**Problem.** Find the least number of coins needed for an exact total.

**Hint and reasoning.** Define best[x] as the minimum number of coins for x. The last coin c leaves x−c, an already solved amount. Initialize zero and record unreachable states. Greedy fails for [1,3,4] and target 6.

```python
def coins_needed(coins, amount):
    best = [0] + [amount + 1] * amount
    for x in range(1, amount + 1):
        for coin in coins:
            if coin <= x:
                best[x] = min(best[x], 1+best[x-coin])
    return best[-1] if best[-1] <= amount else None

assert coins_needed([1,3,4], 6) == 2
assert coins_needed([2], 3) is None
```

**Complexity.** O(amount × number of denominations) time, O(amount) space. **Common mistake.** Treating unreachable totals as zero creates impossible solutions. Assume positive integer coins.

**Practice ladder.** Climbing Stairs → Coin Change → Edit Distance (advanced recurrence).

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## C16 · Backtracking

**Problem.** Enumerate subsets of distinct feature flags.

**Hint and reasoning.** At each level exclude or include one flag. Undo the mutation when returning so neighboring branches start with the same state. Copy the path when saving an answer.

```python
def subsets(items):
    answers, path = [], []
    def visit(i):
        if i == len(items):
            answers.append(path.copy())
            return
        visit(i+1)
        path.append(items[i])
        visit(i+1)
        path.pop()
    visit(0)
    return answers

assert len(subsets(["a","b","c"])) == 8
```

**Complexity.** O(n × 2ⁿ) time and output storage, O(n) auxiliary stack/path. **Common mistake.** Appending the same mutable path object corrupts previous answers.

**Practice ladder.** Binary Tree Paths → Subsets → N-Queens.

**Exit check.** Trace the sample, add an edge case of your choice and explain the step that lets the algorithm discard work.

## Module exit and revision

In two timed interviews solve an unfamiliar easy and medium variant, talk through the invariant, reproduce a failing edge case and justify time and memory. Focus review on the first step where you needed a hint. Practice sources: [MIT 6.006](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/) · [LeetCode problem library](https://leetcode.com/problemset/).

