# P2 · Build an approval-based AI workflow

## The problem and the shipping criteria

A support request may need a ticket. A language model drafts a proposal; a reviewer can edit, approve or reject it. A fake ticket service makes business effects observable without contacting real people.

**Functional requirements.** Submit a request, look up a public policy, propose a ticket, inspect exact arguments, approve/reject, execute once, display a timeline and replay a failed run. Include a dry-run mode. Reject instructions in documents that request additional permissions.

**Nonfunctional targets.** Target a single ledger entry for each approved operation in the synthetic provider. A denied request must have zero effects. Test two concurrent approvals, restart during review and a timeout with unknown outcome. Cap a run at a chosen number of calls, wall time and tokens.

## Architecture and contracts

![P2 · Build an approval-based AI workflow architecture](assets/p2.svg)

FastAPI for run and approval APIs, LangGraph for explicit states and a PostgreSQL checkpointer for restart, adapter for the model, fake ticket provider with unique external operation ID. Reuse P1 membership and document lookup; keep the tool permission separate.

**Data design.** run(id,tenant,state,version), proposal(id,run_id,args_hash,expires_at), approval(id,proposal_id,actor,decision), operation(id,run_id,key,state,provider_ref), event(id,run_id,sequence,type). Unique (run_id,sequence) and operation key. Write review decision and authorized next state in one transaction.

**API contract.** POST /v1/runs → 202; GET /v1/runs/{id} → state and permitted actions; POST /v1/runs/{id}/decisions accepts proposal hash, expected version and decision; GET /v1/runs/{id}/events?after=sequence. Conflict returns 409 if another reviewer changed the version.

**Repository layout.** api/runs · graph/nodes · tools/ticket · policies · storage · migrations · evals/scenarios · tests/replay · ui/review

## Development and release

1. W14: implement deterministic graph and fake tool.

2. W15: add model proposals, allowlist, authenticated review and durable checkpoints.

3. W16: inject crashes, duplicate notifications and revoked permission.

4. W18: deploy with P3 and show a three-minute replay.

**Tests and security.** Use a fake model for deterministic tests; separately evaluate a real model on ambiguous requests. Verify expired approvals, cross-tenant review, stale proposals and duplicate submissions. Simulate timeout after provider commit and reconcile by external key.

**Deployment and monitoring.** Deploy API and worker separately with a restricted worker identity. Export counts by state, age awaiting review, policy denials, duplicate effects and cost per successful run. Keep private request content outside telemetry. Recover stuck runs with bounded retries then manual review.

## Turn the build into evidence

Organize the README as problem → quick start → architecture → sample request → failure demonstration → reproducible results → limitations → next decision. Include a clean-clone command, pinned versions, synthetic fixture, screenshot and one way to verify the result. Show the first failure before the fix. Explain your role and name any borrowed component.

**Résumé bullet after verification.** “Implemented approval-gated ticket automation with persistent workflow state; demonstrated [n] replay scenarios with [actual duplicate-effect count] duplicate effects in a synthetic provider.”

**Interview rehearsal.** Who owns the tool credential? Can an old approval authorize edited arguments? How do you handle a provider without idempotency keys? Show the chart of completed, denied and unresolved runs.

**Exit check.** A peer can follow the README on a clean machine, observe one success and one intentional failure, and find the data behind your résumé sentence.

