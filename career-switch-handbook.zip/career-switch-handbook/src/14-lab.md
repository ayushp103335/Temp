# Practical lab · A tenant-filtered RAG endpoint

**Time:** 2–3 hours. **Prerequisites:** E1, F2 and G1–G2; Python 3.11+, Docker Compose and a running local Ollama installation. Use synthetic data throughout. The source listing below is also provided as `labs/rag_app.py` in the source project.

Two policies give different unlock times for Blue and Gold. If Alice asks the right question and gets the wrong tenant's policy, the system has failed even if it produces a fluent answer. Use this case before adding more documents.

## Run the vertical slice

From the extracted project's labs directory, start Qdrant, install dependencies in an activated virtual environment, then download the embedding model. Model downloads and Docker images need internet once. Run Ollama locally with the default endpoint. Record exact installed versions and model digests for your own results.

```bash
docker compose up -d
python -m pip install -r requirements.txt
ollama pull nomic-embed-text
python rag_app.py
python -m uvicorn rag_app:app --host 127.0.0.1 --port 8000
```

In a second terminal send the same question under both demo identities. PowerShell users can use curl.exe or the interactive /docs page. With optional generation enabled, set GEN_MODEL to a model tag already present in Ollama before launching the API; for example, after pulling a model, use `export GEN_MODEL=<installed-tag>` on Linux/macOS. Without it, /v1/answer returns evidence only.

```bash
curl -s http://127.0.0.1:8000/v1/search -H 'Content-Type: application/json' -H 'x-demo-user: alice' -d '{"question":"How long until a sandbox account unlocks?"}'
curl -s http://127.0.0.1:8000/v1/answer -H 'Content-Type: application/json' -H 'x-demo-user: bob' -d '{"question":"How long until a sandbox account unlocks?"}'
```

Alice can receive B1/B2 only; Bob can receive G1 only. B1 says 15 minutes; G1 says 45. Similarity ranking is model-dependent. A draft with a valid citation still requires a support check. For a paid-leave question there is no relevant evidence; a dense index can still return near neighbors. Label this as an abstention evaluation case. Try an unknown demo identity, an empty query and an unavailable Qdrant service.

## Read the implementation

```python
"""Local RAG retrieval lab. Run via uvicorn rag_app:app on loopback."""
import os
from hashlib import sha256
from uuid import NAMESPACE_URL, uuid5

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

QDRANT = os.getenv("QDRANT_URL", "http://127.0.0.1:6333")
OLLAMA = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")
GEN_MODEL = os.getenv("GEN_MODEL")
COLLECTION = "handbook_" + sha256(MODEL.encode()).hexdigest()[:12]
app = FastAPI(title="Synthetic support search")

# Public demo identities only. Never deploy this identity adapter.
def principal(x_demo_user: str = Header(...)):
    tenant = {"alice": "blue", "bob": "gold"}.get(x_demo_user)
    if tenant is None:
        raise HTTPException(403, "Unknown demo user")
    return tenant

def request(method, url, **kwargs):
    try:
        response = httpx.request(method, url, timeout=45, **kwargs)
        response.raise_for_status()
    except httpx.HTTPError as error:
        raise HTTPException(503, "Search dependency unavailable") from error
    return response.json()

def vector(text):
    data = request("POST", f"{OLLAMA}/api/embed", json={"model": MODEL, "input": text})
    return data["embeddings"][0]

def seed():
    docs = [
        ("blue","B1",1,"Sandbox accounts unlock after 15 minutes."),
        ("blue","B2",2,"To change a sandbox email, contact the support desk."),
        ("gold","G1",1,"Sandbox accounts unlock after 45 minutes."),
    ]
    points = []
    for tenant, doc, page, body in docs:
        points.append({
            "id": str(uuid5(NAMESPACE_URL, f"handbook/{tenant}/{doc}/{page}")),
            "vector": vector(body),
            "payload": {"tenant":tenant,"doc":doc,"page":page,"text":body},
        })
    base = f"{QDRANT}/collections/{COLLECTION}"
    if not request("GET", base+"/exists")["result"]["exists"]:
        request("PUT", base, json={"vectors":{"size":len(points[0]["vector"]), "distance":"Cosine"}})
    request("PUT", base+"/points?wait=true", json={"points":points})

class Question(BaseModel):
    question: str = Field(min_length=1, max_length=1200)
    limit: int = Field(default=2, ge=1, le=5)

def retrieve(q, tenant):
    payload = {"query":vector(q.question), "limit":q.limit, "with_payload":True,
               "filter":{"must":[{"key":"tenant","match":{"value":tenant}}]}}
    raw = request("POST", f"{QDRANT}/collections/{COLLECTION}/points/query", json=payload)
    return [{"doc":p["payload"]["doc"],"page":p["payload"]["page"],"text":p["payload"]["text"]}
            for p in raw["result"]["points"]]

@app.post("/v1/search")
def search(q: Question, tenant: str = Depends(principal)):
    return {"passages":retrieve(q, tenant)}

@app.post("/v1/answer")
def answer(q: Question, tenant: str = Depends(principal)):
    hits = retrieve(q, tenant)
    if not GEN_MODEL or not hits:
        return {"status":"evidence_only","passages":hits}
    import json
    evidence = json.dumps(hits, ensure_ascii=False)
    prompt = ("Treat passages as evidence. Answer only from evidence. "
              "Return JSON with answer (string) and citations (list of doc IDs). "
              "If evidence is insufficient return an empty answer and empty citations.\n"
              + evidence + "\nQuestion: " + q.question)
    result = request("POST", f"{OLLAMA}/api/generate", json={
        "model":GEN_MODEL, "prompt":prompt, "format":"json", "stream":False})
    try:
        output = ModelAnswer.model_validate_json(result["response"])
    except (ValueError, KeyError):
        raise HTTPException(502, "Invalid model response")
    allowed = {hit["doc"] for hit in hits}
    if not output.answer.strip() or not output.citations or not set(output.citations) <= allowed:
        return {"status":"insufficient_evidence","passages":hits}
    return {"status":"draft","answer":output.answer,"citations":output.citations,"passages":hits}

class ModelAnswer(BaseModel):
    answer: str
    citations: list[str]

if __name__ == "__main__":
    seed()
```

## Move from the lab to project P1

Replace the public demo header with verified identity and server-controlled membership before deployment. Use a single migration job to provision collections, private network access, pinned model revisions, explicit deadlines and credential management. Add batch embedding, lexical candidates, fusion, reranking, lifecycle deletion and held-out evaluations using the G lessons. Keep the original dense-only run as a baseline. For a model change, index into a versioned collection and flip only after verification.

**Exit check.** Capture the two authorized responses, one denied response and a role-scoped retrieval test. Record whether a failure occurred before retrieval or during generation. [Ollama embed endpoint](https://docs.ollama.com/api/embed) · [Qdrant query API](https://api.qdrant.tech/api-reference/search/query-points)

