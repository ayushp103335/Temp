# The 24-week plan

**Three workloads.** Minimum: 45 minutes on workdays (20 build, 10 recall/DSA, 15 English), plus 90 minutes Saturday and 45 minutes Sunday; about 6 hours/week. On this track extend calendar dates or defer stretch exercises. Recommended: 75–90 minutes on workdays, 2–3 hours Saturday and 1 hour Sunday; about 9¼–11½ hours. Keep applications inside those blocks. Weekend catch-up: recover one unfinished milestone in two 45-minute blocks, use 30 minutes for tests and 20 minutes for review; drop the optional hard problem first. Keep one evening light during interview weeks.

**Daily rhythm.** Each weekday has a concrete task below. Pair it with a 15-minute English drill and alternate DSA recall with application work. Saturday carries the longer coding task and an interview rehearsal. Sunday compare your work with the exit test, submit the remainder of the weekly applications, contact 1 person in week 1, 2/week in weeks 2–8, then 3/week. Do not count a duplicate or an ineligible remote listing. Targets are coaching goals, adjustable for live interviews.

**How to choose chapters.** A–K and C pattern numbers match the module and lesson headings. P1, P2 and P3 refer to the three portfolio specifications. Use the daily plan in Read first for the full first week. Weeks 8, 16 and 24 are decision points. Learning time in each lesson is a first-pass estimate; scheduled project work supplies the repetition.

## Week 1 · Find your starting point

**Read** A1–A3 / Choose your role. **Application target** 2 qualified applications.

| Day | Task |
|---|---|
| Monday | verify dates and trace count_titles |
| Tuesday | write the title counter |
| Wednesday | explain browser-to-API flow |
| Thursday | score two JDs |
| Friday | submit application and seed two docs |
| Saturday | C1, C2; test duplicate IDs |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Two applications, one recording, a passing test and one gap.

## Week 2 · Write reliable Python

**Read** B1–B2 / K1. **Application target** 3 qualified applications.

| Day | Task |
|---|---|
| Monday | validate a Document |
| Tuesday | read UTF-8 JSON lines |
| Wednesday | add pytest failure cases |
| Thursday | write a tiny CLI |
| Friday | tailor one project bullet |
| Saturday | C2, C3; pairs with duplicates |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Clean run on valid input and a line-numbered error for bad input.

## Week 3 · Measure I/O

**Read** B3 / G1. **Application target** 3 qualified applications.

| Day | Task |
|---|---|
| Monday | time serial reads |
| Tuesday | bound async tasks |
| Wednesday | simulate a timeout |
| Thursday | explain cancellation aloud |
| Friday | write a parser contract |
| Saturday | C4 and C5; trace abba |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Importer closes files and records a testable timeout.

## Week 4 · Prepare a labeled corpus

**Read** G1 / C6–C7. **Application target** 3 qualified applications.

| Day | Task |
|---|---|
| Monday | collect synthetic TXT/PDF fixtures |
| Tuesday | extract text by page |
| Wednesday | mark scanned-page fallback |
| Thursday | label five answerable queries |
| Friday | compare a weak and strong résumé bullet |
| Saturday | C6, C7; reverse a chain |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Two formats parsed, stable page IDs and five hand-checked labels.

## Week 5 · Model the data

**Read** D1 / P1. **Application target** 4 qualified applications.

| Day | Task |
|---|---|
| Monday | draw tenant and document keys |
| Tuesday | write JOIN and GROUP BY |
| Wednesday | resolve window ties |
| Thursday | design unique revision key |
| Friday | rehearse SQL join explanation |
| Saturday | C8; shortest hops |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** A second tenant with zero docs still appears with count zero.

## Week 6 · Protect concurrent writes

**Read** D2–D3 / P1. **Application target** 4 qualified applications.

| Day | Task |
|---|---|
| Monday | read EXPLAIN output |
| Tuesday | add a composite index |
| Wednesday | race two job claims |
| Thursday | test cache expiry |
| Friday | describe one consistency trade-off |
| Saturday | C9; lower-bound duplicates |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** One winning job claim and an index plan explained from measurements.

## Week 7 · Build a tested API

**Read** E1–E2 / P1. **Application target** 4 qualified applications.

| Day | Task |
|---|---|
| Monday | make request/response models |
| Tuesday | write API contract tests |
| Wednesday | add principal dependency |
| Thursday | scope document lookups |
| Friday | record an API walkthrough |
| Saturday | C10; sort intervals |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Anonymous, allowed and wrong-tenant cases give expected results.

## Week 8 · Ship an ingestion slice

**Read** E3 / I1 / P1. **Application target** 4 qualified applications.

| Day | Task |
|---|---|
| Monday | accept a bounded file |
| Tuesday | persist status and request key |
| Wednesday | restart a worker |
| Thursday | fix the first feedback gap |
| Friday | send first revised résumé |
| Saturday | C11; tree depth |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Second upload returns same job; authorized peer can run the demo.

## Week 9 · Understand model behavior

**Read** F1–F2 / P1. **Application target** 5 qualified applications.

| Day | Task |
|---|---|
| Monday | trace one token prediction |
| Tuesday | compute a token budget |
| Wednesday | validate structured output |
| Thursday | write abstention rules |
| Friday | record a model failure |
| Saturday | C12; BST lookup |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** A syntactically valid but unsupported answer is identified.

## Week 10 · Measure dense retrieval

**Read** G2 / Practical lab. **Application target** 5 qualified applications.

| Day | Task |
|---|---|
| Monday | start Qdrant and Ollama |
| Tuesday | seed both tenants |
| Wednesday | trace a query vector |
| Thursday | measure correct page in top five |
| Friday | give a two-minute P1 pitch |
| Saturday | C13; top-k heap |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Two tenant-separated responses and saved dense baseline.

## Week 11 · Compare lexical and hybrid search

**Read** G2–G3 / P1. **Application target** 5 qualified applications.

| Day | Task |
|---|---|
| Monday | add identifier-heavy queries |
| Tuesday | implement lexical ranking |
| Wednesday | fuse lists and rerank |
| Thursday | compare one changed parameter |
| Friday | rehearse recall vs hit rate |
| Saturday | C14; graph cycles |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Per-query rank changes on an unchanged evaluation set.

## Week 12 · Measure answer quality

**Read** F3 / G3 / P1. **Application target** 5 qualified applications.

| Day | Task |
|---|---|
| Monday | label no-answer queries |
| Tuesday | check citation entitlement |
| Wednesday | measure generation timings |
| Thursday | record cost per success |
| Friday | tailor résumé to an applied-AI JD |
| Saturday | C15; coin change |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Fixed holdout with per-slice quality, latency and cost.

## Week 13 · Publish project one

**Read** K1 / P1 / Branding. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | test delete and re-index |
| Tuesday | clean up quick start |
| Wednesday | record the three-minute demo |
| Thursday | invite a peer to run it |
| Friday | add verified metrics to résumé |
| Saturday | C16; backtracking |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** A peer can reproduce one success and one failure.

## Week 14 · Design a controlled workflow

**Read** H1 / P2. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | define ticket tool schema |
| Tuesday | write a fake ticket provider |
| Wednesday | build fixed graph states |
| Thursday | add a dry run |
| Friday | explain workflow vs agent |
| Saturday | C7 and C8 from memory |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Unknown or unauthorized tools produce no ledger entries.

## Week 15 · Persist approval

**Read** H2 / D2 / P2. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | add checkpoints |
| Tuesday | bind approval to argument hash |
| Wednesday | persist actor and expiry |
| Thursday | race duplicate approvals |
| Friday | practice a recruiter screen |
| Saturday | C2, C9 unseen variants |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Restart restores review state and stale approval fails.

## Week 16 · Test failure and apply broadly

**Read** H2 / I2 / P2. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | inject timeout after provider commit |
| Tuesday | reconcile by external key |
| Wednesday | run denial/replay cases |
| Thursday | record a failure narrative |
| Friday | review four-month interview funnel |
| Saturday | C13, C15 timed |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** One external effect after retry; decide primary vs backup application mix.

## Week 17 · Build the runtime

**Read** J1 / P3. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | write Dockerfile |
| Tuesday | create Compose services |
| Wednesday | add named volumes |
| Thursday | inspect container DNS |
| Friday | rehearse a dependency outage |
| Saturday | C4, C6 timed |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Clean startup and durable records after app restart.

## Week 18 · Release through CI

**Read** J2 / K1 / P2–P3. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | add CI unit tests |
| Tuesday | run DB integration suite |
| Wednesday | publish immutable image |
| Thursday | deploy a staged workflow |
| Friday | share verified workflow demo on résumé |
| Saturday | C10, C11 timed |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** CI prevents broken release; reviewer can replay a run.

## Week 19 · Provision a staging environment

**Read** J2–J3 / P3. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | draw AWS boundaries |
| Tuesday | review Terraform plan |
| Wednesday | deploy scoped service identity |
| Thursday | trace a real request |
| Friday | practice system design capacity |
| Saturday | C5, C14 unseen |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Stage runs behind access controls; record cost and teardown steps.

## Week 20 · Prove recovery

**Read** J3 / K2 / P3. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | run fixed-load baseline |
| Tuesday | inject slowdown |
| Wednesday | roll back image |
| Thursday | restore DB in isolation |
| Friday | write one incident story |
| Saturday | C8, C16 unseen |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Measured load, rollback and a successful restored query.

## Week 21 · Close interview gaps

**Read** Interview studio / C1–C16. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | diagnose weakest pattern |
| Tuesday | repeat SQL live query |
| Wednesday | mock an API design |
| Thursday | revise one project claim |
| Friday | record behavioral mock |
| Saturday | One unseen easy + medium |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Score ≥3/4 on two independent mock dimensions.

## Week 22 · Target international roles

**Read** Remote / Job search. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | screen location rules |
| Tuesday | write asynchronous design note |
| Wednesday | calculate overlap in IST |
| Thursday | compare two contract models |
| Friday | send targeted remote applications |
| Saturday | Timed graph + heap |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Two confirmed India-eligible leads and one written walkthrough.

## Week 23 · Practice negotiation

**Read** Compensation / Interview studio. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | normalize two offers |
| Tuesday | compute fixed-pay floor privately |
| Wednesday | mock a low-offer call |
| Thursday | ask about mentorship/on-call |
| Friday | rehearse one company-specific answer |
| Saturday | Timely re-solve of two misses |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** A written decision with pay basis, scope and one unresolved question.

## Week 24 · Make a decision or revise the next cycle

**Read** Tracking / Strategy. **Application target** 6 qualified applications.

| Day | Task |
|---|---|
| Monday | audit active applications |
| Tuesday | repeat weakest mock |
| Wednesday | review references and truthful dates |
| Thursday | evaluate evidence and priorities |
| Friday | follow up on warm leads |
| Saturday | One 45-minute mixed mock |
| Sunday | Compare your result with the exit test, record feedback and plan one correction. |

**Deliverable and assessment.** Written offer decision or a four-week plan tied to measured funnel gaps.

