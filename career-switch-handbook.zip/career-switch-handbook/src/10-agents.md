# H · Agent workflows with controlled tools

Use a synthetic support request that could open an internal ticket. The main engineering question is who decides the next step and who is allowed to cause a business change.

## H1 · Decide where the model may make a choice

Beginner · 2 hours · Requires F2 and E2.

**Objective.** Distinguish one model call, a workflow and an agent; define a safe tool contract.

A normal LLM application answers one prompt. In a workflow, application code fixes the steps, such as classify → retrieve policy → draft. An agent can choose among allowed next steps using intermediate observations. Use a fixed workflow when the business process is already known. Add bounded choice when required inputs or lookup paths vary.

Tool calling supplies schemas for allowed operations; the application validates arguments and permissions every time. MCP defines a client/server protocol for discovering and using tools, resources and prompts. Connecting a server does not grant its tools authority. Session state is the current run; longer-lived memory needs purpose, ownership, deletion and retrieval rules. Multi-agent systems divide work among roles and add handoff, latency and evaluation costs.

```python
from typing import Literal
from pydantic import BaseModel, Field

class Proposal(BaseModel):
    action: Literal["draft_ticket", "lookup_policy"]
    topic: str = Field(min_length=1, max_length=100)

def route(proposal: Proposal):
    return "approval" if proposal.action == "draft_ticket" else "lookup"
```

**Common failure and working practice.** Documents and tool results can contain untrusted instructions. Keep them as data, derive tenant and permissions on the server and enforce an allowlist. A model's explanation is never permission.

**Exercise.** Draw three ways to answer “create a ticket for my issue.” Mark which action has a lasting effect and who can approve it.

**Build and check.** Implement two read-only tools and one proposal tool with validation. Reject an unknown operation, a missing permission and an over-budget run.

**Interview rehearsal.** When would you split into multiple agents? Only when you can name independent responsibilities and demonstrate improvement over a simpler workflow under the same evaluation budget.

## H2 · Pause, resume and recover without repeating a write

Intermediate · 3 hours · Requires H1 and D2.

**Objective.** Persist a run, bind approval to an exact action and design for replay.

A LangGraph state graph connects nodes that read and update typed state. A checkpointer saves progress per thread. An interrupt pauses a node and exposes a review payload. Resume using the same thread ID and an authenticated decision. The interrupted node can restart from the beginning; keep external effects after approval in a separate idempotent step.

Store run ID, tenant ID, plan version, tool arguments hash, approval subject, expiry and attempt count. Approvals bind to the exact action version and cannot transfer between users. Use exponential backoff with jitter for transient failures, a finite retry budget and a terminal needs_review state. If an external write times out, reconcile using its idempotency key before replaying.

```python
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt, Command
from langgraph.checkpoint.memory import InMemorySaver

class State(TypedDict):
    draft: str
    approved: bool

def review(state):
    decision = interrupt({"review": state["draft"]})
    return {"approved": decision is True}

builder = StateGraph(State)
builder.add_node("review", review)
builder.add_edge(START, "review")
builder.add_edge("review", END)
graph = builder.compile(checkpointer=InMemorySaver())
cfg = {"configurable": {"thread_id": "synthetic-demo"}}
graph.invoke({"draft":"Ticket for review", "approved":False}, cfg)
assert graph.invoke(Command(resume=True), cfg)["approved"]
```

**Common failure and working practice.** The in-memory checkpointer is for this local demo. For restart recovery use durable storage, authenticated approval handlers, row locks or state versions, and a provider-supported idempotency key.

**Exercise.** Interrupt a draft, reject it once and approve a fresh run. In P2 inject a crash before and after the external tool response. Count real effects.

**Build and check.** Build a run timeline with attempted, denied, approved and reconciled events. Evaluate task completion, unauthorized-effect count, duplicate effects, tool calls and cost per success.

**Interview rehearsal.** What if the provider accepts a ticket but the worker crashes? A local checkpoint cannot prove whether the external write happened. Reconcile by a stable operation ID, or hold for review if the provider cannot tell.

## Module exit and revision

Demonstrate rejection, restart, bounded retry and replay of the same approval. Show a single effect in the fake ticket ledger. Explain how this changes for a tool with no idempotency support.

**Further reading** · [LangGraph interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts) · [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence) · [Model Context Protocol](https://modelcontextprotocol.io/docs/learn/architecture)

