# First-week workbench · From a blank folder to a tested change

Use this if “make a commit” or “add a test” feels too abstract. The first deliverable is a tiny support-document importer you can show and explain. Everything here uses invented titles.

## Day 1 · Prepare the environment

Install Python 3.11 or later and Git from their official distributions if needed. In a terminal run `python --version` (Windows can use `py -3 --version`) and `git --version`. On Windows, if `python` selects an unexpected interpreter, use `py -3 -m venv .venv` and the interpreter inside the virtual environment. On Linux, use `python3` if necessary.

```bash
mkdir support-index-practice
cd support-index-practice
git init
python -m venv .venv
```

On Linux/macOS run `source .venv/bin/activate`. In Windows PowerShell you can run `.\.venv\Scripts\python.exe -m pip install pytest` and use that full interpreter path for subsequent Python commands without activating. In an activated shell run `python -m pip install pytest`. Make a file named .gitignore with .venv/, __pycache__/ and .pytest_cache/ on separate lines.

## Days 2–3 · Specify a behavior

Create importer.py. Before executing the function, write down the expected output for a blank title and a repeated title.

```python
def count_titles(rows):
    counts = {}
    for row in rows:
        title = row.strip().casefold()
        if title:
            counts[title] = counts.get(title, 0) + 1
    return counts
```

Create test_importer.py next to it.

```python
from importer import count_titles

def test_normalizes_and_counts():
    assert count_titles([" Setup ", "SETUP", "", "Policy"]) == {"setup": 2, "policy": 1}

def test_handles_empty_input():
    assert count_titles([]) == {}

def test_skips_whitespace():
    assert count_titles(["  ", "\t"]) == {}
```

Run `python -m pytest -q`. Remove .casefold() temporarily and predict which assertion fails. Run it, inspect the mismatch, restore the normalization and run again. This shows that the test can detect the behavior you care about.

## Days 4–5 · Connect the change to a job description

Take one role you could apply for. If it asks for Python and testing, you now have a small example to discuss. It is still too small to headline a portfolio. Explain it in two sentences: “I normalized equivalent titles before counting them. I used a failing test to show that case handling mattered.” Add one row to your evidence tracker and complete the first application from the roadmap.

## Days 6–7 · Save your work and explain its limits

```bash
git status
git add .gitignore importer.py test_importer.py
git diff --staged
git commit -m "Count normalized document titles with boundary tests"
git switch -c preserve-original-title
```

Configure your Git author name and email locally if Git requests them. Add a feature that returns the first original spelling alongside each count. Write the expected output first, make the smallest change, run the suite, inspect the diff, and commit. A branch is a name pointing to a line of development. A commit is a saved snapshot with a message. A pull request on GitHub proposes merging one branch into another and gives a reviewer the diff. Practice on your personal synthetic project.

**Ready for week 2?** From a fresh shell, rerun all three tests, explain the failure you introduced and name an unsupported input. If you needed the solution, repeat with document categories instead of titles. Save one English recording and the second application record. [Python downloads](https://www.python.org/downloads/) · [Git installation](https://git-scm.com/downloads) · [pytest getting started](https://docs.pytest.org/en/stable/getting-started.html)

