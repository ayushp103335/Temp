# P3 · Operate a production-style AI application

## The problem and the shipping criteria

A teammate must deploy a known version of the search API, measure it under load and recover after a failed release. Give them a reproducible staging environment and a tested runbook.

**Functional requirements.** Take a commit through CI, build a container image, deploy staging, run a smoke test, inspect a trace, roll back, and restore PostgreSQL into a separate instance. Expose readiness and a deployment version. Use a cheap deterministic model stub for load tests and label it.

**Nonfunctional targets.** Set an illustrative staging goal, e.g. p95 below 500 ms at 5 requests/s for a stubbed endpoint and zero unexpected 5xx for ten minutes. Define restore targets before the drill. Count throughput, failures and queue age. Measure real-provider latency separately.

## Architecture and contracts

![P3 · Operate a production-style AI application architecture](assets/p3.svg)

FastAPI, PostgreSQL, Redis cache, Docker, GitHub Actions, AWS EC2/S3/RDS as budget permits, Terraform, Prometheus/Grafana and OpenTelemetry. Reuse P1/P2 images. Keep provisioning separate from release. A local drill is a milestone; label the cloud deployment only after it ran.

**Data design.** Reuse P1's schema. Add deployment metadata (version, migration version, released_at) and job state if the worker is present. Redis keys include authorized scope and data version. S3 backups and objects have explicit retention. Keep Terraform state encrypted with restricted access.

**API contract.** GET /health/live checks process; GET /health/ready checks essential serving dependencies with a deadline; GET /version returns safe release metadata; POST /v1/search serves the test workload. Metrics endpoint is restricted to the monitoring network.

**Repository layout.** app · infra/terraform · deploy/compose · .github/workflows · monitoring · tests/smoke · load · runbooks · migrations

## Development and release

1. W17: package and run locally.

2. W18: add CI with integration and smoke tests.

3. W19: provision staging with a budget cap/alert and deploy by image digest.

4. W20: measure, roll back and restore. Delete disposable cloud resources after collecting evidence.

**Tests and security.** Test missing configuration and credentials, Redis loss, one slow dependency, incompatible schema and rollback. Validate backup content and restored document counts. Keep database private; scope IAM, rotate secrets and redact logs. Protect deployment secrets from untrusted PRs.

**Deployment and monitoring.** Keep two known-good image digests and an explicit migration compatibility window. Monitor latency, errors, pool wait, CPU, memory, queue age, cache hit rate and estimated cost. A drill is complete only after restored data answers a known query.

## Turn the build into evidence

Organize the README as problem → quick start → architecture → sample request → failure demonstration → reproducible results → limitations → next decision. Include a clean-clone command, pinned versions, synthetic fixture, screenshot and one way to verify the result. Show the first failure before the fix. Explain your role and name any borrowed component.

**Résumé bullet after verification.** “Automated deployment of [service] with CI and Terraform; measured [p95] at [load/conditions] and restored [dataset] in [measured time] during a staging drill.”

**Interview rehearsal.** What failed first under load? Why might Redis lower reliability? Which part of the recovery meets RPO versus RTO? Show the rollback and the query proving restoration.

**Exit check.** A peer can follow the README on a clean machine, observe one success and one intentional failure, and find the data behind your résumé sentence.

