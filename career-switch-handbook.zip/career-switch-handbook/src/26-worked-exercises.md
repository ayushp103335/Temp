# Worked exercises · Three stretch problems and a database review

Use these exercises after the relevant easy and medium problems. For each, try a brute-force solution first. Identify the repeated work and write the invariant before reading the code.

## Minimum covering window · Hard · 45–60 minutes

**Problem.** Find the shortest substring of a log that contains every character of a required signature, including duplicates. For ADOBECODEBANC and ABC the result is BANC. A set loses duplicate requirements. Brute force considers all starts and ends. A sliding window can reuse the counts from the previous end.

**Hint.** Maintain a deficit per character and the total number of required character occurrences still missing. Expand right until the window covers the requirement. Then shrink left as far as possible. A negative deficit represents extra copies.

```python
from collections import Counter

def minimum_window(text, target):
    if not target:
        return ""
    need = Counter(target)
    missing = len(target)
    left = 0
    best = None
    for right, char in enumerate(text):
        if need[char] > 0:
            missing -= 1
        need[char] -= 1
        while missing == 0:
            if best is None or right + 1 - left < best[1] - best[0]:
                best = (left, right+1)
            first = text[left]
            need[first] += 1
            left += 1
            if need[first] > 0:
                missing += 1
    return "" if best is None else text[best[0]:best[1]]

assert minimum_window("ADOBECODEBANC","ABC") == "BANC"
assert minimum_window("BAAC","AA") == "AA"
assert minimum_window("A","AA") == ""
```

Each index enters and leaves once. Expected O(n+m) time, O(u) bookkeeping for unique characters in the input and target, plus the returned substring. Store the best indices and slice only once. **Check:** explain exactly when a character leaving the window makes it invalid.

## Merge sorted result streams · Hard extension · 45 minutes

**Problem.** Merge k ordered lists of timestamps while keeping only one pending item per nonempty stream. Assume timestamps are comparable. A full sort materializes all inputs. The minimum next item must be at the head of one stream.

```python
from heapq import heappop, heappush

def merged(streams):
    heads = []
    for stream_id, stream in enumerate(streams):
        iterator = iter(stream)
        first = next(iterator, None)
        if first is not None:
            heappush(heads, (first, stream_id, iterator))
    while heads:
        value, stream_id, iterator = heappop(heads)
        yield value
        following = next(iterator, None)
        if following is not None:
            heappush(heads, (following, stream_id, iterator))

assert list(merged([[1,4],[],[1,5],[2]])) == [1,1,2,4,5]
```

The stream ID breaks equal-timestamp ties so Python never needs to compare iterator objects. With numeric timestamps, None is available as an exhaustion sentinel. For N total items, time is O(k + N log(k+1)) and extra space O(k). **Check:** show that replacing the popped head cannot hide a lower value from that same sorted stream.

## Edit distance · Hard extension · 60 minutes

**Problem.** What is the minimum number of single-character insertions, deletions and replacements to turn one string into another? Define D[i,j] for the first i and j characters. When the last characters match, extend the diagonal at no cost. Otherwise take one plus the smallest cost after deleting, inserting or replacing.

```python
def distance(a, b):
    if len(b) > len(a):
        a, b = b, a
    previous = list(range(len(b)+1))
    for i, left in enumerate(a, 1):
        current = [i]
        for j, right in enumerate(b, 1):
            current.append(min(previous[j]+1, current[j-1]+1,
                               previous[j-1]+(left != right)))
        previous = current
    return previous[-1]

assert distance("kitten","sitting") == 3
assert distance("","abc") == 3
```

Time O(mn), working space O(min(m,n)). A full matrix is easier if you must reconstruct an edit sequence. **Check:** draw the first two rows by hand. Explain why a plain zero-filled first row silently treats insertions as free.

## Database and access review · 40 minutes

From D1's schema, find the latest document per tenant, retaining tenants with no documents. Start from tenant, use a lateral subquery to select one ordered row per tenant, then preserve the unmatched tenant with a left join.

```sql
SELECT t.name, latest.title
FROM tenant AS t
LEFT JOIN LATERAL (
    SELECT d.title
    FROM document AS d
    WHERE d.tenant_id=t.id
    ORDER BY d.created_at DESC, d.id DESC
    LIMIT 1
) AS latest ON true
ORDER BY t.id;
```

Blue initially returns Access and Gold returns NULL. For a tenant-facing endpoint add an authorized tenant predicate to the outer query; the administrative all-tenant dashboard is a separate permission. Compare its plan with the window query in D1 on realistic tenant counts. Test a tenant with a tie, one document, and none.

**Revision task.** For each exercise record the first incorrect assumption and the smallest input that disproves it. Revisit after one week and solve from a blank editor.

