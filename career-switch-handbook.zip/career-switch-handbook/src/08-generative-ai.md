# F · From tokens to a dependable AI feature

Take a support question such as “How do I reset my sandbox account?” A model can produce fluent instructions without knowing which policy your company uses. Build the mental model first, then build a service that checks the answer.

## F1 · Predict tokens and understand attention

Beginner · 2½ hours · Requires A1.

**Objective.** Explain training, inference, tokens, embeddings and attention with one worked example.

AI is the broad field. In machine learning a model learns parameters from examples. Deep learning composes many learned transformations. Generative models produce content. A neural network transforms arrays of numbers through weighted layers and nonlinear functions. Training adjusts weights to reduce a loss; inference uses the learned weights to produce outputs.

A tokenizer maps text to IDs, sometimes splitting a word into pieces. An embedding table turns each ID into a vector. A transformer layer forms a query, key and value for each position. Scaled dot products between a query and available keys determine softmax weights; the output is a weighted sum of values. Causal masking prevents looking ahead while predicting the next token. Position information lets order matter. The model turns the final representation into scores (logits) for possible next tokens.

```python
import math
scores = [2.0, 0.0]
weights = [math.exp(x-max(scores)) for x in scores]
weights = [x/sum(weights) for x in weights]
values = [10.0, 2.0]
context = sum(w*v for w,v in zip(weights, values))
assert 9.0 < context < 9.1
```

**Common failure and working practice.** A high attention weight measures a model computation; it is insufficient evidence for a factual citation. Use source passages when grounding matters.

**Exercise.** Calculate the context when the two scores are equal. Tokenize one English sentence and one identifier with your chosen model tokenizer; compare token counts and character counts.

**Build and check.** Build a token-budget table for instructions, question, evidence and reserved output. Check on a long query and explain what you would trim first.

**Interview rehearsal.** How is a retrieval embedding different from a token ID? The ID indexes a vocabulary entry. A retrieval model encodes a passage or query into a vector trained for comparison.

## F2 · Constrain generation and measure quality

Intermediate · 2½ hours · Requires F1, B1.

**Objective.** Choose decoding settings, define structured output and score semantic errors.

Generation repeatedly selects another token until a stop condition or limit. Temperature rescales logits before sampling. Top-p sampling restricts candidates to a cumulative probability mass. Lower randomness can improve repeatability, but cannot guarantee truth. A context window limits the combined input and generated sequence according to the model's contract.

Write instructions with a task, allowed evidence, output schema and an explicit insufficient-evidence behavior. A model API can enforce JSON syntax or supported schema constraints. Validate with Pydantic, then verify source IDs, permissions and whether the claim follows from the text. In tool calling the model proposes a function name and arguments; the application validates, executes, and feeds back a result.

```python
from pydantic import BaseModel, ConfigDict

class Answer(BaseModel):
    model_config = ConfigDict(extra="forbid")
    answer: str
    source_ids: list[str]

def validate_sources(result: Answer, permitted: set[str]):
    return set(result.source_ids) <= permitted

assert not validate_sources(Answer(answer="See policy", source_ids=["x"]), {"a"})
```

**Common failure and working practice.** Every cited ID can be valid while the answer is wrong. Score answer support separately. Keep evaluation questions outside prompt-tuning examples and version the prompts.

**Exercise.** Compare two prompts on ten answerable and five unanswerable questions. Record source validity, correctness and abstention separately.

**Build and check.** Publish a small error table with expected answer, actual answer, source and repair category. Show a syntactically valid answer rejected for incorrect evidence.

**Interview rehearsal.** When does lowering temperature help? It can reduce variation. Missing or contradictory source data still needs retrieval, abstention or escalation.

## F3 · Choose a model and serve it under a budget

Intermediate · 2 hours · Requires F2 and B3.

**Objective.** Compare hosted and local inference, adaptation, cost and time to first output.

A hosted API trades operations effort for provider dependency and metered use. A local open-weight model gives you control over execution; verify its license and resource needs. Ollama can serve a downloaded model locally. Quantization represents weights at lower precision to reduce memory; quality and speed depend on hardware and kernels. Fine-tuning changes model behavior using examples. PEFT updates a small subset of parameters; LoRA learns low-rank updates to selected weights.

For changing policy facts, update the knowledge base and test retrieval first. Consider adapters when you have licensed training examples, stable behavior goals and a held-out evaluation. A streaming endpoint sends incremental chunks. Measure time to first token, time to last token and cancellation behavior. A rendered word-by-word animation alone says nothing about upstream streaming.

```bash
# With Ollama installed locally and a permitted model downloaded:
ollama list
# Replace YOUR_MODEL with an installed model tag.
curl http://localhost:11434/api/generate -d '{"model":"YOUR_MODEL","prompt":"Return one short sentence about indexing.","stream":false}'
```

**Common failure and working practice.** Never choose a model on a single attractive answer. Include cost of retries, embedding and reranking. Budget example using invented rates: 2,000 input tokens at $1/million plus 200 output at $4/million costs $0.0028 per call before retries.

**Exercise.** Run the same prompts against two options. Record model ID, quantization if applicable, hardware, tokens, p50 and p95. Repeat with a shorter prompt.

**Build and check.** Create a model decision record showing quality, latency, cost per successful task and a fallback when the provider times out.

**Interview rehearsal.** Why can quantization hurt an application? Reduced numerical precision can change outputs. Test the exact quantized build on your own cases before switching.

## Module exit and revision

Draw tokenization through decoding, implement a schema validator, score one unsupported answer and choose between two model configurations using measured results.

**Further reading** · [Attention Is All You Need, 2017](https://arxiv.org/abs/1706.03762) · [Hugging Face generation](https://huggingface.co/docs/transformers/en/main_classes/text_generation) · [PEFT](https://huggingface.co/docs/transformers/en/peft) · [Ollama API](https://docs.ollama.com/api/introduction)

