# Résumé, LinkedIn, GitHub and portfolio

## A one-page résumé you can customize

Use a single column, standard headings, selectable text, and month/year dates. Put your strongest relevant work in the top half. Copy the PDF text into a plain-text editor and verify reading order, punctuation, links and contact information. ATS alignment means using vocabulary you can demonstrate. A keyword repeated five times still has to survive an interview.

```text
[Name] · Ahmedabad, India · [email] · [phone] · [GitHub] · [LinkedIn]
Programmer Analyst | Python backend and AI applications
[One sentence about verified contribution and the role you seek.]

EXPERIENCE
Meditab Private Limited — Programmer Analyst | Ahmedabad | [MM YYYY]–present
• Contributed to [verified feature] in a support assistant; implemented [specific behavior]
  and verified it using [test/review]. Collaborated with [role] on [boundary].
• Investigated [observable problem] by [action]; confirmed [verifiable result].

SELECTED PROJECTS
[Public-safe P1 title] | Python, FastAPI, Qdrant | [repository/demo]
• [Problem, your implementation, evaluation set, measured result and limitation.]
[Public-safe P2 or P3 title] | [demonstrated stack] | [repository/demo]
• [One decision and a reproducible failure/recovery test.]

SKILLS
Languages: [independently used]   Backend/data: [demonstrated tools]
AI applications: [retrieval/evaluation tasks]   Delivery: [tested/deployed tools]

EDUCATION
[Exact degree], Computer Engineering — VGEC, Gujarat Technological University
[Graduation month/year; include verified academic details only when relevant.]
```

Use “implemented the [verified] UI behavior and traced its API response” if that matches your work. Use “worked with the team on” when the decision was shared. A personal project is its own entry. Report denominators: “retrieved an expected page for 18 of 25 held-out questions on fixture v2” is meaningful **only if that is your recorded result**. For latency include hardware, load, model mode, sample size and percentile. For private employer work, describe approved behavior without publishing code, screenshots or customer details.

## LinkedIn profile copy

**Headline today:** “Programmer Analyst at Meditab | Python and AI application development | RAG and API integration.” Remove any phrase you cannot explain. **After P1 ships:** “Python Backend Engineer | FastAPI, PostgreSQL and evaluated RAG applications | Programmer Analyst at Meditab.” Keep your official designation in Experience.

**About:** “I’m a Programmer Analyst in Ahmedabad with a Computer Engineering background from VGEC. My work has introduced me to document-based support applications, including [verified contribution]. I’m developing deeper Python backend skills through [public project]. In that project I can show [test, design choice or evaluation]. I’m interested in early-career backend and applied AI roles in India and remote teams that hire in India. [Demo or repository].”

**Experience:** Start with the user problem, then describe your own assignment and evidence. Use three short lines: “Our team supports [approved scope]. I worked on [specific feature]. I verified [behavior] with [method].” List a finished portfolio demo under Featured. Ask a colleague for a recommendation referring to one actual collaboration.

## Make GitHub and the website useful to a hiring engineer

Pin P1 first, P3 for backend roles and P2 for workflow roles. Each README needs a two-minute path to the result, a screenshot from synthetic data, one architecture diagram, prerequisites, sample requests, a failing test case, evaluation method, measurements, limitations and attribution. Include an example configuration with dummy values. Make the repository understandable to someone who cannot access your employer's systems.

A one-page portfolio can use four sections: **About**, **Projects**, **Engineering notes**, **Contact**. Each project card links directly to a working example or evaluation. State when an on-demand demo is offline and give a short recording as an alternative. An elaborate website has lower priority than a reproducible repository.

**Before submitting.** Match role title and location, check dates and verbs against your evidence ledger, remove unused skill claims, open every public link in a signed-out browser, and ensure the PDF fits one page. Ask a peer to identify your strongest contribution after a 30-second scan.

