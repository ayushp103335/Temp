# A · Programming and computer science foundations

Start with a program small enough to execute on paper. A support-document importer is a useful example because bad input, repeated names and network failures are easy to reproduce.

## A1 · Trace a program, then give it a contract

Beginner · 2 hours · Requires a Python interpreter.

**Objective.** Predict the value of each variable and identify which object a function changes.

A program is a sequence of instructions. CPython parses source, compiles it to bytecode and executes that bytecode. A variable is a name bound to an object. Numbers, strings, lists and dictionaries support different operations. An if selects a branch, a loop repeats work and a function names a reusable operation.

A list preserves order and permits duplicates. A dictionary maps a hashable key to one value. A set remembers membership. Assignment can bind two names to the same mutable list. A function receives references to objects; rebinding its local name and mutating the shared object have different effects. Trace the dictionary after each title. Each input character is examined during stripping and case folding.

```python
def count_titles(titles):
    counts = {}
    for title in titles:
        key = title.strip().casefold()
        if key:
            counts[key] = counts.get(key, 0) + 1
    return counts

assert count_titles([" Guide ", "", "GUIDE"]) == {"guide": 2}
a = ["Guide"]
b = a
b.append("Policy")
assert len(a) == 2
```

**Common failure and working practice.** Using a list to check every previously seen title costs a growing scan. Define the key normalization rule before optimizing; case folding may merge titles that must remain distinct.

**Exercise.** Trace an empty input, a whitespace-only title and two equal titles. Change the code to preserve the first spelling. Compare time and extra memory as distinct titles grow.

**Build and check.** Build an importer summary. Check output by hand for four rows, show one input it rejects and explain O(total characters) expected work and O(distinct key storage).

**Interview rehearsal.** Why does changing b change a? Both names refer to one list. A shallow copy would separate the outer list while retaining references to nested objects.

## A2 · Model behavior, handle failures and ship a change

Beginner · 2 hours · Requires A1.

**Objective.** Choose a function or object, handle a specific error, and submit a small reviewed change.

A class groups data with behavior; an object is one instance. Encapsulation keeps decisions such as file encoding inside the component that owns them. Abstraction gives the caller a small contract. Polymorphism lets two implementations satisfy it. Inheritance can share implementation, but a caller can also accept anything with a matching method.

For a parser, use a common read operation for text or another source. A module is a Python file; a package groups importable modules. The OS runs a process with its own address space, schedules threads, and tracks open files and sockets. A crash can discard process memory. Commit durable data explicitly.

```python
from pathlib import Path

class TextSource:
    def read(self, path):
        return Path(path).read_text(encoding="utf-8")

class TrimmedSource(TextSource):
    def read(self, path):
        return super().read(path).strip()

def load(source, path):
    try:
        return source.read(path)
    except FileNotFoundError as exc:
        raise ValueError("Document is missing") from exc
```

**Common failure and working practice.** Catching every exception hides programming errors. Separate expected missing input from a permission failure. In Git, branch, make one focused change, run tests, inspect git diff, commit and open a pull request on GitHub.

**Exercise.** Implement an in-memory source, pass it to load and test without touching disk. Predict what happens for a file your process cannot read.

**Build and check.** Put the parser into a package, add one test, and write a PR description with the requested behavior and the observed output.

**Interview rehearsal.** When would you avoid inheritance? If two parsers share a contract but little implementation, pass a parser object or function instead of forcing a class hierarchy.

## A3 · Follow one request across a network

Beginner · 90 minutes · Requires A1.

**Objective.** Explain a browser request and distinguish connection, protocol and application failures.

When you open an HTTPS URL the client obtains an IP address, often by querying DNS. IP routes packets to a host. For HTTP/1.1 or HTTP/2 over TCP, TCP offers an ordered byte stream and TLS authenticates the server and encrypts traffic. HTTP/3 uses QUIC over UDP. HTTP specifies methods, headers, a body and a response status.

Imagine GET /documents/42. DNS can fail before a request reaches the server. A completed TLS handshake still leaves the application to authenticate the user and authorize access to document 42. A 404 is an application/proxy response; a timeout gives less information. Inspect a request ID across layers.

```bash
curl -i http://127.0.0.1:8000/docs
```

**Common failure and working practice.** Opening a port or getting a 200 from a health endpoint does not prove a user can search. Log status and timing by route without logging private payloads.

**Exercise.** Start the local API in E1, call /docs and a missing path, stop it and repeat. Describe the three outcomes.

**Build and check.** Draw the path browser → resolver → gateway → API → data store. Mark who decides access and where a retry might duplicate work.

**Interview rehearsal.** Why can a server return 403 over HTTPS? TLS protects the connection. The application can still deny the requested operation.

## Module exit and revision

Close the guide. Implement the counting function, explain an alias, recover from a missing file, and distinguish a refused connection from an HTTP response. Revisit the part you could only recite.

**Further reading** · [Python tutorial](https://docs.python.org/3/tutorial/) · [Pro Git](https://git-scm.com/book/en/v2) · [HTTP semantics, RFC 9110](https://www.rfc-editor.org/rfc/rfc9110)


**Optional review.** Your earlier System Design study notes include “Follow One Request: Browser to Database and Back” and “Capacity Planning and Back-of-the-Envelope Math.” A3 and I1 cover the specific pieces needed for this switch.
