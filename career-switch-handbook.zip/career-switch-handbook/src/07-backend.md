# E · Design and operate FastAPI services

Follow one request from the HTTP boundary through validation, permissions and storage. The first service is deliberately local. The portfolio versions add persistence, identity and deployment.

## E1 · Define an HTTP contract and test it

Beginner · 2 hours · Requires B1 and A3.

**Objective.** Build a typed endpoint, start the server and exercise success and failure.

A route maps an HTTP method and path to a function. POST creates a resource or triggers work, GET reads, PUT replaces, PATCH changes part and DELETE removes. Idempotency means repeating the request has the same intended effect. A 201 means creation completed; 202 means accepted for future processing.

Use Pydantic request and response types. Dependency injection gives handlers explicit dependencies such as a repository or principal so tests can replace them. Save the code in app.py, install fastapi, uvicorn, pydantic, pytest and httpx, and run python -m uvicorn app:app. Explore /docs locally.

```python
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI()

class CountRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)

class CountResult(BaseModel):
    words: int

@app.post("/v1/count", response_model=CountResult)
def count_words(request: CountRequest):
    return CountResult(words=len(request.text.split()))
```

```python
from fastapi.testclient import TestClient
from app import app

def test_count():
    client = TestClient(app)
    assert client.post("/v1/count", json={"text": "two words"}).json() == {"words": 2}
    assert client.post("/v1/count", json={"text": ""}).status_code == 422
```

**Common failure and working practice.** Whitespace-only text passes the shown schema. Decide whether zero words is valid; test that choice. A permissive response model can leak internal fields.

**Exercise.** Call the endpoint with valid text, no field and a 4,001-character value. Check status and payload in each case.

**Build and check.** Create a versioned POST endpoint plus tests, document its limits in OpenAPI and explain why this calculation returns 200.

**Interview rehearsal.** What should a client do on 422? Repair its request. Repeating an identical invalid input wastes capacity.

## E2 · Authenticate the caller and authorize each object

Intermediate · 2½ hours · Requires E1 and D1.

**Objective.** Separate identity, permission, and tenant isolation in the database query.

Authentication establishes who is calling. Authorization decides whether this caller may act on this object now. OAuth delegates access using tokens; OpenID Connect adds identity. A signed JWT contains claims the receiver must verify. Payloads are normally readable. Prefer an established identity provider and maintained verifier.

For a browser, use the provider's authorization-code flow with PKCE as appropriate. The API validates signature using trusted keys and configured algorithms, issuer, audience and time claims. Map subject to server-controlled tenant membership and roles. A FastAPI Depends dependency returns that principal. A repository query uses both document ID and authorized tenant ID.

```sql
-- psycopg placeholders; bind both values as parameters.
SELECT id,title FROM document WHERE tenant_id=%s AND id=%s;
```

**Common failure and working practice.** A tenant supplied in a request body is input, not proof. Route permissions must also cover list, download, retrieved chunks and cache entries. Use 401 for missing or invalid credentials; choose a consistent disclosure policy for forbidden objects.

**Exercise.** Test anonymous, expired-token, wrong-audience, allowed-user and valid-user/wrong-tenant cases. Make synthetic tenants contain similar document IDs.

**Build and check.** Add a principal dependency backed by a provider verifier; override the dependency in unit tests and run at least one provider-integrated test separately.

**Interview rehearsal.** Why verify audience? A valid issuer can issue tokens for different recipients; this API should only accept credentials meant for it.

## E3 · Accept files, schedule durable work and keep requests bounded

Intermediate · 3 hours · Requires E2, B3 and D2.

**Objective.** Design upload, status and list APIs that remain correct under retry and overload.

Large PDF parsing can outlive the request. Stream the upload into private object storage with a size cap, verify content and record checksum. Commit a job and an outbox message in one database transaction. A dispatcher publishes committed messages and a worker processes them. A retrying client supplies an idempotency key scoped to tenant and operation.

Store a request hash with the key: an identical retry returns the existing job, different input with the same key receives 409. Return 202 plus a status URL only after durable acceptance. Small process-local BackgroundTasks suit incidental tasks; durable indexing needs a persistent queue. Cursor pagination orders by (created_at,id). Middleware supplies request IDs, measures time and maps expected exceptions to stable public errors.

```text
POST /v1/uploads         → 201 {document_id, version}
POST /v1/index-jobs      → 202 {job_id, status_url}
GET  /v1/index-jobs/{id} → 200 {state, error_code}
GET  /v1/documents?after=<opaque-cursor>&limit=20
```

**Common failure and working practice.** Synchronous parsing in an async handler blocks unrelated requests. Cap file size, per-tenant quota, pool connections, retries and worker concurrency. Use 429 with retry guidance for quota and 503 for transient service unavailability.

**Exercise.** Kill a worker after parsing and before acknowledgement; retry and inspect the document count. Test a stale cursor, too-large input and unauthorized download.

**Build and check.** Deploy the job API behind TLS, measure p50/p95 and error rate with concurrent synthetic clients, and record the first bottleneck. Demonstrate structured logs without file contents.

**Interview rehearsal.** How do you stop duplicate jobs after the client times out? Persist the unique idempotency key and payload hash atomically with the job; handle a conflict by returning the original result for identical input.

## E4 · Persist a job with FastAPI and PostgreSQL

**Intermediate · 2½ hours · Prerequisites D2 and E1–E3.** Implement a write that can safely be repeated after a client timeout. This vertical slice shows where database uniqueness belongs and how FastAPI obtains a connection. It provides a local teaching identity and a job record. Add the outbox and worker from E3 as the implementation assignment.

In a disposable PostgreSQL database create the following table once. A unique pair scopes each idempotency key to its tenant. Without the constraint, two concurrent transactions can both decide the key is unused.

```sql
CREATE TABLE index_request (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id text NOT NULL,
    request_key text NOT NULL,
    payload_hash text NOT NULL,
    doc_ref text NOT NULL,
    state text NOT NULL DEFAULT 'queued',
    UNIQUE (tenant_id, request_key)
);
```

Install FastAPI, uvicorn, Pydantic 2 and psycopg 3 with its pool and applicable PostgreSQL client implementation (for local practice, `python -m pip install 'psycopg[binary,pool]'`). Set DATABASE_URL to a local connection string through your shell. Place the following code in jobs.py. Use the SQL above as the first migration. Start with `python -m uvicorn jobs:app --host 127.0.0.1`. Replace the demo identity with the verified principal from E2 before deployment.

```python
from contextlib import asynccontextmanager
from hashlib import sha256
import os
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from psycopg_pool import ConnectionPool

@asynccontextmanager
async def lifespan(application):
    pool = ConnectionPool(os.environ["DATABASE_URL"], min_size=1, max_size=4,
                          open=False, timeout=3)
    pool.open(wait=True, timeout=10)
    application.state.pool = pool
    try:
        yield
    finally:
        pool.close()

app = FastAPI(lifespan=lifespan)

class IndexRequest(BaseModel):
    doc_ref: str = Field(min_length=1, max_length=100)

def demo_principal(x_demo_user: str = Header(...)):
    if x_demo_user != "alice":
        raise HTTPException(403, "Unknown demo user")
    return "blue"

@app.post("/v1/jobs", status_code=202)
def submit(body: IndexRequest, tenant: str = Depends(demo_principal),
           idempotency_key: str = Header(min_length=1, max_length=100)):
    # doc_ref is the entire input contract of this example.
    digest = sha256(body.doc_ref.encode("utf-8")).hexdigest()
    with app.state.pool.connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute("""
                INSERT INTO index_request(tenant_id, request_key, payload_hash, doc_ref)
                VALUES (%s,%s,%s,%s)
                ON CONFLICT (tenant_id, request_key) DO NOTHING
                RETURNING id,state
            """, (tenant,idempotency_key,digest,body.doc_ref))
            row = cursor.fetchone()
            if row is None:
                cursor.execute("""
                    SELECT id,state,payload_hash FROM index_request
                    WHERE tenant_id=%s AND request_key=%s
                """, (tenant,idempotency_key))
                saved = cursor.fetchone()
                if saved is None:
                    raise HTTPException(503, "Retry the request")
                if saved[2] != digest:
                    raise HTTPException(409, "Key already used for different content")
                row = saved[:2]
    return {"job_id":row[0], "state":row[1]}
```

The route is synchronous because it uses a synchronous driver. The connection context commits on success and rolls back on failure. Under PostgreSQL's default Read Committed, the second statement can see a competing transaction that won the insert. Preserve key records for the full advertised retry window. If you change isolation levels, handle serialization errors by retrying the entire transaction. Add a test for pool exhaustion and map a transient timeout to a retryable service response.

**Exercise.** POST the same doc_ref twice with headers x-demo-user: alice and Idempotency-Key: example-1. Predict one database row and the same job ID. Then change doc_ref while reusing the key and expect 409. Use two concurrent clients for the race test. The lab expects a synthetic reference; a real service also verifies that the referenced document is authorized.

**Build and check.** Add an authorized status endpoint and one outbox row on the insert-winning branch in the same transaction. Terminate the dispatcher between publish and marking delivered. Show why a duplicate delivery cannot duplicate the worker's external effect. **Interview rehearsal.** Why does the unique constraint earn its place even when the UI disables its submit button? Multiple requests and retries can reach the service independently of that UI. [Psycopg pool](https://www.psycopg.org/psycopg3/docs/advanced/pool.html) · [PostgreSQL INSERT](https://www.postgresql.org/docs/current/sql-insert.html)

## Module exit and revision

From a clean environment start a service, reject malformed input, isolate tenants, recover a failed job and explain the status contract. Show an integration test with PostgreSQL and a running deployment.

**Further reading** · [FastAPI tutorial](https://fastapi.tiangolo.com/tutorial/) · [Background tasks](https://fastapi.tiangolo.com/tutorial/background-tasks/) · [OAuth security best current practice, RFC 9700](https://www.rfc-editor.org/rfc/rfc9700) · [OWASP authorization guidance](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)

