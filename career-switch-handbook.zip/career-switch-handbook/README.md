# The Career Switch Handbook

Start by opening **offline/index.html** in a browser. The Start here group includes the reading guide, 24-week plan and first-week workbench. Each week's row identifies the required lesson, practice, project evidence and application target. Use the module exit tests and weekly tracker to decide when to move on.

## Contents

- `book.toml` and `src/SUMMARY.md` define a single mdBook. All 28 chapters are in `src/`.
- `src/assets/` contains offline-renderable architecture diagrams. Editable Mermaid originals are in `diagrams/`.
- `labs/` contains the synthetic FastAPI/Qdrant/Ollama example, Compose configuration and an offline API boundary test.
- `offline/index.html` is the compiled standalone HTML edition with local chapter notes, Markdown export and print styles. It requires no server or remote assets. Documentation content and source URLs work without JavaScript; notes and mobile navigation use JavaScript.
- For PDF and standalone HTML copies, use the supplied companion downloads. They render the same book.

## Build or edit

Install the [official mdBook CLI](https://rust-lang.github.io/mdBook/guide/installation.html). From this directory run `mdbook build`, then open `book/index.html`, or use `mdbook serve --open`. A GitHub Actions workflow includes the native build command with mdBook 0.5.4. Running this workflow requires placing the project in a repository and enabling Actions.

To regenerate the supplied single-file edition after edits, install Pandoc and Python 3.11+, then run `python tools/build_reader.py`. Use the same Markdown and same SUMMARY order. This portable build was executed and checked. The native mdBook executable was unavailable in the authoring environment and its native build is unverified.

## Lab checks

From `labs/`, install the declared dependencies and run `python check_rag.py`. This exercises the real FastAPI routes with fixture model/vector responses. The practical lab chapter contains the complete live Qdrant and Ollama setup; it needs local services and model files. Neither live model output nor cloud deployment is represented as a completed personal project.

## Evidence and privacy

Market research cutoff: 19 November 2026. Publication dates are shown where available. Reopen employer links before applying. Exact employment dates, project ownership and public-safe evidence are for the reader to confirm. Never commit private tracker notes, credentials or employer data to a public project.

