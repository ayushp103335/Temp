"""Run offline boundary checks with HTTP dependencies replaced by local fixtures."""
from unittest.mock import patch
from fastapi.testclient import TestClient
import rag_app

client = TestClient(rag_app.app)
calls = []
def fixture(method, url, **kwargs):
    if url.endswith("/api/embed"):
        return {"embeddings": [[0.1,0.2]]}
    if url.endswith("/points/query"):
        params = kwargs["json"]
        tenant = params["filter"]["must"][0]["match"]["value"]
        assert params["filter"]["must"][0]["key"] == "tenant"
        assert params["with_payload"] is True
        calls.append(tenant)
        doc = {"blue": "B1", "gold": "G1"}[tenant]
        return {"result": {"points": [{"payload": {"doc":doc,"page":1,"text":"Synthetic policy"}}]}}
    if url.endswith("/api/generate"):
        return {"response": '{"answer":"A draft","citations":["G1"]}'}
    raise AssertionError("unexpected request")

question = {"question":"How do I unlock the sandbox?"}
with patch.object(rag_app, "request", fixture):
    for user, doc in [("alice","B1"),("bob","G1")]:
        result = client.post("/v1/search",json=question,headers={"x-demo-user":user})
        assert result.status_code == 200 and result.json()["passages"][0]["doc"] == doc
    assert calls == ["blue","gold"]
    assert client.post("/v1/search",json=question,headers={"x-demo-user":"unknown"}).status_code == 403
    assert client.post("/v1/search",json={"question":""},headers={"x-demo-user":"alice"}).status_code == 422
    with patch.object(rag_app, "GEN_MODEL", "fixture"):
        assert client.post("/v1/answer",json=question,headers={"x-demo-user":"alice"}).json()["status"] == "insufficient_evidence"
        assert client.post("/v1/answer",json=question,headers={"x-demo-user":"bob"}).json()["status"] == "draft"
print("Passed API contract, tenant-filter construction and citation-allowlist checks with fixture dependencies.")

