const menu=document.querySelector('#menu');
const sidebar=document.querySelector('#sidebar');
menu.addEventListener('click',()=>{const open=sidebar.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});
sidebar.addEventListener('click',event=>{if(event.target.closest('a')){sidebar.classList.remove('open');menu.setAttribute('aria-expanded','false');}});
const toc=document.querySelector('.contents');
document.querySelector('#print').addEventListener('click',()=>{toc.open=true;window.print();});
window.addEventListener('beforeprint',()=>{toc.open=true;});
const notes=[...document.querySelectorAll('textarea[data-key]')];
function ident(field){return 'career-handbook-v1/'+field.dataset.key;}
for(const field of notes){
 const status=field.nextElementSibling;
 try{field.value=localStorage.getItem(ident(field))||'';}catch{status.textContent='Local saving unavailable. Export notes before closing.';}
 field.addEventListener('input',()=>{try{localStorage.setItem(ident(field),field.value);status.textContent='Saved in this browser.';}catch{status.textContent='Local saving unavailable. Export notes before closing.';}});
}
document.querySelector('#export').addEventListener('click',()=>{
 const body=notes.filter(n=>n.value.trim()).map(n=>'## '+n.closest('article').querySelector('h1').innerText+'\n\n'+n.value).join('\n\n');
 const link=document.createElement('a');link.href=URL.createObjectURL(new Blob(['# Career switch notes\n\n'+body],{type:'text/markdown'}));link.download='career-switch-notes.md';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),2000);
});
const links=new Map([...sidebar.querySelectorAll('nav a')].map(a=>[a.hash.slice(1),a]));
const observer=new IntersectionObserver(entries=>{for(const row of entries){if(row.isIntersecting){links.forEach(a=>a.classList.remove('active'));links.get(row.target.id)?.classList.add('active');}}},{rootMargin:'0% 0% -75% 0%'});
document.querySelectorAll('article').forEach(a=>observer.observe(a));
