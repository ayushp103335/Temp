"""Build a portable HTML reader from the mdBook SUMMARY, using Pandoc."""
from pathlib import Path
from html import escape
import base64
import re
import subprocess

root = Path(__file__).resolve().parents[1]
src = root / "src"
nav, chapters, print_nav = [], [], []
group = ""
for line in (src / "SUMMARY.md").read_text().splitlines():
    if line.startswith("# ") and line != "# Summary":
        group = line[2:]
        nav.append('<h2>'+escape(group)+'</h2>')
        print_nav.append('<h3>'+escape(group)+'</h3>')
    match = re.fullmatch(r"- \[(.+)\]\((.+\.md)\)", line)
    if not match:
        continue
    title, name = match.groups()
    key = Path(name).stem
    idx = len(chapters)+1
    page = (src / name).read_text()
    body = subprocess.run(["pandoc","--from=gfm","--to=html5","--no-highlight","--wrap=none","--id-prefix",key+"-"],input=page,text=True,capture_output=True,check=True).stdout
    def embed(m):
        svg = (src / m[1]).read_bytes()
        return 'src="data:image/svg+xml;base64,'+base64.b64encode(svg).decode()+'"'
    body = re.sub(r'src="(assets/[^"]+\.svg)"',embed,body)
    body = re.sub(r'<table>.*?</table>',lambda m:'<div class="tablebox">'+m[0]+'</div>',body,flags=re.S)
    nav.append(f'<a href="#{key}">{escape(title)}</a>')
    print_nav.append(f'<div><a href="#{key}">{idx:02d} &nbsp; {escape(title)}</a></div>')
    notes=f'<details class="notes"><summary>Private notes</summary><label for="note-{key}">Evidence, questions or tracker entries for this chapter</label><textarea id="note-{key}" data-key="{key}" rows="5"></textarea><small class="save-status" aria-live="polite"></small></details>'
    chapters.append(f'<article id="{key}"><div class="section-label">{escape(group)} &nbsp; / &nbsp; {idx:02d}</div>{body}{notes}<a class="back" href="#top">Back to contents ↑</a></article>')
style=(root/'tools/reader.css').read_text()
script=(root/'tools/reader.js').read_text()
cover='''<header class="cover" id="top"><div class="edition">ENGINEERING CAREERS &nbsp; / &nbsp; NOVEMBER 2026</div><h1>The Career Switch<br>Handbook</h1><p class="deck">From Programmer Analyst to Python backend and applied AI engineering.</p><div class="rule"></div><p class="meta">India and international remote &nbsp; · &nbsp; 24 weeks &nbsp; · &nbsp; 3 portfolio builds</p></header>'''
controls='<div class="navcontrols"><button id="export">Export my notes</button><button id="print">Print</button></div>'
contents='<details class="contents"><summary>Table of contents</summary>'+''.join(print_nav)+'</details>'
page='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>The Career Switch Handbook</title><style>'+style+'</style></head><body><a class="skip" href="#top">Skip to book</a><button id="menu" aria-expanded="false" aria-controls="sidebar">Contents</button><aside id="sidebar"><p class="brand">Career Switch Handbook</p><nav>'+''.join(nav)+'</nav>'+controls+'</aside><main>'+cover+contents+''.join(chapters)+'</main><script>'+script+'</script></body></html>'
out=root/'offline'
out.mkdir(exist_ok=True)
(out/'index.html').write_text(page)

